#!/bin/bash 
cd /workspace/finn/tmp/finn_user-bibo/code_gen_ipgen_StreamingFCLayer_Batch_bss15lga
vivado_hls /workspace/finn/tmp/finn_user-bibo/code_gen_ipgen_StreamingFCLayer_Batch_bss15lga/hls_syn_StreamingFCLayer_Batch_2.tcl
cd /workspace/finn
