#include "StreamingFCLayer_Batch_2_Matrix_Vector_Activa.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_ap_clk_no_reset_() {
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_CS_fsm = ap_ST_fsm_state1;
    } else {
        ap_CS_fsm = ap_NS_fsm.read();
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_enable_reg_pp0_iter0 = ap_const_logic_0;
    } else {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage0_subdone.read(), ap_const_boolean_0) && 
             esl_seteq<1,1,1>(ap_const_logic_1, ap_condition_pp0_exit_iter0_state2.read()))) {
            ap_enable_reg_pp0_iter0 = ap_const_logic_0;
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
                    esl_seteq<1,1,1>(ap_start.read(), ap_const_logic_1))) {
            ap_enable_reg_pp0_iter0 = ap_const_logic_1;
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_enable_reg_pp0_iter1 = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_block_pp0_stage0_subdone.read(), ap_const_boolean_0)) {
            if (esl_seteq<1,1,1>(ap_const_logic_1, ap_condition_pp0_exit_iter0_state2.read())) {
                ap_enable_reg_pp0_iter1 = (ap_condition_pp0_exit_iter0_state2.read() ^ ap_const_logic_1);
            } else if (esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1)) {
                ap_enable_reg_pp0_iter1 = ap_enable_reg_pp0_iter0.read();
            }
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_enable_reg_pp0_iter2 = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_block_pp0_stage0_subdone.read(), ap_const_boolean_0)) {
            ap_enable_reg_pp0_iter2 = ap_enable_reg_pp0_iter1.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
                    esl_seteq<1,1,1>(ap_start.read(), ap_const_logic_1))) {
            ap_enable_reg_pp0_iter2 = ap_const_logic_0;
        }
    }
    if (esl_seteq<1,1,1>(ap_condition_198.read(), ap_const_boolean_1)) {
        if ((esl_seteq<1,1,1>(exitcond_fu_492_p2.read(), ap_const_lv1_0) && 
             esl_seteq<1,1,1>(ap_const_lv1_0, tmp_fu_507_p2.read()))) {
            ap_phi_reg_pp0_iter1_act_m_val_V_reg_468 = inElem_V_fu_532_p6.read();
        } else if ((esl_seteq<1,1,1>(exitcond_fu_492_p2.read(), ap_const_lv1_0) && 
                    esl_seteq<1,1,1>(tmp_fu_507_p2.read(), ap_const_lv1_1))) {
            ap_phi_reg_pp0_iter1_act_m_val_V_reg_468 = in_V_V_TDATA.read();
        } else if (esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1)) {
            ap_phi_reg_pp0_iter1_act_m_val_V_reg_468 = ap_phi_reg_pp0_iter0_act_m_val_V_reg_468.read();
        }
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(exitcond_fu_492_p2.read(), ap_const_lv1_0) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        i_reg_457 = i_1_fu_498_p2.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
                esl_seteq<1,1,1>(ap_start.read(), ap_const_logic_1))) {
        i_reg_457 = ap_const_lv5_0;
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(exitcond_fu_492_p2.read(), ap_const_lv1_0) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_lv1_1, tmp_s_fu_694_p2.read()))) {
        nf_assign_fu_216 = p_s_fu_729_p3.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
                esl_seteq<1,1,1>(ap_start.read(), ap_const_logic_1))) {
        nf_assign_fu_216 = ap_const_lv32_0;
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(exitcond_fu_492_p2.read(), ap_const_lv1_0) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, tmp_s_fu_694_p2.read()))) {
        sf_fu_212 = sf_1_fu_688_p2.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
                 esl_seteq<1,1,1>(ap_start.read(), ap_const_logic_1)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(exitcond_fu_492_p2.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
                 esl_seteq<1,1,1>(ap_const_lv1_1, tmp_s_fu_694_p2.read())))) {
        sf_fu_212 = ap_const_lv32_0;
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(exitcond_fu_492_p2.read(), ap_const_lv1_0) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_lv1_1, tmp_s_fu_694_p2.read()))) {
        tile_assign_fu_208 = p_1_fu_737_p3.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(exitcond_fu_492_p2.read(), ap_const_lv1_0) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, tmp_s_fu_694_p2.read()))) {
        tile_assign_fu_208 = tile_fu_682_p2.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
                esl_seteq<1,1,1>(ap_start.read(), ap_const_logic_1))) {
        tile_assign_fu_208 = ap_const_lv32_0;
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        accu_V_10_fu_184 = accu_10_V_fu_9015_p2.read();
        accu_V_11_fu_188 = accu_11_V_fu_9077_p2.read();
        accu_V_12_fu_192 = accu_12_V_fu_9139_p2.read();
        accu_V_13_fu_196 = accu_13_V_fu_9201_p2.read();
        accu_V_14_fu_200 = accu_14_V_fu_9263_p2.read();
        accu_V_1_fu_148 = accu_1_V_fu_8457_p2.read();
        accu_V_2_fu_152 = accu_2_V_fu_8519_p2.read();
        accu_V_3_fu_156 = accu_3_V_fu_8581_p2.read();
        accu_V_4_fu_160 = accu_4_V_fu_8643_p2.read();
        accu_V_5_fu_164 = accu_5_V_fu_8705_p2.read();
        accu_V_6_fu_168 = accu_6_V_fu_8767_p2.read();
        accu_V_7_fu_172 = accu_7_V_fu_8829_p2.read();
        accu_V_8_fu_176 = accu_8_V_fu_8891_p2.read();
        accu_V_9_fu_180 = accu_9_V_fu_8953_p2.read();
        accu_V_fu_144 = accu_0_V_fu_8395_p2.read();
        accu_V_s_fu_204 = accu_15_V_fu_9325_p2.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && esl_seteq<1,1,1>(exitcond_fu_492_p2.read(), ap_const_lv1_0) && esl_seteq<1,1,1>(tmp_fu_507_p2.read(), ap_const_lv1_1) && esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        inputBuf_3_V_2_fu_220 = inputBuf_3_V_7_fu_622_p3.read();
        inputBuf_3_V_3_fu_224 = inputBuf_3_V_5_fu_614_p3.read();
        inputBuf_3_V_6_fu_228 = inputBuf_3_V_1_fu_598_p3.read();
        inputBuf_3_V_8_fu_232 = inputBuf_3_V_fu_582_p3.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        tmp115_reg_10244 = tmp115_fu_2643_p2.read();
        tmp119_reg_10249 = tmp119_fu_2669_p2.read();
        tmp123_reg_10254 = tmp123_fu_2701_p2.read();
        tmp146_reg_10274 = tmp146_fu_3099_p2.read();
        tmp150_reg_10279 = tmp150_fu_3125_p2.read();
        tmp154_reg_10284 = tmp154_fu_3157_p2.read();
        tmp177_reg_10304 = tmp177_fu_3555_p2.read();
        tmp181_reg_10309 = tmp181_fu_3581_p2.read();
        tmp185_reg_10314 = tmp185_fu_3613_p2.read();
        tmp208_reg_10334 = tmp208_fu_4011_p2.read();
        tmp212_reg_10339 = tmp212_fu_4037_p2.read();
        tmp216_reg_10344 = tmp216_fu_4069_p2.read();
        tmp22_reg_10154 = tmp22_fu_1275_p2.read();
        tmp239_reg_10364 = tmp239_fu_4467_p2.read();
        tmp243_reg_10369 = tmp243_fu_4493_p2.read();
        tmp247_reg_10374 = tmp247_fu_4525_p2.read();
        tmp26_reg_10159 = tmp26_fu_1301_p2.read();
        tmp270_reg_10394 = tmp270_fu_4923_p2.read();
        tmp274_reg_10399 = tmp274_fu_4949_p2.read();
        tmp278_reg_10404 = tmp278_fu_4981_p2.read();
        tmp301_reg_10424 = tmp301_fu_5379_p2.read();
        tmp305_reg_10429 = tmp305_fu_5405_p2.read();
        tmp309_reg_10434 = tmp309_fu_5437_p2.read();
        tmp30_reg_10164 = tmp30_fu_1333_p2.read();
        tmp332_reg_10454 = tmp332_fu_5835_p2.read();
        tmp336_reg_10459 = tmp336_fu_5861_p2.read();
        tmp340_reg_10464 = tmp340_fu_5893_p2.read();
        tmp363_reg_10484 = tmp363_fu_6291_p2.read();
        tmp367_reg_10489 = tmp367_fu_6317_p2.read();
        tmp371_reg_10494 = tmp371_fu_6349_p2.read();
        tmp394_reg_10514 = tmp394_fu_6747_p2.read();
        tmp398_reg_10519 = tmp398_fu_6773_p2.read();
        tmp402_reg_10524 = tmp402_fu_6805_p2.read();
        tmp425_reg_10544 = tmp425_fu_7203_p2.read();
        tmp429_reg_10549 = tmp429_fu_7229_p2.read();
        tmp433_reg_10554 = tmp433_fu_7261_p2.read();
        tmp456_reg_10574 = tmp456_fu_7659_p2.read();
        tmp460_reg_10579 = tmp460_fu_7685_p2.read();
        tmp464_reg_10584 = tmp464_fu_7717_p2.read();
        tmp487_reg_10604 = tmp487_fu_8115_p2.read();
        tmp491_reg_10609 = tmp491_fu_8141_p2.read();
        tmp495_reg_10614 = tmp495_fu_8173_p2.read();
        tmp53_reg_10184 = tmp53_fu_1731_p2.read();
        tmp57_reg_10189 = tmp57_fu_1757_p2.read();
        tmp61_reg_10194 = tmp61_fu_1789_p2.read();
        tmp84_reg_10214 = tmp84_fu_2187_p2.read();
        tmp88_reg_10219 = tmp88_fu_2213_p2.read();
        tmp92_reg_10224 = tmp92_fu_2245_p2.read();
        tmp_12_0_11_reg_10139 = tmp_12_0_11_fu_1161_p2.read();
        tmp_12_0_12_reg_10144 = tmp_12_0_12_fu_1189_p2.read();
        tmp_12_0_13_reg_10149 = tmp_12_0_13_fu_1217_p2.read();
        tmp_12_10_11_reg_10439 = tmp_12_10_11_fu_5745_p2.read();
        tmp_12_10_12_reg_10444 = tmp_12_10_12_fu_5765_p2.read();
        tmp_12_10_13_reg_10449 = tmp_12_10_13_fu_5785_p2.read();
        tmp_12_11_11_reg_10469 = tmp_12_11_11_fu_6201_p2.read();
        tmp_12_11_12_reg_10474 = tmp_12_11_12_fu_6221_p2.read();
        tmp_12_11_13_reg_10479 = tmp_12_11_13_fu_6241_p2.read();
        tmp_12_12_11_reg_10499 = tmp_12_12_11_fu_6657_p2.read();
        tmp_12_12_12_reg_10504 = tmp_12_12_12_fu_6677_p2.read();
        tmp_12_12_13_reg_10509 = tmp_12_12_13_fu_6697_p2.read();
        tmp_12_13_11_reg_10529 = tmp_12_13_11_fu_7113_p2.read();
        tmp_12_13_12_reg_10534 = tmp_12_13_12_fu_7133_p2.read();
        tmp_12_13_13_reg_10539 = tmp_12_13_13_fu_7153_p2.read();
        tmp_12_14_11_reg_10559 = tmp_12_14_11_fu_7569_p2.read();
        tmp_12_14_12_reg_10564 = tmp_12_14_12_fu_7589_p2.read();
        tmp_12_14_13_reg_10569 = tmp_12_14_13_fu_7609_p2.read();
        tmp_12_15_11_reg_10589 = tmp_12_15_11_fu_8025_p2.read();
        tmp_12_15_12_reg_10594 = tmp_12_15_12_fu_8045_p2.read();
        tmp_12_15_13_reg_10599 = tmp_12_15_13_fu_8065_p2.read();
        tmp_12_1_11_reg_10169 = tmp_12_1_11_fu_1641_p2.read();
        tmp_12_1_12_reg_10174 = tmp_12_1_12_fu_1661_p2.read();
        tmp_12_1_13_reg_10179 = tmp_12_1_13_fu_1681_p2.read();
        tmp_12_2_11_reg_10199 = tmp_12_2_11_fu_2097_p2.read();
        tmp_12_2_12_reg_10204 = tmp_12_2_12_fu_2117_p2.read();
        tmp_12_2_13_reg_10209 = tmp_12_2_13_fu_2137_p2.read();
        tmp_12_3_11_reg_10229 = tmp_12_3_11_fu_2553_p2.read();
        tmp_12_3_12_reg_10234 = tmp_12_3_12_fu_2573_p2.read();
        tmp_12_3_13_reg_10239 = tmp_12_3_13_fu_2593_p2.read();
        tmp_12_4_11_reg_10259 = tmp_12_4_11_fu_3009_p2.read();
        tmp_12_4_12_reg_10264 = tmp_12_4_12_fu_3029_p2.read();
        tmp_12_4_13_reg_10269 = tmp_12_4_13_fu_3049_p2.read();
        tmp_12_5_11_reg_10289 = tmp_12_5_11_fu_3465_p2.read();
        tmp_12_5_12_reg_10294 = tmp_12_5_12_fu_3485_p2.read();
        tmp_12_5_13_reg_10299 = tmp_12_5_13_fu_3505_p2.read();
        tmp_12_6_11_reg_10319 = tmp_12_6_11_fu_3921_p2.read();
        tmp_12_6_12_reg_10324 = tmp_12_6_12_fu_3941_p2.read();
        tmp_12_6_13_reg_10329 = tmp_12_6_13_fu_3961_p2.read();
        tmp_12_7_11_reg_10349 = tmp_12_7_11_fu_4377_p2.read();
        tmp_12_7_12_reg_10354 = tmp_12_7_12_fu_4397_p2.read();
        tmp_12_7_13_reg_10359 = tmp_12_7_13_fu_4417_p2.read();
        tmp_12_8_11_reg_10379 = tmp_12_8_11_fu_4833_p2.read();
        tmp_12_8_12_reg_10384 = tmp_12_8_12_fu_4853_p2.read();
        tmp_12_8_13_reg_10389 = tmp_12_8_13_fu_4873_p2.read();
        tmp_12_9_11_reg_10409 = tmp_12_9_11_fu_5289_p2.read();
        tmp_12_9_12_reg_10414 = tmp_12_9_12_fu_5309_p2.read();
        tmp_12_9_13_reg_10419 = tmp_12_9_13_fu_5329_p2.read();
        tmp_497_reg_10119_pp0_iter1_reg = tmp_497_reg_10119.read();
        tmp_4_reg_10015_pp0_iter1_reg = tmp_4_reg_10015.read();
        tmp_s_reg_10115_pp0_iter1_reg = tmp_s_reg_10115.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && esl_seteq<1,1,1>(exitcond_fu_492_p2.read(), ap_const_lv1_0) && esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_lv1_1, tmp_s_fu_694_p2.read()))) {
        tmp_497_reg_10119 = tmp_497_fu_713_p1.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && esl_seteq<1,1,1>(exitcond_fu_492_p2.read(), ap_const_lv1_0) && esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        tmp_4_reg_10015 = tmp_4_fu_656_p2.read();
        tmp_s_reg_10115 = tmp_s_fu_694_p2.read();
    }
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_ap_NS_fsm() {
    switch (ap_CS_fsm.read().to_uint64()) {
        case 1 : 
            if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && esl_seteq<1,1,1>(ap_start.read(), ap_const_logic_1))) {
                ap_NS_fsm = ap_ST_fsm_pp0_stage0;
            } else {
                ap_NS_fsm = ap_ST_fsm_state1;
            }
            break;
        case 2 : 
            if ((!(esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage0_subdone.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_enable_reg_pp0_iter1.read(), ap_const_logic_0)) && !(esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage0_subdone.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(exitcond_fu_492_p2.read(), ap_const_lv1_1) && esl_seteq<1,1,1>(ap_enable_reg_pp0_iter1.read(), ap_const_logic_0)))) {
                ap_NS_fsm = ap_ST_fsm_pp0_stage0;
            } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage0_subdone.read(), ap_const_boolean_0) && 
  esl_seteq<1,1,1>(ap_enable_reg_pp0_iter1.read(), ap_const_logic_0)) || (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage0_subdone.read(), ap_const_boolean_0) && 
  esl_seteq<1,1,1>(exitcond_fu_492_p2.read(), ap_const_lv1_1) && 
  esl_seteq<1,1,1>(ap_enable_reg_pp0_iter1.read(), ap_const_logic_0)))) {
                ap_NS_fsm = ap_ST_fsm_state5;
            } else {
                ap_NS_fsm = ap_ST_fsm_pp0_stage0;
            }
            break;
        case 4 : 
            ap_NS_fsm = ap_ST_fsm_state1;
            break;
        default : 
            ap_NS_fsm = "XXX";
            break;
    }
}

}

