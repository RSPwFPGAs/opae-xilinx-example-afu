#include "StreamingFCLayer_Batch_2_Matrix_Vector_Activa.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp380_cast_fu_8825_p1() {
    tmp380_cast_fu_8825_p1 = esl_zext<32,4>(tmp248_fu_8819_p2.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp380_fu_6531_p2() {
    tmp380_fu_6531_p2 = (p_Result_2_0_7_fu_987_p3.read() ^ p_Result_12_7_fu_6523_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp381_cast_fu_8813_p1() {
    tmp381_cast_fu_8813_p1 = esl_zext<4,3>(tmp243_reg_10369.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp381_fu_6555_p2() {
    tmp381_fu_6555_p2 = (p_Result_2_0_8_fu_1019_p3.read() ^ p_Result_12_8_fu_6547_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp382_cast_fu_4479_p1() {
    tmp382_cast_fu_4479_p1 = esl_zext<3,2>(tmp241_fu_4473_p2.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp382_fu_6579_p2() {
    tmp382_fu_6579_p2 = (p_Result_2_0_9_fu_1051_p3.read() ^ p_Result_12_9_fu_6571_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp383_cast_fu_4489_p1() {
    tmp383_cast_fu_4489_p1 = esl_zext<3,2>(tmp242_fu_4483_p2.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp383_fu_6603_p2() {
    tmp383_fu_6603_p2 = (p_Result_2_0_s_fu_1083_p3.read() ^ p_Result_12_s_fu_6595_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp384_cast_fu_8816_p1() {
    tmp384_cast_fu_8816_p1 = esl_zext<4,3>(tmp247_reg_10374.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp384_fu_6627_p2() {
    tmp384_fu_6627_p2 = (p_Result_2_0_10_fu_1115_p3.read() ^ p_Result_12_10_fu_6619_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp385_cast_fu_4505_p1() {
    tmp385_cast_fu_4505_p1 = esl_zext<3,2>(tmp244_fu_4499_p2.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp385_fu_6651_p2() {
    tmp385_fu_6651_p2 = (p_Result_2_0_11_fu_1147_p3.read() ^ p_Result_12_11_fu_6643_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp386_cast_fu_4521_p1() {
    tmp386_cast_fu_4521_p1 = esl_zext<3,2>(tmp246_fu_4515_p2.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp386_fu_6671_p2() {
    tmp386_fu_6671_p2 = (p_Result_2_0_12_fu_1175_p3.read() ^ p_Result_12_12_fu_6663_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp387_fu_6691_p2() {
    tmp387_fu_6691_p2 = (p_Result_2_0_13_fu_1203_p3.read() ^ p_Result_12_13_fu_6683_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp388_fu_6711_p2() {
    tmp388_fu_6711_p2 = (p_Result_2_0_14_fu_1231_p3.read() ^ p_Result_12_14_fu_6703_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp389_fu_9092_p2() {
    tmp389_fu_9092_p2 = (!p_accu_V_12_fu_8248_p3.read().is_01() || !res_12_s_fu_9086_p1.read().is_01())? sc_lv<32>(): (sc_biguint<32>(p_accu_V_12_fu_8248_p3.read()) + sc_biguint<32>(res_12_s_fu_9086_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp38_fu_1491_p2() {
    tmp38_fu_1491_p2 = (p_Result_2_0_6_fu_955_p3.read() ^ p_Result_1_6_fu_1483_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp390_fu_9098_p2() {
    tmp390_fu_9098_p2 = (!res_12_13_cast_fu_9089_p1.read().is_01() || !res_12_11_cast_fu_9083_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_12_13_cast_fu_9089_p1.read()) + sc_biguint<2>(res_12_11_cast_fu_9083_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp391_fu_9108_p2() {
    tmp391_fu_9108_p2 = (!tmp601_cast_fu_9104_p1.read().is_01() || !tmp389_fu_9092_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(tmp601_cast_fu_9104_p1.read()) + sc_biguint<32>(tmp389_fu_9092_p2.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp392_fu_6727_p2() {
    tmp392_fu_6727_p2 = (!res_12_10_cast_fu_6639_p1.read().is_01() || !res_12_8_cast_fu_6567_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_12_10_cast_fu_6639_p1.read()) + sc_biguint<2>(res_12_8_cast_fu_6567_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp393_fu_6737_p2() {
    tmp393_fu_6737_p2 = (!res_12_7_cast_fu_6543_p1.read().is_01() || !res_12_cast_fu_6615_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_12_7_cast_fu_6543_p1.read()) + sc_biguint<2>(res_12_cast_fu_6615_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp394_fu_6747_p2() {
    tmp394_fu_6747_p2 = (!tmp604_cast_fu_6743_p1.read().is_01() || !tmp603_cast_fu_6733_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp604_cast_fu_6743_p1.read()) + sc_biguint<3>(tmp603_cast_fu_6733_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp395_fu_9117_p2() {
    tmp395_fu_9117_p2 = (!tmp602_cast_fu_9114_p1.read().is_01() || !tmp391_fu_9108_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(tmp602_cast_fu_9114_p1.read()) + sc_biguint<32>(tmp391_fu_9108_p2.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp396_fu_6753_p2() {
    tmp396_fu_6753_p2 = (!res_12_9_cast_fu_6591_p1.read().is_01() || !res_11_cast_268_fu_6375_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_12_9_cast_fu_6591_p1.read()) + sc_biguint<2>(res_11_cast_268_fu_6375_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp397_fu_6763_p2() {
    tmp397_fu_6763_p2 = (!res_12_2_cast_fu_6423_p1.read().is_01() || !res_12_1_cast_fu_6399_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_12_2_cast_fu_6423_p1.read()) + sc_biguint<2>(res_12_1_cast_fu_6399_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp398_fu_6773_p2() {
    tmp398_fu_6773_p2 = (!tmp608_cast_fu_6769_p1.read().is_01() || !tmp607_cast_fu_6759_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp608_cast_fu_6769_p1.read()) + sc_biguint<3>(tmp607_cast_fu_6759_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp399_fu_6779_p2() {
    tmp399_fu_6779_p2 = (!res_12_4_cast_fu_6471_p1.read().is_01() || !res_12_3_cast_fu_6447_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_12_4_cast_fu_6471_p1.read()) + sc_biguint<2>(res_12_3_cast_fu_6447_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp39_fu_1515_p2() {
    tmp39_fu_1515_p2 = (p_Result_2_0_7_fu_987_p3.read() ^ p_Result_1_7_fu_1507_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp3_fu_835_p2() {
    tmp3_fu_835_p2 = (p_Result_2_0_2_fu_827_p3.read() ^ p_Result_0_2_fu_819_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp400_fu_6789_p2() {
    tmp400_fu_6789_p2 = (!res_12_5_cast_fu_6495_p1.read().is_01() || !res_12_14_cast_fu_6723_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_12_5_cast_fu_6495_p1.read()) + sc_biguint<2>(res_12_14_cast_fu_6723_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp401_fu_6795_p2() {
    tmp401_fu_6795_p2 = (!tmp400_fu_6789_p2.read().is_01() || !res_12_6_cast_fu_6519_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(tmp400_fu_6789_p2.read()) + sc_biguint<2>(res_12_6_cast_fu_6519_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp402_fu_6805_p2() {
    tmp402_fu_6805_p2 = (!tmp611_cast_fu_6801_p1.read().is_01() || !tmp610_cast_fu_6785_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp611_cast_fu_6801_p1.read()) + sc_biguint<3>(tmp610_cast_fu_6785_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp403_fu_9129_p2() {
    tmp403_fu_9129_p2 = (!tmp609_cast_fu_9126_p1.read().is_01() || !tmp606_cast_fu_9123_p1.read().is_01())? sc_lv<4>(): (sc_biguint<4>(tmp609_cast_fu_9126_p1.read()) + sc_biguint<4>(tmp606_cast_fu_9123_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp404_fu_6819_p2() {
    tmp404_fu_6819_p2 = (p_Result_2_fu_763_p3.read() ^ p_Result_13_fu_6811_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp405_fu_6843_p2() {
    tmp405_fu_6843_p2 = (p_Result_2_0_1_fu_795_p3.read() ^ p_Result_13_1_fu_6835_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp406_fu_6867_p2() {
    tmp406_fu_6867_p2 = (p_Result_2_0_2_fu_827_p3.read() ^ p_Result_13_2_fu_6859_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp407_fu_6891_p2() {
    tmp407_fu_6891_p2 = (p_Result_2_0_3_fu_859_p3.read() ^ p_Result_13_3_fu_6883_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp408_fu_6915_p2() {
    tmp408_fu_6915_p2 = (p_Result_2_0_4_fu_891_p3.read() ^ p_Result_13_4_fu_6907_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp409_fu_6939_p2() {
    tmp409_fu_6939_p2 = (p_Result_2_0_5_fu_923_p3.read() ^ p_Result_13_5_fu_6931_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp40_fu_1539_p2() {
    tmp40_fu_1539_p2 = (p_Result_2_0_8_fu_1019_p3.read() ^ p_Result_1_8_fu_1531_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp410_fu_6963_p2() {
    tmp410_fu_6963_p2 = (p_Result_2_0_6_fu_955_p3.read() ^ p_Result_13_6_fu_6955_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp411_fu_6987_p2() {
    tmp411_fu_6987_p2 = (p_Result_2_0_7_fu_987_p3.read() ^ p_Result_13_7_fu_6979_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp412_fu_7011_p2() {
    tmp412_fu_7011_p2 = (p_Result_2_0_8_fu_1019_p3.read() ^ p_Result_13_8_fu_7003_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp413_fu_7035_p2() {
    tmp413_fu_7035_p2 = (p_Result_2_0_9_fu_1051_p3.read() ^ p_Result_13_9_fu_7027_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp414_fu_7059_p2() {
    tmp414_fu_7059_p2 = (p_Result_2_0_s_fu_1083_p3.read() ^ p_Result_13_s_fu_7051_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp415_fu_7083_p2() {
    tmp415_fu_7083_p2 = (p_Result_2_0_10_fu_1115_p3.read() ^ p_Result_13_10_fu_7075_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp416_fu_7107_p2() {
    tmp416_fu_7107_p2 = (p_Result_2_0_11_fu_1147_p3.read() ^ p_Result_13_11_fu_7099_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp417_fu_7127_p2() {
    tmp417_fu_7127_p2 = (p_Result_2_0_12_fu_1175_p3.read() ^ p_Result_13_12_fu_7119_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp418_fu_7147_p2() {
    tmp418_fu_7147_p2 = (p_Result_2_0_13_fu_1203_p3.read() ^ p_Result_13_13_fu_7139_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp419_fu_7167_p2() {
    tmp419_fu_7167_p2 = (p_Result_2_0_14_fu_1231_p3.read() ^ p_Result_13_14_fu_7159_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp41_fu_1563_p2() {
    tmp41_fu_1563_p2 = (p_Result_2_0_9_fu_1051_p3.read() ^ p_Result_1_9_fu_1555_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp420_fu_9154_p2() {
    tmp420_fu_9154_p2 = (!p_accu_V_13_fu_8241_p3.read().is_01() || !res_13_s_fu_9148_p1.read().is_01())? sc_lv<32>(): (sc_biguint<32>(p_accu_V_13_fu_8241_p3.read()) + sc_biguint<32>(res_13_s_fu_9148_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp421_cast_fu_8856_p1() {
    tmp421_cast_fu_8856_p1 = esl_zext<32,2>(tmp266_fu_8850_p2.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp421_fu_9160_p2() {
    tmp421_fu_9160_p2 = (!res_13_13_cast_fu_9151_p1.read().is_01() || !res_13_11_cast_fu_9145_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_13_13_cast_fu_9151_p1.read()) + sc_biguint<2>(res_13_11_cast_fu_9145_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp422_cast_fu_8866_p1() {
    tmp422_cast_fu_8866_p1 = esl_zext<32,3>(tmp270_reg_10394.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp422_fu_9170_p2() {
    tmp422_fu_9170_p2 = (!tmp646_cast_fu_9166_p1.read().is_01() || !tmp420_fu_9154_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(tmp646_cast_fu_9166_p1.read()) + sc_biguint<32>(tmp420_fu_9154_p2.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp423_cast_fu_4909_p1() {
    tmp423_cast_fu_4909_p1 = esl_zext<3,2>(tmp268_fu_4903_p2.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp423_fu_7183_p2() {
    tmp423_fu_7183_p2 = (!res_13_10_cast_fu_7095_p1.read().is_01() || !res_13_8_cast_fu_7023_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_13_10_cast_fu_7095_p1.read()) + sc_biguint<2>(res_13_8_cast_fu_7023_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp424_cast_fu_4919_p1() {
    tmp424_cast_fu_4919_p1 = esl_zext<3,2>(tmp269_fu_4913_p2.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp424_fu_7193_p2() {
    tmp424_fu_7193_p2 = (!res_13_7_cast_fu_6999_p1.read().is_01() || !res_13_cast_fu_7071_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_13_7_cast_fu_6999_p1.read()) + sc_biguint<2>(res_13_cast_fu_7071_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp425_cast_fu_8887_p1() {
    tmp425_cast_fu_8887_p1 = esl_zext<32,4>(tmp279_fu_8881_p2.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp425_fu_7203_p2() {
    tmp425_fu_7203_p2 = (!tmp649_cast_fu_7199_p1.read().is_01() || !tmp648_cast_fu_7189_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp649_cast_fu_7199_p1.read()) + sc_biguint<3>(tmp648_cast_fu_7189_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp426_cast_fu_8875_p1() {
    tmp426_cast_fu_8875_p1 = esl_zext<4,3>(tmp274_reg_10399.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp426_fu_9179_p2() {
    tmp426_fu_9179_p2 = (!tmp647_cast_fu_9176_p1.read().is_01() || !tmp422_fu_9170_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(tmp647_cast_fu_9176_p1.read()) + sc_biguint<32>(tmp422_fu_9170_p2.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp427_cast_fu_4935_p1() {
    tmp427_cast_fu_4935_p1 = esl_zext<3,2>(tmp272_fu_4929_p2.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp427_fu_7209_p2() {
    tmp427_fu_7209_p2 = (!res_13_9_cast_fu_7047_p1.read().is_01() || !res_12_cast_285_fu_6831_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_13_9_cast_fu_7047_p1.read()) + sc_biguint<2>(res_12_cast_285_fu_6831_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp428_cast_fu_4945_p1() {
    tmp428_cast_fu_4945_p1 = esl_zext<3,2>(tmp273_fu_4939_p2.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp428_fu_7219_p2() {
    tmp428_fu_7219_p2 = (!res_13_2_cast_fu_6879_p1.read().is_01() || !res_13_1_cast_fu_6855_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_13_2_cast_fu_6879_p1.read()) + sc_biguint<2>(res_13_1_cast_fu_6855_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp429_cast_fu_8878_p1() {
    tmp429_cast_fu_8878_p1 = esl_zext<4,3>(tmp278_reg_10404.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp429_fu_7229_p2() {
    tmp429_fu_7229_p2 = (!tmp653_cast_fu_7225_p1.read().is_01() || !tmp652_cast_fu_7215_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp653_cast_fu_7225_p1.read()) + sc_biguint<3>(tmp652_cast_fu_7215_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp42_fu_1587_p2() {
    tmp42_fu_1587_p2 = (p_Result_2_0_s_fu_1083_p3.read() ^ p_Result_1_s_fu_1579_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp430_cast_fu_4961_p1() {
    tmp430_cast_fu_4961_p1 = esl_zext<3,2>(tmp275_fu_4955_p2.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp430_fu_7235_p2() {
    tmp430_fu_7235_p2 = (!res_13_4_cast_fu_6927_p1.read().is_01() || !res_13_3_cast_fu_6903_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_13_4_cast_fu_6927_p1.read()) + sc_biguint<2>(res_13_3_cast_fu_6903_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp431_cast_fu_4977_p1() {
    tmp431_cast_fu_4977_p1 = esl_zext<3,2>(tmp277_fu_4971_p2.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp431_fu_7245_p2() {
    tmp431_fu_7245_p2 = (!res_13_5_cast_fu_6951_p1.read().is_01() || !res_13_14_cast_fu_7179_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_13_5_cast_fu_6951_p1.read()) + sc_biguint<2>(res_13_14_cast_fu_7179_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp432_fu_7251_p2() {
    tmp432_fu_7251_p2 = (!tmp431_fu_7245_p2.read().is_01() || !res_13_6_cast_fu_6975_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(tmp431_fu_7245_p2.read()) + sc_biguint<2>(res_13_6_cast_fu_6975_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp433_fu_7261_p2() {
    tmp433_fu_7261_p2 = (!tmp656_cast_fu_7257_p1.read().is_01() || !tmp655_cast_fu_7241_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp656_cast_fu_7257_p1.read()) + sc_biguint<3>(tmp655_cast_fu_7241_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp434_fu_9191_p2() {
    tmp434_fu_9191_p2 = (!tmp654_cast_fu_9188_p1.read().is_01() || !tmp651_cast_fu_9185_p1.read().is_01())? sc_lv<4>(): (sc_biguint<4>(tmp654_cast_fu_9188_p1.read()) + sc_biguint<4>(tmp651_cast_fu_9185_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp435_fu_7275_p2() {
    tmp435_fu_7275_p2 = (p_Result_2_fu_763_p3.read() ^ p_Result_14_fu_7267_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp436_fu_7299_p2() {
    tmp436_fu_7299_p2 = (p_Result_2_0_1_fu_795_p3.read() ^ p_Result_14_1_fu_7291_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp437_fu_7323_p2() {
    tmp437_fu_7323_p2 = (p_Result_2_0_2_fu_827_p3.read() ^ p_Result_14_2_fu_7315_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp438_fu_7347_p2() {
    tmp438_fu_7347_p2 = (p_Result_2_0_3_fu_859_p3.read() ^ p_Result_14_3_fu_7339_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp439_fu_7371_p2() {
    tmp439_fu_7371_p2 = (p_Result_2_0_4_fu_891_p3.read() ^ p_Result_14_4_fu_7363_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp43_fu_1611_p2() {
    tmp43_fu_1611_p2 = (p_Result_2_0_10_fu_1115_p3.read() ^ p_Result_1_10_fu_1603_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp440_fu_7395_p2() {
    tmp440_fu_7395_p2 = (p_Result_2_0_5_fu_923_p3.read() ^ p_Result_14_5_fu_7387_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp441_fu_7419_p2() {
    tmp441_fu_7419_p2 = (p_Result_2_0_6_fu_955_p3.read() ^ p_Result_14_6_fu_7411_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp442_fu_7443_p2() {
    tmp442_fu_7443_p2 = (p_Result_2_0_7_fu_987_p3.read() ^ p_Result_14_7_fu_7435_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp443_fu_7467_p2() {
    tmp443_fu_7467_p2 = (p_Result_2_0_8_fu_1019_p3.read() ^ p_Result_14_8_fu_7459_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp444_fu_7491_p2() {
    tmp444_fu_7491_p2 = (p_Result_2_0_9_fu_1051_p3.read() ^ p_Result_14_9_fu_7483_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp445_fu_7515_p2() {
    tmp445_fu_7515_p2 = (p_Result_2_0_s_fu_1083_p3.read() ^ p_Result_14_s_fu_7507_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp446_fu_7539_p2() {
    tmp446_fu_7539_p2 = (p_Result_2_0_10_fu_1115_p3.read() ^ p_Result_14_10_fu_7531_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp447_fu_7563_p2() {
    tmp447_fu_7563_p2 = (p_Result_2_0_11_fu_1147_p3.read() ^ p_Result_14_11_fu_7555_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp448_fu_7583_p2() {
    tmp448_fu_7583_p2 = (p_Result_2_0_12_fu_1175_p3.read() ^ p_Result_14_12_fu_7575_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp449_fu_7603_p2() {
    tmp449_fu_7603_p2 = (p_Result_2_0_13_fu_1203_p3.read() ^ p_Result_14_13_fu_7595_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp44_fu_1635_p2() {
    tmp44_fu_1635_p2 = (p_Result_2_0_11_fu_1147_p3.read() ^ p_Result_1_11_fu_1627_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp450_fu_7623_p2() {
    tmp450_fu_7623_p2 = (p_Result_2_0_14_fu_1231_p3.read() ^ p_Result_14_14_fu_7615_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp451_fu_9216_p2() {
    tmp451_fu_9216_p2 = (!p_accu_V_14_fu_8234_p3.read().is_01() || !res_14_s_fu_9210_p1.read().is_01())? sc_lv<32>(): (sc_biguint<32>(p_accu_V_14_fu_8234_p3.read()) + sc_biguint<32>(res_14_s_fu_9210_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp452_fu_9222_p2() {
    tmp452_fu_9222_p2 = (!res_14_13_cast_fu_9213_p1.read().is_01() || !res_14_11_cast_fu_9207_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_14_13_cast_fu_9213_p1.read()) + sc_biguint<2>(res_14_11_cast_fu_9207_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp453_fu_9232_p2() {
    tmp453_fu_9232_p2 = (!tmp691_cast_fu_9228_p1.read().is_01() || !tmp451_fu_9216_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(tmp691_cast_fu_9228_p1.read()) + sc_biguint<32>(tmp451_fu_9216_p2.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp454_fu_7639_p2() {
    tmp454_fu_7639_p2 = (!res_14_10_cast_fu_7551_p1.read().is_01() || !res_14_8_cast_fu_7479_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_14_10_cast_fu_7551_p1.read()) + sc_biguint<2>(res_14_8_cast_fu_7479_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp455_fu_7649_p2() {
    tmp455_fu_7649_p2 = (!res_14_7_cast_fu_7455_p1.read().is_01() || !res_14_cast_fu_7527_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_14_7_cast_fu_7455_p1.read()) + sc_biguint<2>(res_14_cast_fu_7527_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp456_fu_7659_p2() {
    tmp456_fu_7659_p2 = (!tmp694_cast_fu_7655_p1.read().is_01() || !tmp693_cast_fu_7645_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp694_cast_fu_7655_p1.read()) + sc_biguint<3>(tmp693_cast_fu_7645_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp457_fu_9241_p2() {
    tmp457_fu_9241_p2 = (!tmp692_cast_fu_9238_p1.read().is_01() || !tmp453_fu_9232_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(tmp692_cast_fu_9238_p1.read()) + sc_biguint<32>(tmp453_fu_9232_p2.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp458_fu_7665_p2() {
    tmp458_fu_7665_p2 = (!res_14_9_cast_fu_7503_p1.read().is_01() || !res_13_cast_302_fu_7287_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_14_9_cast_fu_7503_p1.read()) + sc_biguint<2>(res_13_cast_302_fu_7287_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp459_fu_7675_p2() {
    tmp459_fu_7675_p2 = (!res_14_2_cast_fu_7335_p1.read().is_01() || !res_14_1_cast_fu_7311_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_14_2_cast_fu_7335_p1.read()) + sc_biguint<2>(res_14_1_cast_fu_7311_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp45_fu_1655_p2() {
    tmp45_fu_1655_p2 = (p_Result_2_0_12_fu_1175_p3.read() ^ p_Result_1_12_fu_1647_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp460_fu_7685_p2() {
    tmp460_fu_7685_p2 = (!tmp698_cast_fu_7681_p1.read().is_01() || !tmp697_cast_fu_7671_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp698_cast_fu_7681_p1.read()) + sc_biguint<3>(tmp697_cast_fu_7671_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp461_fu_7691_p2() {
    tmp461_fu_7691_p2 = (!res_14_4_cast_fu_7383_p1.read().is_01() || !res_14_3_cast_fu_7359_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_14_4_cast_fu_7383_p1.read()) + sc_biguint<2>(res_14_3_cast_fu_7359_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp462_fu_7701_p2() {
    tmp462_fu_7701_p2 = (!res_14_5_cast_fu_7407_p1.read().is_01() || !res_14_14_cast_fu_7635_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_14_5_cast_fu_7407_p1.read()) + sc_biguint<2>(res_14_14_cast_fu_7635_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp463_fu_7707_p2() {
    tmp463_fu_7707_p2 = (!tmp462_fu_7701_p2.read().is_01() || !res_14_6_cast_fu_7431_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(tmp462_fu_7701_p2.read()) + sc_biguint<2>(res_14_6_cast_fu_7431_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp464_fu_7717_p2() {
    tmp464_fu_7717_p2 = (!tmp701_cast_fu_7713_p1.read().is_01() || !tmp700_cast_fu_7697_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp701_cast_fu_7713_p1.read()) + sc_biguint<3>(tmp700_cast_fu_7697_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp465_fu_9253_p2() {
    tmp465_fu_9253_p2 = (!tmp699_cast_fu_9250_p1.read().is_01() || !tmp696_cast_fu_9247_p1.read().is_01())? sc_lv<4>(): (sc_biguint<4>(tmp699_cast_fu_9250_p1.read()) + sc_biguint<4>(tmp696_cast_fu_9247_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp466_cast_fu_8918_p1() {
    tmp466_cast_fu_8918_p1 = esl_zext<32,2>(tmp297_fu_8912_p2.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp466_fu_7731_p2() {
    tmp466_fu_7731_p2 = (p_Result_2_fu_763_p3.read() ^ p_Result_15_fu_7723_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp467_cast_fu_8928_p1() {
    tmp467_cast_fu_8928_p1 = esl_zext<32,3>(tmp301_reg_10424.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp467_fu_7755_p2() {
    tmp467_fu_7755_p2 = (p_Result_2_0_1_fu_795_p3.read() ^ p_Result_15_1_fu_7747_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp468_cast_fu_5365_p1() {
    tmp468_cast_fu_5365_p1 = esl_zext<3,2>(tmp299_fu_5359_p2.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp468_fu_7779_p2() {
    tmp468_fu_7779_p2 = (p_Result_2_0_2_fu_827_p3.read() ^ p_Result_15_2_fu_7771_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp469_cast_fu_5375_p1() {
    tmp469_cast_fu_5375_p1 = esl_zext<3,2>(tmp300_fu_5369_p2.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp469_fu_7803_p2() {
    tmp469_fu_7803_p2 = (p_Result_2_0_3_fu_859_p3.read() ^ p_Result_15_3_fu_7795_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp46_fu_1675_p2() {
    tmp46_fu_1675_p2 = (p_Result_2_0_13_fu_1203_p3.read() ^ p_Result_1_13_fu_1667_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp470_cast_fu_8949_p1() {
    tmp470_cast_fu_8949_p1 = esl_zext<32,4>(tmp310_fu_8943_p2.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp470_fu_7827_p2() {
    tmp470_fu_7827_p2 = (p_Result_2_0_4_fu_891_p3.read() ^ p_Result_15_4_fu_7819_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp471_cast_fu_8937_p1() {
    tmp471_cast_fu_8937_p1 = esl_zext<4,3>(tmp305_reg_10429.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp471_fu_7851_p2() {
    tmp471_fu_7851_p2 = (p_Result_2_0_5_fu_923_p3.read() ^ p_Result_15_5_fu_7843_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp472_cast_fu_5391_p1() {
    tmp472_cast_fu_5391_p1 = esl_zext<3,2>(tmp303_fu_5385_p2.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp472_fu_7875_p2() {
    tmp472_fu_7875_p2 = (p_Result_2_0_6_fu_955_p3.read() ^ p_Result_15_6_fu_7867_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp473_cast_fu_5401_p1() {
    tmp473_cast_fu_5401_p1 = esl_zext<3,2>(tmp304_fu_5395_p2.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp473_fu_7899_p2() {
    tmp473_fu_7899_p2 = (p_Result_2_0_7_fu_987_p3.read() ^ p_Result_15_7_fu_7891_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp474_cast_fu_8940_p1() {
    tmp474_cast_fu_8940_p1 = esl_zext<4,3>(tmp309_reg_10434.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp474_fu_7923_p2() {
    tmp474_fu_7923_p2 = (p_Result_2_0_8_fu_1019_p3.read() ^ p_Result_15_8_fu_7915_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp475_cast_fu_5417_p1() {
    tmp475_cast_fu_5417_p1 = esl_zext<3,2>(tmp306_fu_5411_p2.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp475_fu_7947_p2() {
    tmp475_fu_7947_p2 = (p_Result_2_0_9_fu_1051_p3.read() ^ p_Result_15_9_fu_7939_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp476_cast_fu_5433_p1() {
    tmp476_cast_fu_5433_p1 = esl_zext<3,2>(tmp308_fu_5427_p2.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp476_fu_7971_p2() {
    tmp476_fu_7971_p2 = (p_Result_2_0_s_fu_1083_p3.read() ^ p_Result_15_s_fu_7963_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp477_fu_7995_p2() {
    tmp477_fu_7995_p2 = (p_Result_2_0_10_fu_1115_p3.read() ^ p_Result_15_10_fu_7987_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp478_fu_8019_p2() {
    tmp478_fu_8019_p2 = (p_Result_2_0_11_fu_1147_p3.read() ^ p_Result_15_11_fu_8011_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp479_fu_8039_p2() {
    tmp479_fu_8039_p2 = (p_Result_2_0_12_fu_1175_p3.read() ^ p_Result_15_12_fu_8031_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp47_fu_1695_p2() {
    tmp47_fu_1695_p2 = (p_Result_2_0_14_fu_1231_p3.read() ^ p_Result_1_14_fu_1687_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp480_fu_8059_p2() {
    tmp480_fu_8059_p2 = (p_Result_2_0_13_fu_1203_p3.read() ^ p_Result_15_13_fu_8051_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp481_fu_8079_p2() {
    tmp481_fu_8079_p2 = (p_Result_2_0_14_fu_1231_p3.read() ^ p_Result_15_14_fu_8071_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp482_fu_9278_p2() {
    tmp482_fu_9278_p2 = (!p_accu_V_s_fu_8227_p3.read().is_01() || !res_15_s_fu_9272_p1.read().is_01())? sc_lv<32>(): (sc_biguint<32>(p_accu_V_s_fu_8227_p3.read()) + sc_biguint<32>(res_15_s_fu_9272_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp483_fu_9284_p2() {
    tmp483_fu_9284_p2 = (!res_15_13_cast_fu_9275_p1.read().is_01() || !res_15_11_cast_fu_9269_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_15_13_cast_fu_9275_p1.read()) + sc_biguint<2>(res_15_11_cast_fu_9269_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp484_fu_9294_p2() {
    tmp484_fu_9294_p2 = (!tmp736_cast_fu_9290_p1.read().is_01() || !tmp482_fu_9278_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(tmp736_cast_fu_9290_p1.read()) + sc_biguint<32>(tmp482_fu_9278_p2.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp485_fu_8095_p2() {
    tmp485_fu_8095_p2 = (!res_15_10_cast_fu_8007_p1.read().is_01() || !res_15_8_cast_fu_7935_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_15_10_cast_fu_8007_p1.read()) + sc_biguint<2>(res_15_8_cast_fu_7935_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp486_fu_8105_p2() {
    tmp486_fu_8105_p2 = (!res_15_7_cast_fu_7911_p1.read().is_01() || !res_15_cast_fu_7983_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_15_7_cast_fu_7911_p1.read()) + sc_biguint<2>(res_15_cast_fu_7983_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp487_fu_8115_p2() {
    tmp487_fu_8115_p2 = (!tmp739_cast_fu_8111_p1.read().is_01() || !tmp738_cast_fu_8101_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp739_cast_fu_8111_p1.read()) + sc_biguint<3>(tmp738_cast_fu_8101_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp488_fu_9303_p2() {
    tmp488_fu_9303_p2 = (!tmp737_cast_fu_9300_p1.read().is_01() || !tmp484_fu_9294_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(tmp737_cast_fu_9300_p1.read()) + sc_biguint<32>(tmp484_fu_9294_p2.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp489_fu_8121_p2() {
    tmp489_fu_8121_p2 = (!res_15_9_cast_fu_7959_p1.read().is_01() || !res_14_cast_319_fu_7743_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_15_9_cast_fu_7959_p1.read()) + sc_biguint<2>(res_14_cast_319_fu_7743_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp48_fu_8410_p2() {
    tmp48_fu_8410_p2 = (!p_accu_V_1_fu_8325_p3.read().is_01() || !res_1_s_fu_8404_p1.read().is_01())? sc_lv<32>(): (sc_biguint<32>(p_accu_V_1_fu_8325_p3.read()) + sc_biguint<32>(res_1_s_fu_8404_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp490_fu_8131_p2() {
    tmp490_fu_8131_p2 = (!res_15_2_cast_fu_7791_p1.read().is_01() || !res_15_1_cast_fu_7767_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_15_2_cast_fu_7791_p1.read()) + sc_biguint<2>(res_15_1_cast_fu_7767_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp491_fu_8141_p2() {
    tmp491_fu_8141_p2 = (!tmp743_cast_fu_8137_p1.read().is_01() || !tmp742_cast_fu_8127_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp743_cast_fu_8137_p1.read()) + sc_biguint<3>(tmp742_cast_fu_8127_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp492_fu_8147_p2() {
    tmp492_fu_8147_p2 = (!res_15_4_cast_fu_7839_p1.read().is_01() || !res_15_3_cast_fu_7815_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_15_4_cast_fu_7839_p1.read()) + sc_biguint<2>(res_15_3_cast_fu_7815_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp493_fu_8157_p2() {
    tmp493_fu_8157_p2 = (!res_15_5_cast_fu_7863_p1.read().is_01() || !res_15_14_cast_fu_8091_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_15_5_cast_fu_7863_p1.read()) + sc_biguint<2>(res_15_14_cast_fu_8091_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp494_fu_8163_p2() {
    tmp494_fu_8163_p2 = (!tmp493_fu_8157_p2.read().is_01() || !res_15_6_cast_fu_7887_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(tmp493_fu_8157_p2.read()) + sc_biguint<2>(res_15_6_cast_fu_7887_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp495_fu_8173_p2() {
    tmp495_fu_8173_p2 = (!tmp746_cast_fu_8169_p1.read().is_01() || !tmp745_cast_fu_8153_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp746_cast_fu_8169_p1.read()) + sc_biguint<3>(tmp745_cast_fu_8153_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp496_fu_9315_p2() {
    tmp496_fu_9315_p2 = (!tmp744_cast_fu_9312_p1.read().is_01() || !tmp741_cast_fu_9309_p1.read().is_01())? sc_lv<4>(): (sc_biguint<4>(tmp744_cast_fu_9312_p1.read()) + sc_biguint<4>(tmp741_cast_fu_9309_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp49_fu_8416_p2() {
    tmp49_fu_8416_p2 = (!res_1_13_cast_fu_8407_p1.read().is_01() || !res_1_11_cast_fu_8401_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_1_13_cast_fu_8407_p1.read()) + sc_biguint<2>(res_1_11_cast_fu_8401_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp4_fu_867_p2() {
    tmp4_fu_867_p2 = (p_Result_2_0_3_fu_859_p3.read() ^ p_Result_0_3_fu_851_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp50_fu_8426_p2() {
    tmp50_fu_8426_p2 = (!tmp106_cast_fu_8422_p1.read().is_01() || !tmp48_fu_8410_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(tmp106_cast_fu_8422_p1.read()) + sc_biguint<32>(tmp48_fu_8410_p2.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp511_cast_fu_8980_p1() {
    tmp511_cast_fu_8980_p1 = esl_zext<32,2>(tmp328_fu_8974_p2.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp512_cast_fu_8990_p1() {
    tmp512_cast_fu_8990_p1 = esl_zext<32,3>(tmp332_reg_10454.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp513_cast_fu_5821_p1() {
    tmp513_cast_fu_5821_p1 = esl_zext<3,2>(tmp330_fu_5815_p2.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp514_cast_fu_5831_p1() {
    tmp514_cast_fu_5831_p1 = esl_zext<3,2>(tmp331_fu_5825_p2.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp515_cast_fu_9011_p1() {
    tmp515_cast_fu_9011_p1 = esl_zext<32,4>(tmp341_fu_9005_p2.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp516_cast_fu_8999_p1() {
    tmp516_cast_fu_8999_p1 = esl_zext<4,3>(tmp336_reg_10459.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp517_cast_fu_5847_p1() {
    tmp517_cast_fu_5847_p1 = esl_zext<3,2>(tmp334_fu_5841_p2.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp518_cast_fu_5857_p1() {
    tmp518_cast_fu_5857_p1 = esl_zext<3,2>(tmp335_fu_5851_p2.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp519_cast_fu_9002_p1() {
    tmp519_cast_fu_9002_p1 = esl_zext<4,3>(tmp340_reg_10464.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp51_fu_1711_p2() {
    tmp51_fu_1711_p2 = (!res_1_10_cast_fu_1623_p1.read().is_01() || !res_1_8_cast_fu_1551_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_1_10_cast_fu_1623_p1.read()) + sc_biguint<2>(res_1_8_cast_fu_1551_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp520_cast_fu_5873_p1() {
    tmp520_cast_fu_5873_p1 = esl_zext<3,2>(tmp337_fu_5867_p2.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp521_cast_fu_5889_p1() {
    tmp521_cast_fu_5889_p1 = esl_zext<3,2>(tmp339_fu_5883_p2.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp52_fu_1721_p2() {
    tmp52_fu_1721_p2 = (!res_1_7_cast_fu_1527_p1.read().is_01() || !res_1_cast_91_fu_1599_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_1_7_cast_fu_1527_p1.read()) + sc_biguint<2>(res_1_cast_91_fu_1599_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp53_fu_1731_p2() {
    tmp53_fu_1731_p2 = (!tmp109_cast_fu_1727_p1.read().is_01() || !tmp108_cast_fu_1717_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp109_cast_fu_1727_p1.read()) + sc_biguint<3>(tmp108_cast_fu_1717_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp54_fu_8435_p2() {
    tmp54_fu_8435_p2 = (!tmp107_cast_fu_8432_p1.read().is_01() || !tmp50_fu_8426_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(tmp107_cast_fu_8432_p1.read()) + sc_biguint<32>(tmp50_fu_8426_p2.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp556_cast_fu_9042_p1() {
    tmp556_cast_fu_9042_p1 = esl_zext<32,2>(tmp359_fu_9036_p2.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp557_cast_fu_9052_p1() {
    tmp557_cast_fu_9052_p1 = esl_zext<32,3>(tmp363_reg_10484.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp558_cast_fu_6277_p1() {
    tmp558_cast_fu_6277_p1 = esl_zext<3,2>(tmp361_fu_6271_p2.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp559_cast_fu_6287_p1() {
    tmp559_cast_fu_6287_p1 = esl_zext<3,2>(tmp362_fu_6281_p2.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp55_fu_1737_p2() {
    tmp55_fu_1737_p2 = (!res_1_9_cast_fu_1575_p1.read().is_01() || !res_1_cast_fu_1359_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_1_9_cast_fu_1575_p1.read()) + sc_biguint<2>(res_1_cast_fu_1359_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp560_cast_fu_9073_p1() {
    tmp560_cast_fu_9073_p1 = esl_zext<32,4>(tmp372_fu_9067_p2.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp561_cast_fu_9061_p1() {
    tmp561_cast_fu_9061_p1 = esl_zext<4,3>(tmp367_reg_10489.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp562_cast_fu_6303_p1() {
    tmp562_cast_fu_6303_p1 = esl_zext<3,2>(tmp365_fu_6297_p2.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp563_cast_fu_6313_p1() {
    tmp563_cast_fu_6313_p1 = esl_zext<3,2>(tmp366_fu_6307_p2.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp564_cast_fu_9064_p1() {
    tmp564_cast_fu_9064_p1 = esl_zext<4,3>(tmp371_reg_10494.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp565_cast_fu_6329_p1() {
    tmp565_cast_fu_6329_p1 = esl_zext<3,2>(tmp368_fu_6323_p2.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp566_cast_fu_6345_p1() {
    tmp566_cast_fu_6345_p1 = esl_zext<3,2>(tmp370_fu_6339_p2.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp56_fu_1747_p2() {
    tmp56_fu_1747_p2 = (!res_1_2_cast_fu_1407_p1.read().is_01() || !res_1_1_cast_fu_1383_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_1_2_cast_fu_1407_p1.read()) + sc_biguint<2>(res_1_1_cast_fu_1383_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp57_fu_1757_p2() {
    tmp57_fu_1757_p2 = (!tmp113_cast_fu_1753_p1.read().is_01() || !tmp112_cast_fu_1743_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp113_cast_fu_1753_p1.read()) + sc_biguint<3>(tmp112_cast_fu_1743_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp58_fu_1763_p2() {
    tmp58_fu_1763_p2 = (!res_1_4_cast_fu_1455_p1.read().is_01() || !res_1_3_cast_fu_1431_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_1_4_cast_fu_1455_p1.read()) + sc_biguint<2>(res_1_3_cast_fu_1431_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp59_fu_1773_p2() {
    tmp59_fu_1773_p2 = (!res_1_5_cast_fu_1479_p1.read().is_01() || !res_1_14_cast_fu_1707_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_1_5_cast_fu_1479_p1.read()) + sc_biguint<2>(res_1_14_cast_fu_1707_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp5_fu_899_p2() {
    tmp5_fu_899_p2 = (p_Result_2_0_4_fu_891_p3.read() ^ p_Result_0_4_fu_883_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp601_cast_fu_9104_p1() {
    tmp601_cast_fu_9104_p1 = esl_zext<32,2>(tmp390_fu_9098_p2.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp602_cast_fu_9114_p1() {
    tmp602_cast_fu_9114_p1 = esl_zext<32,3>(tmp394_reg_10514.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp603_cast_fu_6733_p1() {
    tmp603_cast_fu_6733_p1 = esl_zext<3,2>(tmp392_fu_6727_p2.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp604_cast_fu_6743_p1() {
    tmp604_cast_fu_6743_p1 = esl_zext<3,2>(tmp393_fu_6737_p2.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp605_cast_fu_9135_p1() {
    tmp605_cast_fu_9135_p1 = esl_zext<32,4>(tmp403_fu_9129_p2.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp606_cast_fu_9123_p1() {
    tmp606_cast_fu_9123_p1 = esl_zext<4,3>(tmp398_reg_10519.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp607_cast_fu_6759_p1() {
    tmp607_cast_fu_6759_p1 = esl_zext<3,2>(tmp396_fu_6753_p2.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp608_cast_fu_6769_p1() {
    tmp608_cast_fu_6769_p1 = esl_zext<3,2>(tmp397_fu_6763_p2.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp609_cast_fu_9126_p1() {
    tmp609_cast_fu_9126_p1 = esl_zext<4,3>(tmp402_reg_10524.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp60_fu_1779_p2() {
    tmp60_fu_1779_p2 = (!tmp59_fu_1773_p2.read().is_01() || !res_1_6_cast_fu_1503_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(tmp59_fu_1773_p2.read()) + sc_biguint<2>(res_1_6_cast_fu_1503_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp610_cast_fu_6785_p1() {
    tmp610_cast_fu_6785_p1 = esl_zext<3,2>(tmp399_fu_6779_p2.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp611_cast_fu_6801_p1() {
    tmp611_cast_fu_6801_p1 = esl_zext<3,2>(tmp401_fu_6795_p2.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp61_cast_fu_8360_p1() {
    tmp61_cast_fu_8360_p1 = esl_zext<32,2>(tmp18_fu_8354_p2.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp61_fu_1789_p2() {
    tmp61_fu_1789_p2 = (!tmp116_cast_fu_1785_p1.read().is_01() || !tmp115_cast_fu_1769_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp116_cast_fu_1785_p1.read()) + sc_biguint<3>(tmp115_cast_fu_1769_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp62_cast_fu_8370_p1() {
    tmp62_cast_fu_8370_p1 = esl_zext<32,3>(tmp22_reg_10154.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp62_fu_8447_p2() {
    tmp62_fu_8447_p2 = (!tmp114_cast_fu_8444_p1.read().is_01() || !tmp111_cast_fu_8441_p1.read().is_01())? sc_lv<4>(): (sc_biguint<4>(tmp114_cast_fu_8444_p1.read()) + sc_biguint<4>(tmp111_cast_fu_8441_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp63_cast_fu_1261_p1() {
    tmp63_cast_fu_1261_p1 = esl_zext<3,2>(tmp20_fu_1255_p2.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp63_fu_1803_p2() {
    tmp63_fu_1803_p2 = (p_Result_2_fu_763_p3.read() ^ p_Result_s_98_fu_1795_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp646_cast_fu_9166_p1() {
    tmp646_cast_fu_9166_p1 = esl_zext<32,2>(tmp421_fu_9160_p2.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp647_cast_fu_9176_p1() {
    tmp647_cast_fu_9176_p1 = esl_zext<32,3>(tmp425_reg_10544.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp648_cast_fu_7189_p1() {
    tmp648_cast_fu_7189_p1 = esl_zext<3,2>(tmp423_fu_7183_p2.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp649_cast_fu_7199_p1() {
    tmp649_cast_fu_7199_p1 = esl_zext<3,2>(tmp424_fu_7193_p2.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp64_cast_fu_1271_p1() {
    tmp64_cast_fu_1271_p1 = esl_zext<3,2>(tmp21_fu_1265_p2.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp64_fu_1827_p2() {
    tmp64_fu_1827_p2 = (p_Result_2_0_1_fu_795_p3.read() ^ p_Result_211_1_fu_1819_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp650_cast_fu_9197_p1() {
    tmp650_cast_fu_9197_p1 = esl_zext<32,4>(tmp434_fu_9191_p2.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp651_cast_fu_9185_p1() {
    tmp651_cast_fu_9185_p1 = esl_zext<4,3>(tmp429_reg_10549.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp652_cast_fu_7215_p1() {
    tmp652_cast_fu_7215_p1 = esl_zext<3,2>(tmp427_fu_7209_p2.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp653_cast_fu_7225_p1() {
    tmp653_cast_fu_7225_p1 = esl_zext<3,2>(tmp428_fu_7219_p2.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp654_cast_fu_9188_p1() {
    tmp654_cast_fu_9188_p1 = esl_zext<4,3>(tmp433_reg_10554.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp655_cast_fu_7241_p1() {
    tmp655_cast_fu_7241_p1 = esl_zext<3,2>(tmp430_fu_7235_p2.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp656_cast_fu_7257_p1() {
    tmp656_cast_fu_7257_p1 = esl_zext<3,2>(tmp432_fu_7251_p2.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp65_cast_fu_8391_p1() {
    tmp65_cast_fu_8391_p1 = esl_zext<32,4>(tmp31_fu_8385_p2.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp65_fu_1851_p2() {
    tmp65_fu_1851_p2 = (p_Result_2_0_2_fu_827_p3.read() ^ p_Result_211_2_fu_1843_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp66_cast_fu_8379_p1() {
    tmp66_cast_fu_8379_p1 = esl_zext<4,3>(tmp26_reg_10159.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp66_fu_1875_p2() {
    tmp66_fu_1875_p2 = (p_Result_2_0_3_fu_859_p3.read() ^ p_Result_211_3_fu_1867_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp67_cast_fu_1287_p1() {
    tmp67_cast_fu_1287_p1 = esl_zext<3,2>(tmp24_fu_1281_p2.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp67_fu_1899_p2() {
    tmp67_fu_1899_p2 = (p_Result_2_0_4_fu_891_p3.read() ^ p_Result_211_4_fu_1891_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp68_cast_fu_1297_p1() {
    tmp68_cast_fu_1297_p1 = esl_zext<3,2>(tmp25_fu_1291_p2.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp68_fu_1923_p2() {
    tmp68_fu_1923_p2 = (p_Result_2_0_5_fu_923_p3.read() ^ p_Result_211_5_fu_1915_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp691_cast_fu_9228_p1() {
    tmp691_cast_fu_9228_p1 = esl_zext<32,2>(tmp452_fu_9222_p2.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp692_cast_fu_9238_p1() {
    tmp692_cast_fu_9238_p1 = esl_zext<32,3>(tmp456_reg_10574.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp693_cast_fu_7645_p1() {
    tmp693_cast_fu_7645_p1 = esl_zext<3,2>(tmp454_fu_7639_p2.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp694_cast_fu_7655_p1() {
    tmp694_cast_fu_7655_p1 = esl_zext<3,2>(tmp455_fu_7649_p2.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp695_cast_fu_9259_p1() {
    tmp695_cast_fu_9259_p1 = esl_zext<32,4>(tmp465_fu_9253_p2.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp696_cast_fu_9247_p1() {
    tmp696_cast_fu_9247_p1 = esl_zext<4,3>(tmp460_reg_10579.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp697_cast_fu_7671_p1() {
    tmp697_cast_fu_7671_p1 = esl_zext<3,2>(tmp458_fu_7665_p2.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp698_cast_fu_7681_p1() {
    tmp698_cast_fu_7681_p1 = esl_zext<3,2>(tmp459_fu_7675_p2.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp699_cast_fu_9250_p1() {
    tmp699_cast_fu_9250_p1 = esl_zext<4,3>(tmp464_reg_10584.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp69_cast_fu_8382_p1() {
    tmp69_cast_fu_8382_p1 = esl_zext<4,3>(tmp30_reg_10164.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp69_fu_1947_p2() {
    tmp69_fu_1947_p2 = (p_Result_2_0_6_fu_955_p3.read() ^ p_Result_211_6_fu_1939_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp6_fu_931_p2() {
    tmp6_fu_931_p2 = (p_Result_2_0_5_fu_923_p3.read() ^ p_Result_0_5_fu_915_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp700_cast_fu_7697_p1() {
    tmp700_cast_fu_7697_p1 = esl_zext<3,2>(tmp461_fu_7691_p2.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp701_cast_fu_7713_p1() {
    tmp701_cast_fu_7713_p1 = esl_zext<3,2>(tmp463_fu_7707_p2.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp70_cast_fu_1313_p1() {
    tmp70_cast_fu_1313_p1 = esl_zext<3,2>(tmp27_fu_1307_p2.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp70_fu_1971_p2() {
    tmp70_fu_1971_p2 = (p_Result_2_0_7_fu_987_p3.read() ^ p_Result_211_7_fu_1963_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp71_cast_fu_1329_p1() {
    tmp71_cast_fu_1329_p1 = esl_zext<3,2>(tmp29_fu_1323_p2.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp71_fu_1995_p2() {
    tmp71_fu_1995_p2 = (p_Result_2_0_8_fu_1019_p3.read() ^ p_Result_211_8_fu_1987_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp72_fu_2019_p2() {
    tmp72_fu_2019_p2 = (p_Result_2_0_9_fu_1051_p3.read() ^ p_Result_211_9_fu_2011_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp736_cast_fu_9290_p1() {
    tmp736_cast_fu_9290_p1 = esl_zext<32,2>(tmp483_fu_9284_p2.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp737_cast_fu_9300_p1() {
    tmp737_cast_fu_9300_p1 = esl_zext<32,3>(tmp487_reg_10604.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp738_cast_fu_8101_p1() {
    tmp738_cast_fu_8101_p1 = esl_zext<3,2>(tmp485_fu_8095_p2.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp739_cast_fu_8111_p1() {
    tmp739_cast_fu_8111_p1 = esl_zext<3,2>(tmp486_fu_8105_p2.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp73_fu_2043_p2() {
    tmp73_fu_2043_p2 = (p_Result_2_0_s_fu_1083_p3.read() ^ p_Result_211_s_fu_2035_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp740_cast_fu_9321_p1() {
    tmp740_cast_fu_9321_p1 = esl_zext<32,4>(tmp496_fu_9315_p2.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp741_cast_fu_9309_p1() {
    tmp741_cast_fu_9309_p1 = esl_zext<4,3>(tmp491_reg_10609.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp742_cast_fu_8127_p1() {
    tmp742_cast_fu_8127_p1 = esl_zext<3,2>(tmp489_fu_8121_p2.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp743_cast_fu_8137_p1() {
    tmp743_cast_fu_8137_p1 = esl_zext<3,2>(tmp490_fu_8131_p2.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp744_cast_fu_9312_p1() {
    tmp744_cast_fu_9312_p1 = esl_zext<4,3>(tmp495_reg_10614.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp745_cast_fu_8153_p1() {
    tmp745_cast_fu_8153_p1 = esl_zext<3,2>(tmp492_fu_8147_p2.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp746_cast_fu_8169_p1() {
    tmp746_cast_fu_8169_p1 = esl_zext<3,2>(tmp494_fu_8163_p2.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp74_fu_2067_p2() {
    tmp74_fu_2067_p2 = (p_Result_2_0_10_fu_1115_p3.read() ^ p_Result_211_10_fu_2059_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp75_fu_2091_p2() {
    tmp75_fu_2091_p2 = (p_Result_2_0_11_fu_1147_p3.read() ^ p_Result_211_11_fu_2083_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp76_fu_2111_p2() {
    tmp76_fu_2111_p2 = (p_Result_2_0_12_fu_1175_p3.read() ^ p_Result_211_12_fu_2103_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp77_fu_2131_p2() {
    tmp77_fu_2131_p2 = (p_Result_2_0_13_fu_1203_p3.read() ^ p_Result_211_13_fu_2123_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp78_fu_2151_p2() {
    tmp78_fu_2151_p2 = (p_Result_2_0_14_fu_1231_p3.read() ^ p_Result_211_14_fu_2143_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp79_fu_8472_p2() {
    tmp79_fu_8472_p2 = (!p_accu_V_2_fu_8318_p3.read().is_01() || !res_212_s_fu_8466_p1.read().is_01())? sc_lv<32>(): (sc_biguint<32>(p_accu_V_2_fu_8318_p3.read()) + sc_biguint<32>(res_212_s_fu_8466_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp7_fu_963_p2() {
    tmp7_fu_963_p2 = (p_Result_2_0_6_fu_955_p3.read() ^ p_Result_0_6_fu_947_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp80_fu_8478_p2() {
    tmp80_fu_8478_p2 = (!res_212_13_cast_fu_8469_p1.read().is_01() || !res_212_11_cast_fu_8463_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_212_13_cast_fu_8469_p1.read()) + sc_biguint<2>(res_212_11_cast_fu_8463_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp81_fu_8488_p2() {
    tmp81_fu_8488_p2 = (!tmp151_cast_fu_8484_p1.read().is_01() || !tmp79_fu_8472_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(tmp151_cast_fu_8484_p1.read()) + sc_biguint<32>(tmp79_fu_8472_p2.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp82_fu_2167_p2() {
    tmp82_fu_2167_p2 = (!res_212_10_cast_fu_2079_p1.read().is_01() || !res_212_8_cast_fu_2007_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_212_10_cast_fu_2079_p1.read()) + sc_biguint<2>(res_212_8_cast_fu_2007_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp83_fu_2177_p2() {
    tmp83_fu_2177_p2 = (!res_212_7_cast_fu_1983_p1.read().is_01() || !res_212_cast_fu_2055_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_212_7_cast_fu_1983_p1.read()) + sc_biguint<2>(res_212_cast_fu_2055_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp84_fu_2187_p2() {
    tmp84_fu_2187_p2 = (!tmp154_cast_fu_2183_p1.read().is_01() || !tmp153_cast_fu_2173_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp154_cast_fu_2183_p1.read()) + sc_biguint<3>(tmp153_cast_fu_2173_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp85_fu_8497_p2() {
    tmp85_fu_8497_p2 = (!tmp152_cast_fu_8494_p1.read().is_01() || !tmp81_fu_8488_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(tmp152_cast_fu_8494_p1.read()) + sc_biguint<32>(tmp81_fu_8488_p2.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp86_fu_2193_p2() {
    tmp86_fu_2193_p2 = (!res_212_9_cast_fu_2031_p1.read().is_01() || !res_cast_99_fu_1815_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_212_9_cast_fu_2031_p1.read()) + sc_biguint<2>(res_cast_99_fu_1815_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp87_fu_2203_p2() {
    tmp87_fu_2203_p2 = (!res_212_2_cast_fu_1863_p1.read().is_01() || !res_212_1_cast_fu_1839_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_212_2_cast_fu_1863_p1.read()) + sc_biguint<2>(res_212_1_cast_fu_1839_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp88_fu_2213_p2() {
    tmp88_fu_2213_p2 = (!tmp158_cast_fu_2209_p1.read().is_01() || !tmp157_cast_fu_2199_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp158_cast_fu_2209_p1.read()) + sc_biguint<3>(tmp157_cast_fu_2199_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp89_fu_2219_p2() {
    tmp89_fu_2219_p2 = (!res_212_4_cast_fu_1911_p1.read().is_01() || !res_212_3_cast_fu_1887_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_212_4_cast_fu_1911_p1.read()) + sc_biguint<2>(res_212_3_cast_fu_1887_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp8_fu_995_p2() {
    tmp8_fu_995_p2 = (p_Result_2_0_7_fu_987_p3.read() ^ p_Result_0_7_fu_979_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp90_fu_2229_p2() {
    tmp90_fu_2229_p2 = (!res_212_5_cast_fu_1935_p1.read().is_01() || !res_212_14_cast_fu_2163_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_212_5_cast_fu_1935_p1.read()) + sc_biguint<2>(res_212_14_cast_fu_2163_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp91_fu_2235_p2() {
    tmp91_fu_2235_p2 = (!tmp90_fu_2229_p2.read().is_01() || !res_212_6_cast_fu_1959_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(tmp90_fu_2229_p2.read()) + sc_biguint<2>(res_212_6_cast_fu_1959_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp92_fu_2245_p2() {
    tmp92_fu_2245_p2 = (!tmp161_cast_fu_2241_p1.read().is_01() || !tmp160_cast_fu_2225_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp161_cast_fu_2241_p1.read()) + sc_biguint<3>(tmp160_cast_fu_2225_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp93_fu_8509_p2() {
    tmp93_fu_8509_p2 = (!tmp159_cast_fu_8506_p1.read().is_01() || !tmp156_cast_fu_8503_p1.read().is_01())? sc_lv<4>(): (sc_biguint<4>(tmp159_cast_fu_8506_p1.read()) + sc_biguint<4>(tmp156_cast_fu_8503_p1.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp94_fu_2259_p2() {
    tmp94_fu_2259_p2 = (p_Result_2_fu_763_p3.read() ^ p_Result_3_fu_2251_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp95_fu_2283_p2() {
    tmp95_fu_2283_p2 = (p_Result_2_0_1_fu_795_p3.read() ^ p_Result_313_1_fu_2275_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp96_fu_2307_p2() {
    tmp96_fu_2307_p2 = (p_Result_2_0_2_fu_827_p3.read() ^ p_Result_313_2_fu_2299_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp97_fu_2331_p2() {
    tmp97_fu_2331_p2 = (p_Result_2_0_3_fu_859_p3.read() ^ p_Result_313_3_fu_2323_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp98_fu_2355_p2() {
    tmp98_fu_2355_p2 = (p_Result_2_0_4_fu_891_p3.read() ^ p_Result_313_4_fu_2347_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp99_fu_2379_p2() {
    tmp99_fu_2379_p2 = (p_Result_2_0_5_fu_923_p3.read() ^ p_Result_313_5_fu_2371_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp9_fu_1027_p2() {
    tmp9_fu_1027_p2 = (p_Result_2_0_8_fu_1019_p3.read() ^ p_Result_0_8_fu_1011_p3.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_11_fu_662_p1() {
    tmp_11_fu_662_p1 = esl_zext<64,32>(tile_assign_fu_208.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_0_10_fu_1129_p2() {
    tmp_12_0_10_fu_1129_p2 = (tmp12_fu_1123_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_0_11_fu_1161_p2() {
    tmp_12_0_11_fu_1161_p2 = (tmp13_fu_1155_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_0_12_fu_1189_p2() {
    tmp_12_0_12_fu_1189_p2 = (tmp14_fu_1183_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_0_13_fu_1217_p2() {
    tmp_12_0_13_fu_1217_p2 = (tmp15_fu_1211_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_0_14_fu_1245_p2() {
    tmp_12_0_14_fu_1245_p2 = (tmp16_fu_1239_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_0_1_fu_809_p2() {
    tmp_12_0_1_fu_809_p2 = (tmp2_fu_803_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_0_2_fu_841_p2() {
    tmp_12_0_2_fu_841_p2 = (tmp3_fu_835_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_0_3_fu_873_p2() {
    tmp_12_0_3_fu_873_p2 = (tmp4_fu_867_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_0_4_fu_905_p2() {
    tmp_12_0_4_fu_905_p2 = (tmp5_fu_899_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_0_5_fu_937_p2() {
    tmp_12_0_5_fu_937_p2 = (tmp6_fu_931_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_0_6_fu_969_p2() {
    tmp_12_0_6_fu_969_p2 = (tmp7_fu_963_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_0_7_fu_1001_p2() {
    tmp_12_0_7_fu_1001_p2 = (tmp8_fu_995_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_0_8_fu_1033_p2() {
    tmp_12_0_8_fu_1033_p2 = (tmp9_fu_1027_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_0_9_fu_1065_p2() {
    tmp_12_0_9_fu_1065_p2 = (tmp10_fu_1059_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_0_s_fu_1097_p2() {
    tmp_12_0_s_fu_1097_p2 = (tmp11_fu_1091_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_10_10_fu_5721_p2() {
    tmp_12_10_10_fu_5721_p2 = (tmp322_fu_5715_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_10_11_fu_5745_p2() {
    tmp_12_10_11_fu_5745_p2 = (tmp323_fu_5739_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_10_12_fu_5765_p2() {
    tmp_12_10_12_fu_5765_p2 = (tmp324_fu_5759_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_10_13_fu_5785_p2() {
    tmp_12_10_13_fu_5785_p2 = (tmp325_fu_5779_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_10_14_fu_5805_p2() {
    tmp_12_10_14_fu_5805_p2 = (tmp326_fu_5799_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_10_1_fu_5481_p2() {
    tmp_12_10_1_fu_5481_p2 = (tmp312_fu_5475_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_10_2_fu_5505_p2() {
    tmp_12_10_2_fu_5505_p2 = (tmp313_fu_5499_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_10_3_fu_5529_p2() {
    tmp_12_10_3_fu_5529_p2 = (tmp314_fu_5523_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_10_4_fu_5553_p2() {
    tmp_12_10_4_fu_5553_p2 = (tmp315_fu_5547_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_10_5_fu_5577_p2() {
    tmp_12_10_5_fu_5577_p2 = (tmp316_fu_5571_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_10_6_fu_5601_p2() {
    tmp_12_10_6_fu_5601_p2 = (tmp317_fu_5595_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_10_7_fu_5625_p2() {
    tmp_12_10_7_fu_5625_p2 = (tmp318_fu_5619_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_10_8_fu_5649_p2() {
    tmp_12_10_8_fu_5649_p2 = (tmp319_fu_5643_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_10_9_fu_5673_p2() {
    tmp_12_10_9_fu_5673_p2 = (tmp320_fu_5667_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_10_fu_5913_p2() {
    tmp_12_10_fu_5913_p2 = (tmp342_fu_5907_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_10_s_fu_5697_p2() {
    tmp_12_10_s_fu_5697_p2 = (tmp321_fu_5691_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_11_10_fu_6177_p2() {
    tmp_12_11_10_fu_6177_p2 = (tmp353_fu_6171_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_11_11_fu_6201_p2() {
    tmp_12_11_11_fu_6201_p2 = (tmp354_fu_6195_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_11_12_fu_6221_p2() {
    tmp_12_11_12_fu_6221_p2 = (tmp355_fu_6215_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_11_13_fu_6241_p2() {
    tmp_12_11_13_fu_6241_p2 = (tmp356_fu_6235_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_11_14_fu_6261_p2() {
    tmp_12_11_14_fu_6261_p2 = (tmp357_fu_6255_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_11_1_fu_5937_p2() {
    tmp_12_11_1_fu_5937_p2 = (tmp343_fu_5931_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_11_2_fu_5961_p2() {
    tmp_12_11_2_fu_5961_p2 = (tmp344_fu_5955_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_11_3_fu_5985_p2() {
    tmp_12_11_3_fu_5985_p2 = (tmp345_fu_5979_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_11_4_fu_6009_p2() {
    tmp_12_11_4_fu_6009_p2 = (tmp346_fu_6003_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_11_5_fu_6033_p2() {
    tmp_12_11_5_fu_6033_p2 = (tmp347_fu_6027_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_11_6_fu_6057_p2() {
    tmp_12_11_6_fu_6057_p2 = (tmp348_fu_6051_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_11_7_fu_6081_p2() {
    tmp_12_11_7_fu_6081_p2 = (tmp349_fu_6075_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_11_8_fu_6105_p2() {
    tmp_12_11_8_fu_6105_p2 = (tmp350_fu_6099_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_11_9_fu_6129_p2() {
    tmp_12_11_9_fu_6129_p2 = (tmp351_fu_6123_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_11_fu_6369_p2() {
    tmp_12_11_fu_6369_p2 = (tmp373_fu_6363_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_11_s_fu_6153_p2() {
    tmp_12_11_s_fu_6153_p2 = (tmp352_fu_6147_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_12_10_fu_6633_p2() {
    tmp_12_12_10_fu_6633_p2 = (tmp384_fu_6627_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_12_11_fu_6657_p2() {
    tmp_12_12_11_fu_6657_p2 = (tmp385_fu_6651_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_12_12_fu_6677_p2() {
    tmp_12_12_12_fu_6677_p2 = (tmp386_fu_6671_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_12_13_fu_6697_p2() {
    tmp_12_12_13_fu_6697_p2 = (tmp387_fu_6691_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_12_14_fu_6717_p2() {
    tmp_12_12_14_fu_6717_p2 = (tmp388_fu_6711_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_12_1_fu_6393_p2() {
    tmp_12_12_1_fu_6393_p2 = (tmp374_fu_6387_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_12_2_fu_6417_p2() {
    tmp_12_12_2_fu_6417_p2 = (tmp375_fu_6411_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_12_3_fu_6441_p2() {
    tmp_12_12_3_fu_6441_p2 = (tmp376_fu_6435_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_12_4_fu_6465_p2() {
    tmp_12_12_4_fu_6465_p2 = (tmp377_fu_6459_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_12_5_fu_6489_p2() {
    tmp_12_12_5_fu_6489_p2 = (tmp378_fu_6483_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_12_6_fu_6513_p2() {
    tmp_12_12_6_fu_6513_p2 = (tmp379_fu_6507_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_12_7_fu_6537_p2() {
    tmp_12_12_7_fu_6537_p2 = (tmp380_fu_6531_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_12_8_fu_6561_p2() {
    tmp_12_12_8_fu_6561_p2 = (tmp381_fu_6555_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_12_9_fu_6585_p2() {
    tmp_12_12_9_fu_6585_p2 = (tmp382_fu_6579_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_12_fu_6825_p2() {
    tmp_12_12_fu_6825_p2 = (tmp404_fu_6819_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_12_s_fu_6609_p2() {
    tmp_12_12_s_fu_6609_p2 = (tmp383_fu_6603_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_13_10_fu_7089_p2() {
    tmp_12_13_10_fu_7089_p2 = (tmp415_fu_7083_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_13_11_fu_7113_p2() {
    tmp_12_13_11_fu_7113_p2 = (tmp416_fu_7107_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_13_12_fu_7133_p2() {
    tmp_12_13_12_fu_7133_p2 = (tmp417_fu_7127_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_13_13_fu_7153_p2() {
    tmp_12_13_13_fu_7153_p2 = (tmp418_fu_7147_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_13_14_fu_7173_p2() {
    tmp_12_13_14_fu_7173_p2 = (tmp419_fu_7167_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_13_1_fu_6849_p2() {
    tmp_12_13_1_fu_6849_p2 = (tmp405_fu_6843_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_13_2_fu_6873_p2() {
    tmp_12_13_2_fu_6873_p2 = (tmp406_fu_6867_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_13_3_fu_6897_p2() {
    tmp_12_13_3_fu_6897_p2 = (tmp407_fu_6891_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_13_4_fu_6921_p2() {
    tmp_12_13_4_fu_6921_p2 = (tmp408_fu_6915_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_13_5_fu_6945_p2() {
    tmp_12_13_5_fu_6945_p2 = (tmp409_fu_6939_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_13_6_fu_6969_p2() {
    tmp_12_13_6_fu_6969_p2 = (tmp410_fu_6963_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_13_7_fu_6993_p2() {
    tmp_12_13_7_fu_6993_p2 = (tmp411_fu_6987_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_13_8_fu_7017_p2() {
    tmp_12_13_8_fu_7017_p2 = (tmp412_fu_7011_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_13_9_fu_7041_p2() {
    tmp_12_13_9_fu_7041_p2 = (tmp413_fu_7035_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_13_fu_7281_p2() {
    tmp_12_13_fu_7281_p2 = (tmp435_fu_7275_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_13_s_fu_7065_p2() {
    tmp_12_13_s_fu_7065_p2 = (tmp414_fu_7059_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_14_10_fu_7545_p2() {
    tmp_12_14_10_fu_7545_p2 = (tmp446_fu_7539_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_14_11_fu_7569_p2() {
    tmp_12_14_11_fu_7569_p2 = (tmp447_fu_7563_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_14_12_fu_7589_p2() {
    tmp_12_14_12_fu_7589_p2 = (tmp448_fu_7583_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_14_13_fu_7609_p2() {
    tmp_12_14_13_fu_7609_p2 = (tmp449_fu_7603_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_14_14_fu_7629_p2() {
    tmp_12_14_14_fu_7629_p2 = (tmp450_fu_7623_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_14_1_fu_7305_p2() {
    tmp_12_14_1_fu_7305_p2 = (tmp436_fu_7299_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_14_2_fu_7329_p2() {
    tmp_12_14_2_fu_7329_p2 = (tmp437_fu_7323_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_14_3_fu_7353_p2() {
    tmp_12_14_3_fu_7353_p2 = (tmp438_fu_7347_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_14_4_fu_7377_p2() {
    tmp_12_14_4_fu_7377_p2 = (tmp439_fu_7371_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_14_5_fu_7401_p2() {
    tmp_12_14_5_fu_7401_p2 = (tmp440_fu_7395_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_14_6_fu_7425_p2() {
    tmp_12_14_6_fu_7425_p2 = (tmp441_fu_7419_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_14_7_fu_7449_p2() {
    tmp_12_14_7_fu_7449_p2 = (tmp442_fu_7443_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_14_8_fu_7473_p2() {
    tmp_12_14_8_fu_7473_p2 = (tmp443_fu_7467_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_14_9_fu_7497_p2() {
    tmp_12_14_9_fu_7497_p2 = (tmp444_fu_7491_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_14_fu_7737_p2() {
    tmp_12_14_fu_7737_p2 = (tmp466_fu_7731_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_14_s_fu_7521_p2() {
    tmp_12_14_s_fu_7521_p2 = (tmp445_fu_7515_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_15_10_fu_8001_p2() {
    tmp_12_15_10_fu_8001_p2 = (tmp477_fu_7995_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_15_11_fu_8025_p2() {
    tmp_12_15_11_fu_8025_p2 = (tmp478_fu_8019_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_15_12_fu_8045_p2() {
    tmp_12_15_12_fu_8045_p2 = (tmp479_fu_8039_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_15_13_fu_8065_p2() {
    tmp_12_15_13_fu_8065_p2 = (tmp480_fu_8059_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_15_14_fu_8085_p2() {
    tmp_12_15_14_fu_8085_p2 = (tmp481_fu_8079_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_15_1_fu_7761_p2() {
    tmp_12_15_1_fu_7761_p2 = (tmp467_fu_7755_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_15_2_fu_7785_p2() {
    tmp_12_15_2_fu_7785_p2 = (tmp468_fu_7779_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_15_3_fu_7809_p2() {
    tmp_12_15_3_fu_7809_p2 = (tmp469_fu_7803_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_15_4_fu_7833_p2() {
    tmp_12_15_4_fu_7833_p2 = (tmp470_fu_7827_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_15_5_fu_7857_p2() {
    tmp_12_15_5_fu_7857_p2 = (tmp471_fu_7851_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_15_6_fu_7881_p2() {
    tmp_12_15_6_fu_7881_p2 = (tmp472_fu_7875_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_15_7_fu_7905_p2() {
    tmp_12_15_7_fu_7905_p2 = (tmp473_fu_7899_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_15_8_fu_7929_p2() {
    tmp_12_15_8_fu_7929_p2 = (tmp474_fu_7923_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_15_9_fu_7953_p2() {
    tmp_12_15_9_fu_7953_p2 = (tmp475_fu_7947_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_15_s_fu_7977_p2() {
    tmp_12_15_s_fu_7977_p2 = (tmp476_fu_7971_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_1_10_fu_1617_p2() {
    tmp_12_1_10_fu_1617_p2 = (tmp43_fu_1611_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_1_11_fu_1641_p2() {
    tmp_12_1_11_fu_1641_p2 = (tmp44_fu_1635_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_1_12_fu_1661_p2() {
    tmp_12_1_12_fu_1661_p2 = (tmp45_fu_1655_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_1_13_fu_1681_p2() {
    tmp_12_1_13_fu_1681_p2 = (tmp46_fu_1675_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_1_14_fu_1701_p2() {
    tmp_12_1_14_fu_1701_p2 = (tmp47_fu_1695_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_1_1_fu_1377_p2() {
    tmp_12_1_1_fu_1377_p2 = (tmp33_fu_1371_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_1_2_fu_1401_p2() {
    tmp_12_1_2_fu_1401_p2 = (tmp34_fu_1395_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_1_3_fu_1425_p2() {
    tmp_12_1_3_fu_1425_p2 = (tmp35_fu_1419_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_1_4_fu_1449_p2() {
    tmp_12_1_4_fu_1449_p2 = (tmp36_fu_1443_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_1_5_fu_1473_p2() {
    tmp_12_1_5_fu_1473_p2 = (tmp37_fu_1467_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_1_6_fu_1497_p2() {
    tmp_12_1_6_fu_1497_p2 = (tmp38_fu_1491_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_1_7_fu_1521_p2() {
    tmp_12_1_7_fu_1521_p2 = (tmp39_fu_1515_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_1_8_fu_1545_p2() {
    tmp_12_1_8_fu_1545_p2 = (tmp40_fu_1539_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_1_9_fu_1569_p2() {
    tmp_12_1_9_fu_1569_p2 = (tmp41_fu_1563_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_1_fu_1353_p2() {
    tmp_12_1_fu_1353_p2 = (tmp32_fu_1347_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_1_s_fu_1593_p2() {
    tmp_12_1_s_fu_1593_p2 = (tmp42_fu_1587_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_2_10_fu_2073_p2() {
    tmp_12_2_10_fu_2073_p2 = (tmp74_fu_2067_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_2_11_fu_2097_p2() {
    tmp_12_2_11_fu_2097_p2 = (tmp75_fu_2091_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_2_12_fu_2117_p2() {
    tmp_12_2_12_fu_2117_p2 = (tmp76_fu_2111_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_2_13_fu_2137_p2() {
    tmp_12_2_13_fu_2137_p2 = (tmp77_fu_2131_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_2_14_fu_2157_p2() {
    tmp_12_2_14_fu_2157_p2 = (tmp78_fu_2151_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_2_1_fu_1833_p2() {
    tmp_12_2_1_fu_1833_p2 = (tmp64_fu_1827_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_2_2_fu_1857_p2() {
    tmp_12_2_2_fu_1857_p2 = (tmp65_fu_1851_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_2_3_fu_1881_p2() {
    tmp_12_2_3_fu_1881_p2 = (tmp66_fu_1875_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_2_4_fu_1905_p2() {
    tmp_12_2_4_fu_1905_p2 = (tmp67_fu_1899_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_2_5_fu_1929_p2() {
    tmp_12_2_5_fu_1929_p2 = (tmp68_fu_1923_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_2_6_fu_1953_p2() {
    tmp_12_2_6_fu_1953_p2 = (tmp69_fu_1947_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_2_7_fu_1977_p2() {
    tmp_12_2_7_fu_1977_p2 = (tmp70_fu_1971_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_2_8_fu_2001_p2() {
    tmp_12_2_8_fu_2001_p2 = (tmp71_fu_1995_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_2_9_fu_2025_p2() {
    tmp_12_2_9_fu_2025_p2 = (tmp72_fu_2019_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_2_fu_1809_p2() {
    tmp_12_2_fu_1809_p2 = (tmp63_fu_1803_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_2_s_fu_2049_p2() {
    tmp_12_2_s_fu_2049_p2 = (tmp73_fu_2043_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_3_10_fu_2529_p2() {
    tmp_12_3_10_fu_2529_p2 = (tmp105_fu_2523_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_3_11_fu_2553_p2() {
    tmp_12_3_11_fu_2553_p2 = (tmp106_fu_2547_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_3_12_fu_2573_p2() {
    tmp_12_3_12_fu_2573_p2 = (tmp107_fu_2567_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_3_13_fu_2593_p2() {
    tmp_12_3_13_fu_2593_p2 = (tmp108_fu_2587_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_3_14_fu_2613_p2() {
    tmp_12_3_14_fu_2613_p2 = (tmp109_fu_2607_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_3_1_fu_2289_p2() {
    tmp_12_3_1_fu_2289_p2 = (tmp95_fu_2283_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_3_2_fu_2313_p2() {
    tmp_12_3_2_fu_2313_p2 = (tmp96_fu_2307_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_3_3_fu_2337_p2() {
    tmp_12_3_3_fu_2337_p2 = (tmp97_fu_2331_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_3_4_fu_2361_p2() {
    tmp_12_3_4_fu_2361_p2 = (tmp98_fu_2355_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_3_5_fu_2385_p2() {
    tmp_12_3_5_fu_2385_p2 = (tmp99_fu_2379_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_3_6_fu_2409_p2() {
    tmp_12_3_6_fu_2409_p2 = (tmp100_fu_2403_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_3_7_fu_2433_p2() {
    tmp_12_3_7_fu_2433_p2 = (tmp101_fu_2427_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_3_8_fu_2457_p2() {
    tmp_12_3_8_fu_2457_p2 = (tmp102_fu_2451_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_3_9_fu_2481_p2() {
    tmp_12_3_9_fu_2481_p2 = (tmp103_fu_2475_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_3_fu_2265_p2() {
    tmp_12_3_fu_2265_p2 = (tmp94_fu_2259_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_3_s_fu_2505_p2() {
    tmp_12_3_s_fu_2505_p2 = (tmp104_fu_2499_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_4_10_fu_2985_p2() {
    tmp_12_4_10_fu_2985_p2 = (tmp136_fu_2979_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_4_11_fu_3009_p2() {
    tmp_12_4_11_fu_3009_p2 = (tmp137_fu_3003_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_4_12_fu_3029_p2() {
    tmp_12_4_12_fu_3029_p2 = (tmp138_fu_3023_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_4_13_fu_3049_p2() {
    tmp_12_4_13_fu_3049_p2 = (tmp139_fu_3043_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_4_14_fu_3069_p2() {
    tmp_12_4_14_fu_3069_p2 = (tmp140_fu_3063_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_4_1_fu_2745_p2() {
    tmp_12_4_1_fu_2745_p2 = (tmp126_fu_2739_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_4_2_fu_2769_p2() {
    tmp_12_4_2_fu_2769_p2 = (tmp127_fu_2763_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_4_3_fu_2793_p2() {
    tmp_12_4_3_fu_2793_p2 = (tmp128_fu_2787_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_4_4_fu_2817_p2() {
    tmp_12_4_4_fu_2817_p2 = (tmp129_fu_2811_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_4_5_fu_2841_p2() {
    tmp_12_4_5_fu_2841_p2 = (tmp130_fu_2835_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_4_6_fu_2865_p2() {
    tmp_12_4_6_fu_2865_p2 = (tmp131_fu_2859_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_4_7_fu_2889_p2() {
    tmp_12_4_7_fu_2889_p2 = (tmp132_fu_2883_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_4_8_fu_2913_p2() {
    tmp_12_4_8_fu_2913_p2 = (tmp133_fu_2907_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_4_9_fu_2937_p2() {
    tmp_12_4_9_fu_2937_p2 = (tmp134_fu_2931_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_4_fu_2721_p2() {
    tmp_12_4_fu_2721_p2 = (tmp125_fu_2715_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_4_s_fu_2961_p2() {
    tmp_12_4_s_fu_2961_p2 = (tmp135_fu_2955_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_5_10_fu_3441_p2() {
    tmp_12_5_10_fu_3441_p2 = (tmp167_fu_3435_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_5_11_fu_3465_p2() {
    tmp_12_5_11_fu_3465_p2 = (tmp168_fu_3459_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_5_12_fu_3485_p2() {
    tmp_12_5_12_fu_3485_p2 = (tmp169_fu_3479_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_5_13_fu_3505_p2() {
    tmp_12_5_13_fu_3505_p2 = (tmp170_fu_3499_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_5_14_fu_3525_p2() {
    tmp_12_5_14_fu_3525_p2 = (tmp171_fu_3519_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_5_1_fu_3201_p2() {
    tmp_12_5_1_fu_3201_p2 = (tmp157_fu_3195_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_5_2_fu_3225_p2() {
    tmp_12_5_2_fu_3225_p2 = (tmp158_fu_3219_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_5_3_fu_3249_p2() {
    tmp_12_5_3_fu_3249_p2 = (tmp159_fu_3243_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_5_4_fu_3273_p2() {
    tmp_12_5_4_fu_3273_p2 = (tmp160_fu_3267_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_5_5_fu_3297_p2() {
    tmp_12_5_5_fu_3297_p2 = (tmp161_fu_3291_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_5_6_fu_3321_p2() {
    tmp_12_5_6_fu_3321_p2 = (tmp162_fu_3315_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_5_7_fu_3345_p2() {
    tmp_12_5_7_fu_3345_p2 = (tmp163_fu_3339_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_5_8_fu_3369_p2() {
    tmp_12_5_8_fu_3369_p2 = (tmp164_fu_3363_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_5_9_fu_3393_p2() {
    tmp_12_5_9_fu_3393_p2 = (tmp165_fu_3387_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_5_fu_3177_p2() {
    tmp_12_5_fu_3177_p2 = (tmp156_fu_3171_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_5_s_fu_3417_p2() {
    tmp_12_5_s_fu_3417_p2 = (tmp166_fu_3411_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_6_10_fu_3897_p2() {
    tmp_12_6_10_fu_3897_p2 = (tmp198_fu_3891_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_6_11_fu_3921_p2() {
    tmp_12_6_11_fu_3921_p2 = (tmp199_fu_3915_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_6_12_fu_3941_p2() {
    tmp_12_6_12_fu_3941_p2 = (tmp200_fu_3935_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_6_13_fu_3961_p2() {
    tmp_12_6_13_fu_3961_p2 = (tmp201_fu_3955_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_6_14_fu_3981_p2() {
    tmp_12_6_14_fu_3981_p2 = (tmp202_fu_3975_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_6_1_fu_3657_p2() {
    tmp_12_6_1_fu_3657_p2 = (tmp188_fu_3651_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_6_2_fu_3681_p2() {
    tmp_12_6_2_fu_3681_p2 = (tmp189_fu_3675_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_6_3_fu_3705_p2() {
    tmp_12_6_3_fu_3705_p2 = (tmp190_fu_3699_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_6_4_fu_3729_p2() {
    tmp_12_6_4_fu_3729_p2 = (tmp191_fu_3723_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_6_5_fu_3753_p2() {
    tmp_12_6_5_fu_3753_p2 = (tmp192_fu_3747_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_6_6_fu_3777_p2() {
    tmp_12_6_6_fu_3777_p2 = (tmp193_fu_3771_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_6_7_fu_3801_p2() {
    tmp_12_6_7_fu_3801_p2 = (tmp194_fu_3795_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_6_8_fu_3825_p2() {
    tmp_12_6_8_fu_3825_p2 = (tmp195_fu_3819_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_6_9_fu_3849_p2() {
    tmp_12_6_9_fu_3849_p2 = (tmp196_fu_3843_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_6_fu_3633_p2() {
    tmp_12_6_fu_3633_p2 = (tmp187_fu_3627_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_6_s_fu_3873_p2() {
    tmp_12_6_s_fu_3873_p2 = (tmp197_fu_3867_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_7_10_fu_4353_p2() {
    tmp_12_7_10_fu_4353_p2 = (tmp229_fu_4347_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_7_11_fu_4377_p2() {
    tmp_12_7_11_fu_4377_p2 = (tmp230_fu_4371_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_7_12_fu_4397_p2() {
    tmp_12_7_12_fu_4397_p2 = (tmp231_fu_4391_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_7_13_fu_4417_p2() {
    tmp_12_7_13_fu_4417_p2 = (tmp232_fu_4411_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_7_14_fu_4437_p2() {
    tmp_12_7_14_fu_4437_p2 = (tmp233_fu_4431_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_7_1_fu_4113_p2() {
    tmp_12_7_1_fu_4113_p2 = (tmp219_fu_4107_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_7_2_fu_4137_p2() {
    tmp_12_7_2_fu_4137_p2 = (tmp220_fu_4131_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_7_3_fu_4161_p2() {
    tmp_12_7_3_fu_4161_p2 = (tmp221_fu_4155_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_7_4_fu_4185_p2() {
    tmp_12_7_4_fu_4185_p2 = (tmp222_fu_4179_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_7_5_fu_4209_p2() {
    tmp_12_7_5_fu_4209_p2 = (tmp223_fu_4203_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_7_6_fu_4233_p2() {
    tmp_12_7_6_fu_4233_p2 = (tmp224_fu_4227_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_7_7_fu_4257_p2() {
    tmp_12_7_7_fu_4257_p2 = (tmp225_fu_4251_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_7_8_fu_4281_p2() {
    tmp_12_7_8_fu_4281_p2 = (tmp226_fu_4275_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_7_9_fu_4305_p2() {
    tmp_12_7_9_fu_4305_p2 = (tmp227_fu_4299_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_7_fu_4089_p2() {
    tmp_12_7_fu_4089_p2 = (tmp218_fu_4083_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_7_s_fu_4329_p2() {
    tmp_12_7_s_fu_4329_p2 = (tmp228_fu_4323_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_8_10_fu_4809_p2() {
    tmp_12_8_10_fu_4809_p2 = (tmp260_fu_4803_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_8_11_fu_4833_p2() {
    tmp_12_8_11_fu_4833_p2 = (tmp261_fu_4827_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_8_12_fu_4853_p2() {
    tmp_12_8_12_fu_4853_p2 = (tmp262_fu_4847_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_8_13_fu_4873_p2() {
    tmp_12_8_13_fu_4873_p2 = (tmp263_fu_4867_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_8_14_fu_4893_p2() {
    tmp_12_8_14_fu_4893_p2 = (tmp264_fu_4887_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_8_1_fu_4569_p2() {
    tmp_12_8_1_fu_4569_p2 = (tmp250_fu_4563_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_8_2_fu_4593_p2() {
    tmp_12_8_2_fu_4593_p2 = (tmp251_fu_4587_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_8_3_fu_4617_p2() {
    tmp_12_8_3_fu_4617_p2 = (tmp252_fu_4611_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_8_4_fu_4641_p2() {
    tmp_12_8_4_fu_4641_p2 = (tmp253_fu_4635_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_8_5_fu_4665_p2() {
    tmp_12_8_5_fu_4665_p2 = (tmp254_fu_4659_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_8_6_fu_4689_p2() {
    tmp_12_8_6_fu_4689_p2 = (tmp255_fu_4683_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_8_7_fu_4713_p2() {
    tmp_12_8_7_fu_4713_p2 = (tmp256_fu_4707_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_8_8_fu_4737_p2() {
    tmp_12_8_8_fu_4737_p2 = (tmp257_fu_4731_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_8_9_fu_4761_p2() {
    tmp_12_8_9_fu_4761_p2 = (tmp258_fu_4755_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_8_fu_4545_p2() {
    tmp_12_8_fu_4545_p2 = (tmp249_fu_4539_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_8_s_fu_4785_p2() {
    tmp_12_8_s_fu_4785_p2 = (tmp259_fu_4779_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_9_10_fu_5265_p2() {
    tmp_12_9_10_fu_5265_p2 = (tmp291_fu_5259_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_9_11_fu_5289_p2() {
    tmp_12_9_11_fu_5289_p2 = (tmp292_fu_5283_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_9_12_fu_5309_p2() {
    tmp_12_9_12_fu_5309_p2 = (tmp293_fu_5303_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_9_13_fu_5329_p2() {
    tmp_12_9_13_fu_5329_p2 = (tmp294_fu_5323_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_9_14_fu_5349_p2() {
    tmp_12_9_14_fu_5349_p2 = (tmp295_fu_5343_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_9_1_fu_5025_p2() {
    tmp_12_9_1_fu_5025_p2 = (tmp281_fu_5019_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_9_2_fu_5049_p2() {
    tmp_12_9_2_fu_5049_p2 = (tmp282_fu_5043_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_9_3_fu_5073_p2() {
    tmp_12_9_3_fu_5073_p2 = (tmp283_fu_5067_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_9_4_fu_5097_p2() {
    tmp_12_9_4_fu_5097_p2 = (tmp284_fu_5091_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_9_5_fu_5121_p2() {
    tmp_12_9_5_fu_5121_p2 = (tmp285_fu_5115_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_9_6_fu_5145_p2() {
    tmp_12_9_6_fu_5145_p2 = (tmp286_fu_5139_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_9_7_fu_5169_p2() {
    tmp_12_9_7_fu_5169_p2 = (tmp287_fu_5163_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_9_8_fu_5193_p2() {
    tmp_12_9_8_fu_5193_p2 = (tmp288_fu_5187_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_9_9_fu_5217_p2() {
    tmp_12_9_9_fu_5217_p2 = (tmp289_fu_5211_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_9_fu_5001_p2() {
    tmp_12_9_fu_5001_p2 = (tmp280_fu_4995_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_9_s_fu_5241_p2() {
    tmp_12_9_s_fu_5241_p2 = (tmp290_fu_5235_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_12_s_fu_5457_p2() {
    tmp_12_s_fu_5457_p2 = (tmp311_fu_5451_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_261_fu_777_p2() {
    tmp_261_fu_777_p2 = (tmp1_fu_771_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_262_fu_546_p1() {
    tmp_262_fu_546_p1 = sf_fu_212.read().range(2-1, 0);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_2_fu_723_p2() {
    tmp_2_fu_723_p2 = (!nf_fu_717_p2.read().is_01() || !ap_const_lv32_4.is_01())? sc_lv<1>(): sc_lv<1>(nf_fu_717_p2.read() == ap_const_lv32_4);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_497_fu_713_p1() {
    tmp_497_fu_713_p1 = nf_assign_fu_216.read().range(2-1, 0);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_4_fu_656_p2() {
    tmp_4_fu_656_p2 = (!sf_fu_212.read().is_01() || !ap_const_lv32_0.is_01())? sc_lv<1>(): sc_lv<1>(sf_fu_212.read() == ap_const_lv32_0);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_fu_507_p2() {
    tmp_fu_507_p2 = (!nf_assign_fu_216.read().is_01() || !ap_const_lv32_0.is_01())? sc_lv<1>(): sc_lv<1>(nf_assign_fu_216.read() == ap_const_lv32_0);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_tmp_s_fu_694_p2() {
    tmp_s_fu_694_p2 = (!sf_1_fu_688_p2.read().is_01() || !ap_const_lv32_4.is_01())? sc_lv<1>(): sc_lv<1>(sf_1_fu_688_p2.read() == ap_const_lv32_4);
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_ult10_fu_9674_p2() {
    ult10_fu_9674_p2 = (!accu_10_V_fu_9015_p2.read().is_01() || !p_x_V_read_assign_s_fu_9661_p6.read().is_01())? sc_lv<1>(): (sc_biguint<32>(accu_10_V_fu_9015_p2.read()) < sc_biguint<32>(p_x_V_read_assign_s_fu_9661_p6.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_ult11_fu_9699_p2() {
    ult11_fu_9699_p2 = (!accu_11_V_fu_9077_p2.read().is_01() || !p_x_V_read_assign_10_fu_9686_p6.read().is_01())? sc_lv<1>(): (sc_biguint<32>(accu_11_V_fu_9077_p2.read()) < sc_biguint<32>(p_x_V_read_assign_10_fu_9686_p6.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_ult12_fu_9724_p2() {
    ult12_fu_9724_p2 = (!accu_12_V_fu_9139_p2.read().is_01() || !p_x_V_read_assign_11_fu_9711_p6.read().is_01())? sc_lv<1>(): (sc_biguint<32>(accu_12_V_fu_9139_p2.read()) < sc_biguint<32>(p_x_V_read_assign_11_fu_9711_p6.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_ult13_fu_9749_p2() {
    ult13_fu_9749_p2 = (!accu_13_V_fu_9201_p2.read().is_01() || !p_x_V_read_assign_12_fu_9736_p6.read().is_01())? sc_lv<1>(): (sc_biguint<32>(accu_13_V_fu_9201_p2.read()) < sc_biguint<32>(p_x_V_read_assign_12_fu_9736_p6.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_ult14_fu_9774_p2() {
    ult14_fu_9774_p2 = (!accu_14_V_fu_9263_p2.read().is_01() || !p_x_V_read_assign_13_fu_9761_p6.read().is_01())? sc_lv<1>(): (sc_biguint<32>(accu_14_V_fu_9263_p2.read()) < sc_biguint<32>(p_x_V_read_assign_13_fu_9761_p6.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_ult15_fu_9799_p2() {
    ult15_fu_9799_p2 = (!accu_15_V_fu_9325_p2.read().is_01() || !p_x_V_read_assign_14_fu_9786_p6.read().is_01())? sc_lv<1>(): (sc_biguint<32>(accu_15_V_fu_9325_p2.read()) < sc_biguint<32>(p_x_V_read_assign_14_fu_9786_p6.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_ult1_fu_9449_p2() {
    ult1_fu_9449_p2 = (!accu_1_V_fu_8457_p2.read().is_01() || !p_x_V_read_assign_1_fu_9436_p6.read().is_01())? sc_lv<1>(): (sc_biguint<32>(accu_1_V_fu_8457_p2.read()) < sc_biguint<32>(p_x_V_read_assign_1_fu_9436_p6.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_ult2_fu_9474_p2() {
    ult2_fu_9474_p2 = (!accu_2_V_fu_8519_p2.read().is_01() || !p_x_V_read_assign_2_fu_9461_p6.read().is_01())? sc_lv<1>(): (sc_biguint<32>(accu_2_V_fu_8519_p2.read()) < sc_biguint<32>(p_x_V_read_assign_2_fu_9461_p6.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_ult3_fu_9499_p2() {
    ult3_fu_9499_p2 = (!accu_3_V_fu_8581_p2.read().is_01() || !p_x_V_read_assign_3_fu_9486_p6.read().is_01())? sc_lv<1>(): (sc_biguint<32>(accu_3_V_fu_8581_p2.read()) < sc_biguint<32>(p_x_V_read_assign_3_fu_9486_p6.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_ult4_fu_9524_p2() {
    ult4_fu_9524_p2 = (!accu_4_V_fu_8643_p2.read().is_01() || !p_x_V_read_assign_4_fu_9511_p6.read().is_01())? sc_lv<1>(): (sc_biguint<32>(accu_4_V_fu_8643_p2.read()) < sc_biguint<32>(p_x_V_read_assign_4_fu_9511_p6.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_ult5_fu_9549_p2() {
    ult5_fu_9549_p2 = (!accu_5_V_fu_8705_p2.read().is_01() || !p_x_V_read_assign_5_fu_9536_p6.read().is_01())? sc_lv<1>(): (sc_biguint<32>(accu_5_V_fu_8705_p2.read()) < sc_biguint<32>(p_x_V_read_assign_5_fu_9536_p6.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_ult6_fu_9574_p2() {
    ult6_fu_9574_p2 = (!accu_6_V_fu_8767_p2.read().is_01() || !p_x_V_read_assign_6_fu_9561_p6.read().is_01())? sc_lv<1>(): (sc_biguint<32>(accu_6_V_fu_8767_p2.read()) < sc_biguint<32>(p_x_V_read_assign_6_fu_9561_p6.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_ult7_fu_9599_p2() {
    ult7_fu_9599_p2 = (!accu_7_V_fu_8829_p2.read().is_01() || !p_x_V_read_assign_7_fu_9586_p6.read().is_01())? sc_lv<1>(): (sc_biguint<32>(accu_7_V_fu_8829_p2.read()) < sc_biguint<32>(p_x_V_read_assign_7_fu_9586_p6.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_ult8_fu_9624_p2() {
    ult8_fu_9624_p2 = (!accu_8_V_fu_8891_p2.read().is_01() || !p_x_V_read_assign_8_fu_9611_p6.read().is_01())? sc_lv<1>(): (sc_biguint<32>(accu_8_V_fu_8891_p2.read()) < sc_biguint<32>(p_x_V_read_assign_8_fu_9611_p6.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_ult9_fu_9649_p2() {
    ult9_fu_9649_p2 = (!accu_9_V_fu_8953_p2.read().is_01() || !p_x_V_read_assign_9_fu_9636_p6.read().is_01())? sc_lv<1>(): (sc_biguint<32>(accu_9_V_fu_8953_p2.read()) < sc_biguint<32>(p_x_V_read_assign_9_fu_9636_p6.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_ult_fu_9424_p2() {
    ult_fu_9424_p2 = (!accu_0_V_fu_8395_p2.read().is_01() || !p_x_V_read_assign_fu_9411_p6.read().is_01())? sc_lv<1>(): (sc_biguint<32>(accu_0_V_fu_8395_p2.read()) < sc_biguint<32>(p_x_V_read_assign_fu_9411_p6.read()));
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_weights_m_weights_V_10_address0() {
    weights_m_weights_V_10_address0 =  (sc_lv<4>) (tmp_11_fu_662_p1.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_weights_m_weights_V_10_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        weights_m_weights_V_10_ce0 = ap_const_logic_1;
    } else {
        weights_m_weights_V_10_ce0 = ap_const_logic_0;
    }
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_weights_m_weights_V_11_address0() {
    weights_m_weights_V_11_address0 =  (sc_lv<4>) (tmp_11_fu_662_p1.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_weights_m_weights_V_11_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        weights_m_weights_V_11_ce0 = ap_const_logic_1;
    } else {
        weights_m_weights_V_11_ce0 = ap_const_logic_0;
    }
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_weights_m_weights_V_12_address0() {
    weights_m_weights_V_12_address0 =  (sc_lv<4>) (tmp_11_fu_662_p1.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_weights_m_weights_V_12_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        weights_m_weights_V_12_ce0 = ap_const_logic_1;
    } else {
        weights_m_weights_V_12_ce0 = ap_const_logic_0;
    }
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_weights_m_weights_V_13_address0() {
    weights_m_weights_V_13_address0 =  (sc_lv<4>) (tmp_11_fu_662_p1.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_weights_m_weights_V_13_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        weights_m_weights_V_13_ce0 = ap_const_logic_1;
    } else {
        weights_m_weights_V_13_ce0 = ap_const_logic_0;
    }
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_weights_m_weights_V_14_address0() {
    weights_m_weights_V_14_address0 =  (sc_lv<4>) (tmp_11_fu_662_p1.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_weights_m_weights_V_14_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        weights_m_weights_V_14_ce0 = ap_const_logic_1;
    } else {
        weights_m_weights_V_14_ce0 = ap_const_logic_0;
    }
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_weights_m_weights_V_15_address0() {
    weights_m_weights_V_15_address0 =  (sc_lv<4>) (tmp_11_fu_662_p1.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_weights_m_weights_V_15_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        weights_m_weights_V_15_ce0 = ap_const_logic_1;
    } else {
        weights_m_weights_V_15_ce0 = ap_const_logic_0;
    }
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_weights_m_weights_V_1_address0() {
    weights_m_weights_V_1_address0 =  (sc_lv<4>) (tmp_11_fu_662_p1.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_weights_m_weights_V_1_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        weights_m_weights_V_1_ce0 = ap_const_logic_1;
    } else {
        weights_m_weights_V_1_ce0 = ap_const_logic_0;
    }
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_weights_m_weights_V_2_address0() {
    weights_m_weights_V_2_address0 =  (sc_lv<4>) (tmp_11_fu_662_p1.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_weights_m_weights_V_2_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        weights_m_weights_V_2_ce0 = ap_const_logic_1;
    } else {
        weights_m_weights_V_2_ce0 = ap_const_logic_0;
    }
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_weights_m_weights_V_3_address0() {
    weights_m_weights_V_3_address0 =  (sc_lv<4>) (tmp_11_fu_662_p1.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_weights_m_weights_V_3_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        weights_m_weights_V_3_ce0 = ap_const_logic_1;
    } else {
        weights_m_weights_V_3_ce0 = ap_const_logic_0;
    }
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_weights_m_weights_V_4_address0() {
    weights_m_weights_V_4_address0 =  (sc_lv<4>) (tmp_11_fu_662_p1.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_weights_m_weights_V_4_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        weights_m_weights_V_4_ce0 = ap_const_logic_1;
    } else {
        weights_m_weights_V_4_ce0 = ap_const_logic_0;
    }
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_weights_m_weights_V_5_address0() {
    weights_m_weights_V_5_address0 =  (sc_lv<4>) (tmp_11_fu_662_p1.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_weights_m_weights_V_5_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        weights_m_weights_V_5_ce0 = ap_const_logic_1;
    } else {
        weights_m_weights_V_5_ce0 = ap_const_logic_0;
    }
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_weights_m_weights_V_6_address0() {
    weights_m_weights_V_6_address0 =  (sc_lv<4>) (tmp_11_fu_662_p1.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_weights_m_weights_V_6_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        weights_m_weights_V_6_ce0 = ap_const_logic_1;
    } else {
        weights_m_weights_V_6_ce0 = ap_const_logic_0;
    }
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_weights_m_weights_V_7_address0() {
    weights_m_weights_V_7_address0 =  (sc_lv<4>) (tmp_11_fu_662_p1.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_weights_m_weights_V_7_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        weights_m_weights_V_7_ce0 = ap_const_logic_1;
    } else {
        weights_m_weights_V_7_ce0 = ap_const_logic_0;
    }
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_weights_m_weights_V_8_address0() {
    weights_m_weights_V_8_address0 =  (sc_lv<4>) (tmp_11_fu_662_p1.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_weights_m_weights_V_8_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        weights_m_weights_V_8_ce0 = ap_const_logic_1;
    } else {
        weights_m_weights_V_8_ce0 = ap_const_logic_0;
    }
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_weights_m_weights_V_9_address0() {
    weights_m_weights_V_9_address0 =  (sc_lv<4>) (tmp_11_fu_662_p1.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_weights_m_weights_V_9_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        weights_m_weights_V_9_ce0 = ap_const_logic_1;
    } else {
        weights_m_weights_V_9_ce0 = ap_const_logic_0;
    }
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_weights_m_weights_V_s_address0() {
    weights_m_weights_V_s_address0 =  (sc_lv<4>) (tmp_11_fu_662_p1.read());
}

void StreamingFCLayer_Batch_2_Matrix_Vector_Activa::thread_weights_m_weights_V_s_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        weights_m_weights_V_s_ce0 = ap_const_logic_1;
    } else {
        weights_m_weights_V_s_ce0 = ap_const_logic_0;
    }
}

}

