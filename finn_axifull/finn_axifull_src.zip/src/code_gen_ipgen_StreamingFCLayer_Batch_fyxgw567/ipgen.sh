#!/bin/bash 
cd /workspace/finn/tmp/finn_user-bibo/code_gen_ipgen_StreamingFCLayer_Batch_fyxgw567
vivado_hls /workspace/finn/tmp/finn_user-bibo/code_gen_ipgen_StreamingFCLayer_Batch_fyxgw567/hls_syn_StreamingFCLayer_Batch_1.tcl
cd /workspace/finn
