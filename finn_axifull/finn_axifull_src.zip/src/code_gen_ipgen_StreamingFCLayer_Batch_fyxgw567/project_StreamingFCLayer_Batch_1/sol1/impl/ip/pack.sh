# ==============================================================
# File generated on Fri Jun 19 23:27:29 +0000 2020
# Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2018.3 (64-bit)
# SW Build 2405991 on Thu Dec  6 23:36:41 MST 2018
# IP Build 2404404 on Fri Dec  7 01:43:56 MST 2018
# Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
# ==============================================================

/home/share/eda/xilinx/Vivado/2018.3/bin/vivado  -notrace -mode batch -source run_ippack.tcl
