#include "StreamingFCLayer_Batch_1_Matrix_Vector_Activa.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_ap_clk_no_reset_() {
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_CS_fsm = ap_ST_fsm_state1;
    } else {
        ap_CS_fsm = ap_NS_fsm.read();
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_enable_reg_pp0_iter0 = ap_const_logic_0;
    } else {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage0_subdone.read(), ap_const_boolean_0) && 
             esl_seteq<1,1,1>(ap_const_logic_1, ap_condition_pp0_exit_iter0_state2.read()))) {
            ap_enable_reg_pp0_iter0 = ap_const_logic_0;
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
                    esl_seteq<1,1,1>(ap_start.read(), ap_const_logic_1))) {
            ap_enable_reg_pp0_iter0 = ap_const_logic_1;
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_enable_reg_pp0_iter1 = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_block_pp0_stage0_subdone.read(), ap_const_boolean_0)) {
            if (esl_seteq<1,1,1>(ap_const_logic_1, ap_condition_pp0_exit_iter0_state2.read())) {
                ap_enable_reg_pp0_iter1 = (ap_condition_pp0_exit_iter0_state2.read() ^ ap_const_logic_1);
            } else if (esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1)) {
                ap_enable_reg_pp0_iter1 = ap_enable_reg_pp0_iter0.read();
            }
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_enable_reg_pp0_iter2 = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_block_pp0_stage0_subdone.read(), ap_const_boolean_0)) {
            ap_enable_reg_pp0_iter2 = ap_enable_reg_pp0_iter1.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
                    esl_seteq<1,1,1>(ap_start.read(), ap_const_logic_1))) {
            ap_enable_reg_pp0_iter2 = ap_const_logic_0;
        }
    }
    if (esl_seteq<1,1,1>(ap_condition_198.read(), ap_const_boolean_1)) {
        if ((esl_seteq<1,1,1>(exitcond_fu_510_p2.read(), ap_const_lv1_0) && 
             esl_seteq<1,1,1>(ap_const_lv1_0, tmp_fu_525_p2.read()))) {
            ap_phi_reg_pp0_iter1_act_m_val_V_reg_486 = inElem_V_fu_550_p6.read();
        } else if ((esl_seteq<1,1,1>(exitcond_fu_510_p2.read(), ap_const_lv1_0) && 
                    esl_seteq<1,1,1>(tmp_fu_525_p2.read(), ap_const_lv1_1))) {
            ap_phi_reg_pp0_iter1_act_m_val_V_reg_486 = in_V_V_TDATA.read();
        } else if (esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1)) {
            ap_phi_reg_pp0_iter1_act_m_val_V_reg_486 = ap_phi_reg_pp0_iter0_act_m_val_V_reg_486.read();
        }
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(exitcond_fu_510_p2.read(), ap_const_lv1_0) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        i_reg_475 = i_1_fu_516_p2.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
                esl_seteq<1,1,1>(ap_start.read(), ap_const_logic_1))) {
        i_reg_475 = ap_const_lv5_0;
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(exitcond_fu_510_p2.read(), ap_const_lv1_0) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_lv1_1, tmp_s_fu_712_p2.read()))) {
        nf_assign_fu_234 = p_s_fu_747_p3.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
                esl_seteq<1,1,1>(ap_start.read(), ap_const_logic_1))) {
        nf_assign_fu_234 = ap_const_lv32_0;
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(exitcond_fu_510_p2.read(), ap_const_lv1_0) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, tmp_s_fu_712_p2.read()))) {
        sf_fu_230 = sf_1_fu_706_p2.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
                 esl_seteq<1,1,1>(ap_start.read(), ap_const_logic_1)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(exitcond_fu_510_p2.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
                 esl_seteq<1,1,1>(ap_const_lv1_1, tmp_s_fu_712_p2.read())))) {
        sf_fu_230 = ap_const_lv32_0;
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(exitcond_fu_510_p2.read(), ap_const_lv1_0) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_lv1_1, tmp_s_fu_712_p2.read()))) {
        tile_assign_fu_226 = p_1_fu_755_p3.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(exitcond_fu_510_p2.read(), ap_const_lv1_0) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, tmp_s_fu_712_p2.read()))) {
        tile_assign_fu_226 = tile_fu_700_p2.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
                esl_seteq<1,1,1>(ap_start.read(), ap_const_logic_1))) {
        tile_assign_fu_226 = ap_const_lv32_0;
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        accu_V_10_fu_202 = accu_10_V_fu_9033_p2.read();
        accu_V_11_fu_206 = accu_11_V_fu_9095_p2.read();
        accu_V_12_fu_210 = accu_12_V_fu_9157_p2.read();
        accu_V_13_fu_214 = accu_13_V_fu_9219_p2.read();
        accu_V_14_fu_218 = accu_14_V_fu_9281_p2.read();
        accu_V_1_fu_166 = accu_1_V_fu_8475_p2.read();
        accu_V_2_fu_170 = accu_2_V_fu_8537_p2.read();
        accu_V_3_fu_174 = accu_3_V_fu_8599_p2.read();
        accu_V_4_fu_178 = accu_4_V_fu_8661_p2.read();
        accu_V_5_fu_182 = accu_5_V_fu_8723_p2.read();
        accu_V_6_fu_186 = accu_6_V_fu_8785_p2.read();
        accu_V_7_fu_190 = accu_7_V_fu_8847_p2.read();
        accu_V_8_fu_194 = accu_8_V_fu_8909_p2.read();
        accu_V_9_fu_198 = accu_9_V_fu_8971_p2.read();
        accu_V_fu_162 = accu_0_V_fu_8413_p2.read();
        accu_V_s_fu_222 = accu_15_V_fu_9343_p2.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && esl_seteq<1,1,1>(exitcond_fu_510_p2.read(), ap_const_lv1_0) && esl_seteq<1,1,1>(tmp_fu_525_p2.read(), ap_const_lv1_1) && esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        inputBuf_3_V_2_fu_238 = inputBuf_3_V_7_fu_640_p3.read();
        inputBuf_3_V_3_fu_242 = inputBuf_3_V_5_fu_632_p3.read();
        inputBuf_3_V_6_fu_246 = inputBuf_3_V_1_fu_616_p3.read();
        inputBuf_3_V_8_fu_250 = inputBuf_3_V_fu_600_p3.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        tmp115_reg_10262 = tmp115_fu_2661_p2.read();
        tmp119_reg_10267 = tmp119_fu_2687_p2.read();
        tmp123_reg_10272 = tmp123_fu_2719_p2.read();
        tmp146_reg_10292 = tmp146_fu_3117_p2.read();
        tmp150_reg_10297 = tmp150_fu_3143_p2.read();
        tmp154_reg_10302 = tmp154_fu_3175_p2.read();
        tmp177_reg_10322 = tmp177_fu_3573_p2.read();
        tmp181_reg_10327 = tmp181_fu_3599_p2.read();
        tmp185_reg_10332 = tmp185_fu_3631_p2.read();
        tmp208_reg_10352 = tmp208_fu_4029_p2.read();
        tmp212_reg_10357 = tmp212_fu_4055_p2.read();
        tmp216_reg_10362 = tmp216_fu_4087_p2.read();
        tmp22_reg_10172 = tmp22_fu_1293_p2.read();
        tmp239_reg_10382 = tmp239_fu_4485_p2.read();
        tmp243_reg_10387 = tmp243_fu_4511_p2.read();
        tmp247_reg_10392 = tmp247_fu_4543_p2.read();
        tmp26_reg_10177 = tmp26_fu_1319_p2.read();
        tmp270_reg_10412 = tmp270_fu_4941_p2.read();
        tmp274_reg_10417 = tmp274_fu_4967_p2.read();
        tmp278_reg_10422 = tmp278_fu_4999_p2.read();
        tmp301_reg_10442 = tmp301_fu_5397_p2.read();
        tmp305_reg_10447 = tmp305_fu_5423_p2.read();
        tmp309_reg_10452 = tmp309_fu_5455_p2.read();
        tmp30_reg_10182 = tmp30_fu_1351_p2.read();
        tmp332_reg_10472 = tmp332_fu_5853_p2.read();
        tmp336_reg_10477 = tmp336_fu_5879_p2.read();
        tmp340_reg_10482 = tmp340_fu_5911_p2.read();
        tmp363_reg_10502 = tmp363_fu_6309_p2.read();
        tmp367_reg_10507 = tmp367_fu_6335_p2.read();
        tmp371_reg_10512 = tmp371_fu_6367_p2.read();
        tmp394_reg_10532 = tmp394_fu_6765_p2.read();
        tmp398_reg_10537 = tmp398_fu_6791_p2.read();
        tmp402_reg_10542 = tmp402_fu_6823_p2.read();
        tmp425_reg_10562 = tmp425_fu_7221_p2.read();
        tmp429_reg_10567 = tmp429_fu_7247_p2.read();
        tmp433_reg_10572 = tmp433_fu_7279_p2.read();
        tmp456_reg_10592 = tmp456_fu_7677_p2.read();
        tmp460_reg_10597 = tmp460_fu_7703_p2.read();
        tmp464_reg_10602 = tmp464_fu_7735_p2.read();
        tmp487_reg_10622 = tmp487_fu_8133_p2.read();
        tmp491_reg_10627 = tmp491_fu_8159_p2.read();
        tmp495_reg_10632 = tmp495_fu_8191_p2.read();
        tmp53_reg_10202 = tmp53_fu_1749_p2.read();
        tmp57_reg_10207 = tmp57_fu_1775_p2.read();
        tmp61_reg_10212 = tmp61_fu_1807_p2.read();
        tmp84_reg_10232 = tmp84_fu_2205_p2.read();
        tmp88_reg_10237 = tmp88_fu_2231_p2.read();
        tmp92_reg_10242 = tmp92_fu_2263_p2.read();
        tmp_12_0_11_reg_10157 = tmp_12_0_11_fu_1179_p2.read();
        tmp_12_0_12_reg_10162 = tmp_12_0_12_fu_1207_p2.read();
        tmp_12_0_13_reg_10167 = tmp_12_0_13_fu_1235_p2.read();
        tmp_12_10_11_reg_10457 = tmp_12_10_11_fu_5763_p2.read();
        tmp_12_10_12_reg_10462 = tmp_12_10_12_fu_5783_p2.read();
        tmp_12_10_13_reg_10467 = tmp_12_10_13_fu_5803_p2.read();
        tmp_12_11_11_reg_10487 = tmp_12_11_11_fu_6219_p2.read();
        tmp_12_11_12_reg_10492 = tmp_12_11_12_fu_6239_p2.read();
        tmp_12_11_13_reg_10497 = tmp_12_11_13_fu_6259_p2.read();
        tmp_12_12_11_reg_10517 = tmp_12_12_11_fu_6675_p2.read();
        tmp_12_12_12_reg_10522 = tmp_12_12_12_fu_6695_p2.read();
        tmp_12_12_13_reg_10527 = tmp_12_12_13_fu_6715_p2.read();
        tmp_12_13_11_reg_10547 = tmp_12_13_11_fu_7131_p2.read();
        tmp_12_13_12_reg_10552 = tmp_12_13_12_fu_7151_p2.read();
        tmp_12_13_13_reg_10557 = tmp_12_13_13_fu_7171_p2.read();
        tmp_12_14_11_reg_10577 = tmp_12_14_11_fu_7587_p2.read();
        tmp_12_14_12_reg_10582 = tmp_12_14_12_fu_7607_p2.read();
        tmp_12_14_13_reg_10587 = tmp_12_14_13_fu_7627_p2.read();
        tmp_12_15_11_reg_10607 = tmp_12_15_11_fu_8043_p2.read();
        tmp_12_15_12_reg_10612 = tmp_12_15_12_fu_8063_p2.read();
        tmp_12_15_13_reg_10617 = tmp_12_15_13_fu_8083_p2.read();
        tmp_12_1_11_reg_10187 = tmp_12_1_11_fu_1659_p2.read();
        tmp_12_1_12_reg_10192 = tmp_12_1_12_fu_1679_p2.read();
        tmp_12_1_13_reg_10197 = tmp_12_1_13_fu_1699_p2.read();
        tmp_12_2_11_reg_10217 = tmp_12_2_11_fu_2115_p2.read();
        tmp_12_2_12_reg_10222 = tmp_12_2_12_fu_2135_p2.read();
        tmp_12_2_13_reg_10227 = tmp_12_2_13_fu_2155_p2.read();
        tmp_12_3_11_reg_10247 = tmp_12_3_11_fu_2571_p2.read();
        tmp_12_3_12_reg_10252 = tmp_12_3_12_fu_2591_p2.read();
        tmp_12_3_13_reg_10257 = tmp_12_3_13_fu_2611_p2.read();
        tmp_12_4_11_reg_10277 = tmp_12_4_11_fu_3027_p2.read();
        tmp_12_4_12_reg_10282 = tmp_12_4_12_fu_3047_p2.read();
        tmp_12_4_13_reg_10287 = tmp_12_4_13_fu_3067_p2.read();
        tmp_12_5_11_reg_10307 = tmp_12_5_11_fu_3483_p2.read();
        tmp_12_5_12_reg_10312 = tmp_12_5_12_fu_3503_p2.read();
        tmp_12_5_13_reg_10317 = tmp_12_5_13_fu_3523_p2.read();
        tmp_12_6_11_reg_10337 = tmp_12_6_11_fu_3939_p2.read();
        tmp_12_6_12_reg_10342 = tmp_12_6_12_fu_3959_p2.read();
        tmp_12_6_13_reg_10347 = tmp_12_6_13_fu_3979_p2.read();
        tmp_12_7_11_reg_10367 = tmp_12_7_11_fu_4395_p2.read();
        tmp_12_7_12_reg_10372 = tmp_12_7_12_fu_4415_p2.read();
        tmp_12_7_13_reg_10377 = tmp_12_7_13_fu_4435_p2.read();
        tmp_12_8_11_reg_10397 = tmp_12_8_11_fu_4851_p2.read();
        tmp_12_8_12_reg_10402 = tmp_12_8_12_fu_4871_p2.read();
        tmp_12_8_13_reg_10407 = tmp_12_8_13_fu_4891_p2.read();
        tmp_12_9_11_reg_10427 = tmp_12_9_11_fu_5307_p2.read();
        tmp_12_9_12_reg_10432 = tmp_12_9_12_fu_5327_p2.read();
        tmp_12_9_13_reg_10437 = tmp_12_9_13_fu_5347_p2.read();
        tmp_497_reg_10137_pp0_iter1_reg = tmp_497_reg_10137.read();
        tmp_4_reg_10033_pp0_iter1_reg = tmp_4_reg_10033.read();
        tmp_s_reg_10133_pp0_iter1_reg = tmp_s_reg_10133.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && esl_seteq<1,1,1>(exitcond_fu_510_p2.read(), ap_const_lv1_0) && esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_lv1_1, tmp_s_fu_712_p2.read()))) {
        tmp_497_reg_10137 = tmp_497_fu_731_p1.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && esl_seteq<1,1,1>(exitcond_fu_510_p2.read(), ap_const_lv1_0) && esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        tmp_4_reg_10033 = tmp_4_fu_674_p2.read();
        tmp_s_reg_10133 = tmp_s_fu_712_p2.read();
    }
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_ap_NS_fsm() {
    switch (ap_CS_fsm.read().to_uint64()) {
        case 1 : 
            if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && esl_seteq<1,1,1>(ap_start.read(), ap_const_logic_1))) {
                ap_NS_fsm = ap_ST_fsm_pp0_stage0;
            } else {
                ap_NS_fsm = ap_ST_fsm_state1;
            }
            break;
        case 2 : 
            if ((!(esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage0_subdone.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_enable_reg_pp0_iter1.read(), ap_const_logic_0)) && !(esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage0_subdone.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(exitcond_fu_510_p2.read(), ap_const_lv1_1) && esl_seteq<1,1,1>(ap_enable_reg_pp0_iter1.read(), ap_const_logic_0)))) {
                ap_NS_fsm = ap_ST_fsm_pp0_stage0;
            } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage0_subdone.read(), ap_const_boolean_0) && 
  esl_seteq<1,1,1>(ap_enable_reg_pp0_iter1.read(), ap_const_logic_0)) || (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage0_subdone.read(), ap_const_boolean_0) && 
  esl_seteq<1,1,1>(exitcond_fu_510_p2.read(), ap_const_lv1_1) && 
  esl_seteq<1,1,1>(ap_enable_reg_pp0_iter1.read(), ap_const_logic_0)))) {
                ap_NS_fsm = ap_ST_fsm_state5;
            } else {
                ap_NS_fsm = ap_ST_fsm_pp0_stage0;
            }
            break;
        case 4 : 
            ap_NS_fsm = ap_ST_fsm_state1;
            break;
        default : 
            ap_NS_fsm = "XXX";
            break;
    }
}

}

