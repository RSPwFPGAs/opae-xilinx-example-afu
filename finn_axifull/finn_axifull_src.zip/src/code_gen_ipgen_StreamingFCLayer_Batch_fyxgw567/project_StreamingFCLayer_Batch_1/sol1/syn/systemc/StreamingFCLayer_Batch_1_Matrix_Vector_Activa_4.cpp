#include "StreamingFCLayer_Batch_1_Matrix_Vector_Activa.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp380_cast_fu_8843_p1() {
    tmp380_cast_fu_8843_p1 = esl_zext<32,4>(tmp248_fu_8837_p2.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp380_fu_6549_p2() {
    tmp380_fu_6549_p2 = (p_Result_2_0_7_fu_1005_p3.read() ^ p_Result_12_7_fu_6541_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp381_cast_fu_8831_p1() {
    tmp381_cast_fu_8831_p1 = esl_zext<4,3>(tmp243_reg_10387.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp381_fu_6573_p2() {
    tmp381_fu_6573_p2 = (p_Result_2_0_8_fu_1037_p3.read() ^ p_Result_12_8_fu_6565_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp382_cast_fu_4497_p1() {
    tmp382_cast_fu_4497_p1 = esl_zext<3,2>(tmp241_fu_4491_p2.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp382_fu_6597_p2() {
    tmp382_fu_6597_p2 = (p_Result_2_0_9_fu_1069_p3.read() ^ p_Result_12_9_fu_6589_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp383_cast_fu_4507_p1() {
    tmp383_cast_fu_4507_p1 = esl_zext<3,2>(tmp242_fu_4501_p2.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp383_fu_6621_p2() {
    tmp383_fu_6621_p2 = (p_Result_2_0_s_fu_1101_p3.read() ^ p_Result_12_s_fu_6613_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp384_cast_fu_8834_p1() {
    tmp384_cast_fu_8834_p1 = esl_zext<4,3>(tmp247_reg_10392.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp384_fu_6645_p2() {
    tmp384_fu_6645_p2 = (p_Result_2_0_10_fu_1133_p3.read() ^ p_Result_12_10_fu_6637_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp385_cast_fu_4523_p1() {
    tmp385_cast_fu_4523_p1 = esl_zext<3,2>(tmp244_fu_4517_p2.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp385_fu_6669_p2() {
    tmp385_fu_6669_p2 = (p_Result_2_0_11_fu_1165_p3.read() ^ p_Result_12_11_fu_6661_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp386_cast_fu_4539_p1() {
    tmp386_cast_fu_4539_p1 = esl_zext<3,2>(tmp246_fu_4533_p2.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp386_fu_6689_p2() {
    tmp386_fu_6689_p2 = (p_Result_2_0_12_fu_1193_p3.read() ^ p_Result_12_12_fu_6681_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp387_fu_6709_p2() {
    tmp387_fu_6709_p2 = (p_Result_2_0_13_fu_1221_p3.read() ^ p_Result_12_13_fu_6701_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp388_fu_6729_p2() {
    tmp388_fu_6729_p2 = (p_Result_2_0_14_fu_1249_p3.read() ^ p_Result_12_14_fu_6721_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp389_fu_9110_p2() {
    tmp389_fu_9110_p2 = (!p_accu_V_12_fu_8266_p3.read().is_01() || !res_12_s_fu_9104_p1.read().is_01())? sc_lv<32>(): (sc_biguint<32>(p_accu_V_12_fu_8266_p3.read()) + sc_biguint<32>(res_12_s_fu_9104_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp38_fu_1509_p2() {
    tmp38_fu_1509_p2 = (p_Result_2_0_6_fu_973_p3.read() ^ p_Result_1_6_fu_1501_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp390_fu_9116_p2() {
    tmp390_fu_9116_p2 = (!res_12_13_cast_fu_9107_p1.read().is_01() || !res_12_11_cast_fu_9101_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_12_13_cast_fu_9107_p1.read()) + sc_biguint<2>(res_12_11_cast_fu_9101_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp391_fu_9126_p2() {
    tmp391_fu_9126_p2 = (!tmp601_cast_fu_9122_p1.read().is_01() || !tmp389_fu_9110_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(tmp601_cast_fu_9122_p1.read()) + sc_biguint<32>(tmp389_fu_9110_p2.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp392_fu_6745_p2() {
    tmp392_fu_6745_p2 = (!res_12_10_cast_fu_6657_p1.read().is_01() || !res_12_8_cast_fu_6585_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_12_10_cast_fu_6657_p1.read()) + sc_biguint<2>(res_12_8_cast_fu_6585_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp393_fu_6755_p2() {
    tmp393_fu_6755_p2 = (!res_12_7_cast_fu_6561_p1.read().is_01() || !res_12_cast_fu_6633_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_12_7_cast_fu_6561_p1.read()) + sc_biguint<2>(res_12_cast_fu_6633_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp394_fu_6765_p2() {
    tmp394_fu_6765_p2 = (!tmp604_cast_fu_6761_p1.read().is_01() || !tmp603_cast_fu_6751_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp604_cast_fu_6761_p1.read()) + sc_biguint<3>(tmp603_cast_fu_6751_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp395_fu_9135_p2() {
    tmp395_fu_9135_p2 = (!tmp602_cast_fu_9132_p1.read().is_01() || !tmp391_fu_9126_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(tmp602_cast_fu_9132_p1.read()) + sc_biguint<32>(tmp391_fu_9126_p2.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp396_fu_6771_p2() {
    tmp396_fu_6771_p2 = (!res_12_9_cast_fu_6609_p1.read().is_01() || !res_11_cast_268_fu_6393_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_12_9_cast_fu_6609_p1.read()) + sc_biguint<2>(res_11_cast_268_fu_6393_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp397_fu_6781_p2() {
    tmp397_fu_6781_p2 = (!res_12_2_cast_fu_6441_p1.read().is_01() || !res_12_1_cast_fu_6417_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_12_2_cast_fu_6441_p1.read()) + sc_biguint<2>(res_12_1_cast_fu_6417_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp398_fu_6791_p2() {
    tmp398_fu_6791_p2 = (!tmp608_cast_fu_6787_p1.read().is_01() || !tmp607_cast_fu_6777_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp608_cast_fu_6787_p1.read()) + sc_biguint<3>(tmp607_cast_fu_6777_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp399_fu_6797_p2() {
    tmp399_fu_6797_p2 = (!res_12_4_cast_fu_6489_p1.read().is_01() || !res_12_3_cast_fu_6465_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_12_4_cast_fu_6489_p1.read()) + sc_biguint<2>(res_12_3_cast_fu_6465_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp39_fu_1533_p2() {
    tmp39_fu_1533_p2 = (p_Result_2_0_7_fu_1005_p3.read() ^ p_Result_1_7_fu_1525_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp3_fu_853_p2() {
    tmp3_fu_853_p2 = (p_Result_2_0_2_fu_845_p3.read() ^ p_Result_0_2_fu_837_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp400_fu_6807_p2() {
    tmp400_fu_6807_p2 = (!res_12_5_cast_fu_6513_p1.read().is_01() || !res_12_14_cast_fu_6741_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_12_5_cast_fu_6513_p1.read()) + sc_biguint<2>(res_12_14_cast_fu_6741_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp401_fu_6813_p2() {
    tmp401_fu_6813_p2 = (!tmp400_fu_6807_p2.read().is_01() || !res_12_6_cast_fu_6537_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(tmp400_fu_6807_p2.read()) + sc_biguint<2>(res_12_6_cast_fu_6537_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp402_fu_6823_p2() {
    tmp402_fu_6823_p2 = (!tmp611_cast_fu_6819_p1.read().is_01() || !tmp610_cast_fu_6803_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp611_cast_fu_6819_p1.read()) + sc_biguint<3>(tmp610_cast_fu_6803_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp403_fu_9147_p2() {
    tmp403_fu_9147_p2 = (!tmp609_cast_fu_9144_p1.read().is_01() || !tmp606_cast_fu_9141_p1.read().is_01())? sc_lv<4>(): (sc_biguint<4>(tmp609_cast_fu_9144_p1.read()) + sc_biguint<4>(tmp606_cast_fu_9141_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp404_fu_6837_p2() {
    tmp404_fu_6837_p2 = (p_Result_2_fu_781_p3.read() ^ p_Result_13_fu_6829_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp405_fu_6861_p2() {
    tmp405_fu_6861_p2 = (p_Result_2_0_1_fu_813_p3.read() ^ p_Result_13_1_fu_6853_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp406_fu_6885_p2() {
    tmp406_fu_6885_p2 = (p_Result_2_0_2_fu_845_p3.read() ^ p_Result_13_2_fu_6877_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp407_fu_6909_p2() {
    tmp407_fu_6909_p2 = (p_Result_2_0_3_fu_877_p3.read() ^ p_Result_13_3_fu_6901_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp408_fu_6933_p2() {
    tmp408_fu_6933_p2 = (p_Result_2_0_4_fu_909_p3.read() ^ p_Result_13_4_fu_6925_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp409_fu_6957_p2() {
    tmp409_fu_6957_p2 = (p_Result_2_0_5_fu_941_p3.read() ^ p_Result_13_5_fu_6949_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp40_fu_1557_p2() {
    tmp40_fu_1557_p2 = (p_Result_2_0_8_fu_1037_p3.read() ^ p_Result_1_8_fu_1549_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp410_fu_6981_p2() {
    tmp410_fu_6981_p2 = (p_Result_2_0_6_fu_973_p3.read() ^ p_Result_13_6_fu_6973_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp411_fu_7005_p2() {
    tmp411_fu_7005_p2 = (p_Result_2_0_7_fu_1005_p3.read() ^ p_Result_13_7_fu_6997_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp412_fu_7029_p2() {
    tmp412_fu_7029_p2 = (p_Result_2_0_8_fu_1037_p3.read() ^ p_Result_13_8_fu_7021_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp413_fu_7053_p2() {
    tmp413_fu_7053_p2 = (p_Result_2_0_9_fu_1069_p3.read() ^ p_Result_13_9_fu_7045_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp414_fu_7077_p2() {
    tmp414_fu_7077_p2 = (p_Result_2_0_s_fu_1101_p3.read() ^ p_Result_13_s_fu_7069_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp415_fu_7101_p2() {
    tmp415_fu_7101_p2 = (p_Result_2_0_10_fu_1133_p3.read() ^ p_Result_13_10_fu_7093_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp416_fu_7125_p2() {
    tmp416_fu_7125_p2 = (p_Result_2_0_11_fu_1165_p3.read() ^ p_Result_13_11_fu_7117_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp417_fu_7145_p2() {
    tmp417_fu_7145_p2 = (p_Result_2_0_12_fu_1193_p3.read() ^ p_Result_13_12_fu_7137_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp418_fu_7165_p2() {
    tmp418_fu_7165_p2 = (p_Result_2_0_13_fu_1221_p3.read() ^ p_Result_13_13_fu_7157_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp419_fu_7185_p2() {
    tmp419_fu_7185_p2 = (p_Result_2_0_14_fu_1249_p3.read() ^ p_Result_13_14_fu_7177_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp41_fu_1581_p2() {
    tmp41_fu_1581_p2 = (p_Result_2_0_9_fu_1069_p3.read() ^ p_Result_1_9_fu_1573_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp420_fu_9172_p2() {
    tmp420_fu_9172_p2 = (!p_accu_V_13_fu_8259_p3.read().is_01() || !res_13_s_fu_9166_p1.read().is_01())? sc_lv<32>(): (sc_biguint<32>(p_accu_V_13_fu_8259_p3.read()) + sc_biguint<32>(res_13_s_fu_9166_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp421_cast_fu_8874_p1() {
    tmp421_cast_fu_8874_p1 = esl_zext<32,2>(tmp266_fu_8868_p2.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp421_fu_9178_p2() {
    tmp421_fu_9178_p2 = (!res_13_13_cast_fu_9169_p1.read().is_01() || !res_13_11_cast_fu_9163_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_13_13_cast_fu_9169_p1.read()) + sc_biguint<2>(res_13_11_cast_fu_9163_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp422_cast_fu_8884_p1() {
    tmp422_cast_fu_8884_p1 = esl_zext<32,3>(tmp270_reg_10412.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp422_fu_9188_p2() {
    tmp422_fu_9188_p2 = (!tmp646_cast_fu_9184_p1.read().is_01() || !tmp420_fu_9172_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(tmp646_cast_fu_9184_p1.read()) + sc_biguint<32>(tmp420_fu_9172_p2.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp423_cast_fu_4927_p1() {
    tmp423_cast_fu_4927_p1 = esl_zext<3,2>(tmp268_fu_4921_p2.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp423_fu_7201_p2() {
    tmp423_fu_7201_p2 = (!res_13_10_cast_fu_7113_p1.read().is_01() || !res_13_8_cast_fu_7041_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_13_10_cast_fu_7113_p1.read()) + sc_biguint<2>(res_13_8_cast_fu_7041_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp424_cast_fu_4937_p1() {
    tmp424_cast_fu_4937_p1 = esl_zext<3,2>(tmp269_fu_4931_p2.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp424_fu_7211_p2() {
    tmp424_fu_7211_p2 = (!res_13_7_cast_fu_7017_p1.read().is_01() || !res_13_cast_fu_7089_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_13_7_cast_fu_7017_p1.read()) + sc_biguint<2>(res_13_cast_fu_7089_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp425_cast_fu_8905_p1() {
    tmp425_cast_fu_8905_p1 = esl_zext<32,4>(tmp279_fu_8899_p2.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp425_fu_7221_p2() {
    tmp425_fu_7221_p2 = (!tmp649_cast_fu_7217_p1.read().is_01() || !tmp648_cast_fu_7207_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp649_cast_fu_7217_p1.read()) + sc_biguint<3>(tmp648_cast_fu_7207_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp426_cast_fu_8893_p1() {
    tmp426_cast_fu_8893_p1 = esl_zext<4,3>(tmp274_reg_10417.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp426_fu_9197_p2() {
    tmp426_fu_9197_p2 = (!tmp647_cast_fu_9194_p1.read().is_01() || !tmp422_fu_9188_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(tmp647_cast_fu_9194_p1.read()) + sc_biguint<32>(tmp422_fu_9188_p2.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp427_cast_fu_4953_p1() {
    tmp427_cast_fu_4953_p1 = esl_zext<3,2>(tmp272_fu_4947_p2.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp427_fu_7227_p2() {
    tmp427_fu_7227_p2 = (!res_13_9_cast_fu_7065_p1.read().is_01() || !res_12_cast_285_fu_6849_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_13_9_cast_fu_7065_p1.read()) + sc_biguint<2>(res_12_cast_285_fu_6849_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp428_cast_fu_4963_p1() {
    tmp428_cast_fu_4963_p1 = esl_zext<3,2>(tmp273_fu_4957_p2.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp428_fu_7237_p2() {
    tmp428_fu_7237_p2 = (!res_13_2_cast_fu_6897_p1.read().is_01() || !res_13_1_cast_fu_6873_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_13_2_cast_fu_6897_p1.read()) + sc_biguint<2>(res_13_1_cast_fu_6873_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp429_cast_fu_8896_p1() {
    tmp429_cast_fu_8896_p1 = esl_zext<4,3>(tmp278_reg_10422.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp429_fu_7247_p2() {
    tmp429_fu_7247_p2 = (!tmp653_cast_fu_7243_p1.read().is_01() || !tmp652_cast_fu_7233_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp653_cast_fu_7243_p1.read()) + sc_biguint<3>(tmp652_cast_fu_7233_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp42_fu_1605_p2() {
    tmp42_fu_1605_p2 = (p_Result_2_0_s_fu_1101_p3.read() ^ p_Result_1_s_fu_1597_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp430_cast_fu_4979_p1() {
    tmp430_cast_fu_4979_p1 = esl_zext<3,2>(tmp275_fu_4973_p2.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp430_fu_7253_p2() {
    tmp430_fu_7253_p2 = (!res_13_4_cast_fu_6945_p1.read().is_01() || !res_13_3_cast_fu_6921_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_13_4_cast_fu_6945_p1.read()) + sc_biguint<2>(res_13_3_cast_fu_6921_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp431_cast_fu_4995_p1() {
    tmp431_cast_fu_4995_p1 = esl_zext<3,2>(tmp277_fu_4989_p2.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp431_fu_7263_p2() {
    tmp431_fu_7263_p2 = (!res_13_5_cast_fu_6969_p1.read().is_01() || !res_13_14_cast_fu_7197_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_13_5_cast_fu_6969_p1.read()) + sc_biguint<2>(res_13_14_cast_fu_7197_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp432_fu_7269_p2() {
    tmp432_fu_7269_p2 = (!tmp431_fu_7263_p2.read().is_01() || !res_13_6_cast_fu_6993_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(tmp431_fu_7263_p2.read()) + sc_biguint<2>(res_13_6_cast_fu_6993_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp433_fu_7279_p2() {
    tmp433_fu_7279_p2 = (!tmp656_cast_fu_7275_p1.read().is_01() || !tmp655_cast_fu_7259_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp656_cast_fu_7275_p1.read()) + sc_biguint<3>(tmp655_cast_fu_7259_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp434_fu_9209_p2() {
    tmp434_fu_9209_p2 = (!tmp654_cast_fu_9206_p1.read().is_01() || !tmp651_cast_fu_9203_p1.read().is_01())? sc_lv<4>(): (sc_biguint<4>(tmp654_cast_fu_9206_p1.read()) + sc_biguint<4>(tmp651_cast_fu_9203_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp435_fu_7293_p2() {
    tmp435_fu_7293_p2 = (p_Result_2_fu_781_p3.read() ^ p_Result_14_fu_7285_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp436_fu_7317_p2() {
    tmp436_fu_7317_p2 = (p_Result_2_0_1_fu_813_p3.read() ^ p_Result_14_1_fu_7309_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp437_fu_7341_p2() {
    tmp437_fu_7341_p2 = (p_Result_2_0_2_fu_845_p3.read() ^ p_Result_14_2_fu_7333_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp438_fu_7365_p2() {
    tmp438_fu_7365_p2 = (p_Result_2_0_3_fu_877_p3.read() ^ p_Result_14_3_fu_7357_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp439_fu_7389_p2() {
    tmp439_fu_7389_p2 = (p_Result_2_0_4_fu_909_p3.read() ^ p_Result_14_4_fu_7381_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp43_fu_1629_p2() {
    tmp43_fu_1629_p2 = (p_Result_2_0_10_fu_1133_p3.read() ^ p_Result_1_10_fu_1621_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp440_fu_7413_p2() {
    tmp440_fu_7413_p2 = (p_Result_2_0_5_fu_941_p3.read() ^ p_Result_14_5_fu_7405_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp441_fu_7437_p2() {
    tmp441_fu_7437_p2 = (p_Result_2_0_6_fu_973_p3.read() ^ p_Result_14_6_fu_7429_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp442_fu_7461_p2() {
    tmp442_fu_7461_p2 = (p_Result_2_0_7_fu_1005_p3.read() ^ p_Result_14_7_fu_7453_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp443_fu_7485_p2() {
    tmp443_fu_7485_p2 = (p_Result_2_0_8_fu_1037_p3.read() ^ p_Result_14_8_fu_7477_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp444_fu_7509_p2() {
    tmp444_fu_7509_p2 = (p_Result_2_0_9_fu_1069_p3.read() ^ p_Result_14_9_fu_7501_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp445_fu_7533_p2() {
    tmp445_fu_7533_p2 = (p_Result_2_0_s_fu_1101_p3.read() ^ p_Result_14_s_fu_7525_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp446_fu_7557_p2() {
    tmp446_fu_7557_p2 = (p_Result_2_0_10_fu_1133_p3.read() ^ p_Result_14_10_fu_7549_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp447_fu_7581_p2() {
    tmp447_fu_7581_p2 = (p_Result_2_0_11_fu_1165_p3.read() ^ p_Result_14_11_fu_7573_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp448_fu_7601_p2() {
    tmp448_fu_7601_p2 = (p_Result_2_0_12_fu_1193_p3.read() ^ p_Result_14_12_fu_7593_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp449_fu_7621_p2() {
    tmp449_fu_7621_p2 = (p_Result_2_0_13_fu_1221_p3.read() ^ p_Result_14_13_fu_7613_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp44_fu_1653_p2() {
    tmp44_fu_1653_p2 = (p_Result_2_0_11_fu_1165_p3.read() ^ p_Result_1_11_fu_1645_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp450_fu_7641_p2() {
    tmp450_fu_7641_p2 = (p_Result_2_0_14_fu_1249_p3.read() ^ p_Result_14_14_fu_7633_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp451_fu_9234_p2() {
    tmp451_fu_9234_p2 = (!p_accu_V_14_fu_8252_p3.read().is_01() || !res_14_s_fu_9228_p1.read().is_01())? sc_lv<32>(): (sc_biguint<32>(p_accu_V_14_fu_8252_p3.read()) + sc_biguint<32>(res_14_s_fu_9228_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp452_fu_9240_p2() {
    tmp452_fu_9240_p2 = (!res_14_13_cast_fu_9231_p1.read().is_01() || !res_14_11_cast_fu_9225_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_14_13_cast_fu_9231_p1.read()) + sc_biguint<2>(res_14_11_cast_fu_9225_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp453_fu_9250_p2() {
    tmp453_fu_9250_p2 = (!tmp691_cast_fu_9246_p1.read().is_01() || !tmp451_fu_9234_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(tmp691_cast_fu_9246_p1.read()) + sc_biguint<32>(tmp451_fu_9234_p2.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp454_fu_7657_p2() {
    tmp454_fu_7657_p2 = (!res_14_10_cast_fu_7569_p1.read().is_01() || !res_14_8_cast_fu_7497_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_14_10_cast_fu_7569_p1.read()) + sc_biguint<2>(res_14_8_cast_fu_7497_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp455_fu_7667_p2() {
    tmp455_fu_7667_p2 = (!res_14_7_cast_fu_7473_p1.read().is_01() || !res_14_cast_fu_7545_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_14_7_cast_fu_7473_p1.read()) + sc_biguint<2>(res_14_cast_fu_7545_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp456_fu_7677_p2() {
    tmp456_fu_7677_p2 = (!tmp694_cast_fu_7673_p1.read().is_01() || !tmp693_cast_fu_7663_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp694_cast_fu_7673_p1.read()) + sc_biguint<3>(tmp693_cast_fu_7663_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp457_fu_9259_p2() {
    tmp457_fu_9259_p2 = (!tmp692_cast_fu_9256_p1.read().is_01() || !tmp453_fu_9250_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(tmp692_cast_fu_9256_p1.read()) + sc_biguint<32>(tmp453_fu_9250_p2.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp458_fu_7683_p2() {
    tmp458_fu_7683_p2 = (!res_14_9_cast_fu_7521_p1.read().is_01() || !res_13_cast_302_fu_7305_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_14_9_cast_fu_7521_p1.read()) + sc_biguint<2>(res_13_cast_302_fu_7305_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp459_fu_7693_p2() {
    tmp459_fu_7693_p2 = (!res_14_2_cast_fu_7353_p1.read().is_01() || !res_14_1_cast_fu_7329_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_14_2_cast_fu_7353_p1.read()) + sc_biguint<2>(res_14_1_cast_fu_7329_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp45_fu_1673_p2() {
    tmp45_fu_1673_p2 = (p_Result_2_0_12_fu_1193_p3.read() ^ p_Result_1_12_fu_1665_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp460_fu_7703_p2() {
    tmp460_fu_7703_p2 = (!tmp698_cast_fu_7699_p1.read().is_01() || !tmp697_cast_fu_7689_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp698_cast_fu_7699_p1.read()) + sc_biguint<3>(tmp697_cast_fu_7689_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp461_fu_7709_p2() {
    tmp461_fu_7709_p2 = (!res_14_4_cast_fu_7401_p1.read().is_01() || !res_14_3_cast_fu_7377_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_14_4_cast_fu_7401_p1.read()) + sc_biguint<2>(res_14_3_cast_fu_7377_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp462_fu_7719_p2() {
    tmp462_fu_7719_p2 = (!res_14_5_cast_fu_7425_p1.read().is_01() || !res_14_14_cast_fu_7653_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_14_5_cast_fu_7425_p1.read()) + sc_biguint<2>(res_14_14_cast_fu_7653_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp463_fu_7725_p2() {
    tmp463_fu_7725_p2 = (!tmp462_fu_7719_p2.read().is_01() || !res_14_6_cast_fu_7449_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(tmp462_fu_7719_p2.read()) + sc_biguint<2>(res_14_6_cast_fu_7449_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp464_fu_7735_p2() {
    tmp464_fu_7735_p2 = (!tmp701_cast_fu_7731_p1.read().is_01() || !tmp700_cast_fu_7715_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp701_cast_fu_7731_p1.read()) + sc_biguint<3>(tmp700_cast_fu_7715_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp465_fu_9271_p2() {
    tmp465_fu_9271_p2 = (!tmp699_cast_fu_9268_p1.read().is_01() || !tmp696_cast_fu_9265_p1.read().is_01())? sc_lv<4>(): (sc_biguint<4>(tmp699_cast_fu_9268_p1.read()) + sc_biguint<4>(tmp696_cast_fu_9265_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp466_cast_fu_8936_p1() {
    tmp466_cast_fu_8936_p1 = esl_zext<32,2>(tmp297_fu_8930_p2.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp466_fu_7749_p2() {
    tmp466_fu_7749_p2 = (p_Result_2_fu_781_p3.read() ^ p_Result_15_fu_7741_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp467_cast_fu_8946_p1() {
    tmp467_cast_fu_8946_p1 = esl_zext<32,3>(tmp301_reg_10442.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp467_fu_7773_p2() {
    tmp467_fu_7773_p2 = (p_Result_2_0_1_fu_813_p3.read() ^ p_Result_15_1_fu_7765_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp468_cast_fu_5383_p1() {
    tmp468_cast_fu_5383_p1 = esl_zext<3,2>(tmp299_fu_5377_p2.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp468_fu_7797_p2() {
    tmp468_fu_7797_p2 = (p_Result_2_0_2_fu_845_p3.read() ^ p_Result_15_2_fu_7789_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp469_cast_fu_5393_p1() {
    tmp469_cast_fu_5393_p1 = esl_zext<3,2>(tmp300_fu_5387_p2.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp469_fu_7821_p2() {
    tmp469_fu_7821_p2 = (p_Result_2_0_3_fu_877_p3.read() ^ p_Result_15_3_fu_7813_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp46_fu_1693_p2() {
    tmp46_fu_1693_p2 = (p_Result_2_0_13_fu_1221_p3.read() ^ p_Result_1_13_fu_1685_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp470_cast_fu_8967_p1() {
    tmp470_cast_fu_8967_p1 = esl_zext<32,4>(tmp310_fu_8961_p2.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp470_fu_7845_p2() {
    tmp470_fu_7845_p2 = (p_Result_2_0_4_fu_909_p3.read() ^ p_Result_15_4_fu_7837_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp471_cast_fu_8955_p1() {
    tmp471_cast_fu_8955_p1 = esl_zext<4,3>(tmp305_reg_10447.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp471_fu_7869_p2() {
    tmp471_fu_7869_p2 = (p_Result_2_0_5_fu_941_p3.read() ^ p_Result_15_5_fu_7861_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp472_cast_fu_5409_p1() {
    tmp472_cast_fu_5409_p1 = esl_zext<3,2>(tmp303_fu_5403_p2.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp472_fu_7893_p2() {
    tmp472_fu_7893_p2 = (p_Result_2_0_6_fu_973_p3.read() ^ p_Result_15_6_fu_7885_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp473_cast_fu_5419_p1() {
    tmp473_cast_fu_5419_p1 = esl_zext<3,2>(tmp304_fu_5413_p2.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp473_fu_7917_p2() {
    tmp473_fu_7917_p2 = (p_Result_2_0_7_fu_1005_p3.read() ^ p_Result_15_7_fu_7909_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp474_cast_fu_8958_p1() {
    tmp474_cast_fu_8958_p1 = esl_zext<4,3>(tmp309_reg_10452.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp474_fu_7941_p2() {
    tmp474_fu_7941_p2 = (p_Result_2_0_8_fu_1037_p3.read() ^ p_Result_15_8_fu_7933_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp475_cast_fu_5435_p1() {
    tmp475_cast_fu_5435_p1 = esl_zext<3,2>(tmp306_fu_5429_p2.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp475_fu_7965_p2() {
    tmp475_fu_7965_p2 = (p_Result_2_0_9_fu_1069_p3.read() ^ p_Result_15_9_fu_7957_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp476_cast_fu_5451_p1() {
    tmp476_cast_fu_5451_p1 = esl_zext<3,2>(tmp308_fu_5445_p2.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp476_fu_7989_p2() {
    tmp476_fu_7989_p2 = (p_Result_2_0_s_fu_1101_p3.read() ^ p_Result_15_s_fu_7981_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp477_fu_8013_p2() {
    tmp477_fu_8013_p2 = (p_Result_2_0_10_fu_1133_p3.read() ^ p_Result_15_10_fu_8005_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp478_fu_8037_p2() {
    tmp478_fu_8037_p2 = (p_Result_2_0_11_fu_1165_p3.read() ^ p_Result_15_11_fu_8029_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp479_fu_8057_p2() {
    tmp479_fu_8057_p2 = (p_Result_2_0_12_fu_1193_p3.read() ^ p_Result_15_12_fu_8049_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp47_fu_1713_p2() {
    tmp47_fu_1713_p2 = (p_Result_2_0_14_fu_1249_p3.read() ^ p_Result_1_14_fu_1705_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp480_fu_8077_p2() {
    tmp480_fu_8077_p2 = (p_Result_2_0_13_fu_1221_p3.read() ^ p_Result_15_13_fu_8069_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp481_fu_8097_p2() {
    tmp481_fu_8097_p2 = (p_Result_2_0_14_fu_1249_p3.read() ^ p_Result_15_14_fu_8089_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp482_fu_9296_p2() {
    tmp482_fu_9296_p2 = (!p_accu_V_s_fu_8245_p3.read().is_01() || !res_15_s_fu_9290_p1.read().is_01())? sc_lv<32>(): (sc_biguint<32>(p_accu_V_s_fu_8245_p3.read()) + sc_biguint<32>(res_15_s_fu_9290_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp483_fu_9302_p2() {
    tmp483_fu_9302_p2 = (!res_15_13_cast_fu_9293_p1.read().is_01() || !res_15_11_cast_fu_9287_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_15_13_cast_fu_9293_p1.read()) + sc_biguint<2>(res_15_11_cast_fu_9287_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp484_fu_9312_p2() {
    tmp484_fu_9312_p2 = (!tmp736_cast_fu_9308_p1.read().is_01() || !tmp482_fu_9296_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(tmp736_cast_fu_9308_p1.read()) + sc_biguint<32>(tmp482_fu_9296_p2.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp485_fu_8113_p2() {
    tmp485_fu_8113_p2 = (!res_15_10_cast_fu_8025_p1.read().is_01() || !res_15_8_cast_fu_7953_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_15_10_cast_fu_8025_p1.read()) + sc_biguint<2>(res_15_8_cast_fu_7953_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp486_fu_8123_p2() {
    tmp486_fu_8123_p2 = (!res_15_7_cast_fu_7929_p1.read().is_01() || !res_15_cast_fu_8001_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_15_7_cast_fu_7929_p1.read()) + sc_biguint<2>(res_15_cast_fu_8001_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp487_fu_8133_p2() {
    tmp487_fu_8133_p2 = (!tmp739_cast_fu_8129_p1.read().is_01() || !tmp738_cast_fu_8119_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp739_cast_fu_8129_p1.read()) + sc_biguint<3>(tmp738_cast_fu_8119_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp488_fu_9321_p2() {
    tmp488_fu_9321_p2 = (!tmp737_cast_fu_9318_p1.read().is_01() || !tmp484_fu_9312_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(tmp737_cast_fu_9318_p1.read()) + sc_biguint<32>(tmp484_fu_9312_p2.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp489_fu_8139_p2() {
    tmp489_fu_8139_p2 = (!res_15_9_cast_fu_7977_p1.read().is_01() || !res_14_cast_319_fu_7761_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_15_9_cast_fu_7977_p1.read()) + sc_biguint<2>(res_14_cast_319_fu_7761_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp48_fu_8428_p2() {
    tmp48_fu_8428_p2 = (!p_accu_V_1_fu_8343_p3.read().is_01() || !res_1_s_fu_8422_p1.read().is_01())? sc_lv<32>(): (sc_biguint<32>(p_accu_V_1_fu_8343_p3.read()) + sc_biguint<32>(res_1_s_fu_8422_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp490_fu_8149_p2() {
    tmp490_fu_8149_p2 = (!res_15_2_cast_fu_7809_p1.read().is_01() || !res_15_1_cast_fu_7785_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_15_2_cast_fu_7809_p1.read()) + sc_biguint<2>(res_15_1_cast_fu_7785_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp491_fu_8159_p2() {
    tmp491_fu_8159_p2 = (!tmp743_cast_fu_8155_p1.read().is_01() || !tmp742_cast_fu_8145_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp743_cast_fu_8155_p1.read()) + sc_biguint<3>(tmp742_cast_fu_8145_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp492_fu_8165_p2() {
    tmp492_fu_8165_p2 = (!res_15_4_cast_fu_7857_p1.read().is_01() || !res_15_3_cast_fu_7833_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_15_4_cast_fu_7857_p1.read()) + sc_biguint<2>(res_15_3_cast_fu_7833_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp493_fu_8175_p2() {
    tmp493_fu_8175_p2 = (!res_15_5_cast_fu_7881_p1.read().is_01() || !res_15_14_cast_fu_8109_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_15_5_cast_fu_7881_p1.read()) + sc_biguint<2>(res_15_14_cast_fu_8109_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp494_fu_8181_p2() {
    tmp494_fu_8181_p2 = (!tmp493_fu_8175_p2.read().is_01() || !res_15_6_cast_fu_7905_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(tmp493_fu_8175_p2.read()) + sc_biguint<2>(res_15_6_cast_fu_7905_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp495_fu_8191_p2() {
    tmp495_fu_8191_p2 = (!tmp746_cast_fu_8187_p1.read().is_01() || !tmp745_cast_fu_8171_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp746_cast_fu_8187_p1.read()) + sc_biguint<3>(tmp745_cast_fu_8171_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp496_fu_9333_p2() {
    tmp496_fu_9333_p2 = (!tmp744_cast_fu_9330_p1.read().is_01() || !tmp741_cast_fu_9327_p1.read().is_01())? sc_lv<4>(): (sc_biguint<4>(tmp744_cast_fu_9330_p1.read()) + sc_biguint<4>(tmp741_cast_fu_9327_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp49_fu_8434_p2() {
    tmp49_fu_8434_p2 = (!res_1_13_cast_fu_8425_p1.read().is_01() || !res_1_11_cast_fu_8419_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_1_13_cast_fu_8425_p1.read()) + sc_biguint<2>(res_1_11_cast_fu_8419_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp4_fu_885_p2() {
    tmp4_fu_885_p2 = (p_Result_2_0_3_fu_877_p3.read() ^ p_Result_0_3_fu_869_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp50_fu_8444_p2() {
    tmp50_fu_8444_p2 = (!tmp106_cast_fu_8440_p1.read().is_01() || !tmp48_fu_8428_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(tmp106_cast_fu_8440_p1.read()) + sc_biguint<32>(tmp48_fu_8428_p2.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp511_cast_fu_8998_p1() {
    tmp511_cast_fu_8998_p1 = esl_zext<32,2>(tmp328_fu_8992_p2.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp512_cast_fu_9008_p1() {
    tmp512_cast_fu_9008_p1 = esl_zext<32,3>(tmp332_reg_10472.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp513_cast_fu_5839_p1() {
    tmp513_cast_fu_5839_p1 = esl_zext<3,2>(tmp330_fu_5833_p2.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp514_cast_fu_5849_p1() {
    tmp514_cast_fu_5849_p1 = esl_zext<3,2>(tmp331_fu_5843_p2.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp515_cast_fu_9029_p1() {
    tmp515_cast_fu_9029_p1 = esl_zext<32,4>(tmp341_fu_9023_p2.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp516_cast_fu_9017_p1() {
    tmp516_cast_fu_9017_p1 = esl_zext<4,3>(tmp336_reg_10477.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp517_cast_fu_5865_p1() {
    tmp517_cast_fu_5865_p1 = esl_zext<3,2>(tmp334_fu_5859_p2.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp518_cast_fu_5875_p1() {
    tmp518_cast_fu_5875_p1 = esl_zext<3,2>(tmp335_fu_5869_p2.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp519_cast_fu_9020_p1() {
    tmp519_cast_fu_9020_p1 = esl_zext<4,3>(tmp340_reg_10482.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp51_fu_1729_p2() {
    tmp51_fu_1729_p2 = (!res_1_10_cast_fu_1641_p1.read().is_01() || !res_1_8_cast_fu_1569_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_1_10_cast_fu_1641_p1.read()) + sc_biguint<2>(res_1_8_cast_fu_1569_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp520_cast_fu_5891_p1() {
    tmp520_cast_fu_5891_p1 = esl_zext<3,2>(tmp337_fu_5885_p2.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp521_cast_fu_5907_p1() {
    tmp521_cast_fu_5907_p1 = esl_zext<3,2>(tmp339_fu_5901_p2.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp52_fu_1739_p2() {
    tmp52_fu_1739_p2 = (!res_1_7_cast_fu_1545_p1.read().is_01() || !res_1_cast_91_fu_1617_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_1_7_cast_fu_1545_p1.read()) + sc_biguint<2>(res_1_cast_91_fu_1617_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp53_fu_1749_p2() {
    tmp53_fu_1749_p2 = (!tmp109_cast_fu_1745_p1.read().is_01() || !tmp108_cast_fu_1735_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp109_cast_fu_1745_p1.read()) + sc_biguint<3>(tmp108_cast_fu_1735_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp54_fu_8453_p2() {
    tmp54_fu_8453_p2 = (!tmp107_cast_fu_8450_p1.read().is_01() || !tmp50_fu_8444_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(tmp107_cast_fu_8450_p1.read()) + sc_biguint<32>(tmp50_fu_8444_p2.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp556_cast_fu_9060_p1() {
    tmp556_cast_fu_9060_p1 = esl_zext<32,2>(tmp359_fu_9054_p2.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp557_cast_fu_9070_p1() {
    tmp557_cast_fu_9070_p1 = esl_zext<32,3>(tmp363_reg_10502.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp558_cast_fu_6295_p1() {
    tmp558_cast_fu_6295_p1 = esl_zext<3,2>(tmp361_fu_6289_p2.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp559_cast_fu_6305_p1() {
    tmp559_cast_fu_6305_p1 = esl_zext<3,2>(tmp362_fu_6299_p2.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp55_fu_1755_p2() {
    tmp55_fu_1755_p2 = (!res_1_9_cast_fu_1593_p1.read().is_01() || !res_1_cast_fu_1377_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_1_9_cast_fu_1593_p1.read()) + sc_biguint<2>(res_1_cast_fu_1377_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp560_cast_fu_9091_p1() {
    tmp560_cast_fu_9091_p1 = esl_zext<32,4>(tmp372_fu_9085_p2.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp561_cast_fu_9079_p1() {
    tmp561_cast_fu_9079_p1 = esl_zext<4,3>(tmp367_reg_10507.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp562_cast_fu_6321_p1() {
    tmp562_cast_fu_6321_p1 = esl_zext<3,2>(tmp365_fu_6315_p2.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp563_cast_fu_6331_p1() {
    tmp563_cast_fu_6331_p1 = esl_zext<3,2>(tmp366_fu_6325_p2.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp564_cast_fu_9082_p1() {
    tmp564_cast_fu_9082_p1 = esl_zext<4,3>(tmp371_reg_10512.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp565_cast_fu_6347_p1() {
    tmp565_cast_fu_6347_p1 = esl_zext<3,2>(tmp368_fu_6341_p2.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp566_cast_fu_6363_p1() {
    tmp566_cast_fu_6363_p1 = esl_zext<3,2>(tmp370_fu_6357_p2.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp56_fu_1765_p2() {
    tmp56_fu_1765_p2 = (!res_1_2_cast_fu_1425_p1.read().is_01() || !res_1_1_cast_fu_1401_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_1_2_cast_fu_1425_p1.read()) + sc_biguint<2>(res_1_1_cast_fu_1401_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp57_fu_1775_p2() {
    tmp57_fu_1775_p2 = (!tmp113_cast_fu_1771_p1.read().is_01() || !tmp112_cast_fu_1761_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp113_cast_fu_1771_p1.read()) + sc_biguint<3>(tmp112_cast_fu_1761_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp58_fu_1781_p2() {
    tmp58_fu_1781_p2 = (!res_1_4_cast_fu_1473_p1.read().is_01() || !res_1_3_cast_fu_1449_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_1_4_cast_fu_1473_p1.read()) + sc_biguint<2>(res_1_3_cast_fu_1449_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp59_fu_1791_p2() {
    tmp59_fu_1791_p2 = (!res_1_5_cast_fu_1497_p1.read().is_01() || !res_1_14_cast_fu_1725_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_1_5_cast_fu_1497_p1.read()) + sc_biguint<2>(res_1_14_cast_fu_1725_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp5_fu_917_p2() {
    tmp5_fu_917_p2 = (p_Result_2_0_4_fu_909_p3.read() ^ p_Result_0_4_fu_901_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp601_cast_fu_9122_p1() {
    tmp601_cast_fu_9122_p1 = esl_zext<32,2>(tmp390_fu_9116_p2.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp602_cast_fu_9132_p1() {
    tmp602_cast_fu_9132_p1 = esl_zext<32,3>(tmp394_reg_10532.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp603_cast_fu_6751_p1() {
    tmp603_cast_fu_6751_p1 = esl_zext<3,2>(tmp392_fu_6745_p2.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp604_cast_fu_6761_p1() {
    tmp604_cast_fu_6761_p1 = esl_zext<3,2>(tmp393_fu_6755_p2.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp605_cast_fu_9153_p1() {
    tmp605_cast_fu_9153_p1 = esl_zext<32,4>(tmp403_fu_9147_p2.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp606_cast_fu_9141_p1() {
    tmp606_cast_fu_9141_p1 = esl_zext<4,3>(tmp398_reg_10537.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp607_cast_fu_6777_p1() {
    tmp607_cast_fu_6777_p1 = esl_zext<3,2>(tmp396_fu_6771_p2.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp608_cast_fu_6787_p1() {
    tmp608_cast_fu_6787_p1 = esl_zext<3,2>(tmp397_fu_6781_p2.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp609_cast_fu_9144_p1() {
    tmp609_cast_fu_9144_p1 = esl_zext<4,3>(tmp402_reg_10542.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp60_fu_1797_p2() {
    tmp60_fu_1797_p2 = (!tmp59_fu_1791_p2.read().is_01() || !res_1_6_cast_fu_1521_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(tmp59_fu_1791_p2.read()) + sc_biguint<2>(res_1_6_cast_fu_1521_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp610_cast_fu_6803_p1() {
    tmp610_cast_fu_6803_p1 = esl_zext<3,2>(tmp399_fu_6797_p2.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp611_cast_fu_6819_p1() {
    tmp611_cast_fu_6819_p1 = esl_zext<3,2>(tmp401_fu_6813_p2.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp61_cast_fu_8378_p1() {
    tmp61_cast_fu_8378_p1 = esl_zext<32,2>(tmp18_fu_8372_p2.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp61_fu_1807_p2() {
    tmp61_fu_1807_p2 = (!tmp116_cast_fu_1803_p1.read().is_01() || !tmp115_cast_fu_1787_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp116_cast_fu_1803_p1.read()) + sc_biguint<3>(tmp115_cast_fu_1787_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp62_cast_fu_8388_p1() {
    tmp62_cast_fu_8388_p1 = esl_zext<32,3>(tmp22_reg_10172.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp62_fu_8465_p2() {
    tmp62_fu_8465_p2 = (!tmp114_cast_fu_8462_p1.read().is_01() || !tmp111_cast_fu_8459_p1.read().is_01())? sc_lv<4>(): (sc_biguint<4>(tmp114_cast_fu_8462_p1.read()) + sc_biguint<4>(tmp111_cast_fu_8459_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp63_cast_fu_1279_p1() {
    tmp63_cast_fu_1279_p1 = esl_zext<3,2>(tmp20_fu_1273_p2.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp63_fu_1821_p2() {
    tmp63_fu_1821_p2 = (p_Result_2_fu_781_p3.read() ^ p_Result_s_98_fu_1813_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp646_cast_fu_9184_p1() {
    tmp646_cast_fu_9184_p1 = esl_zext<32,2>(tmp421_fu_9178_p2.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp647_cast_fu_9194_p1() {
    tmp647_cast_fu_9194_p1 = esl_zext<32,3>(tmp425_reg_10562.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp648_cast_fu_7207_p1() {
    tmp648_cast_fu_7207_p1 = esl_zext<3,2>(tmp423_fu_7201_p2.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp649_cast_fu_7217_p1() {
    tmp649_cast_fu_7217_p1 = esl_zext<3,2>(tmp424_fu_7211_p2.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp64_cast_fu_1289_p1() {
    tmp64_cast_fu_1289_p1 = esl_zext<3,2>(tmp21_fu_1283_p2.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp64_fu_1845_p2() {
    tmp64_fu_1845_p2 = (p_Result_2_0_1_fu_813_p3.read() ^ p_Result_211_1_fu_1837_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp650_cast_fu_9215_p1() {
    tmp650_cast_fu_9215_p1 = esl_zext<32,4>(tmp434_fu_9209_p2.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp651_cast_fu_9203_p1() {
    tmp651_cast_fu_9203_p1 = esl_zext<4,3>(tmp429_reg_10567.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp652_cast_fu_7233_p1() {
    tmp652_cast_fu_7233_p1 = esl_zext<3,2>(tmp427_fu_7227_p2.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp653_cast_fu_7243_p1() {
    tmp653_cast_fu_7243_p1 = esl_zext<3,2>(tmp428_fu_7237_p2.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp654_cast_fu_9206_p1() {
    tmp654_cast_fu_9206_p1 = esl_zext<4,3>(tmp433_reg_10572.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp655_cast_fu_7259_p1() {
    tmp655_cast_fu_7259_p1 = esl_zext<3,2>(tmp430_fu_7253_p2.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp656_cast_fu_7275_p1() {
    tmp656_cast_fu_7275_p1 = esl_zext<3,2>(tmp432_fu_7269_p2.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp65_cast_fu_8409_p1() {
    tmp65_cast_fu_8409_p1 = esl_zext<32,4>(tmp31_fu_8403_p2.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp65_fu_1869_p2() {
    tmp65_fu_1869_p2 = (p_Result_2_0_2_fu_845_p3.read() ^ p_Result_211_2_fu_1861_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp66_cast_fu_8397_p1() {
    tmp66_cast_fu_8397_p1 = esl_zext<4,3>(tmp26_reg_10177.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp66_fu_1893_p2() {
    tmp66_fu_1893_p2 = (p_Result_2_0_3_fu_877_p3.read() ^ p_Result_211_3_fu_1885_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp67_cast_fu_1305_p1() {
    tmp67_cast_fu_1305_p1 = esl_zext<3,2>(tmp24_fu_1299_p2.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp67_fu_1917_p2() {
    tmp67_fu_1917_p2 = (p_Result_2_0_4_fu_909_p3.read() ^ p_Result_211_4_fu_1909_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp68_cast_fu_1315_p1() {
    tmp68_cast_fu_1315_p1 = esl_zext<3,2>(tmp25_fu_1309_p2.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp68_fu_1941_p2() {
    tmp68_fu_1941_p2 = (p_Result_2_0_5_fu_941_p3.read() ^ p_Result_211_5_fu_1933_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp691_cast_fu_9246_p1() {
    tmp691_cast_fu_9246_p1 = esl_zext<32,2>(tmp452_fu_9240_p2.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp692_cast_fu_9256_p1() {
    tmp692_cast_fu_9256_p1 = esl_zext<32,3>(tmp456_reg_10592.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp693_cast_fu_7663_p1() {
    tmp693_cast_fu_7663_p1 = esl_zext<3,2>(tmp454_fu_7657_p2.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp694_cast_fu_7673_p1() {
    tmp694_cast_fu_7673_p1 = esl_zext<3,2>(tmp455_fu_7667_p2.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp695_cast_fu_9277_p1() {
    tmp695_cast_fu_9277_p1 = esl_zext<32,4>(tmp465_fu_9271_p2.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp696_cast_fu_9265_p1() {
    tmp696_cast_fu_9265_p1 = esl_zext<4,3>(tmp460_reg_10597.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp697_cast_fu_7689_p1() {
    tmp697_cast_fu_7689_p1 = esl_zext<3,2>(tmp458_fu_7683_p2.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp698_cast_fu_7699_p1() {
    tmp698_cast_fu_7699_p1 = esl_zext<3,2>(tmp459_fu_7693_p2.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp699_cast_fu_9268_p1() {
    tmp699_cast_fu_9268_p1 = esl_zext<4,3>(tmp464_reg_10602.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp69_cast_fu_8400_p1() {
    tmp69_cast_fu_8400_p1 = esl_zext<4,3>(tmp30_reg_10182.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp69_fu_1965_p2() {
    tmp69_fu_1965_p2 = (p_Result_2_0_6_fu_973_p3.read() ^ p_Result_211_6_fu_1957_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp6_fu_949_p2() {
    tmp6_fu_949_p2 = (p_Result_2_0_5_fu_941_p3.read() ^ p_Result_0_5_fu_933_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp700_cast_fu_7715_p1() {
    tmp700_cast_fu_7715_p1 = esl_zext<3,2>(tmp461_fu_7709_p2.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp701_cast_fu_7731_p1() {
    tmp701_cast_fu_7731_p1 = esl_zext<3,2>(tmp463_fu_7725_p2.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp70_cast_fu_1331_p1() {
    tmp70_cast_fu_1331_p1 = esl_zext<3,2>(tmp27_fu_1325_p2.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp70_fu_1989_p2() {
    tmp70_fu_1989_p2 = (p_Result_2_0_7_fu_1005_p3.read() ^ p_Result_211_7_fu_1981_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp71_cast_fu_1347_p1() {
    tmp71_cast_fu_1347_p1 = esl_zext<3,2>(tmp29_fu_1341_p2.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp71_fu_2013_p2() {
    tmp71_fu_2013_p2 = (p_Result_2_0_8_fu_1037_p3.read() ^ p_Result_211_8_fu_2005_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp72_fu_2037_p2() {
    tmp72_fu_2037_p2 = (p_Result_2_0_9_fu_1069_p3.read() ^ p_Result_211_9_fu_2029_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp736_cast_fu_9308_p1() {
    tmp736_cast_fu_9308_p1 = esl_zext<32,2>(tmp483_fu_9302_p2.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp737_cast_fu_9318_p1() {
    tmp737_cast_fu_9318_p1 = esl_zext<32,3>(tmp487_reg_10622.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp738_cast_fu_8119_p1() {
    tmp738_cast_fu_8119_p1 = esl_zext<3,2>(tmp485_fu_8113_p2.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp739_cast_fu_8129_p1() {
    tmp739_cast_fu_8129_p1 = esl_zext<3,2>(tmp486_fu_8123_p2.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp73_fu_2061_p2() {
    tmp73_fu_2061_p2 = (p_Result_2_0_s_fu_1101_p3.read() ^ p_Result_211_s_fu_2053_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp740_cast_fu_9339_p1() {
    tmp740_cast_fu_9339_p1 = esl_zext<32,4>(tmp496_fu_9333_p2.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp741_cast_fu_9327_p1() {
    tmp741_cast_fu_9327_p1 = esl_zext<4,3>(tmp491_reg_10627.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp742_cast_fu_8145_p1() {
    tmp742_cast_fu_8145_p1 = esl_zext<3,2>(tmp489_fu_8139_p2.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp743_cast_fu_8155_p1() {
    tmp743_cast_fu_8155_p1 = esl_zext<3,2>(tmp490_fu_8149_p2.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp744_cast_fu_9330_p1() {
    tmp744_cast_fu_9330_p1 = esl_zext<4,3>(tmp495_reg_10632.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp745_cast_fu_8171_p1() {
    tmp745_cast_fu_8171_p1 = esl_zext<3,2>(tmp492_fu_8165_p2.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp746_cast_fu_8187_p1() {
    tmp746_cast_fu_8187_p1 = esl_zext<3,2>(tmp494_fu_8181_p2.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp74_fu_2085_p2() {
    tmp74_fu_2085_p2 = (p_Result_2_0_10_fu_1133_p3.read() ^ p_Result_211_10_fu_2077_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp75_fu_2109_p2() {
    tmp75_fu_2109_p2 = (p_Result_2_0_11_fu_1165_p3.read() ^ p_Result_211_11_fu_2101_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp76_fu_2129_p2() {
    tmp76_fu_2129_p2 = (p_Result_2_0_12_fu_1193_p3.read() ^ p_Result_211_12_fu_2121_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp77_fu_2149_p2() {
    tmp77_fu_2149_p2 = (p_Result_2_0_13_fu_1221_p3.read() ^ p_Result_211_13_fu_2141_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp78_fu_2169_p2() {
    tmp78_fu_2169_p2 = (p_Result_2_0_14_fu_1249_p3.read() ^ p_Result_211_14_fu_2161_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp79_fu_8490_p2() {
    tmp79_fu_8490_p2 = (!p_accu_V_2_fu_8336_p3.read().is_01() || !res_212_s_fu_8484_p1.read().is_01())? sc_lv<32>(): (sc_biguint<32>(p_accu_V_2_fu_8336_p3.read()) + sc_biguint<32>(res_212_s_fu_8484_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp7_fu_981_p2() {
    tmp7_fu_981_p2 = (p_Result_2_0_6_fu_973_p3.read() ^ p_Result_0_6_fu_965_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp80_fu_8496_p2() {
    tmp80_fu_8496_p2 = (!res_212_13_cast_fu_8487_p1.read().is_01() || !res_212_11_cast_fu_8481_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_212_13_cast_fu_8487_p1.read()) + sc_biguint<2>(res_212_11_cast_fu_8481_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp81_fu_8506_p2() {
    tmp81_fu_8506_p2 = (!tmp151_cast_fu_8502_p1.read().is_01() || !tmp79_fu_8490_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(tmp151_cast_fu_8502_p1.read()) + sc_biguint<32>(tmp79_fu_8490_p2.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp82_fu_2185_p2() {
    tmp82_fu_2185_p2 = (!res_212_10_cast_fu_2097_p1.read().is_01() || !res_212_8_cast_fu_2025_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_212_10_cast_fu_2097_p1.read()) + sc_biguint<2>(res_212_8_cast_fu_2025_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp83_fu_2195_p2() {
    tmp83_fu_2195_p2 = (!res_212_7_cast_fu_2001_p1.read().is_01() || !res_212_cast_fu_2073_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_212_7_cast_fu_2001_p1.read()) + sc_biguint<2>(res_212_cast_fu_2073_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp84_fu_2205_p2() {
    tmp84_fu_2205_p2 = (!tmp154_cast_fu_2201_p1.read().is_01() || !tmp153_cast_fu_2191_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp154_cast_fu_2201_p1.read()) + sc_biguint<3>(tmp153_cast_fu_2191_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp85_fu_8515_p2() {
    tmp85_fu_8515_p2 = (!tmp152_cast_fu_8512_p1.read().is_01() || !tmp81_fu_8506_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(tmp152_cast_fu_8512_p1.read()) + sc_biguint<32>(tmp81_fu_8506_p2.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp86_fu_2211_p2() {
    tmp86_fu_2211_p2 = (!res_212_9_cast_fu_2049_p1.read().is_01() || !res_cast_99_fu_1833_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_212_9_cast_fu_2049_p1.read()) + sc_biguint<2>(res_cast_99_fu_1833_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp87_fu_2221_p2() {
    tmp87_fu_2221_p2 = (!res_212_2_cast_fu_1881_p1.read().is_01() || !res_212_1_cast_fu_1857_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_212_2_cast_fu_1881_p1.read()) + sc_biguint<2>(res_212_1_cast_fu_1857_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp88_fu_2231_p2() {
    tmp88_fu_2231_p2 = (!tmp158_cast_fu_2227_p1.read().is_01() || !tmp157_cast_fu_2217_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp158_cast_fu_2227_p1.read()) + sc_biguint<3>(tmp157_cast_fu_2217_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp89_fu_2237_p2() {
    tmp89_fu_2237_p2 = (!res_212_4_cast_fu_1929_p1.read().is_01() || !res_212_3_cast_fu_1905_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_212_4_cast_fu_1929_p1.read()) + sc_biguint<2>(res_212_3_cast_fu_1905_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp8_fu_1013_p2() {
    tmp8_fu_1013_p2 = (p_Result_2_0_7_fu_1005_p3.read() ^ p_Result_0_7_fu_997_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp90_fu_2247_p2() {
    tmp90_fu_2247_p2 = (!res_212_5_cast_fu_1953_p1.read().is_01() || !res_212_14_cast_fu_2181_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_212_5_cast_fu_1953_p1.read()) + sc_biguint<2>(res_212_14_cast_fu_2181_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp91_fu_2253_p2() {
    tmp91_fu_2253_p2 = (!tmp90_fu_2247_p2.read().is_01() || !res_212_6_cast_fu_1977_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(tmp90_fu_2247_p2.read()) + sc_biguint<2>(res_212_6_cast_fu_1977_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp92_fu_2263_p2() {
    tmp92_fu_2263_p2 = (!tmp161_cast_fu_2259_p1.read().is_01() || !tmp160_cast_fu_2243_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp161_cast_fu_2259_p1.read()) + sc_biguint<3>(tmp160_cast_fu_2243_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp93_fu_8527_p2() {
    tmp93_fu_8527_p2 = (!tmp159_cast_fu_8524_p1.read().is_01() || !tmp156_cast_fu_8521_p1.read().is_01())? sc_lv<4>(): (sc_biguint<4>(tmp159_cast_fu_8524_p1.read()) + sc_biguint<4>(tmp156_cast_fu_8521_p1.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp94_fu_2277_p2() {
    tmp94_fu_2277_p2 = (p_Result_2_fu_781_p3.read() ^ p_Result_3_fu_2269_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp95_fu_2301_p2() {
    tmp95_fu_2301_p2 = (p_Result_2_0_1_fu_813_p3.read() ^ p_Result_313_1_fu_2293_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp96_fu_2325_p2() {
    tmp96_fu_2325_p2 = (p_Result_2_0_2_fu_845_p3.read() ^ p_Result_313_2_fu_2317_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp97_fu_2349_p2() {
    tmp97_fu_2349_p2 = (p_Result_2_0_3_fu_877_p3.read() ^ p_Result_313_3_fu_2341_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp98_fu_2373_p2() {
    tmp98_fu_2373_p2 = (p_Result_2_0_4_fu_909_p3.read() ^ p_Result_313_4_fu_2365_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp99_fu_2397_p2() {
    tmp99_fu_2397_p2 = (p_Result_2_0_5_fu_941_p3.read() ^ p_Result_313_5_fu_2389_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp9_fu_1045_p2() {
    tmp9_fu_1045_p2 = (p_Result_2_0_8_fu_1037_p3.read() ^ p_Result_0_8_fu_1029_p3.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_11_fu_680_p1() {
    tmp_11_fu_680_p1 = esl_zext<64,32>(tile_assign_fu_226.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_0_10_fu_1147_p2() {
    tmp_12_0_10_fu_1147_p2 = (tmp12_fu_1141_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_0_11_fu_1179_p2() {
    tmp_12_0_11_fu_1179_p2 = (tmp13_fu_1173_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_0_12_fu_1207_p2() {
    tmp_12_0_12_fu_1207_p2 = (tmp14_fu_1201_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_0_13_fu_1235_p2() {
    tmp_12_0_13_fu_1235_p2 = (tmp15_fu_1229_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_0_14_fu_1263_p2() {
    tmp_12_0_14_fu_1263_p2 = (tmp16_fu_1257_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_0_1_fu_827_p2() {
    tmp_12_0_1_fu_827_p2 = (tmp2_fu_821_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_0_2_fu_859_p2() {
    tmp_12_0_2_fu_859_p2 = (tmp3_fu_853_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_0_3_fu_891_p2() {
    tmp_12_0_3_fu_891_p2 = (tmp4_fu_885_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_0_4_fu_923_p2() {
    tmp_12_0_4_fu_923_p2 = (tmp5_fu_917_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_0_5_fu_955_p2() {
    tmp_12_0_5_fu_955_p2 = (tmp6_fu_949_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_0_6_fu_987_p2() {
    tmp_12_0_6_fu_987_p2 = (tmp7_fu_981_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_0_7_fu_1019_p2() {
    tmp_12_0_7_fu_1019_p2 = (tmp8_fu_1013_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_0_8_fu_1051_p2() {
    tmp_12_0_8_fu_1051_p2 = (tmp9_fu_1045_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_0_9_fu_1083_p2() {
    tmp_12_0_9_fu_1083_p2 = (tmp10_fu_1077_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_0_s_fu_1115_p2() {
    tmp_12_0_s_fu_1115_p2 = (tmp11_fu_1109_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_10_10_fu_5739_p2() {
    tmp_12_10_10_fu_5739_p2 = (tmp322_fu_5733_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_10_11_fu_5763_p2() {
    tmp_12_10_11_fu_5763_p2 = (tmp323_fu_5757_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_10_12_fu_5783_p2() {
    tmp_12_10_12_fu_5783_p2 = (tmp324_fu_5777_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_10_13_fu_5803_p2() {
    tmp_12_10_13_fu_5803_p2 = (tmp325_fu_5797_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_10_14_fu_5823_p2() {
    tmp_12_10_14_fu_5823_p2 = (tmp326_fu_5817_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_10_1_fu_5499_p2() {
    tmp_12_10_1_fu_5499_p2 = (tmp312_fu_5493_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_10_2_fu_5523_p2() {
    tmp_12_10_2_fu_5523_p2 = (tmp313_fu_5517_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_10_3_fu_5547_p2() {
    tmp_12_10_3_fu_5547_p2 = (tmp314_fu_5541_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_10_4_fu_5571_p2() {
    tmp_12_10_4_fu_5571_p2 = (tmp315_fu_5565_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_10_5_fu_5595_p2() {
    tmp_12_10_5_fu_5595_p2 = (tmp316_fu_5589_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_10_6_fu_5619_p2() {
    tmp_12_10_6_fu_5619_p2 = (tmp317_fu_5613_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_10_7_fu_5643_p2() {
    tmp_12_10_7_fu_5643_p2 = (tmp318_fu_5637_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_10_8_fu_5667_p2() {
    tmp_12_10_8_fu_5667_p2 = (tmp319_fu_5661_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_10_9_fu_5691_p2() {
    tmp_12_10_9_fu_5691_p2 = (tmp320_fu_5685_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_10_fu_5931_p2() {
    tmp_12_10_fu_5931_p2 = (tmp342_fu_5925_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_10_s_fu_5715_p2() {
    tmp_12_10_s_fu_5715_p2 = (tmp321_fu_5709_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_11_10_fu_6195_p2() {
    tmp_12_11_10_fu_6195_p2 = (tmp353_fu_6189_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_11_11_fu_6219_p2() {
    tmp_12_11_11_fu_6219_p2 = (tmp354_fu_6213_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_11_12_fu_6239_p2() {
    tmp_12_11_12_fu_6239_p2 = (tmp355_fu_6233_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_11_13_fu_6259_p2() {
    tmp_12_11_13_fu_6259_p2 = (tmp356_fu_6253_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_11_14_fu_6279_p2() {
    tmp_12_11_14_fu_6279_p2 = (tmp357_fu_6273_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_11_1_fu_5955_p2() {
    tmp_12_11_1_fu_5955_p2 = (tmp343_fu_5949_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_11_2_fu_5979_p2() {
    tmp_12_11_2_fu_5979_p2 = (tmp344_fu_5973_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_11_3_fu_6003_p2() {
    tmp_12_11_3_fu_6003_p2 = (tmp345_fu_5997_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_11_4_fu_6027_p2() {
    tmp_12_11_4_fu_6027_p2 = (tmp346_fu_6021_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_11_5_fu_6051_p2() {
    tmp_12_11_5_fu_6051_p2 = (tmp347_fu_6045_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_11_6_fu_6075_p2() {
    tmp_12_11_6_fu_6075_p2 = (tmp348_fu_6069_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_11_7_fu_6099_p2() {
    tmp_12_11_7_fu_6099_p2 = (tmp349_fu_6093_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_11_8_fu_6123_p2() {
    tmp_12_11_8_fu_6123_p2 = (tmp350_fu_6117_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_11_9_fu_6147_p2() {
    tmp_12_11_9_fu_6147_p2 = (tmp351_fu_6141_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_11_fu_6387_p2() {
    tmp_12_11_fu_6387_p2 = (tmp373_fu_6381_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_11_s_fu_6171_p2() {
    tmp_12_11_s_fu_6171_p2 = (tmp352_fu_6165_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_12_10_fu_6651_p2() {
    tmp_12_12_10_fu_6651_p2 = (tmp384_fu_6645_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_12_11_fu_6675_p2() {
    tmp_12_12_11_fu_6675_p2 = (tmp385_fu_6669_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_12_12_fu_6695_p2() {
    tmp_12_12_12_fu_6695_p2 = (tmp386_fu_6689_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_12_13_fu_6715_p2() {
    tmp_12_12_13_fu_6715_p2 = (tmp387_fu_6709_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_12_14_fu_6735_p2() {
    tmp_12_12_14_fu_6735_p2 = (tmp388_fu_6729_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_12_1_fu_6411_p2() {
    tmp_12_12_1_fu_6411_p2 = (tmp374_fu_6405_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_12_2_fu_6435_p2() {
    tmp_12_12_2_fu_6435_p2 = (tmp375_fu_6429_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_12_3_fu_6459_p2() {
    tmp_12_12_3_fu_6459_p2 = (tmp376_fu_6453_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_12_4_fu_6483_p2() {
    tmp_12_12_4_fu_6483_p2 = (tmp377_fu_6477_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_12_5_fu_6507_p2() {
    tmp_12_12_5_fu_6507_p2 = (tmp378_fu_6501_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_12_6_fu_6531_p2() {
    tmp_12_12_6_fu_6531_p2 = (tmp379_fu_6525_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_12_7_fu_6555_p2() {
    tmp_12_12_7_fu_6555_p2 = (tmp380_fu_6549_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_12_8_fu_6579_p2() {
    tmp_12_12_8_fu_6579_p2 = (tmp381_fu_6573_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_12_9_fu_6603_p2() {
    tmp_12_12_9_fu_6603_p2 = (tmp382_fu_6597_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_12_fu_6843_p2() {
    tmp_12_12_fu_6843_p2 = (tmp404_fu_6837_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_12_s_fu_6627_p2() {
    tmp_12_12_s_fu_6627_p2 = (tmp383_fu_6621_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_13_10_fu_7107_p2() {
    tmp_12_13_10_fu_7107_p2 = (tmp415_fu_7101_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_13_11_fu_7131_p2() {
    tmp_12_13_11_fu_7131_p2 = (tmp416_fu_7125_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_13_12_fu_7151_p2() {
    tmp_12_13_12_fu_7151_p2 = (tmp417_fu_7145_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_13_13_fu_7171_p2() {
    tmp_12_13_13_fu_7171_p2 = (tmp418_fu_7165_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_13_14_fu_7191_p2() {
    tmp_12_13_14_fu_7191_p2 = (tmp419_fu_7185_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_13_1_fu_6867_p2() {
    tmp_12_13_1_fu_6867_p2 = (tmp405_fu_6861_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_13_2_fu_6891_p2() {
    tmp_12_13_2_fu_6891_p2 = (tmp406_fu_6885_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_13_3_fu_6915_p2() {
    tmp_12_13_3_fu_6915_p2 = (tmp407_fu_6909_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_13_4_fu_6939_p2() {
    tmp_12_13_4_fu_6939_p2 = (tmp408_fu_6933_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_13_5_fu_6963_p2() {
    tmp_12_13_5_fu_6963_p2 = (tmp409_fu_6957_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_13_6_fu_6987_p2() {
    tmp_12_13_6_fu_6987_p2 = (tmp410_fu_6981_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_13_7_fu_7011_p2() {
    tmp_12_13_7_fu_7011_p2 = (tmp411_fu_7005_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_13_8_fu_7035_p2() {
    tmp_12_13_8_fu_7035_p2 = (tmp412_fu_7029_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_13_9_fu_7059_p2() {
    tmp_12_13_9_fu_7059_p2 = (tmp413_fu_7053_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_13_fu_7299_p2() {
    tmp_12_13_fu_7299_p2 = (tmp435_fu_7293_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_13_s_fu_7083_p2() {
    tmp_12_13_s_fu_7083_p2 = (tmp414_fu_7077_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_14_10_fu_7563_p2() {
    tmp_12_14_10_fu_7563_p2 = (tmp446_fu_7557_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_14_11_fu_7587_p2() {
    tmp_12_14_11_fu_7587_p2 = (tmp447_fu_7581_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_14_12_fu_7607_p2() {
    tmp_12_14_12_fu_7607_p2 = (tmp448_fu_7601_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_14_13_fu_7627_p2() {
    tmp_12_14_13_fu_7627_p2 = (tmp449_fu_7621_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_14_14_fu_7647_p2() {
    tmp_12_14_14_fu_7647_p2 = (tmp450_fu_7641_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_14_1_fu_7323_p2() {
    tmp_12_14_1_fu_7323_p2 = (tmp436_fu_7317_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_14_2_fu_7347_p2() {
    tmp_12_14_2_fu_7347_p2 = (tmp437_fu_7341_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_14_3_fu_7371_p2() {
    tmp_12_14_3_fu_7371_p2 = (tmp438_fu_7365_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_14_4_fu_7395_p2() {
    tmp_12_14_4_fu_7395_p2 = (tmp439_fu_7389_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_14_5_fu_7419_p2() {
    tmp_12_14_5_fu_7419_p2 = (tmp440_fu_7413_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_14_6_fu_7443_p2() {
    tmp_12_14_6_fu_7443_p2 = (tmp441_fu_7437_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_14_7_fu_7467_p2() {
    tmp_12_14_7_fu_7467_p2 = (tmp442_fu_7461_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_14_8_fu_7491_p2() {
    tmp_12_14_8_fu_7491_p2 = (tmp443_fu_7485_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_14_9_fu_7515_p2() {
    tmp_12_14_9_fu_7515_p2 = (tmp444_fu_7509_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_14_fu_7755_p2() {
    tmp_12_14_fu_7755_p2 = (tmp466_fu_7749_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_14_s_fu_7539_p2() {
    tmp_12_14_s_fu_7539_p2 = (tmp445_fu_7533_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_15_10_fu_8019_p2() {
    tmp_12_15_10_fu_8019_p2 = (tmp477_fu_8013_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_15_11_fu_8043_p2() {
    tmp_12_15_11_fu_8043_p2 = (tmp478_fu_8037_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_15_12_fu_8063_p2() {
    tmp_12_15_12_fu_8063_p2 = (tmp479_fu_8057_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_15_13_fu_8083_p2() {
    tmp_12_15_13_fu_8083_p2 = (tmp480_fu_8077_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_15_14_fu_8103_p2() {
    tmp_12_15_14_fu_8103_p2 = (tmp481_fu_8097_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_15_1_fu_7779_p2() {
    tmp_12_15_1_fu_7779_p2 = (tmp467_fu_7773_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_15_2_fu_7803_p2() {
    tmp_12_15_2_fu_7803_p2 = (tmp468_fu_7797_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_15_3_fu_7827_p2() {
    tmp_12_15_3_fu_7827_p2 = (tmp469_fu_7821_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_15_4_fu_7851_p2() {
    tmp_12_15_4_fu_7851_p2 = (tmp470_fu_7845_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_15_5_fu_7875_p2() {
    tmp_12_15_5_fu_7875_p2 = (tmp471_fu_7869_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_15_6_fu_7899_p2() {
    tmp_12_15_6_fu_7899_p2 = (tmp472_fu_7893_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_15_7_fu_7923_p2() {
    tmp_12_15_7_fu_7923_p2 = (tmp473_fu_7917_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_15_8_fu_7947_p2() {
    tmp_12_15_8_fu_7947_p2 = (tmp474_fu_7941_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_15_9_fu_7971_p2() {
    tmp_12_15_9_fu_7971_p2 = (tmp475_fu_7965_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_15_s_fu_7995_p2() {
    tmp_12_15_s_fu_7995_p2 = (tmp476_fu_7989_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_1_10_fu_1635_p2() {
    tmp_12_1_10_fu_1635_p2 = (tmp43_fu_1629_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_1_11_fu_1659_p2() {
    tmp_12_1_11_fu_1659_p2 = (tmp44_fu_1653_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_1_12_fu_1679_p2() {
    tmp_12_1_12_fu_1679_p2 = (tmp45_fu_1673_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_1_13_fu_1699_p2() {
    tmp_12_1_13_fu_1699_p2 = (tmp46_fu_1693_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_1_14_fu_1719_p2() {
    tmp_12_1_14_fu_1719_p2 = (tmp47_fu_1713_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_1_1_fu_1395_p2() {
    tmp_12_1_1_fu_1395_p2 = (tmp33_fu_1389_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_1_2_fu_1419_p2() {
    tmp_12_1_2_fu_1419_p2 = (tmp34_fu_1413_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_1_3_fu_1443_p2() {
    tmp_12_1_3_fu_1443_p2 = (tmp35_fu_1437_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_1_4_fu_1467_p2() {
    tmp_12_1_4_fu_1467_p2 = (tmp36_fu_1461_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_1_5_fu_1491_p2() {
    tmp_12_1_5_fu_1491_p2 = (tmp37_fu_1485_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_1_6_fu_1515_p2() {
    tmp_12_1_6_fu_1515_p2 = (tmp38_fu_1509_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_1_7_fu_1539_p2() {
    tmp_12_1_7_fu_1539_p2 = (tmp39_fu_1533_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_1_8_fu_1563_p2() {
    tmp_12_1_8_fu_1563_p2 = (tmp40_fu_1557_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_1_9_fu_1587_p2() {
    tmp_12_1_9_fu_1587_p2 = (tmp41_fu_1581_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_1_fu_1371_p2() {
    tmp_12_1_fu_1371_p2 = (tmp32_fu_1365_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_1_s_fu_1611_p2() {
    tmp_12_1_s_fu_1611_p2 = (tmp42_fu_1605_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_2_10_fu_2091_p2() {
    tmp_12_2_10_fu_2091_p2 = (tmp74_fu_2085_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_2_11_fu_2115_p2() {
    tmp_12_2_11_fu_2115_p2 = (tmp75_fu_2109_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_2_12_fu_2135_p2() {
    tmp_12_2_12_fu_2135_p2 = (tmp76_fu_2129_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_2_13_fu_2155_p2() {
    tmp_12_2_13_fu_2155_p2 = (tmp77_fu_2149_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_2_14_fu_2175_p2() {
    tmp_12_2_14_fu_2175_p2 = (tmp78_fu_2169_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_2_1_fu_1851_p2() {
    tmp_12_2_1_fu_1851_p2 = (tmp64_fu_1845_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_2_2_fu_1875_p2() {
    tmp_12_2_2_fu_1875_p2 = (tmp65_fu_1869_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_2_3_fu_1899_p2() {
    tmp_12_2_3_fu_1899_p2 = (tmp66_fu_1893_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_2_4_fu_1923_p2() {
    tmp_12_2_4_fu_1923_p2 = (tmp67_fu_1917_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_2_5_fu_1947_p2() {
    tmp_12_2_5_fu_1947_p2 = (tmp68_fu_1941_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_2_6_fu_1971_p2() {
    tmp_12_2_6_fu_1971_p2 = (tmp69_fu_1965_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_2_7_fu_1995_p2() {
    tmp_12_2_7_fu_1995_p2 = (tmp70_fu_1989_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_2_8_fu_2019_p2() {
    tmp_12_2_8_fu_2019_p2 = (tmp71_fu_2013_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_2_9_fu_2043_p2() {
    tmp_12_2_9_fu_2043_p2 = (tmp72_fu_2037_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_2_fu_1827_p2() {
    tmp_12_2_fu_1827_p2 = (tmp63_fu_1821_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_2_s_fu_2067_p2() {
    tmp_12_2_s_fu_2067_p2 = (tmp73_fu_2061_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_3_10_fu_2547_p2() {
    tmp_12_3_10_fu_2547_p2 = (tmp105_fu_2541_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_3_11_fu_2571_p2() {
    tmp_12_3_11_fu_2571_p2 = (tmp106_fu_2565_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_3_12_fu_2591_p2() {
    tmp_12_3_12_fu_2591_p2 = (tmp107_fu_2585_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_3_13_fu_2611_p2() {
    tmp_12_3_13_fu_2611_p2 = (tmp108_fu_2605_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_3_14_fu_2631_p2() {
    tmp_12_3_14_fu_2631_p2 = (tmp109_fu_2625_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_3_1_fu_2307_p2() {
    tmp_12_3_1_fu_2307_p2 = (tmp95_fu_2301_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_3_2_fu_2331_p2() {
    tmp_12_3_2_fu_2331_p2 = (tmp96_fu_2325_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_3_3_fu_2355_p2() {
    tmp_12_3_3_fu_2355_p2 = (tmp97_fu_2349_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_3_4_fu_2379_p2() {
    tmp_12_3_4_fu_2379_p2 = (tmp98_fu_2373_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_3_5_fu_2403_p2() {
    tmp_12_3_5_fu_2403_p2 = (tmp99_fu_2397_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_3_6_fu_2427_p2() {
    tmp_12_3_6_fu_2427_p2 = (tmp100_fu_2421_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_3_7_fu_2451_p2() {
    tmp_12_3_7_fu_2451_p2 = (tmp101_fu_2445_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_3_8_fu_2475_p2() {
    tmp_12_3_8_fu_2475_p2 = (tmp102_fu_2469_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_3_9_fu_2499_p2() {
    tmp_12_3_9_fu_2499_p2 = (tmp103_fu_2493_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_3_fu_2283_p2() {
    tmp_12_3_fu_2283_p2 = (tmp94_fu_2277_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_3_s_fu_2523_p2() {
    tmp_12_3_s_fu_2523_p2 = (tmp104_fu_2517_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_4_10_fu_3003_p2() {
    tmp_12_4_10_fu_3003_p2 = (tmp136_fu_2997_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_4_11_fu_3027_p2() {
    tmp_12_4_11_fu_3027_p2 = (tmp137_fu_3021_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_4_12_fu_3047_p2() {
    tmp_12_4_12_fu_3047_p2 = (tmp138_fu_3041_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_4_13_fu_3067_p2() {
    tmp_12_4_13_fu_3067_p2 = (tmp139_fu_3061_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_4_14_fu_3087_p2() {
    tmp_12_4_14_fu_3087_p2 = (tmp140_fu_3081_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_4_1_fu_2763_p2() {
    tmp_12_4_1_fu_2763_p2 = (tmp126_fu_2757_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_4_2_fu_2787_p2() {
    tmp_12_4_2_fu_2787_p2 = (tmp127_fu_2781_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_4_3_fu_2811_p2() {
    tmp_12_4_3_fu_2811_p2 = (tmp128_fu_2805_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_4_4_fu_2835_p2() {
    tmp_12_4_4_fu_2835_p2 = (tmp129_fu_2829_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_4_5_fu_2859_p2() {
    tmp_12_4_5_fu_2859_p2 = (tmp130_fu_2853_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_4_6_fu_2883_p2() {
    tmp_12_4_6_fu_2883_p2 = (tmp131_fu_2877_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_4_7_fu_2907_p2() {
    tmp_12_4_7_fu_2907_p2 = (tmp132_fu_2901_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_4_8_fu_2931_p2() {
    tmp_12_4_8_fu_2931_p2 = (tmp133_fu_2925_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_4_9_fu_2955_p2() {
    tmp_12_4_9_fu_2955_p2 = (tmp134_fu_2949_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_4_fu_2739_p2() {
    tmp_12_4_fu_2739_p2 = (tmp125_fu_2733_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_4_s_fu_2979_p2() {
    tmp_12_4_s_fu_2979_p2 = (tmp135_fu_2973_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_5_10_fu_3459_p2() {
    tmp_12_5_10_fu_3459_p2 = (tmp167_fu_3453_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_5_11_fu_3483_p2() {
    tmp_12_5_11_fu_3483_p2 = (tmp168_fu_3477_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_5_12_fu_3503_p2() {
    tmp_12_5_12_fu_3503_p2 = (tmp169_fu_3497_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_5_13_fu_3523_p2() {
    tmp_12_5_13_fu_3523_p2 = (tmp170_fu_3517_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_5_14_fu_3543_p2() {
    tmp_12_5_14_fu_3543_p2 = (tmp171_fu_3537_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_5_1_fu_3219_p2() {
    tmp_12_5_1_fu_3219_p2 = (tmp157_fu_3213_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_5_2_fu_3243_p2() {
    tmp_12_5_2_fu_3243_p2 = (tmp158_fu_3237_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_5_3_fu_3267_p2() {
    tmp_12_5_3_fu_3267_p2 = (tmp159_fu_3261_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_5_4_fu_3291_p2() {
    tmp_12_5_4_fu_3291_p2 = (tmp160_fu_3285_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_5_5_fu_3315_p2() {
    tmp_12_5_5_fu_3315_p2 = (tmp161_fu_3309_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_5_6_fu_3339_p2() {
    tmp_12_5_6_fu_3339_p2 = (tmp162_fu_3333_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_5_7_fu_3363_p2() {
    tmp_12_5_7_fu_3363_p2 = (tmp163_fu_3357_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_5_8_fu_3387_p2() {
    tmp_12_5_8_fu_3387_p2 = (tmp164_fu_3381_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_5_9_fu_3411_p2() {
    tmp_12_5_9_fu_3411_p2 = (tmp165_fu_3405_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_5_fu_3195_p2() {
    tmp_12_5_fu_3195_p2 = (tmp156_fu_3189_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_5_s_fu_3435_p2() {
    tmp_12_5_s_fu_3435_p2 = (tmp166_fu_3429_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_6_10_fu_3915_p2() {
    tmp_12_6_10_fu_3915_p2 = (tmp198_fu_3909_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_6_11_fu_3939_p2() {
    tmp_12_6_11_fu_3939_p2 = (tmp199_fu_3933_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_6_12_fu_3959_p2() {
    tmp_12_6_12_fu_3959_p2 = (tmp200_fu_3953_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_6_13_fu_3979_p2() {
    tmp_12_6_13_fu_3979_p2 = (tmp201_fu_3973_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_6_14_fu_3999_p2() {
    tmp_12_6_14_fu_3999_p2 = (tmp202_fu_3993_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_6_1_fu_3675_p2() {
    tmp_12_6_1_fu_3675_p2 = (tmp188_fu_3669_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_6_2_fu_3699_p2() {
    tmp_12_6_2_fu_3699_p2 = (tmp189_fu_3693_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_6_3_fu_3723_p2() {
    tmp_12_6_3_fu_3723_p2 = (tmp190_fu_3717_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_6_4_fu_3747_p2() {
    tmp_12_6_4_fu_3747_p2 = (tmp191_fu_3741_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_6_5_fu_3771_p2() {
    tmp_12_6_5_fu_3771_p2 = (tmp192_fu_3765_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_6_6_fu_3795_p2() {
    tmp_12_6_6_fu_3795_p2 = (tmp193_fu_3789_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_6_7_fu_3819_p2() {
    tmp_12_6_7_fu_3819_p2 = (tmp194_fu_3813_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_6_8_fu_3843_p2() {
    tmp_12_6_8_fu_3843_p2 = (tmp195_fu_3837_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_6_9_fu_3867_p2() {
    tmp_12_6_9_fu_3867_p2 = (tmp196_fu_3861_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_6_fu_3651_p2() {
    tmp_12_6_fu_3651_p2 = (tmp187_fu_3645_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_6_s_fu_3891_p2() {
    tmp_12_6_s_fu_3891_p2 = (tmp197_fu_3885_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_7_10_fu_4371_p2() {
    tmp_12_7_10_fu_4371_p2 = (tmp229_fu_4365_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_7_11_fu_4395_p2() {
    tmp_12_7_11_fu_4395_p2 = (tmp230_fu_4389_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_7_12_fu_4415_p2() {
    tmp_12_7_12_fu_4415_p2 = (tmp231_fu_4409_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_7_13_fu_4435_p2() {
    tmp_12_7_13_fu_4435_p2 = (tmp232_fu_4429_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_7_14_fu_4455_p2() {
    tmp_12_7_14_fu_4455_p2 = (tmp233_fu_4449_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_7_1_fu_4131_p2() {
    tmp_12_7_1_fu_4131_p2 = (tmp219_fu_4125_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_7_2_fu_4155_p2() {
    tmp_12_7_2_fu_4155_p2 = (tmp220_fu_4149_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_7_3_fu_4179_p2() {
    tmp_12_7_3_fu_4179_p2 = (tmp221_fu_4173_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_7_4_fu_4203_p2() {
    tmp_12_7_4_fu_4203_p2 = (tmp222_fu_4197_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_7_5_fu_4227_p2() {
    tmp_12_7_5_fu_4227_p2 = (tmp223_fu_4221_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_7_6_fu_4251_p2() {
    tmp_12_7_6_fu_4251_p2 = (tmp224_fu_4245_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_7_7_fu_4275_p2() {
    tmp_12_7_7_fu_4275_p2 = (tmp225_fu_4269_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_7_8_fu_4299_p2() {
    tmp_12_7_8_fu_4299_p2 = (tmp226_fu_4293_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_7_9_fu_4323_p2() {
    tmp_12_7_9_fu_4323_p2 = (tmp227_fu_4317_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_7_fu_4107_p2() {
    tmp_12_7_fu_4107_p2 = (tmp218_fu_4101_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_7_s_fu_4347_p2() {
    tmp_12_7_s_fu_4347_p2 = (tmp228_fu_4341_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_8_10_fu_4827_p2() {
    tmp_12_8_10_fu_4827_p2 = (tmp260_fu_4821_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_8_11_fu_4851_p2() {
    tmp_12_8_11_fu_4851_p2 = (tmp261_fu_4845_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_8_12_fu_4871_p2() {
    tmp_12_8_12_fu_4871_p2 = (tmp262_fu_4865_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_8_13_fu_4891_p2() {
    tmp_12_8_13_fu_4891_p2 = (tmp263_fu_4885_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_8_14_fu_4911_p2() {
    tmp_12_8_14_fu_4911_p2 = (tmp264_fu_4905_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_8_1_fu_4587_p2() {
    tmp_12_8_1_fu_4587_p2 = (tmp250_fu_4581_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_8_2_fu_4611_p2() {
    tmp_12_8_2_fu_4611_p2 = (tmp251_fu_4605_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_8_3_fu_4635_p2() {
    tmp_12_8_3_fu_4635_p2 = (tmp252_fu_4629_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_8_4_fu_4659_p2() {
    tmp_12_8_4_fu_4659_p2 = (tmp253_fu_4653_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_8_5_fu_4683_p2() {
    tmp_12_8_5_fu_4683_p2 = (tmp254_fu_4677_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_8_6_fu_4707_p2() {
    tmp_12_8_6_fu_4707_p2 = (tmp255_fu_4701_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_8_7_fu_4731_p2() {
    tmp_12_8_7_fu_4731_p2 = (tmp256_fu_4725_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_8_8_fu_4755_p2() {
    tmp_12_8_8_fu_4755_p2 = (tmp257_fu_4749_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_8_9_fu_4779_p2() {
    tmp_12_8_9_fu_4779_p2 = (tmp258_fu_4773_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_8_fu_4563_p2() {
    tmp_12_8_fu_4563_p2 = (tmp249_fu_4557_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_8_s_fu_4803_p2() {
    tmp_12_8_s_fu_4803_p2 = (tmp259_fu_4797_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_9_10_fu_5283_p2() {
    tmp_12_9_10_fu_5283_p2 = (tmp291_fu_5277_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_9_11_fu_5307_p2() {
    tmp_12_9_11_fu_5307_p2 = (tmp292_fu_5301_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_9_12_fu_5327_p2() {
    tmp_12_9_12_fu_5327_p2 = (tmp293_fu_5321_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_9_13_fu_5347_p2() {
    tmp_12_9_13_fu_5347_p2 = (tmp294_fu_5341_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_9_14_fu_5367_p2() {
    tmp_12_9_14_fu_5367_p2 = (tmp295_fu_5361_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_9_1_fu_5043_p2() {
    tmp_12_9_1_fu_5043_p2 = (tmp281_fu_5037_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_9_2_fu_5067_p2() {
    tmp_12_9_2_fu_5067_p2 = (tmp282_fu_5061_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_9_3_fu_5091_p2() {
    tmp_12_9_3_fu_5091_p2 = (tmp283_fu_5085_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_9_4_fu_5115_p2() {
    tmp_12_9_4_fu_5115_p2 = (tmp284_fu_5109_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_9_5_fu_5139_p2() {
    tmp_12_9_5_fu_5139_p2 = (tmp285_fu_5133_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_9_6_fu_5163_p2() {
    tmp_12_9_6_fu_5163_p2 = (tmp286_fu_5157_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_9_7_fu_5187_p2() {
    tmp_12_9_7_fu_5187_p2 = (tmp287_fu_5181_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_9_8_fu_5211_p2() {
    tmp_12_9_8_fu_5211_p2 = (tmp288_fu_5205_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_9_9_fu_5235_p2() {
    tmp_12_9_9_fu_5235_p2 = (tmp289_fu_5229_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_9_fu_5019_p2() {
    tmp_12_9_fu_5019_p2 = (tmp280_fu_5013_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_9_s_fu_5259_p2() {
    tmp_12_9_s_fu_5259_p2 = (tmp290_fu_5253_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_12_s_fu_5475_p2() {
    tmp_12_s_fu_5475_p2 = (tmp311_fu_5469_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_261_fu_795_p2() {
    tmp_261_fu_795_p2 = (tmp1_fu_789_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_262_fu_564_p1() {
    tmp_262_fu_564_p1 = sf_fu_230.read().range(2-1, 0);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_2_fu_741_p2() {
    tmp_2_fu_741_p2 = (!nf_fu_735_p2.read().is_01() || !ap_const_lv32_4.is_01())? sc_lv<1>(): sc_lv<1>(nf_fu_735_p2.read() == ap_const_lv32_4);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_497_fu_731_p1() {
    tmp_497_fu_731_p1 = nf_assign_fu_234.read().range(2-1, 0);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_4_fu_674_p2() {
    tmp_4_fu_674_p2 = (!sf_fu_230.read().is_01() || !ap_const_lv32_0.is_01())? sc_lv<1>(): sc_lv<1>(sf_fu_230.read() == ap_const_lv32_0);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_fu_525_p2() {
    tmp_fu_525_p2 = (!nf_assign_fu_234.read().is_01() || !ap_const_lv32_0.is_01())? sc_lv<1>(): sc_lv<1>(nf_assign_fu_234.read() == ap_const_lv32_0);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_tmp_s_fu_712_p2() {
    tmp_s_fu_712_p2 = (!sf_1_fu_706_p2.read().is_01() || !ap_const_lv32_4.is_01())? sc_lv<1>(): sc_lv<1>(sf_1_fu_706_p2.read() == ap_const_lv32_4);
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_ult10_fu_9692_p2() {
    ult10_fu_9692_p2 = (!accu_10_V_fu_9033_p2.read().is_01() || !p_x_V_read_assign_s_fu_9679_p6.read().is_01())? sc_lv<1>(): (sc_biguint<32>(accu_10_V_fu_9033_p2.read()) < sc_biguint<32>(p_x_V_read_assign_s_fu_9679_p6.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_ult11_fu_9717_p2() {
    ult11_fu_9717_p2 = (!accu_11_V_fu_9095_p2.read().is_01() || !p_x_V_read_assign_10_fu_9704_p6.read().is_01())? sc_lv<1>(): (sc_biguint<32>(accu_11_V_fu_9095_p2.read()) < sc_biguint<32>(p_x_V_read_assign_10_fu_9704_p6.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_ult12_fu_9742_p2() {
    ult12_fu_9742_p2 = (!accu_12_V_fu_9157_p2.read().is_01() || !p_x_V_read_assign_11_fu_9729_p6.read().is_01())? sc_lv<1>(): (sc_biguint<32>(accu_12_V_fu_9157_p2.read()) < sc_biguint<32>(p_x_V_read_assign_11_fu_9729_p6.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_ult13_fu_9767_p2() {
    ult13_fu_9767_p2 = (!accu_13_V_fu_9219_p2.read().is_01() || !p_x_V_read_assign_12_fu_9754_p6.read().is_01())? sc_lv<1>(): (sc_biguint<32>(accu_13_V_fu_9219_p2.read()) < sc_biguint<32>(p_x_V_read_assign_12_fu_9754_p6.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_ult14_fu_9792_p2() {
    ult14_fu_9792_p2 = (!accu_14_V_fu_9281_p2.read().is_01() || !p_x_V_read_assign_13_fu_9779_p6.read().is_01())? sc_lv<1>(): (sc_biguint<32>(accu_14_V_fu_9281_p2.read()) < sc_biguint<32>(p_x_V_read_assign_13_fu_9779_p6.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_ult15_fu_9817_p2() {
    ult15_fu_9817_p2 = (!accu_15_V_fu_9343_p2.read().is_01() || !p_x_V_read_assign_14_fu_9804_p6.read().is_01())? sc_lv<1>(): (sc_biguint<32>(accu_15_V_fu_9343_p2.read()) < sc_biguint<32>(p_x_V_read_assign_14_fu_9804_p6.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_ult1_fu_9467_p2() {
    ult1_fu_9467_p2 = (!accu_1_V_fu_8475_p2.read().is_01() || !p_x_V_read_assign_1_fu_9454_p6.read().is_01())? sc_lv<1>(): (sc_biguint<32>(accu_1_V_fu_8475_p2.read()) < sc_biguint<32>(p_x_V_read_assign_1_fu_9454_p6.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_ult2_fu_9492_p2() {
    ult2_fu_9492_p2 = (!accu_2_V_fu_8537_p2.read().is_01() || !p_x_V_read_assign_2_fu_9479_p6.read().is_01())? sc_lv<1>(): (sc_biguint<32>(accu_2_V_fu_8537_p2.read()) < sc_biguint<32>(p_x_V_read_assign_2_fu_9479_p6.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_ult3_fu_9517_p2() {
    ult3_fu_9517_p2 = (!accu_3_V_fu_8599_p2.read().is_01() || !p_x_V_read_assign_3_fu_9504_p6.read().is_01())? sc_lv<1>(): (sc_biguint<32>(accu_3_V_fu_8599_p2.read()) < sc_biguint<32>(p_x_V_read_assign_3_fu_9504_p6.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_ult4_fu_9542_p2() {
    ult4_fu_9542_p2 = (!accu_4_V_fu_8661_p2.read().is_01() || !p_x_V_read_assign_4_fu_9529_p6.read().is_01())? sc_lv<1>(): (sc_biguint<32>(accu_4_V_fu_8661_p2.read()) < sc_biguint<32>(p_x_V_read_assign_4_fu_9529_p6.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_ult5_fu_9567_p2() {
    ult5_fu_9567_p2 = (!accu_5_V_fu_8723_p2.read().is_01() || !p_x_V_read_assign_5_fu_9554_p6.read().is_01())? sc_lv<1>(): (sc_biguint<32>(accu_5_V_fu_8723_p2.read()) < sc_biguint<32>(p_x_V_read_assign_5_fu_9554_p6.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_ult6_fu_9592_p2() {
    ult6_fu_9592_p2 = (!accu_6_V_fu_8785_p2.read().is_01() || !p_x_V_read_assign_6_fu_9579_p6.read().is_01())? sc_lv<1>(): (sc_biguint<32>(accu_6_V_fu_8785_p2.read()) < sc_biguint<32>(p_x_V_read_assign_6_fu_9579_p6.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_ult7_fu_9617_p2() {
    ult7_fu_9617_p2 = (!accu_7_V_fu_8847_p2.read().is_01() || !p_x_V_read_assign_7_fu_9604_p6.read().is_01())? sc_lv<1>(): (sc_biguint<32>(accu_7_V_fu_8847_p2.read()) < sc_biguint<32>(p_x_V_read_assign_7_fu_9604_p6.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_ult8_fu_9642_p2() {
    ult8_fu_9642_p2 = (!accu_8_V_fu_8909_p2.read().is_01() || !p_x_V_read_assign_8_fu_9629_p6.read().is_01())? sc_lv<1>(): (sc_biguint<32>(accu_8_V_fu_8909_p2.read()) < sc_biguint<32>(p_x_V_read_assign_8_fu_9629_p6.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_ult9_fu_9667_p2() {
    ult9_fu_9667_p2 = (!accu_9_V_fu_8971_p2.read().is_01() || !p_x_V_read_assign_9_fu_9654_p6.read().is_01())? sc_lv<1>(): (sc_biguint<32>(accu_9_V_fu_8971_p2.read()) < sc_biguint<32>(p_x_V_read_assign_9_fu_9654_p6.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_ult_fu_9442_p2() {
    ult_fu_9442_p2 = (!accu_0_V_fu_8413_p2.read().is_01() || !p_x_V_read_assign_fu_9429_p6.read().is_01())? sc_lv<1>(): (sc_biguint<32>(accu_0_V_fu_8413_p2.read()) < sc_biguint<32>(p_x_V_read_assign_fu_9429_p6.read()));
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_weights_m_weights_V_10_address0() {
    weights_m_weights_V_10_address0 =  (sc_lv<4>) (tmp_11_fu_680_p1.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_weights_m_weights_V_10_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        weights_m_weights_V_10_ce0 = ap_const_logic_1;
    } else {
        weights_m_weights_V_10_ce0 = ap_const_logic_0;
    }
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_weights_m_weights_V_11_address0() {
    weights_m_weights_V_11_address0 =  (sc_lv<4>) (tmp_11_fu_680_p1.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_weights_m_weights_V_11_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        weights_m_weights_V_11_ce0 = ap_const_logic_1;
    } else {
        weights_m_weights_V_11_ce0 = ap_const_logic_0;
    }
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_weights_m_weights_V_12_address0() {
    weights_m_weights_V_12_address0 =  (sc_lv<4>) (tmp_11_fu_680_p1.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_weights_m_weights_V_12_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        weights_m_weights_V_12_ce0 = ap_const_logic_1;
    } else {
        weights_m_weights_V_12_ce0 = ap_const_logic_0;
    }
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_weights_m_weights_V_13_address0() {
    weights_m_weights_V_13_address0 =  (sc_lv<4>) (tmp_11_fu_680_p1.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_weights_m_weights_V_13_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        weights_m_weights_V_13_ce0 = ap_const_logic_1;
    } else {
        weights_m_weights_V_13_ce0 = ap_const_logic_0;
    }
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_weights_m_weights_V_14_address0() {
    weights_m_weights_V_14_address0 =  (sc_lv<4>) (tmp_11_fu_680_p1.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_weights_m_weights_V_14_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        weights_m_weights_V_14_ce0 = ap_const_logic_1;
    } else {
        weights_m_weights_V_14_ce0 = ap_const_logic_0;
    }
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_weights_m_weights_V_15_address0() {
    weights_m_weights_V_15_address0 =  (sc_lv<4>) (tmp_11_fu_680_p1.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_weights_m_weights_V_15_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        weights_m_weights_V_15_ce0 = ap_const_logic_1;
    } else {
        weights_m_weights_V_15_ce0 = ap_const_logic_0;
    }
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_weights_m_weights_V_1_address0() {
    weights_m_weights_V_1_address0 =  (sc_lv<4>) (tmp_11_fu_680_p1.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_weights_m_weights_V_1_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        weights_m_weights_V_1_ce0 = ap_const_logic_1;
    } else {
        weights_m_weights_V_1_ce0 = ap_const_logic_0;
    }
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_weights_m_weights_V_2_address0() {
    weights_m_weights_V_2_address0 =  (sc_lv<4>) (tmp_11_fu_680_p1.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_weights_m_weights_V_2_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        weights_m_weights_V_2_ce0 = ap_const_logic_1;
    } else {
        weights_m_weights_V_2_ce0 = ap_const_logic_0;
    }
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_weights_m_weights_V_3_address0() {
    weights_m_weights_V_3_address0 =  (sc_lv<4>) (tmp_11_fu_680_p1.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_weights_m_weights_V_3_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        weights_m_weights_V_3_ce0 = ap_const_logic_1;
    } else {
        weights_m_weights_V_3_ce0 = ap_const_logic_0;
    }
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_weights_m_weights_V_4_address0() {
    weights_m_weights_V_4_address0 =  (sc_lv<4>) (tmp_11_fu_680_p1.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_weights_m_weights_V_4_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        weights_m_weights_V_4_ce0 = ap_const_logic_1;
    } else {
        weights_m_weights_V_4_ce0 = ap_const_logic_0;
    }
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_weights_m_weights_V_5_address0() {
    weights_m_weights_V_5_address0 =  (sc_lv<4>) (tmp_11_fu_680_p1.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_weights_m_weights_V_5_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        weights_m_weights_V_5_ce0 = ap_const_logic_1;
    } else {
        weights_m_weights_V_5_ce0 = ap_const_logic_0;
    }
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_weights_m_weights_V_6_address0() {
    weights_m_weights_V_6_address0 =  (sc_lv<4>) (tmp_11_fu_680_p1.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_weights_m_weights_V_6_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        weights_m_weights_V_6_ce0 = ap_const_logic_1;
    } else {
        weights_m_weights_V_6_ce0 = ap_const_logic_0;
    }
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_weights_m_weights_V_7_address0() {
    weights_m_weights_V_7_address0 =  (sc_lv<4>) (tmp_11_fu_680_p1.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_weights_m_weights_V_7_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        weights_m_weights_V_7_ce0 = ap_const_logic_1;
    } else {
        weights_m_weights_V_7_ce0 = ap_const_logic_0;
    }
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_weights_m_weights_V_8_address0() {
    weights_m_weights_V_8_address0 =  (sc_lv<4>) (tmp_11_fu_680_p1.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_weights_m_weights_V_8_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        weights_m_weights_V_8_ce0 = ap_const_logic_1;
    } else {
        weights_m_weights_V_8_ce0 = ap_const_logic_0;
    }
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_weights_m_weights_V_9_address0() {
    weights_m_weights_V_9_address0 =  (sc_lv<4>) (tmp_11_fu_680_p1.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_weights_m_weights_V_9_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        weights_m_weights_V_9_ce0 = ap_const_logic_1;
    } else {
        weights_m_weights_V_9_ce0 = ap_const_logic_0;
    }
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_weights_m_weights_V_s_address0() {
    weights_m_weights_V_s_address0 =  (sc_lv<4>) (tmp_11_fu_680_p1.read());
}

void StreamingFCLayer_Batch_1_Matrix_Vector_Activa::thread_weights_m_weights_V_s_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        weights_m_weights_V_s_ce0 = ap_const_logic_1;
    } else {
        weights_m_weights_V_s_ce0 = ap_const_logic_0;
    }
}

}

