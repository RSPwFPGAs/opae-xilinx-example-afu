// ==============================================================
// File generated on Fri Jun 19 23:27:28 +0000 2020
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2018.3 (64-bit)
// SW Build 2405991 on Thu Dec  6 23:36:41 MST 2018
// IP Build 2404404 on Fri Dec  7 01:43:56 MST 2018
// Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __StreamingFCLayer_Batch_1_Matrix_Vector_Activa_weights_m_weights_V_8_H__
#define __StreamingFCLayer_Batch_1_Matrix_Vector_Activa_weights_m_weights_V_8_H__


#include <systemc>
using namespace sc_core;
using namespace sc_dt;




#include <iostream>
#include <fstream>

struct StreamingFCLayer_Batch_1_Matrix_Vector_Activa_weights_m_weights_V_8_ram : public sc_core::sc_module {

  static const unsigned DataWidth = 16;
  static const unsigned AddressRange = 16;
  static const unsigned AddressWidth = 4;

//latency = 1
//input_reg = 1
//output_reg = 0
sc_core::sc_in <sc_lv<AddressWidth> > address0;
sc_core::sc_in <sc_logic> ce0;
sc_core::sc_out <sc_lv<DataWidth> > q0;
sc_core::sc_in<sc_logic> reset;
sc_core::sc_in<bool> clk;


sc_lv<DataWidth> ram[AddressRange];


   SC_CTOR(StreamingFCLayer_Batch_1_Matrix_Vector_Activa_weights_m_weights_V_8_ram) {
        ram[0] = "0b1011110100000100";
        ram[1] = "0b1111110110011101";
        ram[2] = "0b0100110001011101";
        ram[3] = "0b1101110111010010";
        ram[4] = "0b1100101011110111";
        ram[5] = "0b0000100000110100";
        ram[6] = "0b1010010000011100";
        ram[7] = "0b1010000011010010";
        ram[8] = "0b1100101111011101";
        ram[9] = "0b0011110000011110";
        ram[10] = "0b1010110000011000";
        ram[11] = "0b1010111001100101";
        ram[12] = "0b0111100000111011";
        ram[13] = "0b0001010000010010";
        ram[14] = "0b1010110101011000";
        ram[15] = "0b0011000011100110";


SC_METHOD(prc_write_0);
  sensitive<<clk.pos();
   }


void prc_write_0()
{
    if (ce0.read() == sc_dt::Log_1) 
    {
            if(address0.read().is_01() && address0.read().to_uint()<AddressRange)
              q0 = ram[address0.read().to_uint()];
            else
              q0 = sc_lv<DataWidth>();
    }
}


}; //endmodule


SC_MODULE(StreamingFCLayer_Batch_1_Matrix_Vector_Activa_weights_m_weights_V_8) {


static const unsigned DataWidth = 16;
static const unsigned AddressRange = 16;
static const unsigned AddressWidth = 4;

sc_core::sc_in <sc_lv<AddressWidth> > address0;
sc_core::sc_in<sc_logic> ce0;
sc_core::sc_out <sc_lv<DataWidth> > q0;
sc_core::sc_in<sc_logic> reset;
sc_core::sc_in<bool> clk;


StreamingFCLayer_Batch_1_Matrix_Vector_Activa_weights_m_weights_V_8_ram* meminst;


SC_CTOR(StreamingFCLayer_Batch_1_Matrix_Vector_Activa_weights_m_weights_V_8) {
meminst = new StreamingFCLayer_Batch_1_Matrix_Vector_Activa_weights_m_weights_V_8_ram("StreamingFCLayer_Batch_1_Matrix_Vector_Activa_weights_m_weights_V_8_ram");
meminst->address0(address0);
meminst->ce0(ce0);
meminst->q0(q0);

meminst->reset(reset);
meminst->clk(clk);
}
~StreamingFCLayer_Batch_1_Matrix_Vector_Activa_weights_m_weights_V_8() {
    delete meminst;
}


};//endmodule
#endif
