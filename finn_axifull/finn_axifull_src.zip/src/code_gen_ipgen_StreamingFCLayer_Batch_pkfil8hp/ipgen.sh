#!/bin/bash 
cd /workspace/finn/tmp/finn_user-bibo/code_gen_ipgen_StreamingFCLayer_Batch_pkfil8hp
vivado_hls /workspace/finn/tmp/finn_user-bibo/code_gen_ipgen_StreamingFCLayer_Batch_pkfil8hp/hls_syn_StreamingFCLayer_Batch_0.tcl
cd /workspace/finn
