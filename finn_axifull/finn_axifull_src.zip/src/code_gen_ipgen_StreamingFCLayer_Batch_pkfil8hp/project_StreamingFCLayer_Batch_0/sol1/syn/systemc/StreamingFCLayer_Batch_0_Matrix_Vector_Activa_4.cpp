#include "StreamingFCLayer_Batch_0_Matrix_Vector_Activa.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp395_fu_9933_p2() {
    tmp395_fu_9933_p2 = (!tmp624_cast_fu_9930_p1.read().is_01() || !tmp391_fu_9924_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(tmp624_cast_fu_9930_p1.read()) + sc_biguint<32>(tmp391_fu_9924_p2.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp396_fu_7569_p2() {
    tmp396_fu_7569_p2 = (!res_12_9_cast_fu_7407_p1.read().is_01() || !res_11_cast_268_fu_7191_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_12_9_cast_fu_7407_p1.read()) + sc_biguint<2>(res_11_cast_268_fu_7191_p1.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp397_fu_7579_p2() {
    tmp397_fu_7579_p2 = (!res_12_2_cast_fu_7239_p1.read().is_01() || !res_12_1_cast_fu_7215_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_12_2_cast_fu_7239_p1.read()) + sc_biguint<2>(res_12_1_cast_fu_7215_p1.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp398_cast_fu_9610_p1() {
    tmp398_cast_fu_9610_p1 = esl_zext<32,2>(tmp235_fu_9604_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp398_fu_7589_p2() {
    tmp398_fu_7589_p2 = (!tmp630_cast_fu_7585_p1.read().is_01() || !tmp629_cast_fu_7575_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp630_cast_fu_7585_p1.read()) + sc_biguint<3>(tmp629_cast_fu_7575_p1.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp399_cast_fu_9620_p1() {
    tmp399_cast_fu_9620_p1 = esl_zext<32,3>(tmp239_reg_11502.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp399_fu_7595_p2() {
    tmp399_fu_7595_p2 = (!res_12_4_cast_fu_7287_p1.read().is_01() || !res_12_3_cast_fu_7263_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_12_4_cast_fu_7287_p1.read()) + sc_biguint<2>(res_12_3_cast_fu_7263_p1.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp39_fu_2331_p2() {
    tmp39_fu_2331_p2 = (p_Result_2_0_7_fu_1803_p3.read() ^ p_Result_1_7_fu_2323_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp3_fu_1651_p2() {
    tmp3_fu_1651_p2 = (p_Result_2_0_2_fu_1643_p3.read() ^ p_Result_0_2_fu_1635_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp400_cast_fu_5269_p1() {
    tmp400_cast_fu_5269_p1 = esl_zext<3,2>(tmp237_fu_5263_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp400_fu_7605_p2() {
    tmp400_fu_7605_p2 = (!res_12_5_cast_fu_7311_p1.read().is_01() || !res_12_14_cast_fu_7539_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_12_5_cast_fu_7311_p1.read()) + sc_biguint<2>(res_12_14_cast_fu_7539_p1.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp401_cast_fu_5279_p1() {
    tmp401_cast_fu_5279_p1 = esl_zext<3,2>(tmp238_fu_5273_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp401_fu_7611_p2() {
    tmp401_fu_7611_p2 = (!tmp400_fu_7605_p2.read().is_01() || !res_12_6_cast_fu_7335_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(tmp400_fu_7605_p2.read()) + sc_biguint<2>(res_12_6_cast_fu_7335_p1.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp402_cast_fu_9641_p1() {
    tmp402_cast_fu_9641_p1 = esl_zext<32,4>(tmp248_fu_9635_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp402_fu_7621_p2() {
    tmp402_fu_7621_p2 = (!tmp633_cast_fu_7617_p1.read().is_01() || !tmp632_cast_fu_7601_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp633_cast_fu_7617_p1.read()) + sc_biguint<3>(tmp632_cast_fu_7601_p1.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp403_cast_fu_9629_p1() {
    tmp403_cast_fu_9629_p1 = esl_zext<4,3>(tmp243_reg_11507.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp403_fu_9945_p2() {
    tmp403_fu_9945_p2 = (!tmp631_cast_fu_9942_p1.read().is_01() || !tmp628_cast_fu_9939_p1.read().is_01())? sc_lv<4>(): (sc_biguint<4>(tmp631_cast_fu_9942_p1.read()) + sc_biguint<4>(tmp628_cast_fu_9939_p1.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp404_cast_fu_5295_p1() {
    tmp404_cast_fu_5295_p1 = esl_zext<3,2>(tmp241_fu_5289_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp404_fu_7635_p2() {
    tmp404_fu_7635_p2 = (p_Result_2_fu_1579_p3.read() ^ p_Result_13_fu_7627_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp405_cast_fu_5305_p1() {
    tmp405_cast_fu_5305_p1 = esl_zext<3,2>(tmp242_fu_5299_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp405_fu_7659_p2() {
    tmp405_fu_7659_p2 = (p_Result_2_0_1_fu_1611_p3.read() ^ p_Result_13_1_fu_7651_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp406_cast_fu_9632_p1() {
    tmp406_cast_fu_9632_p1 = esl_zext<4,3>(tmp247_reg_11512.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp406_fu_7683_p2() {
    tmp406_fu_7683_p2 = (p_Result_2_0_2_fu_1643_p3.read() ^ p_Result_13_2_fu_7675_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp407_cast_fu_5321_p1() {
    tmp407_cast_fu_5321_p1 = esl_zext<3,2>(tmp244_fu_5315_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp407_fu_7707_p2() {
    tmp407_fu_7707_p2 = (p_Result_2_0_3_fu_1675_p3.read() ^ p_Result_13_3_fu_7699_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp408_cast_fu_5337_p1() {
    tmp408_cast_fu_5337_p1 = esl_zext<3,2>(tmp246_fu_5331_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp408_fu_7731_p2() {
    tmp408_fu_7731_p2 = (p_Result_2_0_4_fu_1707_p3.read() ^ p_Result_13_4_fu_7723_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp409_fu_7755_p2() {
    tmp409_fu_7755_p2 = (p_Result_2_0_5_fu_1739_p3.read() ^ p_Result_13_5_fu_7747_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp40_fu_2355_p2() {
    tmp40_fu_2355_p2 = (p_Result_2_0_8_fu_1835_p3.read() ^ p_Result_1_8_fu_2347_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp410_fu_7779_p2() {
    tmp410_fu_7779_p2 = (p_Result_2_0_6_fu_1771_p3.read() ^ p_Result_13_6_fu_7771_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp411_fu_7803_p2() {
    tmp411_fu_7803_p2 = (p_Result_2_0_7_fu_1803_p3.read() ^ p_Result_13_7_fu_7795_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp412_fu_7827_p2() {
    tmp412_fu_7827_p2 = (p_Result_2_0_8_fu_1835_p3.read() ^ p_Result_13_8_fu_7819_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp413_fu_7851_p2() {
    tmp413_fu_7851_p2 = (p_Result_2_0_9_fu_1867_p3.read() ^ p_Result_13_9_fu_7843_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp414_fu_7875_p2() {
    tmp414_fu_7875_p2 = (p_Result_2_0_s_fu_1899_p3.read() ^ p_Result_13_s_fu_7867_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp415_fu_7899_p2() {
    tmp415_fu_7899_p2 = (p_Result_2_0_10_fu_1931_p3.read() ^ p_Result_13_10_fu_7891_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp416_fu_7923_p2() {
    tmp416_fu_7923_p2 = (p_Result_2_0_11_fu_1963_p3.read() ^ p_Result_13_11_fu_7915_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp417_fu_7943_p2() {
    tmp417_fu_7943_p2 = (p_Result_2_0_12_fu_1991_p3.read() ^ p_Result_13_12_fu_7935_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp418_fu_7963_p2() {
    tmp418_fu_7963_p2 = (p_Result_2_0_13_fu_2019_p3.read() ^ p_Result_13_13_fu_7955_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp419_fu_7983_p2() {
    tmp419_fu_7983_p2 = (p_Result_2_0_14_fu_2047_p3.read() ^ p_Result_13_14_fu_7975_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp41_fu_2379_p2() {
    tmp41_fu_2379_p2 = (p_Result_2_0_9_fu_1867_p3.read() ^ p_Result_1_9_fu_2371_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp420_fu_9970_p2() {
    tmp420_fu_9970_p2 = (!p_accu_V_13_fu_9057_p3.read().is_01() || !res_13_s_fu_9964_p1.read().is_01())? sc_lv<32>(): (sc_biguint<32>(p_accu_V_13_fu_9057_p3.read()) + sc_biguint<32>(res_13_s_fu_9964_p1.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp421_fu_9976_p2() {
    tmp421_fu_9976_p2 = (!res_13_13_cast_fu_9967_p1.read().is_01() || !res_13_11_cast_fu_9961_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_13_13_cast_fu_9967_p1.read()) + sc_biguint<2>(res_13_11_cast_fu_9961_p1.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp422_fu_9986_p2() {
    tmp422_fu_9986_p2 = (!tmp668_cast_fu_9982_p1.read().is_01() || !tmp420_fu_9970_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(tmp668_cast_fu_9982_p1.read()) + sc_biguint<32>(tmp420_fu_9970_p2.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp423_fu_7999_p2() {
    tmp423_fu_7999_p2 = (!res_13_10_cast_fu_7911_p1.read().is_01() || !res_13_8_cast_fu_7839_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_13_10_cast_fu_7911_p1.read()) + sc_biguint<2>(res_13_8_cast_fu_7839_p1.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp424_fu_8009_p2() {
    tmp424_fu_8009_p2 = (!res_13_7_cast_fu_7815_p1.read().is_01() || !res_13_cast_fu_7887_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_13_7_cast_fu_7815_p1.read()) + sc_biguint<2>(res_13_cast_fu_7887_p1.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp425_fu_8019_p2() {
    tmp425_fu_8019_p2 = (!tmp671_cast_fu_8015_p1.read().is_01() || !tmp670_cast_fu_8005_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp671_cast_fu_8015_p1.read()) + sc_biguint<3>(tmp670_cast_fu_8005_p1.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp426_fu_9995_p2() {
    tmp426_fu_9995_p2 = (!tmp669_cast_fu_9992_p1.read().is_01() || !tmp422_fu_9986_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(tmp669_cast_fu_9992_p1.read()) + sc_biguint<32>(tmp422_fu_9986_p2.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp427_fu_8025_p2() {
    tmp427_fu_8025_p2 = (!res_13_9_cast_fu_7863_p1.read().is_01() || !res_12_cast_285_fu_7647_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_13_9_cast_fu_7863_p1.read()) + sc_biguint<2>(res_12_cast_285_fu_7647_p1.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp428_fu_8035_p2() {
    tmp428_fu_8035_p2 = (!res_13_2_cast_fu_7695_p1.read().is_01() || !res_13_1_cast_fu_7671_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_13_2_cast_fu_7695_p1.read()) + sc_biguint<2>(res_13_1_cast_fu_7671_p1.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp429_fu_8045_p2() {
    tmp429_fu_8045_p2 = (!tmp675_cast_fu_8041_p1.read().is_01() || !tmp674_cast_fu_8031_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp675_cast_fu_8041_p1.read()) + sc_biguint<3>(tmp674_cast_fu_8031_p1.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp42_fu_2403_p2() {
    tmp42_fu_2403_p2 = (p_Result_2_0_s_fu_1899_p3.read() ^ p_Result_1_s_fu_2395_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp430_fu_8051_p2() {
    tmp430_fu_8051_p2 = (!res_13_4_cast_fu_7743_p1.read().is_01() || !res_13_3_cast_fu_7719_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_13_4_cast_fu_7743_p1.read()) + sc_biguint<2>(res_13_3_cast_fu_7719_p1.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp431_fu_8061_p2() {
    tmp431_fu_8061_p2 = (!res_13_5_cast_fu_7767_p1.read().is_01() || !res_13_14_cast_fu_7995_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_13_5_cast_fu_7767_p1.read()) + sc_biguint<2>(res_13_14_cast_fu_7995_p1.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp432_fu_8067_p2() {
    tmp432_fu_8067_p2 = (!tmp431_fu_8061_p2.read().is_01() || !res_13_6_cast_fu_7791_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(tmp431_fu_8061_p2.read()) + sc_biguint<2>(res_13_6_cast_fu_7791_p1.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp433_fu_8077_p2() {
    tmp433_fu_8077_p2 = (!tmp678_cast_fu_8073_p1.read().is_01() || !tmp677_cast_fu_8057_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp678_cast_fu_8073_p1.read()) + sc_biguint<3>(tmp677_cast_fu_8057_p1.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp434_fu_10007_p2() {
    tmp434_fu_10007_p2 = (!tmp676_cast_fu_10004_p1.read().is_01() || !tmp673_cast_fu_10001_p1.read().is_01())? sc_lv<4>(): (sc_biguint<4>(tmp676_cast_fu_10004_p1.read()) + sc_biguint<4>(tmp673_cast_fu_10001_p1.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp435_fu_8091_p2() {
    tmp435_fu_8091_p2 = (p_Result_2_fu_1579_p3.read() ^ p_Result_14_fu_8083_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp436_fu_8115_p2() {
    tmp436_fu_8115_p2 = (p_Result_2_0_1_fu_1611_p3.read() ^ p_Result_14_1_fu_8107_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp437_fu_8139_p2() {
    tmp437_fu_8139_p2 = (p_Result_2_0_2_fu_1643_p3.read() ^ p_Result_14_2_fu_8131_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp438_fu_8163_p2() {
    tmp438_fu_8163_p2 = (p_Result_2_0_3_fu_1675_p3.read() ^ p_Result_14_3_fu_8155_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp439_fu_8187_p2() {
    tmp439_fu_8187_p2 = (p_Result_2_0_4_fu_1707_p3.read() ^ p_Result_14_4_fu_8179_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp43_fu_2427_p2() {
    tmp43_fu_2427_p2 = (p_Result_2_0_10_fu_1931_p3.read() ^ p_Result_1_10_fu_2419_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp440_fu_8211_p2() {
    tmp440_fu_8211_p2 = (p_Result_2_0_5_fu_1739_p3.read() ^ p_Result_14_5_fu_8203_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp441_fu_8235_p2() {
    tmp441_fu_8235_p2 = (p_Result_2_0_6_fu_1771_p3.read() ^ p_Result_14_6_fu_8227_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp442_fu_8259_p2() {
    tmp442_fu_8259_p2 = (p_Result_2_0_7_fu_1803_p3.read() ^ p_Result_14_7_fu_8251_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp443_cast_fu_9672_p1() {
    tmp443_cast_fu_9672_p1 = esl_zext<32,2>(tmp266_fu_9666_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp443_fu_8283_p2() {
    tmp443_fu_8283_p2 = (p_Result_2_0_8_fu_1835_p3.read() ^ p_Result_14_8_fu_8275_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp444_cast_fu_9682_p1() {
    tmp444_cast_fu_9682_p1 = esl_zext<32,3>(tmp270_reg_11532.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp444_fu_8307_p2() {
    tmp444_fu_8307_p2 = (p_Result_2_0_9_fu_1867_p3.read() ^ p_Result_14_9_fu_8299_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp445_cast_fu_5725_p1() {
    tmp445_cast_fu_5725_p1 = esl_zext<3,2>(tmp268_fu_5719_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp445_fu_8331_p2() {
    tmp445_fu_8331_p2 = (p_Result_2_0_s_fu_1899_p3.read() ^ p_Result_14_s_fu_8323_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp446_cast_fu_5735_p1() {
    tmp446_cast_fu_5735_p1 = esl_zext<3,2>(tmp269_fu_5729_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp446_fu_8355_p2() {
    tmp446_fu_8355_p2 = (p_Result_2_0_10_fu_1931_p3.read() ^ p_Result_14_10_fu_8347_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp447_cast_fu_9703_p1() {
    tmp447_cast_fu_9703_p1 = esl_zext<32,4>(tmp279_fu_9697_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp447_fu_8379_p2() {
    tmp447_fu_8379_p2 = (p_Result_2_0_11_fu_1963_p3.read() ^ p_Result_14_11_fu_8371_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp448_cast_fu_9691_p1() {
    tmp448_cast_fu_9691_p1 = esl_zext<4,3>(tmp274_reg_11537.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp448_fu_8399_p2() {
    tmp448_fu_8399_p2 = (p_Result_2_0_12_fu_1991_p3.read() ^ p_Result_14_12_fu_8391_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp449_cast_fu_5751_p1() {
    tmp449_cast_fu_5751_p1 = esl_zext<3,2>(tmp272_fu_5745_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp449_fu_8419_p2() {
    tmp449_fu_8419_p2 = (p_Result_2_0_13_fu_2019_p3.read() ^ p_Result_14_13_fu_8411_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp44_fu_2451_p2() {
    tmp44_fu_2451_p2 = (p_Result_2_0_11_fu_1963_p3.read() ^ p_Result_1_11_fu_2443_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp450_cast_fu_5761_p1() {
    tmp450_cast_fu_5761_p1 = esl_zext<3,2>(tmp273_fu_5755_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp450_fu_8439_p2() {
    tmp450_fu_8439_p2 = (p_Result_2_0_14_fu_2047_p3.read() ^ p_Result_14_14_fu_8431_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp451_cast_fu_9694_p1() {
    tmp451_cast_fu_9694_p1 = esl_zext<4,3>(tmp278_reg_11542.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp451_fu_10032_p2() {
    tmp451_fu_10032_p2 = (!p_accu_V_14_fu_9050_p3.read().is_01() || !res_14_s_fu_10026_p1.read().is_01())? sc_lv<32>(): (sc_biguint<32>(p_accu_V_14_fu_9050_p3.read()) + sc_biguint<32>(res_14_s_fu_10026_p1.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp452_cast_fu_5777_p1() {
    tmp452_cast_fu_5777_p1 = esl_zext<3,2>(tmp275_fu_5771_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp452_fu_10038_p2() {
    tmp452_fu_10038_p2 = (!res_14_13_cast_fu_10029_p1.read().is_01() || !res_14_11_cast_fu_10023_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_14_13_cast_fu_10029_p1.read()) + sc_biguint<2>(res_14_11_cast_fu_10023_p1.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp453_cast_fu_5793_p1() {
    tmp453_cast_fu_5793_p1 = esl_zext<3,2>(tmp277_fu_5787_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp453_fu_10048_p2() {
    tmp453_fu_10048_p2 = (!tmp713_cast_fu_10044_p1.read().is_01() || !tmp451_fu_10032_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(tmp713_cast_fu_10044_p1.read()) + sc_biguint<32>(tmp451_fu_10032_p2.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp454_fu_8455_p2() {
    tmp454_fu_8455_p2 = (!res_14_10_cast_fu_8367_p1.read().is_01() || !res_14_8_cast_fu_8295_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_14_10_cast_fu_8367_p1.read()) + sc_biguint<2>(res_14_8_cast_fu_8295_p1.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp455_fu_8465_p2() {
    tmp455_fu_8465_p2 = (!res_14_7_cast_fu_8271_p1.read().is_01() || !res_14_cast_fu_8343_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_14_7_cast_fu_8271_p1.read()) + sc_biguint<2>(res_14_cast_fu_8343_p1.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp456_fu_8475_p2() {
    tmp456_fu_8475_p2 = (!tmp716_cast_fu_8471_p1.read().is_01() || !tmp715_cast_fu_8461_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp716_cast_fu_8471_p1.read()) + sc_biguint<3>(tmp715_cast_fu_8461_p1.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp457_fu_10057_p2() {
    tmp457_fu_10057_p2 = (!tmp714_cast_fu_10054_p1.read().is_01() || !tmp453_fu_10048_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(tmp714_cast_fu_10054_p1.read()) + sc_biguint<32>(tmp453_fu_10048_p2.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp458_fu_8481_p2() {
    tmp458_fu_8481_p2 = (!res_14_9_cast_fu_8319_p1.read().is_01() || !res_13_cast_302_fu_8103_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_14_9_cast_fu_8319_p1.read()) + sc_biguint<2>(res_13_cast_302_fu_8103_p1.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp459_fu_8491_p2() {
    tmp459_fu_8491_p2 = (!res_14_2_cast_fu_8151_p1.read().is_01() || !res_14_1_cast_fu_8127_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_14_2_cast_fu_8151_p1.read()) + sc_biguint<2>(res_14_1_cast_fu_8127_p1.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp45_fu_2471_p2() {
    tmp45_fu_2471_p2 = (p_Result_2_0_12_fu_1991_p3.read() ^ p_Result_1_12_fu_2463_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp460_fu_8501_p2() {
    tmp460_fu_8501_p2 = (!tmp720_cast_fu_8497_p1.read().is_01() || !tmp719_cast_fu_8487_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp720_cast_fu_8497_p1.read()) + sc_biguint<3>(tmp719_cast_fu_8487_p1.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp461_fu_8507_p2() {
    tmp461_fu_8507_p2 = (!res_14_4_cast_fu_8199_p1.read().is_01() || !res_14_3_cast_fu_8175_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_14_4_cast_fu_8199_p1.read()) + sc_biguint<2>(res_14_3_cast_fu_8175_p1.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp462_fu_8517_p2() {
    tmp462_fu_8517_p2 = (!res_14_5_cast_fu_8223_p1.read().is_01() || !res_14_14_cast_fu_8451_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_14_5_cast_fu_8223_p1.read()) + sc_biguint<2>(res_14_14_cast_fu_8451_p1.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp463_fu_8523_p2() {
    tmp463_fu_8523_p2 = (!tmp462_fu_8517_p2.read().is_01() || !res_14_6_cast_fu_8247_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(tmp462_fu_8517_p2.read()) + sc_biguint<2>(res_14_6_cast_fu_8247_p1.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp464_fu_8533_p2() {
    tmp464_fu_8533_p2 = (!tmp723_cast_fu_8529_p1.read().is_01() || !tmp722_cast_fu_8513_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp723_cast_fu_8529_p1.read()) + sc_biguint<3>(tmp722_cast_fu_8513_p1.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp465_fu_10069_p2() {
    tmp465_fu_10069_p2 = (!tmp721_cast_fu_10066_p1.read().is_01() || !tmp718_cast_fu_10063_p1.read().is_01())? sc_lv<4>(): (sc_biguint<4>(tmp721_cast_fu_10066_p1.read()) + sc_biguint<4>(tmp718_cast_fu_10063_p1.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp466_fu_8547_p2() {
    tmp466_fu_8547_p2 = (p_Result_2_fu_1579_p3.read() ^ p_Result_15_fu_8539_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp467_fu_8571_p2() {
    tmp467_fu_8571_p2 = (p_Result_2_0_1_fu_1611_p3.read() ^ p_Result_15_1_fu_8563_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp468_fu_8595_p2() {
    tmp468_fu_8595_p2 = (p_Result_2_0_2_fu_1643_p3.read() ^ p_Result_15_2_fu_8587_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp469_fu_8619_p2() {
    tmp469_fu_8619_p2 = (p_Result_2_0_3_fu_1675_p3.read() ^ p_Result_15_3_fu_8611_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp46_fu_2491_p2() {
    tmp46_fu_2491_p2 = (p_Result_2_0_13_fu_2019_p3.read() ^ p_Result_1_13_fu_2483_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp470_fu_8643_p2() {
    tmp470_fu_8643_p2 = (p_Result_2_0_4_fu_1707_p3.read() ^ p_Result_15_4_fu_8635_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp471_fu_8667_p2() {
    tmp471_fu_8667_p2 = (p_Result_2_0_5_fu_1739_p3.read() ^ p_Result_15_5_fu_8659_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp472_fu_8691_p2() {
    tmp472_fu_8691_p2 = (p_Result_2_0_6_fu_1771_p3.read() ^ p_Result_15_6_fu_8683_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp473_fu_8715_p2() {
    tmp473_fu_8715_p2 = (p_Result_2_0_7_fu_1803_p3.read() ^ p_Result_15_7_fu_8707_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp474_fu_8739_p2() {
    tmp474_fu_8739_p2 = (p_Result_2_0_8_fu_1835_p3.read() ^ p_Result_15_8_fu_8731_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp475_fu_8763_p2() {
    tmp475_fu_8763_p2 = (p_Result_2_0_9_fu_1867_p3.read() ^ p_Result_15_9_fu_8755_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp476_fu_8787_p2() {
    tmp476_fu_8787_p2 = (p_Result_2_0_s_fu_1899_p3.read() ^ p_Result_15_s_fu_8779_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp477_fu_8811_p2() {
    tmp477_fu_8811_p2 = (p_Result_2_0_10_fu_1931_p3.read() ^ p_Result_15_10_fu_8803_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp478_fu_8835_p2() {
    tmp478_fu_8835_p2 = (p_Result_2_0_11_fu_1963_p3.read() ^ p_Result_15_11_fu_8827_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp479_fu_8855_p2() {
    tmp479_fu_8855_p2 = (p_Result_2_0_12_fu_1991_p3.read() ^ p_Result_15_12_fu_8847_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp47_fu_2511_p2() {
    tmp47_fu_2511_p2 = (p_Result_2_0_14_fu_2047_p3.read() ^ p_Result_1_14_fu_2503_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp480_fu_8875_p2() {
    tmp480_fu_8875_p2 = (p_Result_2_0_13_fu_2019_p3.read() ^ p_Result_15_13_fu_8867_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp481_fu_8895_p2() {
    tmp481_fu_8895_p2 = (p_Result_2_0_14_fu_2047_p3.read() ^ p_Result_15_14_fu_8887_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp482_fu_10094_p2() {
    tmp482_fu_10094_p2 = (!p_accu_V_s_fu_9043_p3.read().is_01() || !res_15_s_fu_10088_p1.read().is_01())? sc_lv<32>(): (sc_biguint<32>(p_accu_V_s_fu_9043_p3.read()) + sc_biguint<32>(res_15_s_fu_10088_p1.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp483_fu_10100_p2() {
    tmp483_fu_10100_p2 = (!res_15_13_cast_fu_10091_p1.read().is_01() || !res_15_11_cast_fu_10085_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_15_13_cast_fu_10091_p1.read()) + sc_biguint<2>(res_15_11_cast_fu_10085_p1.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp484_fu_10110_p2() {
    tmp484_fu_10110_p2 = (!tmp758_cast_fu_10106_p1.read().is_01() || !tmp482_fu_10094_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(tmp758_cast_fu_10106_p1.read()) + sc_biguint<32>(tmp482_fu_10094_p2.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp485_fu_8911_p2() {
    tmp485_fu_8911_p2 = (!res_15_10_cast_fu_8823_p1.read().is_01() || !res_15_8_cast_fu_8751_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_15_10_cast_fu_8823_p1.read()) + sc_biguint<2>(res_15_8_cast_fu_8751_p1.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp486_fu_8921_p2() {
    tmp486_fu_8921_p2 = (!res_15_7_cast_fu_8727_p1.read().is_01() || !res_15_cast_fu_8799_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_15_7_cast_fu_8727_p1.read()) + sc_biguint<2>(res_15_cast_fu_8799_p1.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp487_fu_8931_p2() {
    tmp487_fu_8931_p2 = (!tmp761_cast_fu_8927_p1.read().is_01() || !tmp760_cast_fu_8917_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp761_cast_fu_8927_p1.read()) + sc_biguint<3>(tmp760_cast_fu_8917_p1.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp488_cast_fu_9734_p1() {
    tmp488_cast_fu_9734_p1 = esl_zext<32,2>(tmp297_fu_9728_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp488_fu_10119_p2() {
    tmp488_fu_10119_p2 = (!tmp759_cast_fu_10116_p1.read().is_01() || !tmp484_fu_10110_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(tmp759_cast_fu_10116_p1.read()) + sc_biguint<32>(tmp484_fu_10110_p2.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp489_cast_fu_9744_p1() {
    tmp489_cast_fu_9744_p1 = esl_zext<32,3>(tmp301_reg_11562.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp489_fu_8937_p2() {
    tmp489_fu_8937_p2 = (!res_15_9_cast_fu_8775_p1.read().is_01() || !res_14_cast_319_fu_8559_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_15_9_cast_fu_8775_p1.read()) + sc_biguint<2>(res_14_cast_319_fu_8559_p1.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp48_fu_9226_p2() {
    tmp48_fu_9226_p2 = (!p_accu_V_1_fu_9141_p3.read().is_01() || !res_1_s_fu_9220_p1.read().is_01())? sc_lv<32>(): (sc_biguint<32>(p_accu_V_1_fu_9141_p3.read()) + sc_biguint<32>(res_1_s_fu_9220_p1.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp490_cast_fu_6181_p1() {
    tmp490_cast_fu_6181_p1 = esl_zext<3,2>(tmp299_fu_6175_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp490_fu_8947_p2() {
    tmp490_fu_8947_p2 = (!res_15_2_cast_fu_8607_p1.read().is_01() || !res_15_1_cast_fu_8583_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_15_2_cast_fu_8607_p1.read()) + sc_biguint<2>(res_15_1_cast_fu_8583_p1.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp491_cast_fu_6191_p1() {
    tmp491_cast_fu_6191_p1 = esl_zext<3,2>(tmp300_fu_6185_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp491_fu_8957_p2() {
    tmp491_fu_8957_p2 = (!tmp765_cast_fu_8953_p1.read().is_01() || !tmp764_cast_fu_8943_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp765_cast_fu_8953_p1.read()) + sc_biguint<3>(tmp764_cast_fu_8943_p1.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp492_cast_fu_9765_p1() {
    tmp492_cast_fu_9765_p1 = esl_zext<32,4>(tmp310_fu_9759_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp492_fu_8963_p2() {
    tmp492_fu_8963_p2 = (!res_15_4_cast_fu_8655_p1.read().is_01() || !res_15_3_cast_fu_8631_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_15_4_cast_fu_8655_p1.read()) + sc_biguint<2>(res_15_3_cast_fu_8631_p1.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp493_cast_fu_9753_p1() {
    tmp493_cast_fu_9753_p1 = esl_zext<4,3>(tmp305_reg_11567.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp493_fu_8973_p2() {
    tmp493_fu_8973_p2 = (!res_15_5_cast_fu_8679_p1.read().is_01() || !res_15_14_cast_fu_8907_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_15_5_cast_fu_8679_p1.read()) + sc_biguint<2>(res_15_14_cast_fu_8907_p1.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp494_cast_fu_6207_p1() {
    tmp494_cast_fu_6207_p1 = esl_zext<3,2>(tmp303_fu_6201_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp494_fu_8979_p2() {
    tmp494_fu_8979_p2 = (!tmp493_fu_8973_p2.read().is_01() || !res_15_6_cast_fu_8703_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(tmp493_fu_8973_p2.read()) + sc_biguint<2>(res_15_6_cast_fu_8703_p1.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp495_cast_fu_6217_p1() {
    tmp495_cast_fu_6217_p1 = esl_zext<3,2>(tmp304_fu_6211_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp495_fu_8989_p2() {
    tmp495_fu_8989_p2 = (!tmp768_cast_fu_8985_p1.read().is_01() || !tmp767_cast_fu_8969_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp768_cast_fu_8985_p1.read()) + sc_biguint<3>(tmp767_cast_fu_8969_p1.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp496_cast_fu_9756_p1() {
    tmp496_cast_fu_9756_p1 = esl_zext<4,3>(tmp309_reg_11572.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp496_fu_10131_p2() {
    tmp496_fu_10131_p2 = (!tmp766_cast_fu_10128_p1.read().is_01() || !tmp763_cast_fu_10125_p1.read().is_01())? sc_lv<4>(): (sc_biguint<4>(tmp766_cast_fu_10128_p1.read()) + sc_biguint<4>(tmp763_cast_fu_10125_p1.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp497_cast_fu_6233_p1() {
    tmp497_cast_fu_6233_p1 = esl_zext<3,2>(tmp306_fu_6227_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp498_cast_fu_6249_p1() {
    tmp498_cast_fu_6249_p1 = esl_zext<3,2>(tmp308_fu_6243_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp49_fu_9232_p2() {
    tmp49_fu_9232_p2 = (!res_1_13_cast_fu_9223_p1.read().is_01() || !res_1_11_cast_fu_9217_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_1_13_cast_fu_9223_p1.read()) + sc_biguint<2>(res_1_11_cast_fu_9217_p1.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp4_fu_1683_p2() {
    tmp4_fu_1683_p2 = (p_Result_2_0_3_fu_1675_p3.read() ^ p_Result_0_3_fu_1667_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp50_fu_9242_p2() {
    tmp50_fu_9242_p2 = (!tmp128_cast_fu_9238_p1.read().is_01() || !tmp48_fu_9226_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(tmp128_cast_fu_9238_p1.read()) + sc_biguint<32>(tmp48_fu_9226_p2.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp51_fu_2527_p2() {
    tmp51_fu_2527_p2 = (!res_1_10_cast_fu_2439_p1.read().is_01() || !res_1_8_cast_fu_2367_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_1_10_cast_fu_2439_p1.read()) + sc_biguint<2>(res_1_8_cast_fu_2367_p1.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp52_fu_2537_p2() {
    tmp52_fu_2537_p2 = (!res_1_7_cast_fu_2343_p1.read().is_01() || !res_1_cast_91_fu_2415_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_1_7_cast_fu_2343_p1.read()) + sc_biguint<2>(res_1_cast_91_fu_2415_p1.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp533_cast_fu_9796_p1() {
    tmp533_cast_fu_9796_p1 = esl_zext<32,2>(tmp328_fu_9790_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp534_cast_fu_9806_p1() {
    tmp534_cast_fu_9806_p1 = esl_zext<32,3>(tmp332_reg_11592.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp535_cast_fu_6637_p1() {
    tmp535_cast_fu_6637_p1 = esl_zext<3,2>(tmp330_fu_6631_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp536_cast_fu_6647_p1() {
    tmp536_cast_fu_6647_p1 = esl_zext<3,2>(tmp331_fu_6641_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp537_cast_fu_9827_p1() {
    tmp537_cast_fu_9827_p1 = esl_zext<32,4>(tmp341_fu_9821_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp538_cast_fu_9815_p1() {
    tmp538_cast_fu_9815_p1 = esl_zext<4,3>(tmp336_reg_11597.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp539_cast_fu_6663_p1() {
    tmp539_cast_fu_6663_p1 = esl_zext<3,2>(tmp334_fu_6657_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp53_fu_2547_p2() {
    tmp53_fu_2547_p2 = (!tmp131_cast_fu_2543_p1.read().is_01() || !tmp130_cast_fu_2533_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp131_cast_fu_2543_p1.read()) + sc_biguint<3>(tmp130_cast_fu_2533_p1.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp540_cast_fu_6673_p1() {
    tmp540_cast_fu_6673_p1 = esl_zext<3,2>(tmp335_fu_6667_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp541_cast_fu_9818_p1() {
    tmp541_cast_fu_9818_p1 = esl_zext<4,3>(tmp340_reg_11602.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp542_cast_fu_6689_p1() {
    tmp542_cast_fu_6689_p1 = esl_zext<3,2>(tmp337_fu_6683_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp543_cast_fu_6705_p1() {
    tmp543_cast_fu_6705_p1 = esl_zext<3,2>(tmp339_fu_6699_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp54_fu_9251_p2() {
    tmp54_fu_9251_p2 = (!tmp129_cast_fu_9248_p1.read().is_01() || !tmp50_fu_9242_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(tmp129_cast_fu_9248_p1.read()) + sc_biguint<32>(tmp50_fu_9242_p2.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp55_fu_2553_p2() {
    tmp55_fu_2553_p2 = (!res_1_9_cast_fu_2391_p1.read().is_01() || !res_1_cast_fu_2175_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_1_9_cast_fu_2391_p1.read()) + sc_biguint<2>(res_1_cast_fu_2175_p1.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp56_fu_2563_p2() {
    tmp56_fu_2563_p2 = (!res_1_2_cast_fu_2223_p1.read().is_01() || !res_1_1_cast_fu_2199_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_1_2_cast_fu_2223_p1.read()) + sc_biguint<2>(res_1_1_cast_fu_2199_p1.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp578_cast_fu_9858_p1() {
    tmp578_cast_fu_9858_p1 = esl_zext<32,2>(tmp359_fu_9852_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp579_cast_fu_9868_p1() {
    tmp579_cast_fu_9868_p1 = esl_zext<32,3>(tmp363_reg_11622.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp57_fu_2573_p2() {
    tmp57_fu_2573_p2 = (!tmp135_cast_fu_2569_p1.read().is_01() || !tmp134_cast_fu_2559_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp135_cast_fu_2569_p1.read()) + sc_biguint<3>(tmp134_cast_fu_2559_p1.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp580_cast_fu_7093_p1() {
    tmp580_cast_fu_7093_p1 = esl_zext<3,2>(tmp361_fu_7087_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp581_cast_fu_7103_p1() {
    tmp581_cast_fu_7103_p1 = esl_zext<3,2>(tmp362_fu_7097_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp582_cast_fu_9889_p1() {
    tmp582_cast_fu_9889_p1 = esl_zext<32,4>(tmp372_fu_9883_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp583_cast_fu_9877_p1() {
    tmp583_cast_fu_9877_p1 = esl_zext<4,3>(tmp367_reg_11627.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp584_cast_fu_7119_p1() {
    tmp584_cast_fu_7119_p1 = esl_zext<3,2>(tmp365_fu_7113_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp585_cast_fu_7129_p1() {
    tmp585_cast_fu_7129_p1 = esl_zext<3,2>(tmp366_fu_7123_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp586_cast_fu_9880_p1() {
    tmp586_cast_fu_9880_p1 = esl_zext<4,3>(tmp371_reg_11632.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp587_cast_fu_7145_p1() {
    tmp587_cast_fu_7145_p1 = esl_zext<3,2>(tmp368_fu_7139_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp588_cast_fu_7161_p1() {
    tmp588_cast_fu_7161_p1 = esl_zext<3,2>(tmp370_fu_7155_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp58_fu_2579_p2() {
    tmp58_fu_2579_p2 = (!res_1_4_cast_fu_2271_p1.read().is_01() || !res_1_3_cast_fu_2247_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_1_4_cast_fu_2271_p1.read()) + sc_biguint<2>(res_1_3_cast_fu_2247_p1.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp59_fu_2589_p2() {
    tmp59_fu_2589_p2 = (!res_1_5_cast_fu_2295_p1.read().is_01() || !res_1_14_cast_fu_2523_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_1_5_cast_fu_2295_p1.read()) + sc_biguint<2>(res_1_14_cast_fu_2523_p1.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp5_fu_1715_p2() {
    tmp5_fu_1715_p2 = (p_Result_2_0_4_fu_1707_p3.read() ^ p_Result_0_4_fu_1699_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp60_fu_2595_p2() {
    tmp60_fu_2595_p2 = (!tmp59_fu_2589_p2.read().is_01() || !res_1_6_cast_fu_2319_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(tmp59_fu_2589_p2.read()) + sc_biguint<2>(res_1_6_cast_fu_2319_p1.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp61_fu_2605_p2() {
    tmp61_fu_2605_p2 = (!tmp138_cast_fu_2601_p1.read().is_01() || !tmp137_cast_fu_2585_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp138_cast_fu_2601_p1.read()) + sc_biguint<3>(tmp137_cast_fu_2585_p1.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp623_cast_fu_9920_p1() {
    tmp623_cast_fu_9920_p1 = esl_zext<32,2>(tmp390_fu_9914_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp624_cast_fu_9930_p1() {
    tmp624_cast_fu_9930_p1 = esl_zext<32,3>(tmp394_reg_11652.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp625_cast_fu_7549_p1() {
    tmp625_cast_fu_7549_p1 = esl_zext<3,2>(tmp392_fu_7543_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp626_cast_fu_7559_p1() {
    tmp626_cast_fu_7559_p1 = esl_zext<3,2>(tmp393_fu_7553_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp627_cast_fu_9951_p1() {
    tmp627_cast_fu_9951_p1 = esl_zext<32,4>(tmp403_fu_9945_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp628_cast_fu_9939_p1() {
    tmp628_cast_fu_9939_p1 = esl_zext<4,3>(tmp398_reg_11657.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp629_cast_fu_7575_p1() {
    tmp629_cast_fu_7575_p1 = esl_zext<3,2>(tmp396_fu_7569_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp62_fu_9263_p2() {
    tmp62_fu_9263_p2 = (!tmp136_cast_fu_9260_p1.read().is_01() || !tmp133_cast_fu_9257_p1.read().is_01())? sc_lv<4>(): (sc_biguint<4>(tmp136_cast_fu_9260_p1.read()) + sc_biguint<4>(tmp133_cast_fu_9257_p1.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp630_cast_fu_7585_p1() {
    tmp630_cast_fu_7585_p1 = esl_zext<3,2>(tmp397_fu_7579_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp631_cast_fu_9942_p1() {
    tmp631_cast_fu_9942_p1 = esl_zext<4,3>(tmp402_reg_11662.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp632_cast_fu_7601_p1() {
    tmp632_cast_fu_7601_p1 = esl_zext<3,2>(tmp399_fu_7595_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp633_cast_fu_7617_p1() {
    tmp633_cast_fu_7617_p1 = esl_zext<3,2>(tmp401_fu_7611_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp63_fu_2619_p2() {
    tmp63_fu_2619_p2 = (p_Result_2_fu_1579_p3.read() ^ p_Result_s_98_fu_2611_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp64_fu_2643_p2() {
    tmp64_fu_2643_p2 = (p_Result_2_0_1_fu_1611_p3.read() ^ p_Result_211_1_fu_2635_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp65_fu_2667_p2() {
    tmp65_fu_2667_p2 = (p_Result_2_0_2_fu_1643_p3.read() ^ p_Result_211_2_fu_2659_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp668_cast_fu_9982_p1() {
    tmp668_cast_fu_9982_p1 = esl_zext<32,2>(tmp421_fu_9976_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp669_cast_fu_9992_p1() {
    tmp669_cast_fu_9992_p1 = esl_zext<32,3>(tmp425_reg_11682.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp66_fu_2691_p2() {
    tmp66_fu_2691_p2 = (p_Result_2_0_3_fu_1675_p3.read() ^ p_Result_211_3_fu_2683_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp670_cast_fu_8005_p1() {
    tmp670_cast_fu_8005_p1 = esl_zext<3,2>(tmp423_fu_7999_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp671_cast_fu_8015_p1() {
    tmp671_cast_fu_8015_p1 = esl_zext<3,2>(tmp424_fu_8009_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp672_cast_fu_10013_p1() {
    tmp672_cast_fu_10013_p1 = esl_zext<32,4>(tmp434_fu_10007_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp673_cast_fu_10001_p1() {
    tmp673_cast_fu_10001_p1 = esl_zext<4,3>(tmp429_reg_11687.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp674_cast_fu_8031_p1() {
    tmp674_cast_fu_8031_p1 = esl_zext<3,2>(tmp427_fu_8025_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp675_cast_fu_8041_p1() {
    tmp675_cast_fu_8041_p1 = esl_zext<3,2>(tmp428_fu_8035_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp676_cast_fu_10004_p1() {
    tmp676_cast_fu_10004_p1 = esl_zext<4,3>(tmp433_reg_11692.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp677_cast_fu_8057_p1() {
    tmp677_cast_fu_8057_p1 = esl_zext<3,2>(tmp430_fu_8051_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp678_cast_fu_8073_p1() {
    tmp678_cast_fu_8073_p1 = esl_zext<3,2>(tmp432_fu_8067_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp67_fu_2715_p2() {
    tmp67_fu_2715_p2 = (p_Result_2_0_4_fu_1707_p3.read() ^ p_Result_211_4_fu_2707_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp68_fu_2739_p2() {
    tmp68_fu_2739_p2 = (p_Result_2_0_5_fu_1739_p3.read() ^ p_Result_211_5_fu_2731_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp69_fu_2763_p2() {
    tmp69_fu_2763_p2 = (p_Result_2_0_6_fu_1771_p3.read() ^ p_Result_211_6_fu_2755_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp6_fu_1747_p2() {
    tmp6_fu_1747_p2 = (p_Result_2_0_5_fu_1739_p3.read() ^ p_Result_0_5_fu_1731_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp70_fu_2787_p2() {
    tmp70_fu_2787_p2 = (p_Result_2_0_7_fu_1803_p3.read() ^ p_Result_211_7_fu_2779_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp713_cast_fu_10044_p1() {
    tmp713_cast_fu_10044_p1 = esl_zext<32,2>(tmp452_fu_10038_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp714_cast_fu_10054_p1() {
    tmp714_cast_fu_10054_p1 = esl_zext<32,3>(tmp456_reg_11712.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp715_cast_fu_8461_p1() {
    tmp715_cast_fu_8461_p1 = esl_zext<3,2>(tmp454_fu_8455_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp716_cast_fu_8471_p1() {
    tmp716_cast_fu_8471_p1 = esl_zext<3,2>(tmp455_fu_8465_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp717_cast_fu_10075_p1() {
    tmp717_cast_fu_10075_p1 = esl_zext<32,4>(tmp465_fu_10069_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp718_cast_fu_10063_p1() {
    tmp718_cast_fu_10063_p1 = esl_zext<4,3>(tmp460_reg_11717.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp719_cast_fu_8487_p1() {
    tmp719_cast_fu_8487_p1 = esl_zext<3,2>(tmp458_fu_8481_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp71_fu_2811_p2() {
    tmp71_fu_2811_p2 = (p_Result_2_0_8_fu_1835_p3.read() ^ p_Result_211_8_fu_2803_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp720_cast_fu_8497_p1() {
    tmp720_cast_fu_8497_p1 = esl_zext<3,2>(tmp459_fu_8491_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp721_cast_fu_10066_p1() {
    tmp721_cast_fu_10066_p1 = esl_zext<4,3>(tmp464_reg_11722.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp722_cast_fu_8513_p1() {
    tmp722_cast_fu_8513_p1 = esl_zext<3,2>(tmp461_fu_8507_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp723_cast_fu_8529_p1() {
    tmp723_cast_fu_8529_p1 = esl_zext<3,2>(tmp463_fu_8523_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp72_fu_2835_p2() {
    tmp72_fu_2835_p2 = (p_Result_2_0_9_fu_1867_p3.read() ^ p_Result_211_9_fu_2827_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp73_fu_2859_p2() {
    tmp73_fu_2859_p2 = (p_Result_2_0_s_fu_1899_p3.read() ^ p_Result_211_s_fu_2851_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp74_fu_2883_p2() {
    tmp74_fu_2883_p2 = (p_Result_2_0_10_fu_1931_p3.read() ^ p_Result_211_10_fu_2875_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp758_cast_fu_10106_p1() {
    tmp758_cast_fu_10106_p1 = esl_zext<32,2>(tmp483_fu_10100_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp759_cast_fu_10116_p1() {
    tmp759_cast_fu_10116_p1 = esl_zext<32,3>(tmp487_reg_11742.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp75_fu_2907_p2() {
    tmp75_fu_2907_p2 = (p_Result_2_0_11_fu_1963_p3.read() ^ p_Result_211_11_fu_2899_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp760_cast_fu_8917_p1() {
    tmp760_cast_fu_8917_p1 = esl_zext<3,2>(tmp485_fu_8911_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp761_cast_fu_8927_p1() {
    tmp761_cast_fu_8927_p1 = esl_zext<3,2>(tmp486_fu_8921_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp762_cast_fu_10137_p1() {
    tmp762_cast_fu_10137_p1 = esl_zext<32,4>(tmp496_fu_10131_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp763_cast_fu_10125_p1() {
    tmp763_cast_fu_10125_p1 = esl_zext<4,3>(tmp491_reg_11747.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp764_cast_fu_8943_p1() {
    tmp764_cast_fu_8943_p1 = esl_zext<3,2>(tmp489_fu_8937_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp765_cast_fu_8953_p1() {
    tmp765_cast_fu_8953_p1 = esl_zext<3,2>(tmp490_fu_8947_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp766_cast_fu_10128_p1() {
    tmp766_cast_fu_10128_p1 = esl_zext<4,3>(tmp495_reg_11752.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp767_cast_fu_8969_p1() {
    tmp767_cast_fu_8969_p1 = esl_zext<3,2>(tmp492_fu_8963_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp768_cast_fu_8985_p1() {
    tmp768_cast_fu_8985_p1 = esl_zext<3,2>(tmp494_fu_8979_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp76_fu_2927_p2() {
    tmp76_fu_2927_p2 = (p_Result_2_0_12_fu_1991_p3.read() ^ p_Result_211_12_fu_2919_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp77_fu_2947_p2() {
    tmp77_fu_2947_p2 = (p_Result_2_0_13_fu_2019_p3.read() ^ p_Result_211_13_fu_2939_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp78_fu_2967_p2() {
    tmp78_fu_2967_p2 = (p_Result_2_0_14_fu_2047_p3.read() ^ p_Result_211_14_fu_2959_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp79_fu_9288_p2() {
    tmp79_fu_9288_p2 = (!p_accu_V_2_fu_9134_p3.read().is_01() || !res_212_s_fu_9282_p1.read().is_01())? sc_lv<32>(): (sc_biguint<32>(p_accu_V_2_fu_9134_p3.read()) + sc_biguint<32>(res_212_s_fu_9282_p1.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp7_fu_1779_p2() {
    tmp7_fu_1779_p2 = (p_Result_2_0_6_fu_1771_p3.read() ^ p_Result_0_6_fu_1763_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp80_fu_9294_p2() {
    tmp80_fu_9294_p2 = (!res_212_13_cast_fu_9285_p1.read().is_01() || !res_212_11_cast_fu_9279_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_212_13_cast_fu_9285_p1.read()) + sc_biguint<2>(res_212_11_cast_fu_9279_p1.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp81_fu_9304_p2() {
    tmp81_fu_9304_p2 = (!tmp173_cast_fu_9300_p1.read().is_01() || !tmp79_fu_9288_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(tmp173_cast_fu_9300_p1.read()) + sc_biguint<32>(tmp79_fu_9288_p2.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp82_fu_2983_p2() {
    tmp82_fu_2983_p2 = (!res_212_10_cast_fu_2895_p1.read().is_01() || !res_212_8_cast_fu_2823_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_212_10_cast_fu_2895_p1.read()) + sc_biguint<2>(res_212_8_cast_fu_2823_p1.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp83_cast_fu_9176_p1() {
    tmp83_cast_fu_9176_p1 = esl_zext<32,2>(tmp18_fu_9170_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp83_fu_2993_p2() {
    tmp83_fu_2993_p2 = (!res_212_7_cast_fu_2799_p1.read().is_01() || !res_212_cast_fu_2871_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_212_7_cast_fu_2799_p1.read()) + sc_biguint<2>(res_212_cast_fu_2871_p1.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp84_cast_fu_9186_p1() {
    tmp84_cast_fu_9186_p1 = esl_zext<32,3>(tmp22_reg_11292.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp84_fu_3003_p2() {
    tmp84_fu_3003_p2 = (!tmp176_cast_fu_2999_p1.read().is_01() || !tmp175_cast_fu_2989_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp176_cast_fu_2999_p1.read()) + sc_biguint<3>(tmp175_cast_fu_2989_p1.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp85_cast_fu_2077_p1() {
    tmp85_cast_fu_2077_p1 = esl_zext<3,2>(tmp20_fu_2071_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp85_fu_9313_p2() {
    tmp85_fu_9313_p2 = (!tmp174_cast_fu_9310_p1.read().is_01() || !tmp81_fu_9304_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(tmp174_cast_fu_9310_p1.read()) + sc_biguint<32>(tmp81_fu_9304_p2.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp86_cast_fu_2087_p1() {
    tmp86_cast_fu_2087_p1 = esl_zext<3,2>(tmp21_fu_2081_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp86_fu_3009_p2() {
    tmp86_fu_3009_p2 = (!res_212_9_cast_fu_2847_p1.read().is_01() || !res_cast_99_fu_2631_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_212_9_cast_fu_2847_p1.read()) + sc_biguint<2>(res_cast_99_fu_2631_p1.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp87_cast_fu_9207_p1() {
    tmp87_cast_fu_9207_p1 = esl_zext<32,4>(tmp31_fu_9201_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp87_fu_3019_p2() {
    tmp87_fu_3019_p2 = (!res_212_2_cast_fu_2679_p1.read().is_01() || !res_212_1_cast_fu_2655_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_212_2_cast_fu_2679_p1.read()) + sc_biguint<2>(res_212_1_cast_fu_2655_p1.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp88_cast_fu_9195_p1() {
    tmp88_cast_fu_9195_p1 = esl_zext<4,3>(tmp26_reg_11297.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp88_fu_3029_p2() {
    tmp88_fu_3029_p2 = (!tmp180_cast_fu_3025_p1.read().is_01() || !tmp179_cast_fu_3015_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp180_cast_fu_3025_p1.read()) + sc_biguint<3>(tmp179_cast_fu_3015_p1.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp89_cast_fu_2103_p1() {
    tmp89_cast_fu_2103_p1 = esl_zext<3,2>(tmp24_fu_2097_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp89_fu_3035_p2() {
    tmp89_fu_3035_p2 = (!res_212_4_cast_fu_2727_p1.read().is_01() || !res_212_3_cast_fu_2703_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_212_4_cast_fu_2727_p1.read()) + sc_biguint<2>(res_212_3_cast_fu_2703_p1.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp8_fu_1811_p2() {
    tmp8_fu_1811_p2 = (p_Result_2_0_7_fu_1803_p3.read() ^ p_Result_0_7_fu_1795_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp90_cast_fu_2113_p1() {
    tmp90_cast_fu_2113_p1 = esl_zext<3,2>(tmp25_fu_2107_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp90_fu_3045_p2() {
    tmp90_fu_3045_p2 = (!res_212_5_cast_fu_2751_p1.read().is_01() || !res_212_14_cast_fu_2979_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_212_5_cast_fu_2751_p1.read()) + sc_biguint<2>(res_212_14_cast_fu_2979_p1.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp91_cast_fu_9198_p1() {
    tmp91_cast_fu_9198_p1 = esl_zext<4,3>(tmp30_reg_11302.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp91_fu_3051_p2() {
    tmp91_fu_3051_p2 = (!tmp90_fu_3045_p2.read().is_01() || !res_212_6_cast_fu_2775_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(tmp90_fu_3045_p2.read()) + sc_biguint<2>(res_212_6_cast_fu_2775_p1.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp92_cast_fu_2129_p1() {
    tmp92_cast_fu_2129_p1 = esl_zext<3,2>(tmp27_fu_2123_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp92_fu_3061_p2() {
    tmp92_fu_3061_p2 = (!tmp183_cast_fu_3057_p1.read().is_01() || !tmp182_cast_fu_3041_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp183_cast_fu_3057_p1.read()) + sc_biguint<3>(tmp182_cast_fu_3041_p1.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp93_cast_fu_2145_p1() {
    tmp93_cast_fu_2145_p1 = esl_zext<3,2>(tmp29_fu_2139_p2.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp93_fu_9325_p2() {
    tmp93_fu_9325_p2 = (!tmp181_cast_fu_9322_p1.read().is_01() || !tmp178_cast_fu_9319_p1.read().is_01())? sc_lv<4>(): (sc_biguint<4>(tmp181_cast_fu_9322_p1.read()) + sc_biguint<4>(tmp178_cast_fu_9319_p1.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp94_fu_3075_p2() {
    tmp94_fu_3075_p2 = (p_Result_2_fu_1579_p3.read() ^ p_Result_3_fu_3067_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp95_fu_3099_p2() {
    tmp95_fu_3099_p2 = (p_Result_2_0_1_fu_1611_p3.read() ^ p_Result_313_1_fu_3091_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp96_fu_3123_p2() {
    tmp96_fu_3123_p2 = (p_Result_2_0_2_fu_1643_p3.read() ^ p_Result_313_2_fu_3115_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp97_fu_3147_p2() {
    tmp97_fu_3147_p2 = (p_Result_2_0_3_fu_1675_p3.read() ^ p_Result_313_3_fu_3139_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp98_fu_3171_p2() {
    tmp98_fu_3171_p2 = (p_Result_2_0_4_fu_1707_p3.read() ^ p_Result_313_4_fu_3163_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp99_fu_3195_p2() {
    tmp99_fu_3195_p2 = (p_Result_2_0_5_fu_1739_p3.read() ^ p_Result_313_5_fu_3187_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp9_fu_1843_p2() {
    tmp9_fu_1843_p2 = (p_Result_2_0_8_fu_1835_p3.read() ^ p_Result_0_8_fu_1827_p3.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_11_fu_1478_p1() {
    tmp_11_fu_1478_p1 = esl_zext<64,32>(tile_assign_fu_378.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_0_10_fu_1945_p2() {
    tmp_12_0_10_fu_1945_p2 = (tmp12_fu_1939_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_0_11_fu_1977_p2() {
    tmp_12_0_11_fu_1977_p2 = (tmp13_fu_1971_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_0_12_fu_2005_p2() {
    tmp_12_0_12_fu_2005_p2 = (tmp14_fu_1999_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_0_13_fu_2033_p2() {
    tmp_12_0_13_fu_2033_p2 = (tmp15_fu_2027_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_0_14_fu_2061_p2() {
    tmp_12_0_14_fu_2061_p2 = (tmp16_fu_2055_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_0_1_fu_1625_p2() {
    tmp_12_0_1_fu_1625_p2 = (tmp2_fu_1619_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_0_2_fu_1657_p2() {
    tmp_12_0_2_fu_1657_p2 = (tmp3_fu_1651_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_0_3_fu_1689_p2() {
    tmp_12_0_3_fu_1689_p2 = (tmp4_fu_1683_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_0_4_fu_1721_p2() {
    tmp_12_0_4_fu_1721_p2 = (tmp5_fu_1715_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_0_5_fu_1753_p2() {
    tmp_12_0_5_fu_1753_p2 = (tmp6_fu_1747_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_0_6_fu_1785_p2() {
    tmp_12_0_6_fu_1785_p2 = (tmp7_fu_1779_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_0_7_fu_1817_p2() {
    tmp_12_0_7_fu_1817_p2 = (tmp8_fu_1811_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_0_8_fu_1849_p2() {
    tmp_12_0_8_fu_1849_p2 = (tmp9_fu_1843_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_0_9_fu_1881_p2() {
    tmp_12_0_9_fu_1881_p2 = (tmp10_fu_1875_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_0_s_fu_1913_p2() {
    tmp_12_0_s_fu_1913_p2 = (tmp11_fu_1907_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_10_10_fu_6537_p2() {
    tmp_12_10_10_fu_6537_p2 = (tmp322_fu_6531_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_10_11_fu_6561_p2() {
    tmp_12_10_11_fu_6561_p2 = (tmp323_fu_6555_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_10_12_fu_6581_p2() {
    tmp_12_10_12_fu_6581_p2 = (tmp324_fu_6575_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_10_13_fu_6601_p2() {
    tmp_12_10_13_fu_6601_p2 = (tmp325_fu_6595_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_10_14_fu_6621_p2() {
    tmp_12_10_14_fu_6621_p2 = (tmp326_fu_6615_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_10_1_fu_6297_p2() {
    tmp_12_10_1_fu_6297_p2 = (tmp312_fu_6291_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_10_2_fu_6321_p2() {
    tmp_12_10_2_fu_6321_p2 = (tmp313_fu_6315_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_10_3_fu_6345_p2() {
    tmp_12_10_3_fu_6345_p2 = (tmp314_fu_6339_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_10_4_fu_6369_p2() {
    tmp_12_10_4_fu_6369_p2 = (tmp315_fu_6363_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_10_5_fu_6393_p2() {
    tmp_12_10_5_fu_6393_p2 = (tmp316_fu_6387_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_10_6_fu_6417_p2() {
    tmp_12_10_6_fu_6417_p2 = (tmp317_fu_6411_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_10_7_fu_6441_p2() {
    tmp_12_10_7_fu_6441_p2 = (tmp318_fu_6435_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_10_8_fu_6465_p2() {
    tmp_12_10_8_fu_6465_p2 = (tmp319_fu_6459_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_10_9_fu_6489_p2() {
    tmp_12_10_9_fu_6489_p2 = (tmp320_fu_6483_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_10_fu_6729_p2() {
    tmp_12_10_fu_6729_p2 = (tmp342_fu_6723_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_10_s_fu_6513_p2() {
    tmp_12_10_s_fu_6513_p2 = (tmp321_fu_6507_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_11_10_fu_6993_p2() {
    tmp_12_11_10_fu_6993_p2 = (tmp353_fu_6987_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_11_11_fu_7017_p2() {
    tmp_12_11_11_fu_7017_p2 = (tmp354_fu_7011_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_11_12_fu_7037_p2() {
    tmp_12_11_12_fu_7037_p2 = (tmp355_fu_7031_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_11_13_fu_7057_p2() {
    tmp_12_11_13_fu_7057_p2 = (tmp356_fu_7051_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_11_14_fu_7077_p2() {
    tmp_12_11_14_fu_7077_p2 = (tmp357_fu_7071_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_11_1_fu_6753_p2() {
    tmp_12_11_1_fu_6753_p2 = (tmp343_fu_6747_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_11_2_fu_6777_p2() {
    tmp_12_11_2_fu_6777_p2 = (tmp344_fu_6771_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_11_3_fu_6801_p2() {
    tmp_12_11_3_fu_6801_p2 = (tmp345_fu_6795_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_11_4_fu_6825_p2() {
    tmp_12_11_4_fu_6825_p2 = (tmp346_fu_6819_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_11_5_fu_6849_p2() {
    tmp_12_11_5_fu_6849_p2 = (tmp347_fu_6843_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_11_6_fu_6873_p2() {
    tmp_12_11_6_fu_6873_p2 = (tmp348_fu_6867_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_11_7_fu_6897_p2() {
    tmp_12_11_7_fu_6897_p2 = (tmp349_fu_6891_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_11_8_fu_6921_p2() {
    tmp_12_11_8_fu_6921_p2 = (tmp350_fu_6915_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_11_9_fu_6945_p2() {
    tmp_12_11_9_fu_6945_p2 = (tmp351_fu_6939_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_11_fu_7185_p2() {
    tmp_12_11_fu_7185_p2 = (tmp373_fu_7179_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_11_s_fu_6969_p2() {
    tmp_12_11_s_fu_6969_p2 = (tmp352_fu_6963_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_12_10_fu_7449_p2() {
    tmp_12_12_10_fu_7449_p2 = (tmp384_fu_7443_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_12_11_fu_7473_p2() {
    tmp_12_12_11_fu_7473_p2 = (tmp385_fu_7467_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_12_12_fu_7493_p2() {
    tmp_12_12_12_fu_7493_p2 = (tmp386_fu_7487_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_12_13_fu_7513_p2() {
    tmp_12_12_13_fu_7513_p2 = (tmp387_fu_7507_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_12_14_fu_7533_p2() {
    tmp_12_12_14_fu_7533_p2 = (tmp388_fu_7527_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_12_1_fu_7209_p2() {
    tmp_12_12_1_fu_7209_p2 = (tmp374_fu_7203_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_12_2_fu_7233_p2() {
    tmp_12_12_2_fu_7233_p2 = (tmp375_fu_7227_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_12_3_fu_7257_p2() {
    tmp_12_12_3_fu_7257_p2 = (tmp376_fu_7251_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_12_4_fu_7281_p2() {
    tmp_12_12_4_fu_7281_p2 = (tmp377_fu_7275_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_12_5_fu_7305_p2() {
    tmp_12_12_5_fu_7305_p2 = (tmp378_fu_7299_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_12_6_fu_7329_p2() {
    tmp_12_12_6_fu_7329_p2 = (tmp379_fu_7323_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_12_7_fu_7353_p2() {
    tmp_12_12_7_fu_7353_p2 = (tmp380_fu_7347_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_12_8_fu_7377_p2() {
    tmp_12_12_8_fu_7377_p2 = (tmp381_fu_7371_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_12_9_fu_7401_p2() {
    tmp_12_12_9_fu_7401_p2 = (tmp382_fu_7395_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_12_fu_7641_p2() {
    tmp_12_12_fu_7641_p2 = (tmp404_fu_7635_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_12_s_fu_7425_p2() {
    tmp_12_12_s_fu_7425_p2 = (tmp383_fu_7419_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_13_10_fu_7905_p2() {
    tmp_12_13_10_fu_7905_p2 = (tmp415_fu_7899_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_13_11_fu_7929_p2() {
    tmp_12_13_11_fu_7929_p2 = (tmp416_fu_7923_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_13_12_fu_7949_p2() {
    tmp_12_13_12_fu_7949_p2 = (tmp417_fu_7943_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_13_13_fu_7969_p2() {
    tmp_12_13_13_fu_7969_p2 = (tmp418_fu_7963_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_13_14_fu_7989_p2() {
    tmp_12_13_14_fu_7989_p2 = (tmp419_fu_7983_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_13_1_fu_7665_p2() {
    tmp_12_13_1_fu_7665_p2 = (tmp405_fu_7659_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_13_2_fu_7689_p2() {
    tmp_12_13_2_fu_7689_p2 = (tmp406_fu_7683_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_13_3_fu_7713_p2() {
    tmp_12_13_3_fu_7713_p2 = (tmp407_fu_7707_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_13_4_fu_7737_p2() {
    tmp_12_13_4_fu_7737_p2 = (tmp408_fu_7731_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_13_5_fu_7761_p2() {
    tmp_12_13_5_fu_7761_p2 = (tmp409_fu_7755_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_13_6_fu_7785_p2() {
    tmp_12_13_6_fu_7785_p2 = (tmp410_fu_7779_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_13_7_fu_7809_p2() {
    tmp_12_13_7_fu_7809_p2 = (tmp411_fu_7803_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_13_8_fu_7833_p2() {
    tmp_12_13_8_fu_7833_p2 = (tmp412_fu_7827_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_13_9_fu_7857_p2() {
    tmp_12_13_9_fu_7857_p2 = (tmp413_fu_7851_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_13_fu_8097_p2() {
    tmp_12_13_fu_8097_p2 = (tmp435_fu_8091_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_13_s_fu_7881_p2() {
    tmp_12_13_s_fu_7881_p2 = (tmp414_fu_7875_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_14_10_fu_8361_p2() {
    tmp_12_14_10_fu_8361_p2 = (tmp446_fu_8355_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_14_11_fu_8385_p2() {
    tmp_12_14_11_fu_8385_p2 = (tmp447_fu_8379_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_14_12_fu_8405_p2() {
    tmp_12_14_12_fu_8405_p2 = (tmp448_fu_8399_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_14_13_fu_8425_p2() {
    tmp_12_14_13_fu_8425_p2 = (tmp449_fu_8419_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_14_14_fu_8445_p2() {
    tmp_12_14_14_fu_8445_p2 = (tmp450_fu_8439_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_14_1_fu_8121_p2() {
    tmp_12_14_1_fu_8121_p2 = (tmp436_fu_8115_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_14_2_fu_8145_p2() {
    tmp_12_14_2_fu_8145_p2 = (tmp437_fu_8139_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_14_3_fu_8169_p2() {
    tmp_12_14_3_fu_8169_p2 = (tmp438_fu_8163_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_14_4_fu_8193_p2() {
    tmp_12_14_4_fu_8193_p2 = (tmp439_fu_8187_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_14_5_fu_8217_p2() {
    tmp_12_14_5_fu_8217_p2 = (tmp440_fu_8211_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_14_6_fu_8241_p2() {
    tmp_12_14_6_fu_8241_p2 = (tmp441_fu_8235_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_14_7_fu_8265_p2() {
    tmp_12_14_7_fu_8265_p2 = (tmp442_fu_8259_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_14_8_fu_8289_p2() {
    tmp_12_14_8_fu_8289_p2 = (tmp443_fu_8283_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_14_9_fu_8313_p2() {
    tmp_12_14_9_fu_8313_p2 = (tmp444_fu_8307_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_14_fu_8553_p2() {
    tmp_12_14_fu_8553_p2 = (tmp466_fu_8547_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_14_s_fu_8337_p2() {
    tmp_12_14_s_fu_8337_p2 = (tmp445_fu_8331_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_15_10_fu_8817_p2() {
    tmp_12_15_10_fu_8817_p2 = (tmp477_fu_8811_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_15_11_fu_8841_p2() {
    tmp_12_15_11_fu_8841_p2 = (tmp478_fu_8835_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_15_12_fu_8861_p2() {
    tmp_12_15_12_fu_8861_p2 = (tmp479_fu_8855_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_15_13_fu_8881_p2() {
    tmp_12_15_13_fu_8881_p2 = (tmp480_fu_8875_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_15_14_fu_8901_p2() {
    tmp_12_15_14_fu_8901_p2 = (tmp481_fu_8895_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_15_1_fu_8577_p2() {
    tmp_12_15_1_fu_8577_p2 = (tmp467_fu_8571_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_15_2_fu_8601_p2() {
    tmp_12_15_2_fu_8601_p2 = (tmp468_fu_8595_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_15_3_fu_8625_p2() {
    tmp_12_15_3_fu_8625_p2 = (tmp469_fu_8619_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_15_4_fu_8649_p2() {
    tmp_12_15_4_fu_8649_p2 = (tmp470_fu_8643_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_15_5_fu_8673_p2() {
    tmp_12_15_5_fu_8673_p2 = (tmp471_fu_8667_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_15_6_fu_8697_p2() {
    tmp_12_15_6_fu_8697_p2 = (tmp472_fu_8691_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_15_7_fu_8721_p2() {
    tmp_12_15_7_fu_8721_p2 = (tmp473_fu_8715_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_15_8_fu_8745_p2() {
    tmp_12_15_8_fu_8745_p2 = (tmp474_fu_8739_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_15_9_fu_8769_p2() {
    tmp_12_15_9_fu_8769_p2 = (tmp475_fu_8763_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_15_s_fu_8793_p2() {
    tmp_12_15_s_fu_8793_p2 = (tmp476_fu_8787_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_1_10_fu_2433_p2() {
    tmp_12_1_10_fu_2433_p2 = (tmp43_fu_2427_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_1_11_fu_2457_p2() {
    tmp_12_1_11_fu_2457_p2 = (tmp44_fu_2451_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_1_12_fu_2477_p2() {
    tmp_12_1_12_fu_2477_p2 = (tmp45_fu_2471_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_1_13_fu_2497_p2() {
    tmp_12_1_13_fu_2497_p2 = (tmp46_fu_2491_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_1_14_fu_2517_p2() {
    tmp_12_1_14_fu_2517_p2 = (tmp47_fu_2511_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_1_1_fu_2193_p2() {
    tmp_12_1_1_fu_2193_p2 = (tmp33_fu_2187_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_1_2_fu_2217_p2() {
    tmp_12_1_2_fu_2217_p2 = (tmp34_fu_2211_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_1_3_fu_2241_p2() {
    tmp_12_1_3_fu_2241_p2 = (tmp35_fu_2235_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_1_4_fu_2265_p2() {
    tmp_12_1_4_fu_2265_p2 = (tmp36_fu_2259_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_1_5_fu_2289_p2() {
    tmp_12_1_5_fu_2289_p2 = (tmp37_fu_2283_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_1_6_fu_2313_p2() {
    tmp_12_1_6_fu_2313_p2 = (tmp38_fu_2307_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_1_7_fu_2337_p2() {
    tmp_12_1_7_fu_2337_p2 = (tmp39_fu_2331_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_1_8_fu_2361_p2() {
    tmp_12_1_8_fu_2361_p2 = (tmp40_fu_2355_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_1_9_fu_2385_p2() {
    tmp_12_1_9_fu_2385_p2 = (tmp41_fu_2379_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_1_fu_2169_p2() {
    tmp_12_1_fu_2169_p2 = (tmp32_fu_2163_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_1_s_fu_2409_p2() {
    tmp_12_1_s_fu_2409_p2 = (tmp42_fu_2403_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_2_10_fu_2889_p2() {
    tmp_12_2_10_fu_2889_p2 = (tmp74_fu_2883_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_2_11_fu_2913_p2() {
    tmp_12_2_11_fu_2913_p2 = (tmp75_fu_2907_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_2_12_fu_2933_p2() {
    tmp_12_2_12_fu_2933_p2 = (tmp76_fu_2927_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_2_13_fu_2953_p2() {
    tmp_12_2_13_fu_2953_p2 = (tmp77_fu_2947_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_2_14_fu_2973_p2() {
    tmp_12_2_14_fu_2973_p2 = (tmp78_fu_2967_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_2_1_fu_2649_p2() {
    tmp_12_2_1_fu_2649_p2 = (tmp64_fu_2643_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_2_2_fu_2673_p2() {
    tmp_12_2_2_fu_2673_p2 = (tmp65_fu_2667_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_2_3_fu_2697_p2() {
    tmp_12_2_3_fu_2697_p2 = (tmp66_fu_2691_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_2_4_fu_2721_p2() {
    tmp_12_2_4_fu_2721_p2 = (tmp67_fu_2715_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_2_5_fu_2745_p2() {
    tmp_12_2_5_fu_2745_p2 = (tmp68_fu_2739_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_2_6_fu_2769_p2() {
    tmp_12_2_6_fu_2769_p2 = (tmp69_fu_2763_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_2_7_fu_2793_p2() {
    tmp_12_2_7_fu_2793_p2 = (tmp70_fu_2787_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_2_8_fu_2817_p2() {
    tmp_12_2_8_fu_2817_p2 = (tmp71_fu_2811_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_2_9_fu_2841_p2() {
    tmp_12_2_9_fu_2841_p2 = (tmp72_fu_2835_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_2_fu_2625_p2() {
    tmp_12_2_fu_2625_p2 = (tmp63_fu_2619_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_2_s_fu_2865_p2() {
    tmp_12_2_s_fu_2865_p2 = (tmp73_fu_2859_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_3_10_fu_3345_p2() {
    tmp_12_3_10_fu_3345_p2 = (tmp105_fu_3339_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_3_11_fu_3369_p2() {
    tmp_12_3_11_fu_3369_p2 = (tmp106_fu_3363_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_3_12_fu_3389_p2() {
    tmp_12_3_12_fu_3389_p2 = (tmp107_fu_3383_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_3_13_fu_3409_p2() {
    tmp_12_3_13_fu_3409_p2 = (tmp108_fu_3403_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_3_14_fu_3429_p2() {
    tmp_12_3_14_fu_3429_p2 = (tmp109_fu_3423_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_3_1_fu_3105_p2() {
    tmp_12_3_1_fu_3105_p2 = (tmp95_fu_3099_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_3_2_fu_3129_p2() {
    tmp_12_3_2_fu_3129_p2 = (tmp96_fu_3123_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_3_3_fu_3153_p2() {
    tmp_12_3_3_fu_3153_p2 = (tmp97_fu_3147_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_3_4_fu_3177_p2() {
    tmp_12_3_4_fu_3177_p2 = (tmp98_fu_3171_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_3_5_fu_3201_p2() {
    tmp_12_3_5_fu_3201_p2 = (tmp99_fu_3195_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_3_6_fu_3225_p2() {
    tmp_12_3_6_fu_3225_p2 = (tmp100_fu_3219_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_3_7_fu_3249_p2() {
    tmp_12_3_7_fu_3249_p2 = (tmp101_fu_3243_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_3_8_fu_3273_p2() {
    tmp_12_3_8_fu_3273_p2 = (tmp102_fu_3267_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_3_9_fu_3297_p2() {
    tmp_12_3_9_fu_3297_p2 = (tmp103_fu_3291_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_3_fu_3081_p2() {
    tmp_12_3_fu_3081_p2 = (tmp94_fu_3075_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_3_s_fu_3321_p2() {
    tmp_12_3_s_fu_3321_p2 = (tmp104_fu_3315_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_4_10_fu_3801_p2() {
    tmp_12_4_10_fu_3801_p2 = (tmp136_fu_3795_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_4_11_fu_3825_p2() {
    tmp_12_4_11_fu_3825_p2 = (tmp137_fu_3819_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_4_12_fu_3845_p2() {
    tmp_12_4_12_fu_3845_p2 = (tmp138_fu_3839_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_4_13_fu_3865_p2() {
    tmp_12_4_13_fu_3865_p2 = (tmp139_fu_3859_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_4_14_fu_3885_p2() {
    tmp_12_4_14_fu_3885_p2 = (tmp140_fu_3879_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_4_1_fu_3561_p2() {
    tmp_12_4_1_fu_3561_p2 = (tmp126_fu_3555_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_4_2_fu_3585_p2() {
    tmp_12_4_2_fu_3585_p2 = (tmp127_fu_3579_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_4_3_fu_3609_p2() {
    tmp_12_4_3_fu_3609_p2 = (tmp128_fu_3603_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_4_4_fu_3633_p2() {
    tmp_12_4_4_fu_3633_p2 = (tmp129_fu_3627_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_4_5_fu_3657_p2() {
    tmp_12_4_5_fu_3657_p2 = (tmp130_fu_3651_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_4_6_fu_3681_p2() {
    tmp_12_4_6_fu_3681_p2 = (tmp131_fu_3675_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_4_7_fu_3705_p2() {
    tmp_12_4_7_fu_3705_p2 = (tmp132_fu_3699_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_4_8_fu_3729_p2() {
    tmp_12_4_8_fu_3729_p2 = (tmp133_fu_3723_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_4_9_fu_3753_p2() {
    tmp_12_4_9_fu_3753_p2 = (tmp134_fu_3747_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_4_fu_3537_p2() {
    tmp_12_4_fu_3537_p2 = (tmp125_fu_3531_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_4_s_fu_3777_p2() {
    tmp_12_4_s_fu_3777_p2 = (tmp135_fu_3771_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_5_10_fu_4257_p2() {
    tmp_12_5_10_fu_4257_p2 = (tmp167_fu_4251_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_5_11_fu_4281_p2() {
    tmp_12_5_11_fu_4281_p2 = (tmp168_fu_4275_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_5_12_fu_4301_p2() {
    tmp_12_5_12_fu_4301_p2 = (tmp169_fu_4295_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_5_13_fu_4321_p2() {
    tmp_12_5_13_fu_4321_p2 = (tmp170_fu_4315_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_5_14_fu_4341_p2() {
    tmp_12_5_14_fu_4341_p2 = (tmp171_fu_4335_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_5_1_fu_4017_p2() {
    tmp_12_5_1_fu_4017_p2 = (tmp157_fu_4011_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_5_2_fu_4041_p2() {
    tmp_12_5_2_fu_4041_p2 = (tmp158_fu_4035_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_5_3_fu_4065_p2() {
    tmp_12_5_3_fu_4065_p2 = (tmp159_fu_4059_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_5_4_fu_4089_p2() {
    tmp_12_5_4_fu_4089_p2 = (tmp160_fu_4083_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_5_5_fu_4113_p2() {
    tmp_12_5_5_fu_4113_p2 = (tmp161_fu_4107_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_5_6_fu_4137_p2() {
    tmp_12_5_6_fu_4137_p2 = (tmp162_fu_4131_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_5_7_fu_4161_p2() {
    tmp_12_5_7_fu_4161_p2 = (tmp163_fu_4155_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_5_8_fu_4185_p2() {
    tmp_12_5_8_fu_4185_p2 = (tmp164_fu_4179_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_5_9_fu_4209_p2() {
    tmp_12_5_9_fu_4209_p2 = (tmp165_fu_4203_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_5_fu_3993_p2() {
    tmp_12_5_fu_3993_p2 = (tmp156_fu_3987_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_5_s_fu_4233_p2() {
    tmp_12_5_s_fu_4233_p2 = (tmp166_fu_4227_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_6_10_fu_4713_p2() {
    tmp_12_6_10_fu_4713_p2 = (tmp198_fu_4707_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_6_11_fu_4737_p2() {
    tmp_12_6_11_fu_4737_p2 = (tmp199_fu_4731_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_6_12_fu_4757_p2() {
    tmp_12_6_12_fu_4757_p2 = (tmp200_fu_4751_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_6_13_fu_4777_p2() {
    tmp_12_6_13_fu_4777_p2 = (tmp201_fu_4771_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_6_14_fu_4797_p2() {
    tmp_12_6_14_fu_4797_p2 = (tmp202_fu_4791_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_6_1_fu_4473_p2() {
    tmp_12_6_1_fu_4473_p2 = (tmp188_fu_4467_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_6_2_fu_4497_p2() {
    tmp_12_6_2_fu_4497_p2 = (tmp189_fu_4491_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_6_3_fu_4521_p2() {
    tmp_12_6_3_fu_4521_p2 = (tmp190_fu_4515_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_6_4_fu_4545_p2() {
    tmp_12_6_4_fu_4545_p2 = (tmp191_fu_4539_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_6_5_fu_4569_p2() {
    tmp_12_6_5_fu_4569_p2 = (tmp192_fu_4563_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_6_6_fu_4593_p2() {
    tmp_12_6_6_fu_4593_p2 = (tmp193_fu_4587_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_6_7_fu_4617_p2() {
    tmp_12_6_7_fu_4617_p2 = (tmp194_fu_4611_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_6_8_fu_4641_p2() {
    tmp_12_6_8_fu_4641_p2 = (tmp195_fu_4635_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_6_9_fu_4665_p2() {
    tmp_12_6_9_fu_4665_p2 = (tmp196_fu_4659_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_6_fu_4449_p2() {
    tmp_12_6_fu_4449_p2 = (tmp187_fu_4443_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_6_s_fu_4689_p2() {
    tmp_12_6_s_fu_4689_p2 = (tmp197_fu_4683_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_7_10_fu_5169_p2() {
    tmp_12_7_10_fu_5169_p2 = (tmp229_fu_5163_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_7_11_fu_5193_p2() {
    tmp_12_7_11_fu_5193_p2 = (tmp230_fu_5187_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_7_12_fu_5213_p2() {
    tmp_12_7_12_fu_5213_p2 = (tmp231_fu_5207_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_7_13_fu_5233_p2() {
    tmp_12_7_13_fu_5233_p2 = (tmp232_fu_5227_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_7_14_fu_5253_p2() {
    tmp_12_7_14_fu_5253_p2 = (tmp233_fu_5247_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_7_1_fu_4929_p2() {
    tmp_12_7_1_fu_4929_p2 = (tmp219_fu_4923_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_7_2_fu_4953_p2() {
    tmp_12_7_2_fu_4953_p2 = (tmp220_fu_4947_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_7_3_fu_4977_p2() {
    tmp_12_7_3_fu_4977_p2 = (tmp221_fu_4971_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_7_4_fu_5001_p2() {
    tmp_12_7_4_fu_5001_p2 = (tmp222_fu_4995_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_7_5_fu_5025_p2() {
    tmp_12_7_5_fu_5025_p2 = (tmp223_fu_5019_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_7_6_fu_5049_p2() {
    tmp_12_7_6_fu_5049_p2 = (tmp224_fu_5043_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_7_7_fu_5073_p2() {
    tmp_12_7_7_fu_5073_p2 = (tmp225_fu_5067_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_7_8_fu_5097_p2() {
    tmp_12_7_8_fu_5097_p2 = (tmp226_fu_5091_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_7_9_fu_5121_p2() {
    tmp_12_7_9_fu_5121_p2 = (tmp227_fu_5115_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_7_fu_4905_p2() {
    tmp_12_7_fu_4905_p2 = (tmp218_fu_4899_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_7_s_fu_5145_p2() {
    tmp_12_7_s_fu_5145_p2 = (tmp228_fu_5139_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_8_10_fu_5625_p2() {
    tmp_12_8_10_fu_5625_p2 = (tmp260_fu_5619_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_8_11_fu_5649_p2() {
    tmp_12_8_11_fu_5649_p2 = (tmp261_fu_5643_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_8_12_fu_5669_p2() {
    tmp_12_8_12_fu_5669_p2 = (tmp262_fu_5663_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_8_13_fu_5689_p2() {
    tmp_12_8_13_fu_5689_p2 = (tmp263_fu_5683_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_8_14_fu_5709_p2() {
    tmp_12_8_14_fu_5709_p2 = (tmp264_fu_5703_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_8_1_fu_5385_p2() {
    tmp_12_8_1_fu_5385_p2 = (tmp250_fu_5379_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_8_2_fu_5409_p2() {
    tmp_12_8_2_fu_5409_p2 = (tmp251_fu_5403_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_8_3_fu_5433_p2() {
    tmp_12_8_3_fu_5433_p2 = (tmp252_fu_5427_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_8_4_fu_5457_p2() {
    tmp_12_8_4_fu_5457_p2 = (tmp253_fu_5451_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_8_5_fu_5481_p2() {
    tmp_12_8_5_fu_5481_p2 = (tmp254_fu_5475_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_8_6_fu_5505_p2() {
    tmp_12_8_6_fu_5505_p2 = (tmp255_fu_5499_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_8_7_fu_5529_p2() {
    tmp_12_8_7_fu_5529_p2 = (tmp256_fu_5523_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_8_8_fu_5553_p2() {
    tmp_12_8_8_fu_5553_p2 = (tmp257_fu_5547_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_8_9_fu_5577_p2() {
    tmp_12_8_9_fu_5577_p2 = (tmp258_fu_5571_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_8_fu_5361_p2() {
    tmp_12_8_fu_5361_p2 = (tmp249_fu_5355_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_8_s_fu_5601_p2() {
    tmp_12_8_s_fu_5601_p2 = (tmp259_fu_5595_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_9_10_fu_6081_p2() {
    tmp_12_9_10_fu_6081_p2 = (tmp291_fu_6075_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_9_11_fu_6105_p2() {
    tmp_12_9_11_fu_6105_p2 = (tmp292_fu_6099_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_9_12_fu_6125_p2() {
    tmp_12_9_12_fu_6125_p2 = (tmp293_fu_6119_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_9_13_fu_6145_p2() {
    tmp_12_9_13_fu_6145_p2 = (tmp294_fu_6139_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_9_14_fu_6165_p2() {
    tmp_12_9_14_fu_6165_p2 = (tmp295_fu_6159_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_9_1_fu_5841_p2() {
    tmp_12_9_1_fu_5841_p2 = (tmp281_fu_5835_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_9_2_fu_5865_p2() {
    tmp_12_9_2_fu_5865_p2 = (tmp282_fu_5859_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_9_3_fu_5889_p2() {
    tmp_12_9_3_fu_5889_p2 = (tmp283_fu_5883_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_9_4_fu_5913_p2() {
    tmp_12_9_4_fu_5913_p2 = (tmp284_fu_5907_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_9_5_fu_5937_p2() {
    tmp_12_9_5_fu_5937_p2 = (tmp285_fu_5931_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_9_6_fu_5961_p2() {
    tmp_12_9_6_fu_5961_p2 = (tmp286_fu_5955_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_9_7_fu_5985_p2() {
    tmp_12_9_7_fu_5985_p2 = (tmp287_fu_5979_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_9_8_fu_6009_p2() {
    tmp_12_9_8_fu_6009_p2 = (tmp288_fu_6003_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_9_9_fu_6033_p2() {
    tmp_12_9_9_fu_6033_p2 = (tmp289_fu_6027_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_9_fu_5817_p2() {
    tmp_12_9_fu_5817_p2 = (tmp280_fu_5811_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_9_s_fu_6057_p2() {
    tmp_12_9_s_fu_6057_p2 = (tmp290_fu_6051_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_12_s_fu_6273_p2() {
    tmp_12_s_fu_6273_p2 = (tmp311_fu_6267_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_261_fu_1593_p2() {
    tmp_261_fu_1593_p2 = (tmp1_fu_1587_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_262_fu_1217_p1() {
    tmp_262_fu_1217_p1 = sf_fu_382.read().range(6-1, 0);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_2_fu_1539_p2() {
    tmp_2_fu_1539_p2 = (!nf_fu_1533_p2.read().is_01() || !ap_const_lv32_4.is_01())? sc_lv<1>(): sc_lv<1>(nf_fu_1533_p2.read() == ap_const_lv32_4);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_497_fu_1529_p1() {
    tmp_497_fu_1529_p1 = nf_assign_fu_582.read().range(2-1, 0);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_4_fu_1472_p2() {
    tmp_4_fu_1472_p2 = (!sf_fu_382.read().is_01() || !ap_const_lv32_0.is_01())? sc_lv<1>(): sc_lv<1>(sf_fu_382.read() == ap_const_lv32_0);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_fu_953_p2() {
    tmp_fu_953_p2 = (!nf_assign_fu_582.read().is_01() || !ap_const_lv32_0.is_01())? sc_lv<1>(): sc_lv<1>(nf_assign_fu_582.read() == ap_const_lv32_0);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_tmp_s_fu_1510_p2() {
    tmp_s_fu_1510_p2 = (!sf_1_fu_1504_p2.read().is_01() || !ap_const_lv32_31.is_01())? sc_lv<1>(): sc_lv<1>(sf_1_fu_1504_p2.read() == ap_const_lv32_31);
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_ult10_fu_10490_p2() {
    ult10_fu_10490_p2 = (!accu_10_V_fu_9831_p2.read().is_01() || !p_x_V_read_assign_s_fu_10477_p6.read().is_01())? sc_lv<1>(): (sc_biguint<32>(accu_10_V_fu_9831_p2.read()) < sc_biguint<32>(p_x_V_read_assign_s_fu_10477_p6.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_ult11_fu_10515_p2() {
    ult11_fu_10515_p2 = (!accu_11_V_fu_9893_p2.read().is_01() || !p_x_V_read_assign_10_fu_10502_p6.read().is_01())? sc_lv<1>(): (sc_biguint<32>(accu_11_V_fu_9893_p2.read()) < sc_biguint<32>(p_x_V_read_assign_10_fu_10502_p6.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_ult12_fu_10540_p2() {
    ult12_fu_10540_p2 = (!accu_12_V_fu_9955_p2.read().is_01() || !p_x_V_read_assign_11_fu_10527_p6.read().is_01())? sc_lv<1>(): (sc_biguint<32>(accu_12_V_fu_9955_p2.read()) < sc_biguint<32>(p_x_V_read_assign_11_fu_10527_p6.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_ult13_fu_10565_p2() {
    ult13_fu_10565_p2 = (!accu_13_V_fu_10017_p2.read().is_01() || !p_x_V_read_assign_12_fu_10552_p6.read().is_01())? sc_lv<1>(): (sc_biguint<32>(accu_13_V_fu_10017_p2.read()) < sc_biguint<32>(p_x_V_read_assign_12_fu_10552_p6.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_ult14_fu_10590_p2() {
    ult14_fu_10590_p2 = (!accu_14_V_fu_10079_p2.read().is_01() || !p_x_V_read_assign_13_fu_10577_p6.read().is_01())? sc_lv<1>(): (sc_biguint<32>(accu_14_V_fu_10079_p2.read()) < sc_biguint<32>(p_x_V_read_assign_13_fu_10577_p6.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_ult15_fu_10615_p2() {
    ult15_fu_10615_p2 = (!accu_15_V_fu_10141_p2.read().is_01() || !p_x_V_read_assign_14_fu_10602_p6.read().is_01())? sc_lv<1>(): (sc_biguint<32>(accu_15_V_fu_10141_p2.read()) < sc_biguint<32>(p_x_V_read_assign_14_fu_10602_p6.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_ult1_fu_10265_p2() {
    ult1_fu_10265_p2 = (!accu_1_V_fu_9273_p2.read().is_01() || !p_x_V_read_assign_1_fu_10252_p6.read().is_01())? sc_lv<1>(): (sc_biguint<32>(accu_1_V_fu_9273_p2.read()) < sc_biguint<32>(p_x_V_read_assign_1_fu_10252_p6.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_ult2_fu_10290_p2() {
    ult2_fu_10290_p2 = (!accu_2_V_fu_9335_p2.read().is_01() || !p_x_V_read_assign_2_fu_10277_p6.read().is_01())? sc_lv<1>(): (sc_biguint<32>(accu_2_V_fu_9335_p2.read()) < sc_biguint<32>(p_x_V_read_assign_2_fu_10277_p6.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_ult3_fu_10315_p2() {
    ult3_fu_10315_p2 = (!accu_3_V_fu_9397_p2.read().is_01() || !p_x_V_read_assign_3_fu_10302_p6.read().is_01())? sc_lv<1>(): (sc_biguint<32>(accu_3_V_fu_9397_p2.read()) < sc_biguint<32>(p_x_V_read_assign_3_fu_10302_p6.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_ult4_fu_10340_p2() {
    ult4_fu_10340_p2 = (!accu_4_V_fu_9459_p2.read().is_01() || !p_x_V_read_assign_4_fu_10327_p6.read().is_01())? sc_lv<1>(): (sc_biguint<32>(accu_4_V_fu_9459_p2.read()) < sc_biguint<32>(p_x_V_read_assign_4_fu_10327_p6.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_ult5_fu_10365_p2() {
    ult5_fu_10365_p2 = (!accu_5_V_fu_9521_p2.read().is_01() || !p_x_V_read_assign_5_fu_10352_p6.read().is_01())? sc_lv<1>(): (sc_biguint<32>(accu_5_V_fu_9521_p2.read()) < sc_biguint<32>(p_x_V_read_assign_5_fu_10352_p6.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_ult6_fu_10390_p2() {
    ult6_fu_10390_p2 = (!accu_6_V_fu_9583_p2.read().is_01() || !p_x_V_read_assign_6_fu_10377_p6.read().is_01())? sc_lv<1>(): (sc_biguint<32>(accu_6_V_fu_9583_p2.read()) < sc_biguint<32>(p_x_V_read_assign_6_fu_10377_p6.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_ult7_fu_10415_p2() {
    ult7_fu_10415_p2 = (!accu_7_V_fu_9645_p2.read().is_01() || !p_x_V_read_assign_7_fu_10402_p6.read().is_01())? sc_lv<1>(): (sc_biguint<32>(accu_7_V_fu_9645_p2.read()) < sc_biguint<32>(p_x_V_read_assign_7_fu_10402_p6.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_ult8_fu_10440_p2() {
    ult8_fu_10440_p2 = (!accu_8_V_fu_9707_p2.read().is_01() || !p_x_V_read_assign_8_fu_10427_p6.read().is_01())? sc_lv<1>(): (sc_biguint<32>(accu_8_V_fu_9707_p2.read()) < sc_biguint<32>(p_x_V_read_assign_8_fu_10427_p6.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_ult9_fu_10465_p2() {
    ult9_fu_10465_p2 = (!accu_9_V_fu_9769_p2.read().is_01() || !p_x_V_read_assign_9_fu_10452_p6.read().is_01())? sc_lv<1>(): (sc_biguint<32>(accu_9_V_fu_9769_p2.read()) < sc_biguint<32>(p_x_V_read_assign_9_fu_10452_p6.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_ult_fu_10240_p2() {
    ult_fu_10240_p2 = (!accu_0_V_fu_9211_p2.read().is_01() || !p_x_V_read_assign_fu_10227_p6.read().is_01())? sc_lv<1>(): (sc_biguint<32>(accu_0_V_fu_9211_p2.read()) < sc_biguint<32>(p_x_V_read_assign_fu_10227_p6.read()));
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_weights_m_weights_V_10_address0() {
    weights_m_weights_V_10_address0 =  (sc_lv<8>) (tmp_11_fu_1478_p1.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_weights_m_weights_V_10_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        weights_m_weights_V_10_ce0 = ap_const_logic_1;
    } else {
        weights_m_weights_V_10_ce0 = ap_const_logic_0;
    }
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_weights_m_weights_V_11_address0() {
    weights_m_weights_V_11_address0 =  (sc_lv<8>) (tmp_11_fu_1478_p1.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_weights_m_weights_V_11_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        weights_m_weights_V_11_ce0 = ap_const_logic_1;
    } else {
        weights_m_weights_V_11_ce0 = ap_const_logic_0;
    }
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_weights_m_weights_V_12_address0() {
    weights_m_weights_V_12_address0 =  (sc_lv<8>) (tmp_11_fu_1478_p1.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_weights_m_weights_V_12_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        weights_m_weights_V_12_ce0 = ap_const_logic_1;
    } else {
        weights_m_weights_V_12_ce0 = ap_const_logic_0;
    }
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_weights_m_weights_V_13_address0() {
    weights_m_weights_V_13_address0 =  (sc_lv<8>) (tmp_11_fu_1478_p1.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_weights_m_weights_V_13_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        weights_m_weights_V_13_ce0 = ap_const_logic_1;
    } else {
        weights_m_weights_V_13_ce0 = ap_const_logic_0;
    }
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_weights_m_weights_V_14_address0() {
    weights_m_weights_V_14_address0 =  (sc_lv<8>) (tmp_11_fu_1478_p1.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_weights_m_weights_V_14_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        weights_m_weights_V_14_ce0 = ap_const_logic_1;
    } else {
        weights_m_weights_V_14_ce0 = ap_const_logic_0;
    }
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_weights_m_weights_V_15_address0() {
    weights_m_weights_V_15_address0 =  (sc_lv<8>) (tmp_11_fu_1478_p1.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_weights_m_weights_V_15_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        weights_m_weights_V_15_ce0 = ap_const_logic_1;
    } else {
        weights_m_weights_V_15_ce0 = ap_const_logic_0;
    }
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_weights_m_weights_V_1_address0() {
    weights_m_weights_V_1_address0 =  (sc_lv<8>) (tmp_11_fu_1478_p1.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_weights_m_weights_V_1_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        weights_m_weights_V_1_ce0 = ap_const_logic_1;
    } else {
        weights_m_weights_V_1_ce0 = ap_const_logic_0;
    }
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_weights_m_weights_V_2_address0() {
    weights_m_weights_V_2_address0 =  (sc_lv<8>) (tmp_11_fu_1478_p1.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_weights_m_weights_V_2_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        weights_m_weights_V_2_ce0 = ap_const_logic_1;
    } else {
        weights_m_weights_V_2_ce0 = ap_const_logic_0;
    }
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_weights_m_weights_V_3_address0() {
    weights_m_weights_V_3_address0 =  (sc_lv<8>) (tmp_11_fu_1478_p1.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_weights_m_weights_V_3_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        weights_m_weights_V_3_ce0 = ap_const_logic_1;
    } else {
        weights_m_weights_V_3_ce0 = ap_const_logic_0;
    }
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_weights_m_weights_V_4_address0() {
    weights_m_weights_V_4_address0 =  (sc_lv<8>) (tmp_11_fu_1478_p1.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_weights_m_weights_V_4_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        weights_m_weights_V_4_ce0 = ap_const_logic_1;
    } else {
        weights_m_weights_V_4_ce0 = ap_const_logic_0;
    }
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_weights_m_weights_V_5_address0() {
    weights_m_weights_V_5_address0 =  (sc_lv<8>) (tmp_11_fu_1478_p1.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_weights_m_weights_V_5_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        weights_m_weights_V_5_ce0 = ap_const_logic_1;
    } else {
        weights_m_weights_V_5_ce0 = ap_const_logic_0;
    }
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_weights_m_weights_V_6_address0() {
    weights_m_weights_V_6_address0 =  (sc_lv<8>) (tmp_11_fu_1478_p1.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_weights_m_weights_V_6_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        weights_m_weights_V_6_ce0 = ap_const_logic_1;
    } else {
        weights_m_weights_V_6_ce0 = ap_const_logic_0;
    }
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_weights_m_weights_V_7_address0() {
    weights_m_weights_V_7_address0 =  (sc_lv<8>) (tmp_11_fu_1478_p1.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_weights_m_weights_V_7_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        weights_m_weights_V_7_ce0 = ap_const_logic_1;
    } else {
        weights_m_weights_V_7_ce0 = ap_const_logic_0;
    }
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_weights_m_weights_V_8_address0() {
    weights_m_weights_V_8_address0 =  (sc_lv<8>) (tmp_11_fu_1478_p1.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_weights_m_weights_V_8_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        weights_m_weights_V_8_ce0 = ap_const_logic_1;
    } else {
        weights_m_weights_V_8_ce0 = ap_const_logic_0;
    }
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_weights_m_weights_V_9_address0() {
    weights_m_weights_V_9_address0 =  (sc_lv<8>) (tmp_11_fu_1478_p1.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_weights_m_weights_V_9_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        weights_m_weights_V_9_ce0 = ap_const_logic_1;
    } else {
        weights_m_weights_V_9_ce0 = ap_const_logic_0;
    }
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_weights_m_weights_V_s_address0() {
    weights_m_weights_V_s_address0 =  (sc_lv<8>) (tmp_11_fu_1478_p1.read());
}

void StreamingFCLayer_Batch_0_Matrix_Vector_Activa::thread_weights_m_weights_V_s_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        weights_m_weights_V_s_ce0 = ap_const_logic_1;
    } else {
        weights_m_weights_V_s_ce0 = ap_const_logic_0;
    }
}

}

