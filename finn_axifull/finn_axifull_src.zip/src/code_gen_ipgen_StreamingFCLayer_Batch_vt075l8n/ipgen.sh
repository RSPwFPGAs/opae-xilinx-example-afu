#!/bin/bash 
cd /workspace/finn/tmp/finn_user-bibo/code_gen_ipgen_StreamingFCLayer_Batch_vt075l8n
vivado_hls /workspace/finn/tmp/finn_user-bibo/code_gen_ipgen_StreamingFCLayer_Batch_vt075l8n/hls_syn_StreamingFCLayer_Batch_3.tcl
cd /workspace/finn
