#include "StreamingFCLayer_Batch_3_Matrix_Vector_Activa.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_accu_0_V_fu_1263_p2() {
    accu_0_V_fu_1263_p2 = (!tmp65_cast_fu_1259_p1.read().is_01() || !tmp23_fu_1181_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(tmp65_cast_fu_1259_p1.read()) + sc_biguint<32>(tmp23_fu_1181_p2.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_accu_1_V_fu_1801_p2() {
    accu_1_V_fu_1801_p2 = (!tmp110_cast_fu_1797_p1.read().is_01() || !tmp54_fu_1719_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(tmp110_cast_fu_1797_p1.read()) + sc_biguint<32>(tmp54_fu_1719_p2.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_accu_2_V_fu_2339_p2() {
    accu_2_V_fu_2339_p2 = (!tmp155_cast_fu_2335_p1.read().is_01() || !tmp85_fu_2257_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(tmp155_cast_fu_2335_p1.read()) + sc_biguint<32>(tmp85_fu_2257_p2.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_accu_3_V_fu_2877_p2() {
    accu_3_V_fu_2877_p2 = (!tmp200_cast_fu_2873_p1.read().is_01() || !tmp116_fu_2795_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(tmp200_cast_fu_2873_p1.read()) + sc_biguint<32>(tmp116_fu_2795_p2.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_accu_4_V_fu_3415_p2() {
    accu_4_V_fu_3415_p2 = (!tmp245_cast_fu_3411_p1.read().is_01() || !tmp147_fu_3333_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(tmp245_cast_fu_3411_p1.read()) + sc_biguint<32>(tmp147_fu_3333_p2.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_accu_5_V_fu_3953_p2() {
    accu_5_V_fu_3953_p2 = (!tmp290_cast_fu_3949_p1.read().is_01() || !tmp178_fu_3871_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(tmp290_cast_fu_3949_p1.read()) + sc_biguint<32>(tmp178_fu_3871_p2.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_accu_6_V_fu_4491_p2() {
    accu_6_V_fu_4491_p2 = (!tmp335_cast_fu_4487_p1.read().is_01() || !tmp209_fu_4409_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(tmp335_cast_fu_4487_p1.read()) + sc_biguint<32>(tmp209_fu_4409_p2.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_accu_7_V_fu_5029_p2() {
    accu_7_V_fu_5029_p2 = (!tmp380_cast_fu_5025_p1.read().is_01() || !tmp240_fu_4947_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(tmp380_cast_fu_5025_p1.read()) + sc_biguint<32>(tmp240_fu_4947_p2.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_accu_8_V_fu_5567_p2() {
    accu_8_V_fu_5567_p2 = (!tmp425_cast_fu_5563_p1.read().is_01() || !tmp271_fu_5485_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(tmp425_cast_fu_5563_p1.read()) + sc_biguint<32>(tmp271_fu_5485_p2.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_accu_9_V_fu_6105_p2() {
    accu_9_V_fu_6105_p2 = (!tmp470_cast_fu_6101_p1.read().is_01() || !tmp302_fu_6023_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(tmp470_cast_fu_6101_p1.read()) + sc_biguint<32>(tmp302_fu_6023_p2.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_ap_CS_fsm_pp0_stage0() {
    ap_CS_fsm_pp0_stage0 = ap_CS_fsm.read()[1];
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_ap_CS_fsm_state1() {
    ap_CS_fsm_state1 = ap_CS_fsm.read()[0];
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_ap_CS_fsm_state4() {
    ap_CS_fsm_state4 = ap_CS_fsm.read()[2];
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_ap_block_pp0_stage0() {
    ap_block_pp0_stage0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_ap_block_pp0_stage0_01001() {
    ap_block_pp0_stage0_01001 = (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && esl_seteq<1,1,1>(ap_const_logic_0, in_V_V_TVALID.read()) && esl_seteq<1,1,1>(ap_const_boolean_1, ap_predicate_op46_read_state2.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_ap_block_pp0_stage0_11001() {
    ap_block_pp0_stage0_11001 = ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
  esl_seteq<1,1,1>(ap_const_logic_0, in_V_V_TVALID.read()) && 
  esl_seteq<1,1,1>(ap_const_boolean_1, ap_predicate_op46_read_state2.read())) || (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
  esl_seteq<1,1,1>(ap_const_boolean_1, ap_block_state3_io.read())));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_ap_block_pp0_stage0_subdone() {
    ap_block_pp0_stage0_subdone = ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
  esl_seteq<1,1,1>(ap_const_logic_0, in_V_V_TVALID.read()) && 
  esl_seteq<1,1,1>(ap_const_boolean_1, ap_predicate_op46_read_state2.read())) || (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
  esl_seteq<1,1,1>(ap_const_boolean_1, ap_block_state3_io.read())));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_ap_block_state2_pp0_stage0_iter0() {
    ap_block_state2_pp0_stage0_iter0 = (esl_seteq<1,1,1>(ap_const_logic_0, in_V_V_TVALID.read()) && esl_seteq<1,1,1>(ap_const_boolean_1, ap_predicate_op46_read_state2.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_ap_block_state3_io() {
    ap_block_state3_io = (esl_seteq<1,1,1>(ap_const_lv1_1, tmp_s_reg_6355.read()) && esl_seteq<1,1,1>(ap_const_logic_0, out_V_V_TREADY.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_ap_block_state3_pp0_stage0_iter1() {
    ap_block_state3_pp0_stage0_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_ap_condition_83() {
    ap_condition_83 = (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_ap_condition_pp0_exit_iter0_state2() {
    if (esl_seteq<1,1,1>(exitcond_fu_290_p2.read(), ap_const_lv1_1)) {
        ap_condition_pp0_exit_iter0_state2 = ap_const_logic_1;
    } else {
        ap_condition_pp0_exit_iter0_state2 = ap_const_logic_0;
    }
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_ap_done() {
    if (((esl_seteq<1,1,1>(ap_const_logic_0, ap_start.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state4.read()))) {
        ap_done = ap_const_logic_1;
    } else {
        ap_done = ap_const_logic_0;
    }
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_ap_enable_pp0() {
    ap_enable_pp0 = (ap_idle_pp0.read() ^ ap_const_logic_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_ap_idle() {
    if ((esl_seteq<1,1,1>(ap_const_logic_0, ap_start.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()))) {
        ap_idle = ap_const_logic_1;
    } else {
        ap_idle = ap_const_logic_0;
    }
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_ap_idle_pp0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp0_iter1.read()))) {
        ap_idle_pp0 = ap_const_logic_1;
    } else {
        ap_idle_pp0 = ap_const_logic_0;
    }
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_ap_phi_reg_pp0_iter0_act_m_val_V_reg_266() {
    ap_phi_reg_pp0_iter0_act_m_val_V_reg_266 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_ap_predicate_op46_read_state2() {
    ap_predicate_op46_read_state2 = (esl_seteq<1,1,1>(exitcond_fu_290_p2.read(), ap_const_lv1_0) && esl_seteq<1,1,1>(tmp_fu_305_p2.read(), ap_const_lv1_1));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_ap_ready() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state4.read())) {
        ap_ready = ap_const_logic_1;
    } else {
        ap_ready = ap_const_logic_0;
    }
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_exitcond_fu_290_p2() {
    exitcond_fu_290_p2 = (!i_reg_255.read().is_01() || !ap_const_lv3_4.is_01())? sc_lv<1>(): sc_lv<1>(i_reg_255.read() == ap_const_lv3_4);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_i_1_fu_296_p2() {
    i_1_fu_296_p2 = (!i_reg_255.read().is_01() || !ap_const_lv3_1.is_01())? sc_lv<3>(): (sc_biguint<3>(i_reg_255.read()) + sc_biguint<3>(ap_const_lv3_1));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_inElem_V_fu_330_p5() {
    inElem_V_fu_330_p5 = sf_fu_218.read().range(2-1, 0);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_in_V_V_TDATA_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(exitcond_fu_290_p2.read(), ap_const_lv1_0) && 
         esl_seteq<1,1,1>(tmp_fu_305_p2.read(), ap_const_lv1_1))) {
        in_V_V_TDATA_blk_n = in_V_V_TVALID.read();
    } else {
        in_V_V_TDATA_blk_n = ap_const_logic_1;
    }
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_in_V_V_TREADY() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_boolean_1, ap_predicate_op46_read_state2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        in_V_V_TREADY = ap_const_logic_1;
    } else {
        in_V_V_TREADY = ap_const_logic_0;
    }
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_inputBuf_3_V_1_fu_396_p3() {
    inputBuf_3_V_1_fu_396_p3 = (!or_cond_fu_366_p2.read()[0].is_01())? sc_lv<16>(): ((or_cond_fu_366_p2.read()[0].to_bool())? inputBuf_3_V_6_fu_234.read(): newSel2_fu_388_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_inputBuf_3_V_4_fu_404_p3() {
    inputBuf_3_V_4_fu_404_p3 = (!sel_tmp6_fu_354_p2.read()[0].is_01())? sc_lv<16>(): ((sel_tmp6_fu_354_p2.read()[0].to_bool())? in_V_V_TDATA.read(): inputBuf_3_V_3_fu_230.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_inputBuf_3_V_5_fu_412_p3() {
    inputBuf_3_V_5_fu_412_p3 = (!sel_tmp8_fu_360_p2.read()[0].is_01())? sc_lv<16>(): ((sel_tmp8_fu_360_p2.read()[0].to_bool())? inputBuf_3_V_3_fu_230.read(): inputBuf_3_V_4_fu_404_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_inputBuf_3_V_7_fu_420_p3() {
    inputBuf_3_V_7_fu_420_p3 = (!sel_tmp8_fu_360_p2.read()[0].is_01())? sc_lv<16>(): ((sel_tmp8_fu_360_p2.read()[0].to_bool())? in_V_V_TDATA.read(): inputBuf_3_V_2_fu_226.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_inputBuf_3_V_fu_380_p3() {
    inputBuf_3_V_fu_380_p3 = (!or_cond_fu_366_p2.read()[0].is_01())? sc_lv<16>(): ((or_cond_fu_366_p2.read()[0].to_bool())? inputBuf_3_V_8_fu_238.read(): newSel_fu_372_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_newSel2_fu_388_p3() {
    newSel2_fu_388_p3 = (!sel_tmp_fu_348_p2.read()[0].is_01())? sc_lv<16>(): ((sel_tmp_fu_348_p2.read()[0].to_bool())? in_V_V_TDATA.read(): inputBuf_3_V_6_fu_234.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_newSel_fu_372_p3() {
    newSel_fu_372_p3 = (!sel_tmp_fu_348_p2.read()[0].is_01())? sc_lv<16>(): ((sel_tmp_fu_348_p2.read()[0].to_bool())? inputBuf_3_V_8_fu_238.read(): in_V_V_TDATA.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_nf_1_fu_477_p2() {
    nf_1_fu_477_p2 = (!nf_fu_222.read().is_01() || !ap_const_lv32_1.is_01())? sc_lv<32>(): (sc_biguint<32>(nf_fu_222.read()) + sc_biguint<32>(ap_const_lv32_1));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_or_cond_fu_366_p2() {
    or_cond_fu_366_p2 = (sel_tmp8_fu_360_p2.read() | sel_tmp6_fu_354_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_out_V_V_TDATA() {
    out_V_V_TDATA = esl_concat<288,32>(esl_concat<256,32>(esl_concat<224,32>(esl_concat<192,32>(esl_concat<160,32>(esl_concat<128,32>(esl_concat<96,32>(esl_concat<64,32>(esl_concat<32,32>(accu_9_V_fu_6105_p2.read(), accu_8_V_fu_5567_p2.read()), accu_7_V_fu_5029_p2.read()), accu_6_V_fu_4491_p2.read()), accu_5_V_fu_3953_p2.read()), accu_4_V_fu_3415_p2.read()), accu_3_V_fu_2877_p2.read()), accu_2_V_fu_2339_p2.read()), accu_1_V_fu_1801_p2.read()), accu_0_V_fu_1263_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_out_V_V_TDATA_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_1, tmp_s_reg_6355.read()))) {
        out_V_V_TDATA_blk_n = out_V_V_TREADY.read();
    } else {
        out_V_V_TDATA_blk_n = ap_const_logic_1;
    }
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_out_V_V_TVALID() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_1, tmp_s_reg_6355.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        out_V_V_TVALID = ap_const_logic_1;
    } else {
        out_V_V_TVALID = ap_const_logic_0;
    }
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_1_fu_6197_p3() {
    p_1_fu_6197_p3 = (!tmp_reg_6326.read()[0].is_01())? sc_lv<32>(): ((tmp_reg_6326.read()[0].to_bool())? ap_const_lv32_0: tile_fu_6111_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_0_10_fu_969_p3() {
    p_Result_0_10_fu_969_p3 = tmp_20_fu_603_p6.read().range(11, 11);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_0_11_fu_1001_p3() {
    p_Result_0_11_fu_1001_p3 = tmp_20_fu_603_p6.read().range(12, 12);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_0_12_fu_1033_p3() {
    p_Result_0_12_fu_1033_p3 = tmp_20_fu_603_p6.read().range(13, 13);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_0_13_fu_1065_p3() {
    p_Result_0_13_fu_1065_p3 = tmp_20_fu_603_p6.read().range(14, 14);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_0_14_fu_1097_p3() {
    p_Result_0_14_fu_1097_p3 = tmp_20_fu_603_p6.read().range(15, 15);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_0_1_fu_649_p3() {
    p_Result_0_1_fu_649_p3 = tmp_20_fu_603_p6.read().range(1, 1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_0_2_fu_681_p3() {
    p_Result_0_2_fu_681_p3 = tmp_20_fu_603_p6.read().range(2, 2);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_0_3_fu_713_p3() {
    p_Result_0_3_fu_713_p3 = tmp_20_fu_603_p6.read().range(3, 3);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_0_4_fu_745_p3() {
    p_Result_0_4_fu_745_p3 = tmp_20_fu_603_p6.read().range(4, 4);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_0_5_fu_777_p3() {
    p_Result_0_5_fu_777_p3 = tmp_20_fu_603_p6.read().range(5, 5);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_0_6_fu_809_p3() {
    p_Result_0_6_fu_809_p3 = tmp_20_fu_603_p6.read().range(6, 6);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_0_7_fu_841_p3() {
    p_Result_0_7_fu_841_p3 = tmp_20_fu_603_p6.read().range(7, 7);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_0_8_fu_873_p3() {
    p_Result_0_8_fu_873_p3 = tmp_20_fu_603_p6.read().range(8, 8);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_0_9_fu_905_p3() {
    p_Result_0_9_fu_905_p3 = tmp_20_fu_603_p6.read().range(9, 9);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_0_s_fu_937_p3() {
    p_Result_0_s_fu_937_p3 = tmp_20_fu_603_p6.read().range(10, 10);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_1_10_fu_1547_p3() {
    p_Result_1_10_fu_1547_p3 = tmp_54_fu_1269_p6.read().range(11, 11);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_1_11_fu_1571_p3() {
    p_Result_1_11_fu_1571_p3 = tmp_54_fu_1269_p6.read().range(12, 12);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_1_12_fu_1595_p3() {
    p_Result_1_12_fu_1595_p3 = tmp_54_fu_1269_p6.read().range(13, 13);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_1_13_fu_1619_p3() {
    p_Result_1_13_fu_1619_p3 = tmp_54_fu_1269_p6.read().range(14, 14);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_1_14_fu_1643_p3() {
    p_Result_1_14_fu_1643_p3 = tmp_54_fu_1269_p6.read().range(15, 15);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_1_1_fu_1307_p3() {
    p_Result_1_1_fu_1307_p3 = tmp_54_fu_1269_p6.read().range(1, 1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_1_2_fu_1331_p3() {
    p_Result_1_2_fu_1331_p3 = tmp_54_fu_1269_p6.read().range(2, 2);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_1_3_fu_1355_p3() {
    p_Result_1_3_fu_1355_p3 = tmp_54_fu_1269_p6.read().range(3, 3);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_1_4_fu_1379_p3() {
    p_Result_1_4_fu_1379_p3 = tmp_54_fu_1269_p6.read().range(4, 4);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_1_5_fu_1403_p3() {
    p_Result_1_5_fu_1403_p3 = tmp_54_fu_1269_p6.read().range(5, 5);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_1_6_fu_1427_p3() {
    p_Result_1_6_fu_1427_p3 = tmp_54_fu_1269_p6.read().range(6, 6);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_1_7_fu_1451_p3() {
    p_Result_1_7_fu_1451_p3 = tmp_54_fu_1269_p6.read().range(7, 7);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_1_8_fu_1475_p3() {
    p_Result_1_8_fu_1475_p3 = tmp_54_fu_1269_p6.read().range(8, 8);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_1_9_fu_1499_p3() {
    p_Result_1_9_fu_1499_p3 = tmp_54_fu_1269_p6.read().range(9, 9);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_1_fu_1283_p3() {
    p_Result_1_fu_1283_p3 = tmp_54_fu_1269_p6.read().range(0, 0);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_1_s_fu_1523_p3() {
    p_Result_1_s_fu_1523_p3 = tmp_54_fu_1269_p6.read().range(10, 10);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_28_10_fu_2085_p3() {
    p_Result_28_10_fu_2085_p3 = tmp_88_fu_1807_p6.read().range(11, 11);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_28_11_fu_2109_p3() {
    p_Result_28_11_fu_2109_p3 = tmp_88_fu_1807_p6.read().range(12, 12);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_28_12_fu_2133_p3() {
    p_Result_28_12_fu_2133_p3 = tmp_88_fu_1807_p6.read().range(13, 13);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_28_13_fu_2157_p3() {
    p_Result_28_13_fu_2157_p3 = tmp_88_fu_1807_p6.read().range(14, 14);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_28_14_fu_2181_p3() {
    p_Result_28_14_fu_2181_p3 = tmp_88_fu_1807_p6.read().range(15, 15);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_28_1_fu_1845_p3() {
    p_Result_28_1_fu_1845_p3 = tmp_88_fu_1807_p6.read().range(1, 1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_28_2_fu_1869_p3() {
    p_Result_28_2_fu_1869_p3 = tmp_88_fu_1807_p6.read().range(2, 2);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_28_3_fu_1893_p3() {
    p_Result_28_3_fu_1893_p3 = tmp_88_fu_1807_p6.read().range(3, 3);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_28_4_fu_1917_p3() {
    p_Result_28_4_fu_1917_p3 = tmp_88_fu_1807_p6.read().range(4, 4);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_28_5_fu_1941_p3() {
    p_Result_28_5_fu_1941_p3 = tmp_88_fu_1807_p6.read().range(5, 5);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_28_6_fu_1965_p3() {
    p_Result_28_6_fu_1965_p3 = tmp_88_fu_1807_p6.read().range(6, 6);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_28_7_fu_1989_p3() {
    p_Result_28_7_fu_1989_p3 = tmp_88_fu_1807_p6.read().range(7, 7);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_28_8_fu_2013_p3() {
    p_Result_28_8_fu_2013_p3 = tmp_88_fu_1807_p6.read().range(8, 8);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_28_9_fu_2037_p3() {
    p_Result_28_9_fu_2037_p3 = tmp_88_fu_1807_p6.read().range(9, 9);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_28_s_fu_2061_p3() {
    p_Result_28_s_fu_2061_p3 = tmp_88_fu_1807_p6.read().range(10, 10);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_2_0_10_fu_977_p3() {
    p_Result_2_0_10_fu_977_p3 = ap_phi_reg_pp0_iter1_act_m_val_V_reg_266.read().range(11, 11);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_2_0_11_fu_1009_p3() {
    p_Result_2_0_11_fu_1009_p3 = ap_phi_reg_pp0_iter1_act_m_val_V_reg_266.read().range(12, 12);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_2_0_12_fu_1041_p3() {
    p_Result_2_0_12_fu_1041_p3 = ap_phi_reg_pp0_iter1_act_m_val_V_reg_266.read().range(13, 13);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_2_0_13_fu_1073_p3() {
    p_Result_2_0_13_fu_1073_p3 = ap_phi_reg_pp0_iter1_act_m_val_V_reg_266.read().range(14, 14);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_2_0_14_fu_1105_p3() {
    p_Result_2_0_14_fu_1105_p3 = ap_phi_reg_pp0_iter1_act_m_val_V_reg_266.read().range(15, 15);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_2_0_1_fu_657_p3() {
    p_Result_2_0_1_fu_657_p3 = ap_phi_reg_pp0_iter1_act_m_val_V_reg_266.read().range(1, 1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_2_0_2_fu_689_p3() {
    p_Result_2_0_2_fu_689_p3 = ap_phi_reg_pp0_iter1_act_m_val_V_reg_266.read().range(2, 2);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_2_0_3_fu_721_p3() {
    p_Result_2_0_3_fu_721_p3 = ap_phi_reg_pp0_iter1_act_m_val_V_reg_266.read().range(3, 3);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_2_0_4_fu_753_p3() {
    p_Result_2_0_4_fu_753_p3 = ap_phi_reg_pp0_iter1_act_m_val_V_reg_266.read().range(4, 4);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_2_0_5_fu_785_p3() {
    p_Result_2_0_5_fu_785_p3 = ap_phi_reg_pp0_iter1_act_m_val_V_reg_266.read().range(5, 5);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_2_0_6_fu_817_p3() {
    p_Result_2_0_6_fu_817_p3 = ap_phi_reg_pp0_iter1_act_m_val_V_reg_266.read().range(6, 6);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_2_0_7_fu_849_p3() {
    p_Result_2_0_7_fu_849_p3 = ap_phi_reg_pp0_iter1_act_m_val_V_reg_266.read().range(7, 7);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_2_0_8_fu_881_p3() {
    p_Result_2_0_8_fu_881_p3 = ap_phi_reg_pp0_iter1_act_m_val_V_reg_266.read().range(8, 8);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_2_0_9_fu_913_p3() {
    p_Result_2_0_9_fu_913_p3 = ap_phi_reg_pp0_iter1_act_m_val_V_reg_266.read().range(9, 9);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_2_0_s_fu_945_p3() {
    p_Result_2_0_s_fu_945_p3 = ap_phi_reg_pp0_iter1_act_m_val_V_reg_266.read().range(10, 10);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_2_fu_625_p3() {
    p_Result_2_fu_625_p3 = ap_phi_reg_pp0_iter1_act_m_val_V_reg_266.read().range(0, 0);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_310_10_fu_2623_p3() {
    p_Result_310_10_fu_2623_p3 = tmp_122_fu_2345_p6.read().range(11, 11);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_310_11_fu_2647_p3() {
    p_Result_310_11_fu_2647_p3 = tmp_122_fu_2345_p6.read().range(12, 12);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_310_12_fu_2671_p3() {
    p_Result_310_12_fu_2671_p3 = tmp_122_fu_2345_p6.read().range(13, 13);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_310_13_fu_2695_p3() {
    p_Result_310_13_fu_2695_p3 = tmp_122_fu_2345_p6.read().range(14, 14);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_310_14_fu_2719_p3() {
    p_Result_310_14_fu_2719_p3 = tmp_122_fu_2345_p6.read().range(15, 15);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_310_1_fu_2383_p3() {
    p_Result_310_1_fu_2383_p3 = tmp_122_fu_2345_p6.read().range(1, 1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_310_2_fu_2407_p3() {
    p_Result_310_2_fu_2407_p3 = tmp_122_fu_2345_p6.read().range(2, 2);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_310_3_fu_2431_p3() {
    p_Result_310_3_fu_2431_p3 = tmp_122_fu_2345_p6.read().range(3, 3);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_310_4_fu_2455_p3() {
    p_Result_310_4_fu_2455_p3 = tmp_122_fu_2345_p6.read().range(4, 4);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_310_5_fu_2479_p3() {
    p_Result_310_5_fu_2479_p3 = tmp_122_fu_2345_p6.read().range(5, 5);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_310_6_fu_2503_p3() {
    p_Result_310_6_fu_2503_p3 = tmp_122_fu_2345_p6.read().range(6, 6);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_310_7_fu_2527_p3() {
    p_Result_310_7_fu_2527_p3 = tmp_122_fu_2345_p6.read().range(7, 7);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_310_8_fu_2551_p3() {
    p_Result_310_8_fu_2551_p3 = tmp_122_fu_2345_p6.read().range(8, 8);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_310_9_fu_2575_p3() {
    p_Result_310_9_fu_2575_p3 = tmp_122_fu_2345_p6.read().range(9, 9);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_310_s_fu_2599_p3() {
    p_Result_310_s_fu_2599_p3 = tmp_122_fu_2345_p6.read().range(10, 10);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_3_fu_2359_p3() {
    p_Result_3_fu_2359_p3 = tmp_122_fu_2345_p6.read().range(0, 0);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_4_10_fu_3161_p3() {
    p_Result_4_10_fu_3161_p3 = tmp_156_fu_2883_p6.read().range(11, 11);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_4_11_fu_3185_p3() {
    p_Result_4_11_fu_3185_p3 = tmp_156_fu_2883_p6.read().range(12, 12);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_4_12_fu_3209_p3() {
    p_Result_4_12_fu_3209_p3 = tmp_156_fu_2883_p6.read().range(13, 13);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_4_13_fu_3233_p3() {
    p_Result_4_13_fu_3233_p3 = tmp_156_fu_2883_p6.read().range(14, 14);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_4_14_fu_3257_p3() {
    p_Result_4_14_fu_3257_p3 = tmp_156_fu_2883_p6.read().range(15, 15);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_4_1_fu_2921_p3() {
    p_Result_4_1_fu_2921_p3 = tmp_156_fu_2883_p6.read().range(1, 1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_4_2_fu_2945_p3() {
    p_Result_4_2_fu_2945_p3 = tmp_156_fu_2883_p6.read().range(2, 2);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_4_3_fu_2969_p3() {
    p_Result_4_3_fu_2969_p3 = tmp_156_fu_2883_p6.read().range(3, 3);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_4_4_fu_2993_p3() {
    p_Result_4_4_fu_2993_p3 = tmp_156_fu_2883_p6.read().range(4, 4);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_4_5_fu_3017_p3() {
    p_Result_4_5_fu_3017_p3 = tmp_156_fu_2883_p6.read().range(5, 5);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_4_6_fu_3041_p3() {
    p_Result_4_6_fu_3041_p3 = tmp_156_fu_2883_p6.read().range(6, 6);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_4_7_fu_3065_p3() {
    p_Result_4_7_fu_3065_p3 = tmp_156_fu_2883_p6.read().range(7, 7);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_4_8_fu_3089_p3() {
    p_Result_4_8_fu_3089_p3 = tmp_156_fu_2883_p6.read().range(8, 8);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_4_9_fu_3113_p3() {
    p_Result_4_9_fu_3113_p3 = tmp_156_fu_2883_p6.read().range(9, 9);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_4_fu_2897_p3() {
    p_Result_4_fu_2897_p3 = tmp_156_fu_2883_p6.read().range(0, 0);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_4_s_fu_3137_p3() {
    p_Result_4_s_fu_3137_p3 = tmp_156_fu_2883_p6.read().range(10, 10);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_5_10_fu_3699_p3() {
    p_Result_5_10_fu_3699_p3 = tmp_169_fu_3421_p6.read().range(11, 11);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_5_11_fu_3723_p3() {
    p_Result_5_11_fu_3723_p3 = tmp_169_fu_3421_p6.read().range(12, 12);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_5_12_fu_3747_p3() {
    p_Result_5_12_fu_3747_p3 = tmp_169_fu_3421_p6.read().range(13, 13);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_5_13_fu_3771_p3() {
    p_Result_5_13_fu_3771_p3 = tmp_169_fu_3421_p6.read().range(14, 14);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_5_14_fu_3795_p3() {
    p_Result_5_14_fu_3795_p3 = tmp_169_fu_3421_p6.read().range(15, 15);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_5_1_fu_3459_p3() {
    p_Result_5_1_fu_3459_p3 = tmp_169_fu_3421_p6.read().range(1, 1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_5_2_fu_3483_p3() {
    p_Result_5_2_fu_3483_p3 = tmp_169_fu_3421_p6.read().range(2, 2);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_5_3_fu_3507_p3() {
    p_Result_5_3_fu_3507_p3 = tmp_169_fu_3421_p6.read().range(3, 3);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_5_4_fu_3531_p3() {
    p_Result_5_4_fu_3531_p3 = tmp_169_fu_3421_p6.read().range(4, 4);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_5_5_fu_3555_p3() {
    p_Result_5_5_fu_3555_p3 = tmp_169_fu_3421_p6.read().range(5, 5);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_5_6_fu_3579_p3() {
    p_Result_5_6_fu_3579_p3 = tmp_169_fu_3421_p6.read().range(6, 6);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_5_7_fu_3603_p3() {
    p_Result_5_7_fu_3603_p3 = tmp_169_fu_3421_p6.read().range(7, 7);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_5_8_fu_3627_p3() {
    p_Result_5_8_fu_3627_p3 = tmp_169_fu_3421_p6.read().range(8, 8);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_5_9_fu_3651_p3() {
    p_Result_5_9_fu_3651_p3 = tmp_169_fu_3421_p6.read().range(9, 9);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_5_fu_3435_p3() {
    p_Result_5_fu_3435_p3 = tmp_169_fu_3421_p6.read().range(0, 0);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_5_s_fu_3675_p3() {
    p_Result_5_s_fu_3675_p3 = tmp_169_fu_3421_p6.read().range(10, 10);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_6_10_fu_4237_p3() {
    p_Result_6_10_fu_4237_p3 = tmp_170_fu_3959_p6.read().range(11, 11);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_6_11_fu_4261_p3() {
    p_Result_6_11_fu_4261_p3 = tmp_170_fu_3959_p6.read().range(12, 12);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_6_12_fu_4285_p3() {
    p_Result_6_12_fu_4285_p3 = tmp_170_fu_3959_p6.read().range(13, 13);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_6_13_fu_4309_p3() {
    p_Result_6_13_fu_4309_p3 = tmp_170_fu_3959_p6.read().range(14, 14);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_6_14_fu_4333_p3() {
    p_Result_6_14_fu_4333_p3 = tmp_170_fu_3959_p6.read().range(15, 15);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_6_1_fu_3997_p3() {
    p_Result_6_1_fu_3997_p3 = tmp_170_fu_3959_p6.read().range(1, 1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_6_2_fu_4021_p3() {
    p_Result_6_2_fu_4021_p3 = tmp_170_fu_3959_p6.read().range(2, 2);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_6_3_fu_4045_p3() {
    p_Result_6_3_fu_4045_p3 = tmp_170_fu_3959_p6.read().range(3, 3);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_6_4_fu_4069_p3() {
    p_Result_6_4_fu_4069_p3 = tmp_170_fu_3959_p6.read().range(4, 4);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_6_5_fu_4093_p3() {
    p_Result_6_5_fu_4093_p3 = tmp_170_fu_3959_p6.read().range(5, 5);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_6_6_fu_4117_p3() {
    p_Result_6_6_fu_4117_p3 = tmp_170_fu_3959_p6.read().range(6, 6);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_6_7_fu_4141_p3() {
    p_Result_6_7_fu_4141_p3 = tmp_170_fu_3959_p6.read().range(7, 7);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_6_8_fu_4165_p3() {
    p_Result_6_8_fu_4165_p3 = tmp_170_fu_3959_p6.read().range(8, 8);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_6_9_fu_4189_p3() {
    p_Result_6_9_fu_4189_p3 = tmp_170_fu_3959_p6.read().range(9, 9);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_6_fu_3973_p3() {
    p_Result_6_fu_3973_p3 = tmp_170_fu_3959_p6.read().range(0, 0);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_6_s_fu_4213_p3() {
    p_Result_6_s_fu_4213_p3 = tmp_170_fu_3959_p6.read().range(10, 10);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_7_10_fu_4775_p3() {
    p_Result_7_10_fu_4775_p3 = tmp_171_fu_4497_p6.read().range(11, 11);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_7_11_fu_4799_p3() {
    p_Result_7_11_fu_4799_p3 = tmp_171_fu_4497_p6.read().range(12, 12);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_7_12_fu_4823_p3() {
    p_Result_7_12_fu_4823_p3 = tmp_171_fu_4497_p6.read().range(13, 13);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_7_13_fu_4847_p3() {
    p_Result_7_13_fu_4847_p3 = tmp_171_fu_4497_p6.read().range(14, 14);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_7_14_fu_4871_p3() {
    p_Result_7_14_fu_4871_p3 = tmp_171_fu_4497_p6.read().range(15, 15);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_7_1_fu_4535_p3() {
    p_Result_7_1_fu_4535_p3 = tmp_171_fu_4497_p6.read().range(1, 1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_7_2_fu_4559_p3() {
    p_Result_7_2_fu_4559_p3 = tmp_171_fu_4497_p6.read().range(2, 2);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_7_3_fu_4583_p3() {
    p_Result_7_3_fu_4583_p3 = tmp_171_fu_4497_p6.read().range(3, 3);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_7_4_fu_4607_p3() {
    p_Result_7_4_fu_4607_p3 = tmp_171_fu_4497_p6.read().range(4, 4);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_7_5_fu_4631_p3() {
    p_Result_7_5_fu_4631_p3 = tmp_171_fu_4497_p6.read().range(5, 5);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_7_6_fu_4655_p3() {
    p_Result_7_6_fu_4655_p3 = tmp_171_fu_4497_p6.read().range(6, 6);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_7_7_fu_4679_p3() {
    p_Result_7_7_fu_4679_p3 = tmp_171_fu_4497_p6.read().range(7, 7);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_7_8_fu_4703_p3() {
    p_Result_7_8_fu_4703_p3 = tmp_171_fu_4497_p6.read().range(8, 8);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_7_9_fu_4727_p3() {
    p_Result_7_9_fu_4727_p3 = tmp_171_fu_4497_p6.read().range(9, 9);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_7_fu_4511_p3() {
    p_Result_7_fu_4511_p3 = tmp_171_fu_4497_p6.read().range(0, 0);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_7_s_fu_4751_p3() {
    p_Result_7_s_fu_4751_p3 = tmp_171_fu_4497_p6.read().range(10, 10);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_8_10_fu_5313_p3() {
    p_Result_8_10_fu_5313_p3 = tmp_172_fu_5035_p6.read().range(11, 11);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_8_11_fu_5337_p3() {
    p_Result_8_11_fu_5337_p3 = tmp_172_fu_5035_p6.read().range(12, 12);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_8_12_fu_5361_p3() {
    p_Result_8_12_fu_5361_p3 = tmp_172_fu_5035_p6.read().range(13, 13);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_8_13_fu_5385_p3() {
    p_Result_8_13_fu_5385_p3 = tmp_172_fu_5035_p6.read().range(14, 14);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_8_14_fu_5409_p3() {
    p_Result_8_14_fu_5409_p3 = tmp_172_fu_5035_p6.read().range(15, 15);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_8_1_fu_5073_p3() {
    p_Result_8_1_fu_5073_p3 = tmp_172_fu_5035_p6.read().range(1, 1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_8_2_fu_5097_p3() {
    p_Result_8_2_fu_5097_p3 = tmp_172_fu_5035_p6.read().range(2, 2);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_8_3_fu_5121_p3() {
    p_Result_8_3_fu_5121_p3 = tmp_172_fu_5035_p6.read().range(3, 3);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_8_4_fu_5145_p3() {
    p_Result_8_4_fu_5145_p3 = tmp_172_fu_5035_p6.read().range(4, 4);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_8_5_fu_5169_p3() {
    p_Result_8_5_fu_5169_p3 = tmp_172_fu_5035_p6.read().range(5, 5);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_8_6_fu_5193_p3() {
    p_Result_8_6_fu_5193_p3 = tmp_172_fu_5035_p6.read().range(6, 6);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_8_7_fu_5217_p3() {
    p_Result_8_7_fu_5217_p3 = tmp_172_fu_5035_p6.read().range(7, 7);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_8_8_fu_5241_p3() {
    p_Result_8_8_fu_5241_p3 = tmp_172_fu_5035_p6.read().range(8, 8);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_8_9_fu_5265_p3() {
    p_Result_8_9_fu_5265_p3 = tmp_172_fu_5035_p6.read().range(9, 9);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_8_fu_5049_p3() {
    p_Result_8_fu_5049_p3 = tmp_172_fu_5035_p6.read().range(0, 0);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_8_s_fu_5289_p3() {
    p_Result_8_s_fu_5289_p3 = tmp_172_fu_5035_p6.read().range(10, 10);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_9_10_fu_5851_p3() {
    p_Result_9_10_fu_5851_p3 = tmp_173_fu_5573_p6.read().range(11, 11);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_9_11_fu_5875_p3() {
    p_Result_9_11_fu_5875_p3 = tmp_173_fu_5573_p6.read().range(12, 12);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_9_12_fu_5899_p3() {
    p_Result_9_12_fu_5899_p3 = tmp_173_fu_5573_p6.read().range(13, 13);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_9_13_fu_5923_p3() {
    p_Result_9_13_fu_5923_p3 = tmp_173_fu_5573_p6.read().range(14, 14);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_9_14_fu_5947_p3() {
    p_Result_9_14_fu_5947_p3 = tmp_173_fu_5573_p6.read().range(15, 15);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_9_1_fu_5611_p3() {
    p_Result_9_1_fu_5611_p3 = tmp_173_fu_5573_p6.read().range(1, 1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_9_2_fu_5635_p3() {
    p_Result_9_2_fu_5635_p3 = tmp_173_fu_5573_p6.read().range(2, 2);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_9_3_fu_5659_p3() {
    p_Result_9_3_fu_5659_p3 = tmp_173_fu_5573_p6.read().range(3, 3);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_9_4_fu_5683_p3() {
    p_Result_9_4_fu_5683_p3 = tmp_173_fu_5573_p6.read().range(4, 4);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_9_5_fu_5707_p3() {
    p_Result_9_5_fu_5707_p3 = tmp_173_fu_5573_p6.read().range(5, 5);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_9_6_fu_5731_p3() {
    p_Result_9_6_fu_5731_p3 = tmp_173_fu_5573_p6.read().range(6, 6);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_9_7_fu_5755_p3() {
    p_Result_9_7_fu_5755_p3 = tmp_173_fu_5573_p6.read().range(7, 7);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_9_8_fu_5779_p3() {
    p_Result_9_8_fu_5779_p3 = tmp_173_fu_5573_p6.read().range(8, 8);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_9_9_fu_5803_p3() {
    p_Result_9_9_fu_5803_p3 = tmp_173_fu_5573_p6.read().range(9, 9);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_9_fu_5587_p3() {
    p_Result_9_fu_5587_p3 = tmp_173_fu_5573_p6.read().range(0, 0);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_9_s_fu_5827_p3() {
    p_Result_9_s_fu_5827_p3 = tmp_173_fu_5573_p6.read().range(10, 10);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_s_73_fu_1821_p3() {
    p_Result_s_73_fu_1821_p3 = tmp_88_fu_1807_p6.read().range(0, 0);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_Result_s_fu_617_p3() {
    p_Result_s_fu_617_p3 = tmp_20_fu_603_p6.read().range(0, 0);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_accu_V_1_fu_585_p3() {
    p_accu_V_1_fu_585_p3 = (!tmp_4_reg_6341.read()[0].is_01())? sc_lv<32>(): ((tmp_4_reg_6341.read()[0].to_bool())? ap_const_lv32_0: accu_1_V_1_fu_178.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_accu_V_2_fu_578_p3() {
    p_accu_V_2_fu_578_p3 = (!tmp_4_reg_6341.read()[0].is_01())? sc_lv<32>(): ((tmp_4_reg_6341.read()[0].to_bool())? ap_const_lv32_0: accu_2_V_1_fu_182.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_accu_V_3_fu_571_p3() {
    p_accu_V_3_fu_571_p3 = (!tmp_4_reg_6341.read()[0].is_01())? sc_lv<32>(): ((tmp_4_reg_6341.read()[0].to_bool())? ap_const_lv32_0: accu_3_V_1_fu_186.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_accu_V_4_fu_564_p3() {
    p_accu_V_4_fu_564_p3 = (!tmp_4_reg_6341.read()[0].is_01())? sc_lv<32>(): ((tmp_4_reg_6341.read()[0].to_bool())? ap_const_lv32_0: accu_4_V_1_fu_190.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_accu_V_5_fu_557_p3() {
    p_accu_V_5_fu_557_p3 = (!tmp_4_reg_6341.read()[0].is_01())? sc_lv<32>(): ((tmp_4_reg_6341.read()[0].to_bool())? ap_const_lv32_0: accu_5_V_1_fu_194.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_accu_V_6_fu_550_p3() {
    p_accu_V_6_fu_550_p3 = (!tmp_4_reg_6341.read()[0].is_01())? sc_lv<32>(): ((tmp_4_reg_6341.read()[0].to_bool())? ap_const_lv32_0: accu_6_V_1_fu_198.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_accu_V_7_fu_543_p3() {
    p_accu_V_7_fu_543_p3 = (!tmp_4_reg_6341.read()[0].is_01())? sc_lv<32>(): ((tmp_4_reg_6341.read()[0].to_bool())? ap_const_lv32_0: accu_7_V_1_fu_202.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_accu_V_8_fu_536_p3() {
    p_accu_V_8_fu_536_p3 = (!tmp_4_reg_6341.read()[0].is_01())? sc_lv<32>(): ((tmp_4_reg_6341.read()[0].to_bool())? ap_const_lv32_0: accu_8_V_1_fu_206.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_accu_V_9_fu_529_p3() {
    p_accu_V_9_fu_529_p3 = (!tmp_4_reg_6341.read()[0].is_01())? sc_lv<32>(): ((tmp_4_reg_6341.read()[0].to_bool())? ap_const_lv32_0: accu_9_V_1_fu_210.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_accu_V_fu_592_p3() {
    p_accu_V_fu_592_p3 = (!tmp_4_reg_6341.read()[0].is_01())? sc_lv<32>(): ((tmp_4_reg_6341.read()[0].to_bool())? ap_const_lv32_0: accu_0_V_1_fu_174.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_p_s_fu_483_p3() {
    p_s_fu_483_p3 = (!tmp_fu_305_p2.read()[0].is_01())? sc_lv<32>(): ((tmp_fu_305_p2.read()[0].to_bool())? ap_const_lv32_0: nf_1_fu_477_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_0_10_cast_fu_997_p1() {
    res_0_10_cast_fu_997_p1 = esl_zext<2,1>(tmp_12_0_10_fu_991_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_0_11_cast_fu_1029_p1() {
    res_0_11_cast_fu_1029_p1 = esl_zext<2,1>(tmp_12_0_11_fu_1023_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_0_13_cast_fu_1093_p1() {
    res_0_13_cast_fu_1093_p1 = esl_zext<2,1>(tmp_12_0_13_fu_1087_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_0_14_cast_fu_1125_p1() {
    res_0_14_cast_fu_1125_p1 = esl_zext<2,1>(tmp_12_0_14_fu_1119_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_0_1_cast_fu_677_p1() {
    res_0_1_cast_fu_677_p1 = esl_zext<2,1>(tmp_12_0_1_fu_671_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_0_2_cast_fu_709_p1() {
    res_0_2_cast_fu_709_p1 = esl_zext<2,1>(tmp_12_0_2_fu_703_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_0_3_cast_fu_741_p1() {
    res_0_3_cast_fu_741_p1 = esl_zext<2,1>(tmp_12_0_3_fu_735_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_0_4_cast_fu_773_p1() {
    res_0_4_cast_fu_773_p1 = esl_zext<2,1>(tmp_12_0_4_fu_767_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_0_5_cast_fu_805_p1() {
    res_0_5_cast_fu_805_p1 = esl_zext<2,1>(tmp_12_0_5_fu_799_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_0_6_cast_fu_837_p1() {
    res_0_6_cast_fu_837_p1 = esl_zext<2,1>(tmp_12_0_6_fu_831_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_0_7_cast_fu_869_p1() {
    res_0_7_cast_fu_869_p1 = esl_zext<2,1>(tmp_12_0_7_fu_863_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_0_8_cast_fu_901_p1() {
    res_0_8_cast_fu_901_p1 = esl_zext<2,1>(tmp_12_0_8_fu_895_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_0_9_cast_fu_933_p1() {
    res_0_9_cast_fu_933_p1 = esl_zext<2,1>(tmp_12_0_9_fu_927_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_0_cast_fu_965_p1() {
    res_0_cast_fu_965_p1 = esl_zext<2,1>(tmp_12_0_s_fu_959_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_0_s_fu_1061_p1() {
    res_0_s_fu_1061_p1 = esl_zext<32,1>(tmp_12_0_12_fu_1055_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_1_10_cast_fu_1567_p1() {
    res_1_10_cast_fu_1567_p1 = esl_zext<2,1>(tmp_12_1_10_fu_1561_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_1_11_cast_fu_1591_p1() {
    res_1_11_cast_fu_1591_p1 = esl_zext<2,1>(tmp_12_1_11_fu_1585_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_1_13_cast_fu_1639_p1() {
    res_1_13_cast_fu_1639_p1 = esl_zext<2,1>(tmp_12_1_13_fu_1633_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_1_14_cast_fu_1663_p1() {
    res_1_14_cast_fu_1663_p1 = esl_zext<2,1>(tmp_12_1_14_fu_1657_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_1_1_cast_fu_1327_p1() {
    res_1_1_cast_fu_1327_p1 = esl_zext<2,1>(tmp_12_1_1_fu_1321_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_1_2_cast_fu_1351_p1() {
    res_1_2_cast_fu_1351_p1 = esl_zext<2,1>(tmp_12_1_2_fu_1345_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_1_3_cast_fu_1375_p1() {
    res_1_3_cast_fu_1375_p1 = esl_zext<2,1>(tmp_12_1_3_fu_1369_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_1_4_cast_fu_1399_p1() {
    res_1_4_cast_fu_1399_p1 = esl_zext<2,1>(tmp_12_1_4_fu_1393_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_1_5_cast_fu_1423_p1() {
    res_1_5_cast_fu_1423_p1 = esl_zext<2,1>(tmp_12_1_5_fu_1417_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_1_6_cast_fu_1447_p1() {
    res_1_6_cast_fu_1447_p1 = esl_zext<2,1>(tmp_12_1_6_fu_1441_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_1_7_cast_fu_1471_p1() {
    res_1_7_cast_fu_1471_p1 = esl_zext<2,1>(tmp_12_1_7_fu_1465_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_1_8_cast_fu_1495_p1() {
    res_1_8_cast_fu_1495_p1 = esl_zext<2,1>(tmp_12_1_8_fu_1489_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_1_9_cast_fu_1519_p1() {
    res_1_9_cast_fu_1519_p1 = esl_zext<2,1>(tmp_12_1_9_fu_1513_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_1_cast_66_fu_1543_p1() {
    res_1_cast_66_fu_1543_p1 = esl_zext<2,1>(tmp_12_1_s_fu_1537_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_1_cast_fu_1303_p1() {
    res_1_cast_fu_1303_p1 = esl_zext<2,1>(tmp_12_1_fu_1297_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_1_s_fu_1615_p1() {
    res_1_s_fu_1615_p1 = esl_zext<32,1>(tmp_12_1_12_fu_1609_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_29_10_cast_fu_2105_p1() {
    res_29_10_cast_fu_2105_p1 = esl_zext<2,1>(tmp_12_2_10_fu_2099_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_29_11_cast_fu_2129_p1() {
    res_29_11_cast_fu_2129_p1 = esl_zext<2,1>(tmp_12_2_11_fu_2123_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_29_13_cast_fu_2177_p1() {
    res_29_13_cast_fu_2177_p1 = esl_zext<2,1>(tmp_12_2_13_fu_2171_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_29_14_cast_fu_2201_p1() {
    res_29_14_cast_fu_2201_p1 = esl_zext<2,1>(tmp_12_2_14_fu_2195_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_29_1_cast_fu_1865_p1() {
    res_29_1_cast_fu_1865_p1 = esl_zext<2,1>(tmp_12_2_1_fu_1859_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_29_2_cast_fu_1889_p1() {
    res_29_2_cast_fu_1889_p1 = esl_zext<2,1>(tmp_12_2_2_fu_1883_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_29_3_cast_fu_1913_p1() {
    res_29_3_cast_fu_1913_p1 = esl_zext<2,1>(tmp_12_2_3_fu_1907_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_29_4_cast_fu_1937_p1() {
    res_29_4_cast_fu_1937_p1 = esl_zext<2,1>(tmp_12_2_4_fu_1931_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_29_5_cast_fu_1961_p1() {
    res_29_5_cast_fu_1961_p1 = esl_zext<2,1>(tmp_12_2_5_fu_1955_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_29_6_cast_fu_1985_p1() {
    res_29_6_cast_fu_1985_p1 = esl_zext<2,1>(tmp_12_2_6_fu_1979_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_29_7_cast_fu_2009_p1() {
    res_29_7_cast_fu_2009_p1 = esl_zext<2,1>(tmp_12_2_7_fu_2003_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_29_8_cast_fu_2033_p1() {
    res_29_8_cast_fu_2033_p1 = esl_zext<2,1>(tmp_12_2_8_fu_2027_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_29_9_cast_fu_2057_p1() {
    res_29_9_cast_fu_2057_p1 = esl_zext<2,1>(tmp_12_2_9_fu_2051_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_29_cast_fu_2081_p1() {
    res_29_cast_fu_2081_p1 = esl_zext<2,1>(tmp_12_2_s_fu_2075_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_29_s_fu_2153_p1() {
    res_29_s_fu_2153_p1 = esl_zext<32,1>(tmp_12_2_12_fu_2147_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_3_10_cast_fu_2643_p1() {
    res_3_10_cast_fu_2643_p1 = esl_zext<2,1>(tmp_12_3_10_fu_2637_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_3_11_cast_fu_2667_p1() {
    res_3_11_cast_fu_2667_p1 = esl_zext<2,1>(tmp_12_3_11_fu_2661_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_3_13_cast_fu_2715_p1() {
    res_3_13_cast_fu_2715_p1 = esl_zext<2,1>(tmp_12_3_13_fu_2709_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_3_14_cast_fu_2739_p1() {
    res_3_14_cast_fu_2739_p1 = esl_zext<2,1>(tmp_12_3_14_fu_2733_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_3_1_cast_fu_2403_p1() {
    res_3_1_cast_fu_2403_p1 = esl_zext<2,1>(tmp_12_3_1_fu_2397_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_3_2_cast_fu_2427_p1() {
    res_3_2_cast_fu_2427_p1 = esl_zext<2,1>(tmp_12_3_2_fu_2421_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_3_3_cast_fu_2451_p1() {
    res_3_3_cast_fu_2451_p1 = esl_zext<2,1>(tmp_12_3_3_fu_2445_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_3_4_cast_fu_2475_p1() {
    res_3_4_cast_fu_2475_p1 = esl_zext<2,1>(tmp_12_3_4_fu_2469_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_3_5_cast_fu_2499_p1() {
    res_3_5_cast_fu_2499_p1 = esl_zext<2,1>(tmp_12_3_5_fu_2493_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_3_6_cast_fu_2523_p1() {
    res_3_6_cast_fu_2523_p1 = esl_zext<2,1>(tmp_12_3_6_fu_2517_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_3_7_cast_fu_2547_p1() {
    res_3_7_cast_fu_2547_p1 = esl_zext<2,1>(tmp_12_3_7_fu_2541_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_3_8_cast_fu_2571_p1() {
    res_3_8_cast_fu_2571_p1 = esl_zext<2,1>(tmp_12_3_8_fu_2565_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_3_9_cast_fu_2595_p1() {
    res_3_9_cast_fu_2595_p1 = esl_zext<2,1>(tmp_12_3_9_fu_2589_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_3_cast_101_fu_2619_p1() {
    res_3_cast_101_fu_2619_p1 = esl_zext<2,1>(tmp_12_3_s_fu_2613_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_3_cast_fu_2379_p1() {
    res_3_cast_fu_2379_p1 = esl_zext<2,1>(tmp_12_3_fu_2373_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_3_s_fu_2691_p1() {
    res_3_s_fu_2691_p1 = esl_zext<32,1>(tmp_12_3_12_fu_2685_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_4_10_cast_fu_3181_p1() {
    res_4_10_cast_fu_3181_p1 = esl_zext<2,1>(tmp_12_4_10_fu_3175_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_4_11_cast_fu_3205_p1() {
    res_4_11_cast_fu_3205_p1 = esl_zext<2,1>(tmp_12_4_11_fu_3199_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_4_13_cast_fu_3253_p1() {
    res_4_13_cast_fu_3253_p1 = esl_zext<2,1>(tmp_12_4_13_fu_3247_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_4_14_cast_fu_3277_p1() {
    res_4_14_cast_fu_3277_p1 = esl_zext<2,1>(tmp_12_4_14_fu_3271_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_4_1_cast_fu_2941_p1() {
    res_4_1_cast_fu_2941_p1 = esl_zext<2,1>(tmp_12_4_1_fu_2935_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_4_2_cast_fu_2965_p1() {
    res_4_2_cast_fu_2965_p1 = esl_zext<2,1>(tmp_12_4_2_fu_2959_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_4_3_cast_fu_2989_p1() {
    res_4_3_cast_fu_2989_p1 = esl_zext<2,1>(tmp_12_4_3_fu_2983_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_4_4_cast_fu_3013_p1() {
    res_4_4_cast_fu_3013_p1 = esl_zext<2,1>(tmp_12_4_4_fu_3007_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_4_5_cast_fu_3037_p1() {
    res_4_5_cast_fu_3037_p1 = esl_zext<2,1>(tmp_12_4_5_fu_3031_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_4_6_cast_fu_3061_p1() {
    res_4_6_cast_fu_3061_p1 = esl_zext<2,1>(tmp_12_4_6_fu_3055_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_4_7_cast_fu_3085_p1() {
    res_4_7_cast_fu_3085_p1 = esl_zext<2,1>(tmp_12_4_7_fu_3079_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_4_8_cast_fu_3109_p1() {
    res_4_8_cast_fu_3109_p1 = esl_zext<2,1>(tmp_12_4_8_fu_3103_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_4_9_cast_fu_3133_p1() {
    res_4_9_cast_fu_3133_p1 = esl_zext<2,1>(tmp_12_4_9_fu_3127_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_4_cast_118_fu_3157_p1() {
    res_4_cast_118_fu_3157_p1 = esl_zext<2,1>(tmp_12_4_s_fu_3151_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_4_cast_fu_2917_p1() {
    res_4_cast_fu_2917_p1 = esl_zext<2,1>(tmp_12_4_fu_2911_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_4_s_fu_3229_p1() {
    res_4_s_fu_3229_p1 = esl_zext<32,1>(tmp_12_4_12_fu_3223_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_5_10_cast_fu_3719_p1() {
    res_5_10_cast_fu_3719_p1 = esl_zext<2,1>(tmp_12_5_10_fu_3713_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_5_11_cast_fu_3743_p1() {
    res_5_11_cast_fu_3743_p1 = esl_zext<2,1>(tmp_12_5_11_fu_3737_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_5_13_cast_fu_3791_p1() {
    res_5_13_cast_fu_3791_p1 = esl_zext<2,1>(tmp_12_5_13_fu_3785_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_5_14_cast_fu_3815_p1() {
    res_5_14_cast_fu_3815_p1 = esl_zext<2,1>(tmp_12_5_14_fu_3809_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_5_1_cast_fu_3479_p1() {
    res_5_1_cast_fu_3479_p1 = esl_zext<2,1>(tmp_12_5_1_fu_3473_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_5_2_cast_fu_3503_p1() {
    res_5_2_cast_fu_3503_p1 = esl_zext<2,1>(tmp_12_5_2_fu_3497_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_5_3_cast_fu_3527_p1() {
    res_5_3_cast_fu_3527_p1 = esl_zext<2,1>(tmp_12_5_3_fu_3521_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_5_4_cast_fu_3551_p1() {
    res_5_4_cast_fu_3551_p1 = esl_zext<2,1>(tmp_12_5_4_fu_3545_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_5_5_cast_fu_3575_p1() {
    res_5_5_cast_fu_3575_p1 = esl_zext<2,1>(tmp_12_5_5_fu_3569_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_5_6_cast_fu_3599_p1() {
    res_5_6_cast_fu_3599_p1 = esl_zext<2,1>(tmp_12_5_6_fu_3593_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_5_7_cast_fu_3623_p1() {
    res_5_7_cast_fu_3623_p1 = esl_zext<2,1>(tmp_12_5_7_fu_3617_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_5_8_cast_fu_3647_p1() {
    res_5_8_cast_fu_3647_p1 = esl_zext<2,1>(tmp_12_5_8_fu_3641_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_5_9_cast_fu_3671_p1() {
    res_5_9_cast_fu_3671_p1 = esl_zext<2,1>(tmp_12_5_9_fu_3665_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_5_cast_135_fu_3695_p1() {
    res_5_cast_135_fu_3695_p1 = esl_zext<2,1>(tmp_12_5_s_fu_3689_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_5_cast_fu_3455_p1() {
    res_5_cast_fu_3455_p1 = esl_zext<2,1>(tmp_12_5_fu_3449_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_5_s_fu_3767_p1() {
    res_5_s_fu_3767_p1 = esl_zext<32,1>(tmp_12_5_12_fu_3761_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_6_10_cast_fu_4257_p1() {
    res_6_10_cast_fu_4257_p1 = esl_zext<2,1>(tmp_12_6_10_fu_4251_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_6_11_cast_fu_4281_p1() {
    res_6_11_cast_fu_4281_p1 = esl_zext<2,1>(tmp_12_6_11_fu_4275_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_6_13_cast_fu_4329_p1() {
    res_6_13_cast_fu_4329_p1 = esl_zext<2,1>(tmp_12_6_13_fu_4323_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_6_14_cast_fu_4353_p1() {
    res_6_14_cast_fu_4353_p1 = esl_zext<2,1>(tmp_12_6_14_fu_4347_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_6_1_cast_fu_4017_p1() {
    res_6_1_cast_fu_4017_p1 = esl_zext<2,1>(tmp_12_6_1_fu_4011_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_6_2_cast_fu_4041_p1() {
    res_6_2_cast_fu_4041_p1 = esl_zext<2,1>(tmp_12_6_2_fu_4035_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_6_3_cast_fu_4065_p1() {
    res_6_3_cast_fu_4065_p1 = esl_zext<2,1>(tmp_12_6_3_fu_4059_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_6_4_cast_fu_4089_p1() {
    res_6_4_cast_fu_4089_p1 = esl_zext<2,1>(tmp_12_6_4_fu_4083_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_6_5_cast_fu_4113_p1() {
    res_6_5_cast_fu_4113_p1 = esl_zext<2,1>(tmp_12_6_5_fu_4107_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_6_6_cast_fu_4137_p1() {
    res_6_6_cast_fu_4137_p1 = esl_zext<2,1>(tmp_12_6_6_fu_4131_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_6_7_cast_fu_4161_p1() {
    res_6_7_cast_fu_4161_p1 = esl_zext<2,1>(tmp_12_6_7_fu_4155_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_6_8_cast_fu_4185_p1() {
    res_6_8_cast_fu_4185_p1 = esl_zext<2,1>(tmp_12_6_8_fu_4179_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_6_9_cast_fu_4209_p1() {
    res_6_9_cast_fu_4209_p1 = esl_zext<2,1>(tmp_12_6_9_fu_4203_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_6_cast_152_fu_4233_p1() {
    res_6_cast_152_fu_4233_p1 = esl_zext<2,1>(tmp_12_6_s_fu_4227_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_6_cast_fu_3993_p1() {
    res_6_cast_fu_3993_p1 = esl_zext<2,1>(tmp_12_6_fu_3987_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_6_s_fu_4305_p1() {
    res_6_s_fu_4305_p1 = esl_zext<32,1>(tmp_12_6_12_fu_4299_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_7_10_cast_fu_4795_p1() {
    res_7_10_cast_fu_4795_p1 = esl_zext<2,1>(tmp_12_7_10_fu_4789_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_7_11_cast_fu_4819_p1() {
    res_7_11_cast_fu_4819_p1 = esl_zext<2,1>(tmp_12_7_11_fu_4813_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_7_13_cast_fu_4867_p1() {
    res_7_13_cast_fu_4867_p1 = esl_zext<2,1>(tmp_12_7_13_fu_4861_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_7_14_cast_fu_4891_p1() {
    res_7_14_cast_fu_4891_p1 = esl_zext<2,1>(tmp_12_7_14_fu_4885_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_7_1_cast_fu_4555_p1() {
    res_7_1_cast_fu_4555_p1 = esl_zext<2,1>(tmp_12_7_1_fu_4549_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_7_2_cast_fu_4579_p1() {
    res_7_2_cast_fu_4579_p1 = esl_zext<2,1>(tmp_12_7_2_fu_4573_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_7_3_cast_fu_4603_p1() {
    res_7_3_cast_fu_4603_p1 = esl_zext<2,1>(tmp_12_7_3_fu_4597_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_7_4_cast_fu_4627_p1() {
    res_7_4_cast_fu_4627_p1 = esl_zext<2,1>(tmp_12_7_4_fu_4621_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_7_5_cast_fu_4651_p1() {
    res_7_5_cast_fu_4651_p1 = esl_zext<2,1>(tmp_12_7_5_fu_4645_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_7_6_cast_fu_4675_p1() {
    res_7_6_cast_fu_4675_p1 = esl_zext<2,1>(tmp_12_7_6_fu_4669_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_7_7_cast_fu_4699_p1() {
    res_7_7_cast_fu_4699_p1 = esl_zext<2,1>(tmp_12_7_7_fu_4693_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_7_8_cast_fu_4723_p1() {
    res_7_8_cast_fu_4723_p1 = esl_zext<2,1>(tmp_12_7_8_fu_4717_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_7_9_cast_fu_4747_p1() {
    res_7_9_cast_fu_4747_p1 = esl_zext<2,1>(tmp_12_7_9_fu_4741_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_7_cast_169_fu_4771_p1() {
    res_7_cast_169_fu_4771_p1 = esl_zext<2,1>(tmp_12_7_s_fu_4765_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_7_cast_fu_4531_p1() {
    res_7_cast_fu_4531_p1 = esl_zext<2,1>(tmp_12_7_fu_4525_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_7_s_fu_4843_p1() {
    res_7_s_fu_4843_p1 = esl_zext<32,1>(tmp_12_7_12_fu_4837_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_8_10_cast_fu_5333_p1() {
    res_8_10_cast_fu_5333_p1 = esl_zext<2,1>(tmp_12_8_10_fu_5327_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_8_11_cast_fu_5357_p1() {
    res_8_11_cast_fu_5357_p1 = esl_zext<2,1>(tmp_12_8_11_fu_5351_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_8_13_cast_fu_5405_p1() {
    res_8_13_cast_fu_5405_p1 = esl_zext<2,1>(tmp_12_8_13_fu_5399_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_8_14_cast_fu_5429_p1() {
    res_8_14_cast_fu_5429_p1 = esl_zext<2,1>(tmp_12_8_14_fu_5423_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_8_1_cast_fu_5093_p1() {
    res_8_1_cast_fu_5093_p1 = esl_zext<2,1>(tmp_12_8_1_fu_5087_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_8_2_cast_fu_5117_p1() {
    res_8_2_cast_fu_5117_p1 = esl_zext<2,1>(tmp_12_8_2_fu_5111_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_8_3_cast_fu_5141_p1() {
    res_8_3_cast_fu_5141_p1 = esl_zext<2,1>(tmp_12_8_3_fu_5135_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_8_4_cast_fu_5165_p1() {
    res_8_4_cast_fu_5165_p1 = esl_zext<2,1>(tmp_12_8_4_fu_5159_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_8_5_cast_fu_5189_p1() {
    res_8_5_cast_fu_5189_p1 = esl_zext<2,1>(tmp_12_8_5_fu_5183_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_8_6_cast_fu_5213_p1() {
    res_8_6_cast_fu_5213_p1 = esl_zext<2,1>(tmp_12_8_6_fu_5207_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_8_7_cast_fu_5237_p1() {
    res_8_7_cast_fu_5237_p1 = esl_zext<2,1>(tmp_12_8_7_fu_5231_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_8_8_cast_fu_5261_p1() {
    res_8_8_cast_fu_5261_p1 = esl_zext<2,1>(tmp_12_8_8_fu_5255_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_8_9_cast_fu_5285_p1() {
    res_8_9_cast_fu_5285_p1 = esl_zext<2,1>(tmp_12_8_9_fu_5279_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_8_cast_186_fu_5309_p1() {
    res_8_cast_186_fu_5309_p1 = esl_zext<2,1>(tmp_12_8_s_fu_5303_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_8_cast_fu_5069_p1() {
    res_8_cast_fu_5069_p1 = esl_zext<2,1>(tmp_12_8_fu_5063_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_8_s_fu_5381_p1() {
    res_8_s_fu_5381_p1 = esl_zext<32,1>(tmp_12_8_12_fu_5375_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_9_10_cast_fu_5871_p1() {
    res_9_10_cast_fu_5871_p1 = esl_zext<2,1>(tmp_12_9_10_fu_5865_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_9_11_cast_fu_5895_p1() {
    res_9_11_cast_fu_5895_p1 = esl_zext<2,1>(tmp_12_9_11_fu_5889_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_9_13_cast_fu_5943_p1() {
    res_9_13_cast_fu_5943_p1 = esl_zext<2,1>(tmp_12_9_13_fu_5937_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_9_14_cast_fu_5967_p1() {
    res_9_14_cast_fu_5967_p1 = esl_zext<2,1>(tmp_12_9_14_fu_5961_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_9_1_cast_fu_5631_p1() {
    res_9_1_cast_fu_5631_p1 = esl_zext<2,1>(tmp_12_9_1_fu_5625_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_9_2_cast_fu_5655_p1() {
    res_9_2_cast_fu_5655_p1 = esl_zext<2,1>(tmp_12_9_2_fu_5649_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_9_3_cast_fu_5679_p1() {
    res_9_3_cast_fu_5679_p1 = esl_zext<2,1>(tmp_12_9_3_fu_5673_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_9_4_cast_fu_5703_p1() {
    res_9_4_cast_fu_5703_p1 = esl_zext<2,1>(tmp_12_9_4_fu_5697_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_9_5_cast_fu_5727_p1() {
    res_9_5_cast_fu_5727_p1 = esl_zext<2,1>(tmp_12_9_5_fu_5721_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_9_6_cast_fu_5751_p1() {
    res_9_6_cast_fu_5751_p1 = esl_zext<2,1>(tmp_12_9_6_fu_5745_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_9_7_cast_fu_5775_p1() {
    res_9_7_cast_fu_5775_p1 = esl_zext<2,1>(tmp_12_9_7_fu_5769_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_9_8_cast_fu_5799_p1() {
    res_9_8_cast_fu_5799_p1 = esl_zext<2,1>(tmp_12_9_8_fu_5793_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_9_9_cast_fu_5823_p1() {
    res_9_9_cast_fu_5823_p1 = esl_zext<2,1>(tmp_12_9_9_fu_5817_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_9_cast_203_fu_5847_p1() {
    res_9_cast_203_fu_5847_p1 = esl_zext<2,1>(tmp_12_9_s_fu_5841_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_9_cast_fu_5607_p1() {
    res_9_cast_fu_5607_p1 = esl_zext<2,1>(tmp_12_9_fu_5601_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_9_s_fu_5919_p1() {
    res_9_s_fu_5919_p1 = esl_zext<32,1>(tmp_12_9_12_fu_5913_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_cast_74_fu_1841_p1() {
    res_cast_74_fu_1841_p1 = esl_zext<2,1>(tmp_12_2_fu_1835_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_res_cast_fu_645_p1() {
    res_cast_fu_645_p1 = esl_zext<2,1>(tmp_3_fu_639_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_sel_tmp6_fu_354_p2() {
    sel_tmp6_fu_354_p2 = (!tmp_174_fu_344_p1.read().is_01() || !ap_const_lv2_1.is_01())? sc_lv<1>(): sc_lv<1>(tmp_174_fu_344_p1.read() == ap_const_lv2_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_sel_tmp8_fu_360_p2() {
    sel_tmp8_fu_360_p2 = (!tmp_174_fu_344_p1.read().is_01() || !ap_const_lv2_0.is_01())? sc_lv<1>(): sc_lv<1>(tmp_174_fu_344_p1.read() == ap_const_lv2_0);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_sel_tmp_fu_348_p2() {
    sel_tmp_fu_348_p2 = (!tmp_174_fu_344_p1.read().is_01() || !ap_const_lv2_2.is_01())? sc_lv<1>(): sc_lv<1>(tmp_174_fu_344_p1.read() == ap_const_lv2_2);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_sf_1_fu_457_p2() {
    sf_1_fu_457_p2 = (!ap_const_lv32_1.is_01() || !sf_fu_218.read().is_01())? sc_lv<32>(): (sc_biguint<32>(ap_const_lv32_1) + sc_biguint<32>(sf_fu_218.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tile_fu_6111_p2() {
    tile_fu_6111_p2 = (!ap_const_lv32_1.is_01() || !tile_assign_fu_214.read().is_01())? sc_lv<32>(): (sc_biguint<32>(ap_const_lv32_1) + sc_biguint<32>(tile_assign_fu_214.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp100_fu_2511_p2() {
    tmp100_fu_2511_p2 = (p_Result_2_0_6_fu_817_p3.read() ^ p_Result_310_6_fu_2503_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp101_fu_2535_p2() {
    tmp101_fu_2535_p2 = (p_Result_2_0_7_fu_849_p3.read() ^ p_Result_310_7_fu_2527_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp102_fu_2559_p2() {
    tmp102_fu_2559_p2 = (p_Result_2_0_8_fu_881_p3.read() ^ p_Result_310_8_fu_2551_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp103_fu_2583_p2() {
    tmp103_fu_2583_p2 = (p_Result_2_0_9_fu_913_p3.read() ^ p_Result_310_9_fu_2575_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp104_fu_2607_p2() {
    tmp104_fu_2607_p2 = (p_Result_2_0_s_fu_945_p3.read() ^ p_Result_310_s_fu_2599_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp105_fu_2631_p2() {
    tmp105_fu_2631_p2 = (p_Result_2_0_10_fu_977_p3.read() ^ p_Result_310_10_fu_2623_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp106_cast_fu_1679_p1() {
    tmp106_cast_fu_1679_p1 = esl_zext<32,2>(tmp49_fu_1673_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp106_fu_2655_p2() {
    tmp106_fu_2655_p2 = (p_Result_2_0_11_fu_1009_p3.read() ^ p_Result_310_11_fu_2647_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp107_cast_fu_1715_p1() {
    tmp107_cast_fu_1715_p1 = esl_zext<32,3>(tmp53_fu_1709_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp107_fu_2679_p2() {
    tmp107_fu_2679_p2 = (p_Result_2_0_12_fu_1041_p3.read() ^ p_Result_310_12_fu_2671_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp108_cast_fu_1695_p1() {
    tmp108_cast_fu_1695_p1 = esl_zext<3,2>(tmp51_fu_1689_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp108_fu_2703_p2() {
    tmp108_fu_2703_p2 = (p_Result_2_0_13_fu_1073_p3.read() ^ p_Result_310_13_fu_2695_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp109_cast_fu_1705_p1() {
    tmp109_cast_fu_1705_p1 = esl_zext<3,2>(tmp52_fu_1699_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp109_fu_2727_p2() {
    tmp109_fu_2727_p2 = (p_Result_2_0_14_fu_1105_p3.read() ^ p_Result_310_14_fu_2719_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp10_fu_921_p2() {
    tmp10_fu_921_p2 = (p_Result_2_0_9_fu_913_p3.read() ^ p_Result_0_9_fu_905_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp110_cast_fu_1797_p1() {
    tmp110_cast_fu_1797_p1 = esl_zext<32,4>(tmp62_fu_1791_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp110_fu_2743_p2() {
    tmp110_fu_2743_p2 = (!p_accu_V_3_fu_571_p3.read().is_01() || !res_3_s_fu_2691_p1.read().is_01())? sc_lv<32>(): (sc_biguint<32>(p_accu_V_3_fu_571_p3.read()) + sc_biguint<32>(res_3_s_fu_2691_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp111_cast_fu_1751_p1() {
    tmp111_cast_fu_1751_p1 = esl_zext<4,3>(tmp57_fu_1745_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp111_fu_2749_p2() {
    tmp111_fu_2749_p2 = (!res_3_13_cast_fu_2715_p1.read().is_01() || !res_3_11_cast_fu_2667_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_3_13_cast_fu_2715_p1.read()) + sc_biguint<2>(res_3_11_cast_fu_2667_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp112_cast_fu_1731_p1() {
    tmp112_cast_fu_1731_p1 = esl_zext<3,2>(tmp55_fu_1725_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp112_fu_2759_p2() {
    tmp112_fu_2759_p2 = (!tmp196_cast_fu_2755_p1.read().is_01() || !tmp110_fu_2743_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(tmp196_cast_fu_2755_p1.read()) + sc_biguint<32>(tmp110_fu_2743_p2.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp113_cast_fu_1741_p1() {
    tmp113_cast_fu_1741_p1 = esl_zext<3,2>(tmp56_fu_1735_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp113_fu_2765_p2() {
    tmp113_fu_2765_p2 = (!res_3_10_cast_fu_2643_p1.read().is_01() || !res_3_8_cast_fu_2571_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_3_10_cast_fu_2643_p1.read()) + sc_biguint<2>(res_3_8_cast_fu_2571_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp114_cast_fu_1787_p1() {
    tmp114_cast_fu_1787_p1 = esl_zext<4,3>(tmp61_fu_1781_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp114_fu_2775_p2() {
    tmp114_fu_2775_p2 = (!res_3_7_cast_fu_2547_p1.read().is_01() || !res_3_cast_101_fu_2619_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_3_7_cast_fu_2547_p1.read()) + sc_biguint<2>(res_3_cast_101_fu_2619_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp115_cast_fu_1761_p1() {
    tmp115_cast_fu_1761_p1 = esl_zext<3,2>(tmp58_fu_1755_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp115_fu_2785_p2() {
    tmp115_fu_2785_p2 = (!tmp199_cast_fu_2781_p1.read().is_01() || !tmp198_cast_fu_2771_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp199_cast_fu_2781_p1.read()) + sc_biguint<3>(tmp198_cast_fu_2771_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp116_cast_fu_1777_p1() {
    tmp116_cast_fu_1777_p1 = esl_zext<3,2>(tmp60_fu_1771_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp116_fu_2795_p2() {
    tmp116_fu_2795_p2 = (!tmp197_cast_fu_2791_p1.read().is_01() || !tmp112_fu_2759_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(tmp197_cast_fu_2791_p1.read()) + sc_biguint<32>(tmp112_fu_2759_p2.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp117_fu_2801_p2() {
    tmp117_fu_2801_p2 = (!res_3_9_cast_fu_2595_p1.read().is_01() || !res_3_cast_fu_2379_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_3_9_cast_fu_2595_p1.read()) + sc_biguint<2>(res_3_cast_fu_2379_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp118_fu_2811_p2() {
    tmp118_fu_2811_p2 = (!res_3_2_cast_fu_2427_p1.read().is_01() || !res_3_1_cast_fu_2403_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_3_2_cast_fu_2427_p1.read()) + sc_biguint<2>(res_3_1_cast_fu_2403_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp119_fu_2821_p2() {
    tmp119_fu_2821_p2 = (!tmp203_cast_fu_2817_p1.read().is_01() || !tmp202_cast_fu_2807_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp203_cast_fu_2817_p1.read()) + sc_biguint<3>(tmp202_cast_fu_2807_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp11_fu_953_p2() {
    tmp11_fu_953_p2 = (p_Result_2_0_s_fu_945_p3.read() ^ p_Result_0_s_fu_937_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp120_fu_2831_p2() {
    tmp120_fu_2831_p2 = (!res_3_4_cast_fu_2475_p1.read().is_01() || !res_3_3_cast_fu_2451_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_3_4_cast_fu_2475_p1.read()) + sc_biguint<2>(res_3_3_cast_fu_2451_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp121_fu_2841_p2() {
    tmp121_fu_2841_p2 = (!res_3_5_cast_fu_2499_p1.read().is_01() || !res_3_14_cast_fu_2739_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_3_5_cast_fu_2499_p1.read()) + sc_biguint<2>(res_3_14_cast_fu_2739_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp122_fu_2847_p2() {
    tmp122_fu_2847_p2 = (!tmp121_fu_2841_p2.read().is_01() || !res_3_6_cast_fu_2523_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(tmp121_fu_2841_p2.read()) + sc_biguint<2>(res_3_6_cast_fu_2523_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp123_fu_2857_p2() {
    tmp123_fu_2857_p2 = (!tmp206_cast_fu_2853_p1.read().is_01() || !tmp205_cast_fu_2837_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp206_cast_fu_2853_p1.read()) + sc_biguint<3>(tmp205_cast_fu_2837_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp124_fu_2867_p2() {
    tmp124_fu_2867_p2 = (!tmp204_cast_fu_2863_p1.read().is_01() || !tmp201_cast_fu_2827_p1.read().is_01())? sc_lv<4>(): (sc_biguint<4>(tmp204_cast_fu_2863_p1.read()) + sc_biguint<4>(tmp201_cast_fu_2827_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp125_fu_2905_p2() {
    tmp125_fu_2905_p2 = (p_Result_2_fu_625_p3.read() ^ p_Result_4_fu_2897_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp126_fu_2929_p2() {
    tmp126_fu_2929_p2 = (p_Result_2_0_1_fu_657_p3.read() ^ p_Result_4_1_fu_2921_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp127_fu_2953_p2() {
    tmp127_fu_2953_p2 = (p_Result_2_0_2_fu_689_p3.read() ^ p_Result_4_2_fu_2945_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp128_fu_2977_p2() {
    tmp128_fu_2977_p2 = (p_Result_2_0_3_fu_721_p3.read() ^ p_Result_4_3_fu_2969_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp129_fu_3001_p2() {
    tmp129_fu_3001_p2 = (p_Result_2_0_4_fu_753_p3.read() ^ p_Result_4_4_fu_2993_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp12_fu_985_p2() {
    tmp12_fu_985_p2 = (p_Result_2_0_10_fu_977_p3.read() ^ p_Result_0_10_fu_969_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp130_fu_3025_p2() {
    tmp130_fu_3025_p2 = (p_Result_2_0_5_fu_785_p3.read() ^ p_Result_4_5_fu_3017_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp131_fu_3049_p2() {
    tmp131_fu_3049_p2 = (p_Result_2_0_6_fu_817_p3.read() ^ p_Result_4_6_fu_3041_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp132_fu_3073_p2() {
    tmp132_fu_3073_p2 = (p_Result_2_0_7_fu_849_p3.read() ^ p_Result_4_7_fu_3065_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp133_fu_3097_p2() {
    tmp133_fu_3097_p2 = (p_Result_2_0_8_fu_881_p3.read() ^ p_Result_4_8_fu_3089_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp134_fu_3121_p2() {
    tmp134_fu_3121_p2 = (p_Result_2_0_9_fu_913_p3.read() ^ p_Result_4_9_fu_3113_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp135_fu_3145_p2() {
    tmp135_fu_3145_p2 = (p_Result_2_0_s_fu_945_p3.read() ^ p_Result_4_s_fu_3137_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp136_fu_3169_p2() {
    tmp136_fu_3169_p2 = (p_Result_2_0_10_fu_977_p3.read() ^ p_Result_4_10_fu_3161_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp137_fu_3193_p2() {
    tmp137_fu_3193_p2 = (p_Result_2_0_11_fu_1009_p3.read() ^ p_Result_4_11_fu_3185_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp138_fu_3217_p2() {
    tmp138_fu_3217_p2 = (p_Result_2_0_12_fu_1041_p3.read() ^ p_Result_4_12_fu_3209_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp139_fu_3241_p2() {
    tmp139_fu_3241_p2 = (p_Result_2_0_13_fu_1073_p3.read() ^ p_Result_4_13_fu_3233_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp13_fu_1017_p2() {
    tmp13_fu_1017_p2 = (p_Result_2_0_11_fu_1009_p3.read() ^ p_Result_0_11_fu_1001_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp140_fu_3265_p2() {
    tmp140_fu_3265_p2 = (p_Result_2_0_14_fu_1105_p3.read() ^ p_Result_4_14_fu_3257_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp141_fu_3281_p2() {
    tmp141_fu_3281_p2 = (!p_accu_V_4_fu_564_p3.read().is_01() || !res_4_s_fu_3229_p1.read().is_01())? sc_lv<32>(): (sc_biguint<32>(p_accu_V_4_fu_564_p3.read()) + sc_biguint<32>(res_4_s_fu_3229_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp142_fu_3287_p2() {
    tmp142_fu_3287_p2 = (!res_4_13_cast_fu_3253_p1.read().is_01() || !res_4_11_cast_fu_3205_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_4_13_cast_fu_3253_p1.read()) + sc_biguint<2>(res_4_11_cast_fu_3205_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp143_fu_3297_p2() {
    tmp143_fu_3297_p2 = (!tmp241_cast_fu_3293_p1.read().is_01() || !tmp141_fu_3281_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(tmp241_cast_fu_3293_p1.read()) + sc_biguint<32>(tmp141_fu_3281_p2.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp144_fu_3303_p2() {
    tmp144_fu_3303_p2 = (!res_4_10_cast_fu_3181_p1.read().is_01() || !res_4_8_cast_fu_3109_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_4_10_cast_fu_3181_p1.read()) + sc_biguint<2>(res_4_8_cast_fu_3109_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp145_fu_3313_p2() {
    tmp145_fu_3313_p2 = (!res_4_7_cast_fu_3085_p1.read().is_01() || !res_4_cast_118_fu_3157_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_4_7_cast_fu_3085_p1.read()) + sc_biguint<2>(res_4_cast_118_fu_3157_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp146_fu_3323_p2() {
    tmp146_fu_3323_p2 = (!tmp244_cast_fu_3319_p1.read().is_01() || !tmp243_cast_fu_3309_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp244_cast_fu_3319_p1.read()) + sc_biguint<3>(tmp243_cast_fu_3309_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp147_fu_3333_p2() {
    tmp147_fu_3333_p2 = (!tmp242_cast_fu_3329_p1.read().is_01() || !tmp143_fu_3297_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(tmp242_cast_fu_3329_p1.read()) + sc_biguint<32>(tmp143_fu_3297_p2.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp148_fu_3339_p2() {
    tmp148_fu_3339_p2 = (!res_4_9_cast_fu_3133_p1.read().is_01() || !res_4_cast_fu_2917_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_4_9_cast_fu_3133_p1.read()) + sc_biguint<2>(res_4_cast_fu_2917_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp149_fu_3349_p2() {
    tmp149_fu_3349_p2 = (!res_4_2_cast_fu_2965_p1.read().is_01() || !res_4_1_cast_fu_2941_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_4_2_cast_fu_2965_p1.read()) + sc_biguint<2>(res_4_1_cast_fu_2941_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp14_fu_1049_p2() {
    tmp14_fu_1049_p2 = (p_Result_2_0_12_fu_1041_p3.read() ^ p_Result_0_12_fu_1033_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp150_fu_3359_p2() {
    tmp150_fu_3359_p2 = (!tmp248_cast_fu_3355_p1.read().is_01() || !tmp247_cast_fu_3345_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp248_cast_fu_3355_p1.read()) + sc_biguint<3>(tmp247_cast_fu_3345_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp151_cast_fu_2217_p1() {
    tmp151_cast_fu_2217_p1 = esl_zext<32,2>(tmp80_fu_2211_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp151_fu_3369_p2() {
    tmp151_fu_3369_p2 = (!res_4_4_cast_fu_3013_p1.read().is_01() || !res_4_3_cast_fu_2989_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_4_4_cast_fu_3013_p1.read()) + sc_biguint<2>(res_4_3_cast_fu_2989_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp152_cast_fu_2253_p1() {
    tmp152_cast_fu_2253_p1 = esl_zext<32,3>(tmp84_fu_2247_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp152_fu_3379_p2() {
    tmp152_fu_3379_p2 = (!res_4_5_cast_fu_3037_p1.read().is_01() || !res_4_14_cast_fu_3277_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_4_5_cast_fu_3037_p1.read()) + sc_biguint<2>(res_4_14_cast_fu_3277_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp153_cast_fu_2233_p1() {
    tmp153_cast_fu_2233_p1 = esl_zext<3,2>(tmp82_fu_2227_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp153_fu_3385_p2() {
    tmp153_fu_3385_p2 = (!tmp152_fu_3379_p2.read().is_01() || !res_4_6_cast_fu_3061_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(tmp152_fu_3379_p2.read()) + sc_biguint<2>(res_4_6_cast_fu_3061_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp154_cast_fu_2243_p1() {
    tmp154_cast_fu_2243_p1 = esl_zext<3,2>(tmp83_fu_2237_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp154_fu_3395_p2() {
    tmp154_fu_3395_p2 = (!tmp251_cast_fu_3391_p1.read().is_01() || !tmp250_cast_fu_3375_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp251_cast_fu_3391_p1.read()) + sc_biguint<3>(tmp250_cast_fu_3375_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp155_cast_fu_2335_p1() {
    tmp155_cast_fu_2335_p1 = esl_zext<32,4>(tmp93_fu_2329_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp155_fu_3405_p2() {
    tmp155_fu_3405_p2 = (!tmp249_cast_fu_3401_p1.read().is_01() || !tmp246_cast_fu_3365_p1.read().is_01())? sc_lv<4>(): (sc_biguint<4>(tmp249_cast_fu_3401_p1.read()) + sc_biguint<4>(tmp246_cast_fu_3365_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp156_cast_fu_2289_p1() {
    tmp156_cast_fu_2289_p1 = esl_zext<4,3>(tmp88_fu_2283_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp156_fu_3443_p2() {
    tmp156_fu_3443_p2 = (p_Result_2_fu_625_p3.read() ^ p_Result_5_fu_3435_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp157_cast_fu_2269_p1() {
    tmp157_cast_fu_2269_p1 = esl_zext<3,2>(tmp86_fu_2263_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp157_fu_3467_p2() {
    tmp157_fu_3467_p2 = (p_Result_2_0_1_fu_657_p3.read() ^ p_Result_5_1_fu_3459_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp158_cast_fu_2279_p1() {
    tmp158_cast_fu_2279_p1 = esl_zext<3,2>(tmp87_fu_2273_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp158_fu_3491_p2() {
    tmp158_fu_3491_p2 = (p_Result_2_0_2_fu_689_p3.read() ^ p_Result_5_2_fu_3483_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp159_cast_fu_2325_p1() {
    tmp159_cast_fu_2325_p1 = esl_zext<4,3>(tmp92_fu_2319_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp159_fu_3515_p2() {
    tmp159_fu_3515_p2 = (p_Result_2_0_3_fu_721_p3.read() ^ p_Result_5_3_fu_3507_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp15_fu_1081_p2() {
    tmp15_fu_1081_p2 = (p_Result_2_0_13_fu_1073_p3.read() ^ p_Result_0_13_fu_1065_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp160_cast_fu_2299_p1() {
    tmp160_cast_fu_2299_p1 = esl_zext<3,2>(tmp89_fu_2293_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp160_fu_3539_p2() {
    tmp160_fu_3539_p2 = (p_Result_2_0_4_fu_753_p3.read() ^ p_Result_5_4_fu_3531_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp161_cast_fu_2315_p1() {
    tmp161_cast_fu_2315_p1 = esl_zext<3,2>(tmp91_fu_2309_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp161_fu_3563_p2() {
    tmp161_fu_3563_p2 = (p_Result_2_0_5_fu_785_p3.read() ^ p_Result_5_5_fu_3555_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp162_fu_3587_p2() {
    tmp162_fu_3587_p2 = (p_Result_2_0_6_fu_817_p3.read() ^ p_Result_5_6_fu_3579_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp163_fu_3611_p2() {
    tmp163_fu_3611_p2 = (p_Result_2_0_7_fu_849_p3.read() ^ p_Result_5_7_fu_3603_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp164_fu_3635_p2() {
    tmp164_fu_3635_p2 = (p_Result_2_0_8_fu_881_p3.read() ^ p_Result_5_8_fu_3627_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp165_fu_3659_p2() {
    tmp165_fu_3659_p2 = (p_Result_2_0_9_fu_913_p3.read() ^ p_Result_5_9_fu_3651_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp166_fu_3683_p2() {
    tmp166_fu_3683_p2 = (p_Result_2_0_s_fu_945_p3.read() ^ p_Result_5_s_fu_3675_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp167_fu_3707_p2() {
    tmp167_fu_3707_p2 = (p_Result_2_0_10_fu_977_p3.read() ^ p_Result_5_10_fu_3699_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp168_fu_3731_p2() {
    tmp168_fu_3731_p2 = (p_Result_2_0_11_fu_1009_p3.read() ^ p_Result_5_11_fu_3723_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp169_fu_3755_p2() {
    tmp169_fu_3755_p2 = (p_Result_2_0_12_fu_1041_p3.read() ^ p_Result_5_12_fu_3747_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp16_fu_1113_p2() {
    tmp16_fu_1113_p2 = (p_Result_2_0_14_fu_1105_p3.read() ^ p_Result_0_14_fu_1097_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp170_fu_3779_p2() {
    tmp170_fu_3779_p2 = (p_Result_2_0_13_fu_1073_p3.read() ^ p_Result_5_13_fu_3771_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp171_fu_3803_p2() {
    tmp171_fu_3803_p2 = (p_Result_2_0_14_fu_1105_p3.read() ^ p_Result_5_14_fu_3795_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp172_fu_3819_p2() {
    tmp172_fu_3819_p2 = (!p_accu_V_5_fu_557_p3.read().is_01() || !res_5_s_fu_3767_p1.read().is_01())? sc_lv<32>(): (sc_biguint<32>(p_accu_V_5_fu_557_p3.read()) + sc_biguint<32>(res_5_s_fu_3767_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp173_fu_3825_p2() {
    tmp173_fu_3825_p2 = (!res_5_13_cast_fu_3791_p1.read().is_01() || !res_5_11_cast_fu_3743_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_5_13_cast_fu_3791_p1.read()) + sc_biguint<2>(res_5_11_cast_fu_3743_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp174_fu_3835_p2() {
    tmp174_fu_3835_p2 = (!tmp286_cast_fu_3831_p1.read().is_01() || !tmp172_fu_3819_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(tmp286_cast_fu_3831_p1.read()) + sc_biguint<32>(tmp172_fu_3819_p2.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp175_fu_3841_p2() {
    tmp175_fu_3841_p2 = (!res_5_10_cast_fu_3719_p1.read().is_01() || !res_5_8_cast_fu_3647_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_5_10_cast_fu_3719_p1.read()) + sc_biguint<2>(res_5_8_cast_fu_3647_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp176_fu_3851_p2() {
    tmp176_fu_3851_p2 = (!res_5_7_cast_fu_3623_p1.read().is_01() || !res_5_cast_135_fu_3695_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_5_7_cast_fu_3623_p1.read()) + sc_biguint<2>(res_5_cast_135_fu_3695_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp177_fu_3861_p2() {
    tmp177_fu_3861_p2 = (!tmp289_cast_fu_3857_p1.read().is_01() || !tmp288_cast_fu_3847_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp289_cast_fu_3857_p1.read()) + sc_biguint<3>(tmp288_cast_fu_3847_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp178_fu_3871_p2() {
    tmp178_fu_3871_p2 = (!tmp287_cast_fu_3867_p1.read().is_01() || !tmp174_fu_3835_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(tmp287_cast_fu_3867_p1.read()) + sc_biguint<32>(tmp174_fu_3835_p2.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp179_fu_3877_p2() {
    tmp179_fu_3877_p2 = (!res_5_9_cast_fu_3671_p1.read().is_01() || !res_5_cast_fu_3455_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_5_9_cast_fu_3671_p1.read()) + sc_biguint<2>(res_5_cast_fu_3455_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp17_fu_1129_p2() {
    tmp17_fu_1129_p2 = (!p_accu_V_fu_592_p3.read().is_01() || !res_0_s_fu_1061_p1.read().is_01())? sc_lv<32>(): (sc_biguint<32>(p_accu_V_fu_592_p3.read()) + sc_biguint<32>(res_0_s_fu_1061_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp180_fu_3887_p2() {
    tmp180_fu_3887_p2 = (!res_5_2_cast_fu_3503_p1.read().is_01() || !res_5_1_cast_fu_3479_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_5_2_cast_fu_3503_p1.read()) + sc_biguint<2>(res_5_1_cast_fu_3479_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp181_fu_3897_p2() {
    tmp181_fu_3897_p2 = (!tmp293_cast_fu_3893_p1.read().is_01() || !tmp292_cast_fu_3883_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp293_cast_fu_3893_p1.read()) + sc_biguint<3>(tmp292_cast_fu_3883_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp182_fu_3907_p2() {
    tmp182_fu_3907_p2 = (!res_5_4_cast_fu_3551_p1.read().is_01() || !res_5_3_cast_fu_3527_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_5_4_cast_fu_3551_p1.read()) + sc_biguint<2>(res_5_3_cast_fu_3527_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp183_fu_3917_p2() {
    tmp183_fu_3917_p2 = (!res_5_5_cast_fu_3575_p1.read().is_01() || !res_5_14_cast_fu_3815_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_5_5_cast_fu_3575_p1.read()) + sc_biguint<2>(res_5_14_cast_fu_3815_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp184_fu_3923_p2() {
    tmp184_fu_3923_p2 = (!tmp183_fu_3917_p2.read().is_01() || !res_5_6_cast_fu_3599_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(tmp183_fu_3917_p2.read()) + sc_biguint<2>(res_5_6_cast_fu_3599_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp185_fu_3933_p2() {
    tmp185_fu_3933_p2 = (!tmp296_cast_fu_3929_p1.read().is_01() || !tmp295_cast_fu_3913_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp296_cast_fu_3929_p1.read()) + sc_biguint<3>(tmp295_cast_fu_3913_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp186_fu_3943_p2() {
    tmp186_fu_3943_p2 = (!tmp294_cast_fu_3939_p1.read().is_01() || !tmp291_cast_fu_3903_p1.read().is_01())? sc_lv<4>(): (sc_biguint<4>(tmp294_cast_fu_3939_p1.read()) + sc_biguint<4>(tmp291_cast_fu_3903_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp187_fu_3981_p2() {
    tmp187_fu_3981_p2 = (p_Result_2_fu_625_p3.read() ^ p_Result_6_fu_3973_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp188_fu_4005_p2() {
    tmp188_fu_4005_p2 = (p_Result_2_0_1_fu_657_p3.read() ^ p_Result_6_1_fu_3997_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp189_fu_4029_p2() {
    tmp189_fu_4029_p2 = (p_Result_2_0_2_fu_689_p3.read() ^ p_Result_6_2_fu_4021_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp18_fu_1135_p2() {
    tmp18_fu_1135_p2 = (!res_0_13_cast_fu_1093_p1.read().is_01() || !res_0_11_cast_fu_1029_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_0_13_cast_fu_1093_p1.read()) + sc_biguint<2>(res_0_11_cast_fu_1029_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp190_fu_4053_p2() {
    tmp190_fu_4053_p2 = (p_Result_2_0_3_fu_721_p3.read() ^ p_Result_6_3_fu_4045_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp191_fu_4077_p2() {
    tmp191_fu_4077_p2 = (p_Result_2_0_4_fu_753_p3.read() ^ p_Result_6_4_fu_4069_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp192_fu_4101_p2() {
    tmp192_fu_4101_p2 = (p_Result_2_0_5_fu_785_p3.read() ^ p_Result_6_5_fu_4093_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp193_fu_4125_p2() {
    tmp193_fu_4125_p2 = (p_Result_2_0_6_fu_817_p3.read() ^ p_Result_6_6_fu_4117_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp194_fu_4149_p2() {
    tmp194_fu_4149_p2 = (p_Result_2_0_7_fu_849_p3.read() ^ p_Result_6_7_fu_4141_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp195_fu_4173_p2() {
    tmp195_fu_4173_p2 = (p_Result_2_0_8_fu_881_p3.read() ^ p_Result_6_8_fu_4165_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp196_cast_fu_2755_p1() {
    tmp196_cast_fu_2755_p1 = esl_zext<32,2>(tmp111_fu_2749_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp196_fu_4197_p2() {
    tmp196_fu_4197_p2 = (p_Result_2_0_9_fu_913_p3.read() ^ p_Result_6_9_fu_4189_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp197_cast_fu_2791_p1() {
    tmp197_cast_fu_2791_p1 = esl_zext<32,3>(tmp115_fu_2785_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp197_fu_4221_p2() {
    tmp197_fu_4221_p2 = (p_Result_2_0_s_fu_945_p3.read() ^ p_Result_6_s_fu_4213_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp198_cast_fu_2771_p1() {
    tmp198_cast_fu_2771_p1 = esl_zext<3,2>(tmp113_fu_2765_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp198_fu_4245_p2() {
    tmp198_fu_4245_p2 = (p_Result_2_0_10_fu_977_p3.read() ^ p_Result_6_10_fu_4237_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp199_cast_fu_2781_p1() {
    tmp199_cast_fu_2781_p1 = esl_zext<3,2>(tmp114_fu_2775_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp199_fu_4269_p2() {
    tmp199_fu_4269_p2 = (p_Result_2_0_11_fu_1009_p3.read() ^ p_Result_6_11_fu_4261_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp19_fu_1145_p2() {
    tmp19_fu_1145_p2 = (!tmp61_cast_fu_1141_p1.read().is_01() || !tmp17_fu_1129_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(tmp61_cast_fu_1141_p1.read()) + sc_biguint<32>(tmp17_fu_1129_p2.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp1_fu_633_p2() {
    tmp1_fu_633_p2 = (p_Result_2_fu_625_p3.read() ^ p_Result_s_fu_617_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp200_cast_fu_2873_p1() {
    tmp200_cast_fu_2873_p1 = esl_zext<32,4>(tmp124_fu_2867_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp200_fu_4293_p2() {
    tmp200_fu_4293_p2 = (p_Result_2_0_12_fu_1041_p3.read() ^ p_Result_6_12_fu_4285_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp201_cast_fu_2827_p1() {
    tmp201_cast_fu_2827_p1 = esl_zext<4,3>(tmp119_fu_2821_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp201_fu_4317_p2() {
    tmp201_fu_4317_p2 = (p_Result_2_0_13_fu_1073_p3.read() ^ p_Result_6_13_fu_4309_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp202_cast_fu_2807_p1() {
    tmp202_cast_fu_2807_p1 = esl_zext<3,2>(tmp117_fu_2801_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp202_fu_4341_p2() {
    tmp202_fu_4341_p2 = (p_Result_2_0_14_fu_1105_p3.read() ^ p_Result_6_14_fu_4333_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp203_cast_fu_2817_p1() {
    tmp203_cast_fu_2817_p1 = esl_zext<3,2>(tmp118_fu_2811_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp203_fu_4357_p2() {
    tmp203_fu_4357_p2 = (!p_accu_V_6_fu_550_p3.read().is_01() || !res_6_s_fu_4305_p1.read().is_01())? sc_lv<32>(): (sc_biguint<32>(p_accu_V_6_fu_550_p3.read()) + sc_biguint<32>(res_6_s_fu_4305_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp204_cast_fu_2863_p1() {
    tmp204_cast_fu_2863_p1 = esl_zext<4,3>(tmp123_fu_2857_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp204_fu_4363_p2() {
    tmp204_fu_4363_p2 = (!res_6_13_cast_fu_4329_p1.read().is_01() || !res_6_11_cast_fu_4281_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_6_13_cast_fu_4329_p1.read()) + sc_biguint<2>(res_6_11_cast_fu_4281_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp205_cast_fu_2837_p1() {
    tmp205_cast_fu_2837_p1 = esl_zext<3,2>(tmp120_fu_2831_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp205_fu_4373_p2() {
    tmp205_fu_4373_p2 = (!tmp331_cast_fu_4369_p1.read().is_01() || !tmp203_fu_4357_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(tmp331_cast_fu_4369_p1.read()) + sc_biguint<32>(tmp203_fu_4357_p2.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp206_cast_fu_2853_p1() {
    tmp206_cast_fu_2853_p1 = esl_zext<3,2>(tmp122_fu_2847_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp206_fu_4379_p2() {
    tmp206_fu_4379_p2 = (!res_6_10_cast_fu_4257_p1.read().is_01() || !res_6_8_cast_fu_4185_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_6_10_cast_fu_4257_p1.read()) + sc_biguint<2>(res_6_8_cast_fu_4185_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp207_fu_4389_p2() {
    tmp207_fu_4389_p2 = (!res_6_7_cast_fu_4161_p1.read().is_01() || !res_6_cast_152_fu_4233_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_6_7_cast_fu_4161_p1.read()) + sc_biguint<2>(res_6_cast_152_fu_4233_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp208_fu_4399_p2() {
    tmp208_fu_4399_p2 = (!tmp334_cast_fu_4395_p1.read().is_01() || !tmp333_cast_fu_4385_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp334_cast_fu_4395_p1.read()) + sc_biguint<3>(tmp333_cast_fu_4385_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp209_fu_4409_p2() {
    tmp209_fu_4409_p2 = (!tmp332_cast_fu_4405_p1.read().is_01() || !tmp205_fu_4373_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(tmp332_cast_fu_4405_p1.read()) + sc_biguint<32>(tmp205_fu_4373_p2.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp20_fu_1151_p2() {
    tmp20_fu_1151_p2 = (!res_0_10_cast_fu_997_p1.read().is_01() || !res_0_8_cast_fu_901_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_0_10_cast_fu_997_p1.read()) + sc_biguint<2>(res_0_8_cast_fu_901_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp210_fu_4415_p2() {
    tmp210_fu_4415_p2 = (!res_6_9_cast_fu_4209_p1.read().is_01() || !res_6_cast_fu_3993_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_6_9_cast_fu_4209_p1.read()) + sc_biguint<2>(res_6_cast_fu_3993_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp211_fu_4425_p2() {
    tmp211_fu_4425_p2 = (!res_6_2_cast_fu_4041_p1.read().is_01() || !res_6_1_cast_fu_4017_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_6_2_cast_fu_4041_p1.read()) + sc_biguint<2>(res_6_1_cast_fu_4017_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp212_fu_4435_p2() {
    tmp212_fu_4435_p2 = (!tmp338_cast_fu_4431_p1.read().is_01() || !tmp337_cast_fu_4421_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp338_cast_fu_4431_p1.read()) + sc_biguint<3>(tmp337_cast_fu_4421_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp213_fu_4445_p2() {
    tmp213_fu_4445_p2 = (!res_6_4_cast_fu_4089_p1.read().is_01() || !res_6_3_cast_fu_4065_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_6_4_cast_fu_4089_p1.read()) + sc_biguint<2>(res_6_3_cast_fu_4065_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp214_fu_4455_p2() {
    tmp214_fu_4455_p2 = (!res_6_5_cast_fu_4113_p1.read().is_01() || !res_6_14_cast_fu_4353_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_6_5_cast_fu_4113_p1.read()) + sc_biguint<2>(res_6_14_cast_fu_4353_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp215_fu_4461_p2() {
    tmp215_fu_4461_p2 = (!tmp214_fu_4455_p2.read().is_01() || !res_6_6_cast_fu_4137_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(tmp214_fu_4455_p2.read()) + sc_biguint<2>(res_6_6_cast_fu_4137_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp216_fu_4471_p2() {
    tmp216_fu_4471_p2 = (!tmp341_cast_fu_4467_p1.read().is_01() || !tmp340_cast_fu_4451_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp341_cast_fu_4467_p1.read()) + sc_biguint<3>(tmp340_cast_fu_4451_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp217_fu_4481_p2() {
    tmp217_fu_4481_p2 = (!tmp339_cast_fu_4477_p1.read().is_01() || !tmp336_cast_fu_4441_p1.read().is_01())? sc_lv<4>(): (sc_biguint<4>(tmp339_cast_fu_4477_p1.read()) + sc_biguint<4>(tmp336_cast_fu_4441_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp218_fu_4519_p2() {
    tmp218_fu_4519_p2 = (p_Result_2_fu_625_p3.read() ^ p_Result_7_fu_4511_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp219_fu_4543_p2() {
    tmp219_fu_4543_p2 = (p_Result_2_0_1_fu_657_p3.read() ^ p_Result_7_1_fu_4535_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp21_fu_1161_p2() {
    tmp21_fu_1161_p2 = (!res_0_7_cast_fu_869_p1.read().is_01() || !res_0_cast_fu_965_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_0_7_cast_fu_869_p1.read()) + sc_biguint<2>(res_0_cast_fu_965_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp220_fu_4567_p2() {
    tmp220_fu_4567_p2 = (p_Result_2_0_2_fu_689_p3.read() ^ p_Result_7_2_fu_4559_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp221_fu_4591_p2() {
    tmp221_fu_4591_p2 = (p_Result_2_0_3_fu_721_p3.read() ^ p_Result_7_3_fu_4583_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp222_fu_4615_p2() {
    tmp222_fu_4615_p2 = (p_Result_2_0_4_fu_753_p3.read() ^ p_Result_7_4_fu_4607_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp223_fu_4639_p2() {
    tmp223_fu_4639_p2 = (p_Result_2_0_5_fu_785_p3.read() ^ p_Result_7_5_fu_4631_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp224_fu_4663_p2() {
    tmp224_fu_4663_p2 = (p_Result_2_0_6_fu_817_p3.read() ^ p_Result_7_6_fu_4655_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp225_fu_4687_p2() {
    tmp225_fu_4687_p2 = (p_Result_2_0_7_fu_849_p3.read() ^ p_Result_7_7_fu_4679_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp226_fu_4711_p2() {
    tmp226_fu_4711_p2 = (p_Result_2_0_8_fu_881_p3.read() ^ p_Result_7_8_fu_4703_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp227_fu_4735_p2() {
    tmp227_fu_4735_p2 = (p_Result_2_0_9_fu_913_p3.read() ^ p_Result_7_9_fu_4727_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp228_fu_4759_p2() {
    tmp228_fu_4759_p2 = (p_Result_2_0_s_fu_945_p3.read() ^ p_Result_7_s_fu_4751_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp229_fu_4783_p2() {
    tmp229_fu_4783_p2 = (p_Result_2_0_10_fu_977_p3.read() ^ p_Result_7_10_fu_4775_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp22_fu_1171_p2() {
    tmp22_fu_1171_p2 = (!tmp64_cast_fu_1167_p1.read().is_01() || !tmp63_cast_fu_1157_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp64_cast_fu_1167_p1.read()) + sc_biguint<3>(tmp63_cast_fu_1157_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp230_fu_4807_p2() {
    tmp230_fu_4807_p2 = (p_Result_2_0_11_fu_1009_p3.read() ^ p_Result_7_11_fu_4799_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp231_fu_4831_p2() {
    tmp231_fu_4831_p2 = (p_Result_2_0_12_fu_1041_p3.read() ^ p_Result_7_12_fu_4823_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp232_fu_4855_p2() {
    tmp232_fu_4855_p2 = (p_Result_2_0_13_fu_1073_p3.read() ^ p_Result_7_13_fu_4847_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp233_fu_4879_p2() {
    tmp233_fu_4879_p2 = (p_Result_2_0_14_fu_1105_p3.read() ^ p_Result_7_14_fu_4871_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp234_fu_4895_p2() {
    tmp234_fu_4895_p2 = (!p_accu_V_7_fu_543_p3.read().is_01() || !res_7_s_fu_4843_p1.read().is_01())? sc_lv<32>(): (sc_biguint<32>(p_accu_V_7_fu_543_p3.read()) + sc_biguint<32>(res_7_s_fu_4843_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp235_fu_4901_p2() {
    tmp235_fu_4901_p2 = (!res_7_13_cast_fu_4867_p1.read().is_01() || !res_7_11_cast_fu_4819_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_7_13_cast_fu_4867_p1.read()) + sc_biguint<2>(res_7_11_cast_fu_4819_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp236_fu_4911_p2() {
    tmp236_fu_4911_p2 = (!tmp376_cast_fu_4907_p1.read().is_01() || !tmp234_fu_4895_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(tmp376_cast_fu_4907_p1.read()) + sc_biguint<32>(tmp234_fu_4895_p2.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp237_fu_4917_p2() {
    tmp237_fu_4917_p2 = (!res_7_10_cast_fu_4795_p1.read().is_01() || !res_7_8_cast_fu_4723_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_7_10_cast_fu_4795_p1.read()) + sc_biguint<2>(res_7_8_cast_fu_4723_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp238_fu_4927_p2() {
    tmp238_fu_4927_p2 = (!res_7_7_cast_fu_4699_p1.read().is_01() || !res_7_cast_169_fu_4771_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_7_7_cast_fu_4699_p1.read()) + sc_biguint<2>(res_7_cast_169_fu_4771_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp239_fu_4937_p2() {
    tmp239_fu_4937_p2 = (!tmp379_cast_fu_4933_p1.read().is_01() || !tmp378_cast_fu_4923_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp379_cast_fu_4933_p1.read()) + sc_biguint<3>(tmp378_cast_fu_4923_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp23_fu_1181_p2() {
    tmp23_fu_1181_p2 = (!tmp62_cast_fu_1177_p1.read().is_01() || !tmp19_fu_1145_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(tmp62_cast_fu_1177_p1.read()) + sc_biguint<32>(tmp19_fu_1145_p2.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp240_fu_4947_p2() {
    tmp240_fu_4947_p2 = (!tmp377_cast_fu_4943_p1.read().is_01() || !tmp236_fu_4911_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(tmp377_cast_fu_4943_p1.read()) + sc_biguint<32>(tmp236_fu_4911_p2.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp241_cast_fu_3293_p1() {
    tmp241_cast_fu_3293_p1 = esl_zext<32,2>(tmp142_fu_3287_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp241_fu_4953_p2() {
    tmp241_fu_4953_p2 = (!res_7_9_cast_fu_4747_p1.read().is_01() || !res_7_cast_fu_4531_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_7_9_cast_fu_4747_p1.read()) + sc_biguint<2>(res_7_cast_fu_4531_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp242_cast_fu_3329_p1() {
    tmp242_cast_fu_3329_p1 = esl_zext<32,3>(tmp146_fu_3323_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp242_fu_4963_p2() {
    tmp242_fu_4963_p2 = (!res_7_2_cast_fu_4579_p1.read().is_01() || !res_7_1_cast_fu_4555_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_7_2_cast_fu_4579_p1.read()) + sc_biguint<2>(res_7_1_cast_fu_4555_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp243_cast_fu_3309_p1() {
    tmp243_cast_fu_3309_p1 = esl_zext<3,2>(tmp144_fu_3303_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp243_fu_4973_p2() {
    tmp243_fu_4973_p2 = (!tmp383_cast_fu_4969_p1.read().is_01() || !tmp382_cast_fu_4959_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp383_cast_fu_4969_p1.read()) + sc_biguint<3>(tmp382_cast_fu_4959_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp244_cast_fu_3319_p1() {
    tmp244_cast_fu_3319_p1 = esl_zext<3,2>(tmp145_fu_3313_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp244_fu_4983_p2() {
    tmp244_fu_4983_p2 = (!res_7_4_cast_fu_4627_p1.read().is_01() || !res_7_3_cast_fu_4603_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_7_4_cast_fu_4627_p1.read()) + sc_biguint<2>(res_7_3_cast_fu_4603_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp245_cast_fu_3411_p1() {
    tmp245_cast_fu_3411_p1 = esl_zext<32,4>(tmp155_fu_3405_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp245_fu_4993_p2() {
    tmp245_fu_4993_p2 = (!res_7_5_cast_fu_4651_p1.read().is_01() || !res_7_14_cast_fu_4891_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_7_5_cast_fu_4651_p1.read()) + sc_biguint<2>(res_7_14_cast_fu_4891_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp246_cast_fu_3365_p1() {
    tmp246_cast_fu_3365_p1 = esl_zext<4,3>(tmp150_fu_3359_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp246_fu_4999_p2() {
    tmp246_fu_4999_p2 = (!tmp245_fu_4993_p2.read().is_01() || !res_7_6_cast_fu_4675_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(tmp245_fu_4993_p2.read()) + sc_biguint<2>(res_7_6_cast_fu_4675_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp247_cast_fu_3345_p1() {
    tmp247_cast_fu_3345_p1 = esl_zext<3,2>(tmp148_fu_3339_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp247_fu_5009_p2() {
    tmp247_fu_5009_p2 = (!tmp386_cast_fu_5005_p1.read().is_01() || !tmp385_cast_fu_4989_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp386_cast_fu_5005_p1.read()) + sc_biguint<3>(tmp385_cast_fu_4989_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp248_cast_fu_3355_p1() {
    tmp248_cast_fu_3355_p1 = esl_zext<3,2>(tmp149_fu_3349_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp248_fu_5019_p2() {
    tmp248_fu_5019_p2 = (!tmp384_cast_fu_5015_p1.read().is_01() || !tmp381_cast_fu_4979_p1.read().is_01())? sc_lv<4>(): (sc_biguint<4>(tmp384_cast_fu_5015_p1.read()) + sc_biguint<4>(tmp381_cast_fu_4979_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp249_cast_fu_3401_p1() {
    tmp249_cast_fu_3401_p1 = esl_zext<4,3>(tmp154_fu_3395_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp249_fu_5057_p2() {
    tmp249_fu_5057_p2 = (p_Result_2_fu_625_p3.read() ^ p_Result_8_fu_5049_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp24_fu_1187_p2() {
    tmp24_fu_1187_p2 = (!res_0_9_cast_fu_933_p1.read().is_01() || !res_cast_fu_645_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_0_9_cast_fu_933_p1.read()) + sc_biguint<2>(res_cast_fu_645_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp250_cast_fu_3375_p1() {
    tmp250_cast_fu_3375_p1 = esl_zext<3,2>(tmp151_fu_3369_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp250_fu_5081_p2() {
    tmp250_fu_5081_p2 = (p_Result_2_0_1_fu_657_p3.read() ^ p_Result_8_1_fu_5073_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp251_cast_fu_3391_p1() {
    tmp251_cast_fu_3391_p1 = esl_zext<3,2>(tmp153_fu_3385_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp251_fu_5105_p2() {
    tmp251_fu_5105_p2 = (p_Result_2_0_2_fu_689_p3.read() ^ p_Result_8_2_fu_5097_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp252_fu_5129_p2() {
    tmp252_fu_5129_p2 = (p_Result_2_0_3_fu_721_p3.read() ^ p_Result_8_3_fu_5121_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp253_fu_5153_p2() {
    tmp253_fu_5153_p2 = (p_Result_2_0_4_fu_753_p3.read() ^ p_Result_8_4_fu_5145_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp254_fu_5177_p2() {
    tmp254_fu_5177_p2 = (p_Result_2_0_5_fu_785_p3.read() ^ p_Result_8_5_fu_5169_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp255_fu_5201_p2() {
    tmp255_fu_5201_p2 = (p_Result_2_0_6_fu_817_p3.read() ^ p_Result_8_6_fu_5193_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp256_fu_5225_p2() {
    tmp256_fu_5225_p2 = (p_Result_2_0_7_fu_849_p3.read() ^ p_Result_8_7_fu_5217_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp257_fu_5249_p2() {
    tmp257_fu_5249_p2 = (p_Result_2_0_8_fu_881_p3.read() ^ p_Result_8_8_fu_5241_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp258_fu_5273_p2() {
    tmp258_fu_5273_p2 = (p_Result_2_0_9_fu_913_p3.read() ^ p_Result_8_9_fu_5265_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp259_fu_5297_p2() {
    tmp259_fu_5297_p2 = (p_Result_2_0_s_fu_945_p3.read() ^ p_Result_8_s_fu_5289_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp25_fu_1197_p2() {
    tmp25_fu_1197_p2 = (!res_0_2_cast_fu_709_p1.read().is_01() || !res_0_1_cast_fu_677_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_0_2_cast_fu_709_p1.read()) + sc_biguint<2>(res_0_1_cast_fu_677_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp260_fu_5321_p2() {
    tmp260_fu_5321_p2 = (p_Result_2_0_10_fu_977_p3.read() ^ p_Result_8_10_fu_5313_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp261_fu_5345_p2() {
    tmp261_fu_5345_p2 = (p_Result_2_0_11_fu_1009_p3.read() ^ p_Result_8_11_fu_5337_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp262_fu_5369_p2() {
    tmp262_fu_5369_p2 = (p_Result_2_0_12_fu_1041_p3.read() ^ p_Result_8_12_fu_5361_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp263_fu_5393_p2() {
    tmp263_fu_5393_p2 = (p_Result_2_0_13_fu_1073_p3.read() ^ p_Result_8_13_fu_5385_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp264_fu_5417_p2() {
    tmp264_fu_5417_p2 = (p_Result_2_0_14_fu_1105_p3.read() ^ p_Result_8_14_fu_5409_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp265_fu_5433_p2() {
    tmp265_fu_5433_p2 = (!p_accu_V_8_fu_536_p3.read().is_01() || !res_8_s_fu_5381_p1.read().is_01())? sc_lv<32>(): (sc_biguint<32>(p_accu_V_8_fu_536_p3.read()) + sc_biguint<32>(res_8_s_fu_5381_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp266_fu_5439_p2() {
    tmp266_fu_5439_p2 = (!res_8_13_cast_fu_5405_p1.read().is_01() || !res_8_11_cast_fu_5357_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_8_13_cast_fu_5405_p1.read()) + sc_biguint<2>(res_8_11_cast_fu_5357_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp267_fu_5449_p2() {
    tmp267_fu_5449_p2 = (!tmp421_cast_fu_5445_p1.read().is_01() || !tmp265_fu_5433_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(tmp421_cast_fu_5445_p1.read()) + sc_biguint<32>(tmp265_fu_5433_p2.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp268_fu_5455_p2() {
    tmp268_fu_5455_p2 = (!res_8_10_cast_fu_5333_p1.read().is_01() || !res_8_8_cast_fu_5261_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_8_10_cast_fu_5333_p1.read()) + sc_biguint<2>(res_8_8_cast_fu_5261_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp269_fu_5465_p2() {
    tmp269_fu_5465_p2 = (!res_8_7_cast_fu_5237_p1.read().is_01() || !res_8_cast_186_fu_5309_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_8_7_cast_fu_5237_p1.read()) + sc_biguint<2>(res_8_cast_186_fu_5309_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp26_fu_1207_p2() {
    tmp26_fu_1207_p2 = (!tmp68_cast_fu_1203_p1.read().is_01() || !tmp67_cast_fu_1193_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp68_cast_fu_1203_p1.read()) + sc_biguint<3>(tmp67_cast_fu_1193_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp270_fu_5475_p2() {
    tmp270_fu_5475_p2 = (!tmp424_cast_fu_5471_p1.read().is_01() || !tmp423_cast_fu_5461_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp424_cast_fu_5471_p1.read()) + sc_biguint<3>(tmp423_cast_fu_5461_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp271_fu_5485_p2() {
    tmp271_fu_5485_p2 = (!tmp422_cast_fu_5481_p1.read().is_01() || !tmp267_fu_5449_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(tmp422_cast_fu_5481_p1.read()) + sc_biguint<32>(tmp267_fu_5449_p2.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp272_fu_5491_p2() {
    tmp272_fu_5491_p2 = (!res_8_9_cast_fu_5285_p1.read().is_01() || !res_8_cast_fu_5069_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_8_9_cast_fu_5285_p1.read()) + sc_biguint<2>(res_8_cast_fu_5069_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp273_fu_5501_p2() {
    tmp273_fu_5501_p2 = (!res_8_2_cast_fu_5117_p1.read().is_01() || !res_8_1_cast_fu_5093_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_8_2_cast_fu_5117_p1.read()) + sc_biguint<2>(res_8_1_cast_fu_5093_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp274_fu_5511_p2() {
    tmp274_fu_5511_p2 = (!tmp428_cast_fu_5507_p1.read().is_01() || !tmp427_cast_fu_5497_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp428_cast_fu_5507_p1.read()) + sc_biguint<3>(tmp427_cast_fu_5497_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp275_fu_5521_p2() {
    tmp275_fu_5521_p2 = (!res_8_4_cast_fu_5165_p1.read().is_01() || !res_8_3_cast_fu_5141_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_8_4_cast_fu_5165_p1.read()) + sc_biguint<2>(res_8_3_cast_fu_5141_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp276_fu_5531_p2() {
    tmp276_fu_5531_p2 = (!res_8_5_cast_fu_5189_p1.read().is_01() || !res_8_14_cast_fu_5429_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_8_5_cast_fu_5189_p1.read()) + sc_biguint<2>(res_8_14_cast_fu_5429_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp277_fu_5537_p2() {
    tmp277_fu_5537_p2 = (!tmp276_fu_5531_p2.read().is_01() || !res_8_6_cast_fu_5213_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(tmp276_fu_5531_p2.read()) + sc_biguint<2>(res_8_6_cast_fu_5213_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp278_fu_5547_p2() {
    tmp278_fu_5547_p2 = (!tmp431_cast_fu_5543_p1.read().is_01() || !tmp430_cast_fu_5527_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp431_cast_fu_5543_p1.read()) + sc_biguint<3>(tmp430_cast_fu_5527_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp279_fu_5557_p2() {
    tmp279_fu_5557_p2 = (!tmp429_cast_fu_5553_p1.read().is_01() || !tmp426_cast_fu_5517_p1.read().is_01())? sc_lv<4>(): (sc_biguint<4>(tmp429_cast_fu_5553_p1.read()) + sc_biguint<4>(tmp426_cast_fu_5517_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp27_fu_1217_p2() {
    tmp27_fu_1217_p2 = (!res_0_4_cast_fu_773_p1.read().is_01() || !res_0_3_cast_fu_741_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_0_4_cast_fu_773_p1.read()) + sc_biguint<2>(res_0_3_cast_fu_741_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp280_fu_5595_p2() {
    tmp280_fu_5595_p2 = (p_Result_2_fu_625_p3.read() ^ p_Result_9_fu_5587_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp281_fu_5619_p2() {
    tmp281_fu_5619_p2 = (p_Result_2_0_1_fu_657_p3.read() ^ p_Result_9_1_fu_5611_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp282_fu_5643_p2() {
    tmp282_fu_5643_p2 = (p_Result_2_0_2_fu_689_p3.read() ^ p_Result_9_2_fu_5635_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp283_fu_5667_p2() {
    tmp283_fu_5667_p2 = (p_Result_2_0_3_fu_721_p3.read() ^ p_Result_9_3_fu_5659_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp284_fu_5691_p2() {
    tmp284_fu_5691_p2 = (p_Result_2_0_4_fu_753_p3.read() ^ p_Result_9_4_fu_5683_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp285_fu_5715_p2() {
    tmp285_fu_5715_p2 = (p_Result_2_0_5_fu_785_p3.read() ^ p_Result_9_5_fu_5707_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp286_cast_fu_3831_p1() {
    tmp286_cast_fu_3831_p1 = esl_zext<32,2>(tmp173_fu_3825_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp286_fu_5739_p2() {
    tmp286_fu_5739_p2 = (p_Result_2_0_6_fu_817_p3.read() ^ p_Result_9_6_fu_5731_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp287_cast_fu_3867_p1() {
    tmp287_cast_fu_3867_p1 = esl_zext<32,3>(tmp177_fu_3861_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp287_fu_5763_p2() {
    tmp287_fu_5763_p2 = (p_Result_2_0_7_fu_849_p3.read() ^ p_Result_9_7_fu_5755_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp288_cast_fu_3847_p1() {
    tmp288_cast_fu_3847_p1 = esl_zext<3,2>(tmp175_fu_3841_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp288_fu_5787_p2() {
    tmp288_fu_5787_p2 = (p_Result_2_0_8_fu_881_p3.read() ^ p_Result_9_8_fu_5779_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp289_cast_fu_3857_p1() {
    tmp289_cast_fu_3857_p1 = esl_zext<3,2>(tmp176_fu_3851_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp289_fu_5811_p2() {
    tmp289_fu_5811_p2 = (p_Result_2_0_9_fu_913_p3.read() ^ p_Result_9_9_fu_5803_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp28_fu_1227_p2() {
    tmp28_fu_1227_p2 = (!res_0_5_cast_fu_805_p1.read().is_01() || !res_0_14_cast_fu_1125_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_0_5_cast_fu_805_p1.read()) + sc_biguint<2>(res_0_14_cast_fu_1125_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp290_cast_fu_3949_p1() {
    tmp290_cast_fu_3949_p1 = esl_zext<32,4>(tmp186_fu_3943_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp290_fu_5835_p2() {
    tmp290_fu_5835_p2 = (p_Result_2_0_s_fu_945_p3.read() ^ p_Result_9_s_fu_5827_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp291_cast_fu_3903_p1() {
    tmp291_cast_fu_3903_p1 = esl_zext<4,3>(tmp181_fu_3897_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp291_fu_5859_p2() {
    tmp291_fu_5859_p2 = (p_Result_2_0_10_fu_977_p3.read() ^ p_Result_9_10_fu_5851_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp292_cast_fu_3883_p1() {
    tmp292_cast_fu_3883_p1 = esl_zext<3,2>(tmp179_fu_3877_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp292_fu_5883_p2() {
    tmp292_fu_5883_p2 = (p_Result_2_0_11_fu_1009_p3.read() ^ p_Result_9_11_fu_5875_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp293_cast_fu_3893_p1() {
    tmp293_cast_fu_3893_p1 = esl_zext<3,2>(tmp180_fu_3887_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp293_fu_5907_p2() {
    tmp293_fu_5907_p2 = (p_Result_2_0_12_fu_1041_p3.read() ^ p_Result_9_12_fu_5899_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp294_cast_fu_3939_p1() {
    tmp294_cast_fu_3939_p1 = esl_zext<4,3>(tmp185_fu_3933_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp294_fu_5931_p2() {
    tmp294_fu_5931_p2 = (p_Result_2_0_13_fu_1073_p3.read() ^ p_Result_9_13_fu_5923_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp295_cast_fu_3913_p1() {
    tmp295_cast_fu_3913_p1 = esl_zext<3,2>(tmp182_fu_3907_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp295_fu_5955_p2() {
    tmp295_fu_5955_p2 = (p_Result_2_0_14_fu_1105_p3.read() ^ p_Result_9_14_fu_5947_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp296_cast_fu_3929_p1() {
    tmp296_cast_fu_3929_p1 = esl_zext<3,2>(tmp184_fu_3923_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp296_fu_5971_p2() {
    tmp296_fu_5971_p2 = (!p_accu_V_9_fu_529_p3.read().is_01() || !res_9_s_fu_5919_p1.read().is_01())? sc_lv<32>(): (sc_biguint<32>(p_accu_V_9_fu_529_p3.read()) + sc_biguint<32>(res_9_s_fu_5919_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp297_fu_5977_p2() {
    tmp297_fu_5977_p2 = (!res_9_13_cast_fu_5943_p1.read().is_01() || !res_9_11_cast_fu_5895_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_9_13_cast_fu_5943_p1.read()) + sc_biguint<2>(res_9_11_cast_fu_5895_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp298_fu_5987_p2() {
    tmp298_fu_5987_p2 = (!tmp466_cast_fu_5983_p1.read().is_01() || !tmp296_fu_5971_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(tmp466_cast_fu_5983_p1.read()) + sc_biguint<32>(tmp296_fu_5971_p2.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp299_fu_5993_p2() {
    tmp299_fu_5993_p2 = (!res_9_10_cast_fu_5871_p1.read().is_01() || !res_9_8_cast_fu_5799_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_9_10_cast_fu_5871_p1.read()) + sc_biguint<2>(res_9_8_cast_fu_5799_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp29_fu_1233_p2() {
    tmp29_fu_1233_p2 = (!tmp28_fu_1227_p2.read().is_01() || !res_0_6_cast_fu_837_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(tmp28_fu_1227_p2.read()) + sc_biguint<2>(res_0_6_cast_fu_837_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp2_fu_665_p2() {
    tmp2_fu_665_p2 = (p_Result_2_0_1_fu_657_p3.read() ^ p_Result_0_1_fu_649_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp300_fu_6003_p2() {
    tmp300_fu_6003_p2 = (!res_9_7_cast_fu_5775_p1.read().is_01() || !res_9_cast_203_fu_5847_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_9_7_cast_fu_5775_p1.read()) + sc_biguint<2>(res_9_cast_203_fu_5847_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp301_fu_6013_p2() {
    tmp301_fu_6013_p2 = (!tmp469_cast_fu_6009_p1.read().is_01() || !tmp468_cast_fu_5999_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp469_cast_fu_6009_p1.read()) + sc_biguint<3>(tmp468_cast_fu_5999_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp302_fu_6023_p2() {
    tmp302_fu_6023_p2 = (!tmp467_cast_fu_6019_p1.read().is_01() || !tmp298_fu_5987_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(tmp467_cast_fu_6019_p1.read()) + sc_biguint<32>(tmp298_fu_5987_p2.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp303_fu_6029_p2() {
    tmp303_fu_6029_p2 = (!res_9_9_cast_fu_5823_p1.read().is_01() || !res_9_cast_fu_5607_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_9_9_cast_fu_5823_p1.read()) + sc_biguint<2>(res_9_cast_fu_5607_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp304_fu_6039_p2() {
    tmp304_fu_6039_p2 = (!res_9_2_cast_fu_5655_p1.read().is_01() || !res_9_1_cast_fu_5631_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_9_2_cast_fu_5655_p1.read()) + sc_biguint<2>(res_9_1_cast_fu_5631_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp305_fu_6049_p2() {
    tmp305_fu_6049_p2 = (!tmp473_cast_fu_6045_p1.read().is_01() || !tmp472_cast_fu_6035_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp473_cast_fu_6045_p1.read()) + sc_biguint<3>(tmp472_cast_fu_6035_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp306_fu_6059_p2() {
    tmp306_fu_6059_p2 = (!res_9_4_cast_fu_5703_p1.read().is_01() || !res_9_3_cast_fu_5679_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_9_4_cast_fu_5703_p1.read()) + sc_biguint<2>(res_9_3_cast_fu_5679_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp307_fu_6069_p2() {
    tmp307_fu_6069_p2 = (!res_9_5_cast_fu_5727_p1.read().is_01() || !res_9_14_cast_fu_5967_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_9_5_cast_fu_5727_p1.read()) + sc_biguint<2>(res_9_14_cast_fu_5967_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp308_fu_6075_p2() {
    tmp308_fu_6075_p2 = (!tmp307_fu_6069_p2.read().is_01() || !res_9_6_cast_fu_5751_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(tmp307_fu_6069_p2.read()) + sc_biguint<2>(res_9_6_cast_fu_5751_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp309_fu_6085_p2() {
    tmp309_fu_6085_p2 = (!tmp476_cast_fu_6081_p1.read().is_01() || !tmp475_cast_fu_6065_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp476_cast_fu_6081_p1.read()) + sc_biguint<3>(tmp475_cast_fu_6065_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp30_fu_1243_p2() {
    tmp30_fu_1243_p2 = (!tmp71_cast_fu_1239_p1.read().is_01() || !tmp70_cast_fu_1223_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp71_cast_fu_1239_p1.read()) + sc_biguint<3>(tmp70_cast_fu_1223_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp310_fu_6095_p2() {
    tmp310_fu_6095_p2 = (!tmp474_cast_fu_6091_p1.read().is_01() || !tmp471_cast_fu_6055_p1.read().is_01())? sc_lv<4>(): (sc_biguint<4>(tmp474_cast_fu_6091_p1.read()) + sc_biguint<4>(tmp471_cast_fu_6055_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp31_fu_1253_p2() {
    tmp31_fu_1253_p2 = (!tmp69_cast_fu_1249_p1.read().is_01() || !tmp66_cast_fu_1213_p1.read().is_01())? sc_lv<4>(): (sc_biguint<4>(tmp69_cast_fu_1249_p1.read()) + sc_biguint<4>(tmp66_cast_fu_1213_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp32_fu_1291_p2() {
    tmp32_fu_1291_p2 = (p_Result_2_fu_625_p3.read() ^ p_Result_1_fu_1283_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp331_cast_fu_4369_p1() {
    tmp331_cast_fu_4369_p1 = esl_zext<32,2>(tmp204_fu_4363_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp332_cast_fu_4405_p1() {
    tmp332_cast_fu_4405_p1 = esl_zext<32,3>(tmp208_fu_4399_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp333_cast_fu_4385_p1() {
    tmp333_cast_fu_4385_p1 = esl_zext<3,2>(tmp206_fu_4379_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp334_cast_fu_4395_p1() {
    tmp334_cast_fu_4395_p1 = esl_zext<3,2>(tmp207_fu_4389_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp335_cast_fu_4487_p1() {
    tmp335_cast_fu_4487_p1 = esl_zext<32,4>(tmp217_fu_4481_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp336_cast_fu_4441_p1() {
    tmp336_cast_fu_4441_p1 = esl_zext<4,3>(tmp212_fu_4435_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp337_cast_fu_4421_p1() {
    tmp337_cast_fu_4421_p1 = esl_zext<3,2>(tmp210_fu_4415_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp338_cast_fu_4431_p1() {
    tmp338_cast_fu_4431_p1 = esl_zext<3,2>(tmp211_fu_4425_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp339_cast_fu_4477_p1() {
    tmp339_cast_fu_4477_p1 = esl_zext<4,3>(tmp216_fu_4471_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp33_fu_1315_p2() {
    tmp33_fu_1315_p2 = (p_Result_2_0_1_fu_657_p3.read() ^ p_Result_1_1_fu_1307_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp340_cast_fu_4451_p1() {
    tmp340_cast_fu_4451_p1 = esl_zext<3,2>(tmp213_fu_4445_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp341_cast_fu_4467_p1() {
    tmp341_cast_fu_4467_p1 = esl_zext<3,2>(tmp215_fu_4461_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp34_fu_1339_p2() {
    tmp34_fu_1339_p2 = (p_Result_2_0_2_fu_689_p3.read() ^ p_Result_1_2_fu_1331_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp35_fu_1363_p2() {
    tmp35_fu_1363_p2 = (p_Result_2_0_3_fu_721_p3.read() ^ p_Result_1_3_fu_1355_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp36_fu_1387_p2() {
    tmp36_fu_1387_p2 = (p_Result_2_0_4_fu_753_p3.read() ^ p_Result_1_4_fu_1379_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp376_cast_fu_4907_p1() {
    tmp376_cast_fu_4907_p1 = esl_zext<32,2>(tmp235_fu_4901_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp377_cast_fu_4943_p1() {
    tmp377_cast_fu_4943_p1 = esl_zext<32,3>(tmp239_fu_4937_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp378_cast_fu_4923_p1() {
    tmp378_cast_fu_4923_p1 = esl_zext<3,2>(tmp237_fu_4917_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp379_cast_fu_4933_p1() {
    tmp379_cast_fu_4933_p1 = esl_zext<3,2>(tmp238_fu_4927_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp37_fu_1411_p2() {
    tmp37_fu_1411_p2 = (p_Result_2_0_5_fu_785_p3.read() ^ p_Result_1_5_fu_1403_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp380_cast_fu_5025_p1() {
    tmp380_cast_fu_5025_p1 = esl_zext<32,4>(tmp248_fu_5019_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp381_cast_fu_4979_p1() {
    tmp381_cast_fu_4979_p1 = esl_zext<4,3>(tmp243_fu_4973_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp382_cast_fu_4959_p1() {
    tmp382_cast_fu_4959_p1 = esl_zext<3,2>(tmp241_fu_4953_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp383_cast_fu_4969_p1() {
    tmp383_cast_fu_4969_p1 = esl_zext<3,2>(tmp242_fu_4963_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp384_cast_fu_5015_p1() {
    tmp384_cast_fu_5015_p1 = esl_zext<4,3>(tmp247_fu_5009_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp385_cast_fu_4989_p1() {
    tmp385_cast_fu_4989_p1 = esl_zext<3,2>(tmp244_fu_4983_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp386_cast_fu_5005_p1() {
    tmp386_cast_fu_5005_p1 = esl_zext<3,2>(tmp246_fu_4999_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp38_fu_1435_p2() {
    tmp38_fu_1435_p2 = (p_Result_2_0_6_fu_817_p3.read() ^ p_Result_1_6_fu_1427_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp39_fu_1459_p2() {
    tmp39_fu_1459_p2 = (p_Result_2_0_7_fu_849_p3.read() ^ p_Result_1_7_fu_1451_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp3_fu_697_p2() {
    tmp3_fu_697_p2 = (p_Result_2_0_2_fu_689_p3.read() ^ p_Result_0_2_fu_681_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp40_fu_1483_p2() {
    tmp40_fu_1483_p2 = (p_Result_2_0_8_fu_881_p3.read() ^ p_Result_1_8_fu_1475_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp41_fu_1507_p2() {
    tmp41_fu_1507_p2 = (p_Result_2_0_9_fu_913_p3.read() ^ p_Result_1_9_fu_1499_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp421_cast_fu_5445_p1() {
    tmp421_cast_fu_5445_p1 = esl_zext<32,2>(tmp266_fu_5439_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp422_cast_fu_5481_p1() {
    tmp422_cast_fu_5481_p1 = esl_zext<32,3>(tmp270_fu_5475_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp423_cast_fu_5461_p1() {
    tmp423_cast_fu_5461_p1 = esl_zext<3,2>(tmp268_fu_5455_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp424_cast_fu_5471_p1() {
    tmp424_cast_fu_5471_p1 = esl_zext<3,2>(tmp269_fu_5465_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp425_cast_fu_5563_p1() {
    tmp425_cast_fu_5563_p1 = esl_zext<32,4>(tmp279_fu_5557_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp426_cast_fu_5517_p1() {
    tmp426_cast_fu_5517_p1 = esl_zext<4,3>(tmp274_fu_5511_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp427_cast_fu_5497_p1() {
    tmp427_cast_fu_5497_p1 = esl_zext<3,2>(tmp272_fu_5491_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp428_cast_fu_5507_p1() {
    tmp428_cast_fu_5507_p1 = esl_zext<3,2>(tmp273_fu_5501_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp429_cast_fu_5553_p1() {
    tmp429_cast_fu_5553_p1 = esl_zext<4,3>(tmp278_fu_5547_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp42_fu_1531_p2() {
    tmp42_fu_1531_p2 = (p_Result_2_0_s_fu_945_p3.read() ^ p_Result_1_s_fu_1523_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp430_cast_fu_5527_p1() {
    tmp430_cast_fu_5527_p1 = esl_zext<3,2>(tmp275_fu_5521_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp431_cast_fu_5543_p1() {
    tmp431_cast_fu_5543_p1 = esl_zext<3,2>(tmp277_fu_5537_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp43_fu_1555_p2() {
    tmp43_fu_1555_p2 = (p_Result_2_0_10_fu_977_p3.read() ^ p_Result_1_10_fu_1547_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp44_fu_1579_p2() {
    tmp44_fu_1579_p2 = (p_Result_2_0_11_fu_1009_p3.read() ^ p_Result_1_11_fu_1571_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp45_fu_1603_p2() {
    tmp45_fu_1603_p2 = (p_Result_2_0_12_fu_1041_p3.read() ^ p_Result_1_12_fu_1595_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp466_cast_fu_5983_p1() {
    tmp466_cast_fu_5983_p1 = esl_zext<32,2>(tmp297_fu_5977_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp467_cast_fu_6019_p1() {
    tmp467_cast_fu_6019_p1 = esl_zext<32,3>(tmp301_fu_6013_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp468_cast_fu_5999_p1() {
    tmp468_cast_fu_5999_p1 = esl_zext<3,2>(tmp299_fu_5993_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp469_cast_fu_6009_p1() {
    tmp469_cast_fu_6009_p1 = esl_zext<3,2>(tmp300_fu_6003_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp46_fu_1627_p2() {
    tmp46_fu_1627_p2 = (p_Result_2_0_13_fu_1073_p3.read() ^ p_Result_1_13_fu_1619_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp470_cast_fu_6101_p1() {
    tmp470_cast_fu_6101_p1 = esl_zext<32,4>(tmp310_fu_6095_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp471_cast_fu_6055_p1() {
    tmp471_cast_fu_6055_p1 = esl_zext<4,3>(tmp305_fu_6049_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp472_cast_fu_6035_p1() {
    tmp472_cast_fu_6035_p1 = esl_zext<3,2>(tmp303_fu_6029_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp473_cast_fu_6045_p1() {
    tmp473_cast_fu_6045_p1 = esl_zext<3,2>(tmp304_fu_6039_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp474_cast_fu_6091_p1() {
    tmp474_cast_fu_6091_p1 = esl_zext<4,3>(tmp309_fu_6085_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp475_cast_fu_6065_p1() {
    tmp475_cast_fu_6065_p1 = esl_zext<3,2>(tmp306_fu_6059_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp476_cast_fu_6081_p1() {
    tmp476_cast_fu_6081_p1 = esl_zext<3,2>(tmp308_fu_6075_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp47_fu_1651_p2() {
    tmp47_fu_1651_p2 = (p_Result_2_0_14_fu_1105_p3.read() ^ p_Result_1_14_fu_1643_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp48_fu_1667_p2() {
    tmp48_fu_1667_p2 = (!p_accu_V_1_fu_585_p3.read().is_01() || !res_1_s_fu_1615_p1.read().is_01())? sc_lv<32>(): (sc_biguint<32>(p_accu_V_1_fu_585_p3.read()) + sc_biguint<32>(res_1_s_fu_1615_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp49_fu_1673_p2() {
    tmp49_fu_1673_p2 = (!res_1_13_cast_fu_1639_p1.read().is_01() || !res_1_11_cast_fu_1591_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_1_13_cast_fu_1639_p1.read()) + sc_biguint<2>(res_1_11_cast_fu_1591_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp4_fu_729_p2() {
    tmp4_fu_729_p2 = (p_Result_2_0_3_fu_721_p3.read() ^ p_Result_0_3_fu_713_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp50_fu_1683_p2() {
    tmp50_fu_1683_p2 = (!tmp106_cast_fu_1679_p1.read().is_01() || !tmp48_fu_1667_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(tmp106_cast_fu_1679_p1.read()) + sc_biguint<32>(tmp48_fu_1667_p2.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp51_fu_1689_p2() {
    tmp51_fu_1689_p2 = (!res_1_10_cast_fu_1567_p1.read().is_01() || !res_1_8_cast_fu_1495_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_1_10_cast_fu_1567_p1.read()) + sc_biguint<2>(res_1_8_cast_fu_1495_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp52_fu_1699_p2() {
    tmp52_fu_1699_p2 = (!res_1_7_cast_fu_1471_p1.read().is_01() || !res_1_cast_66_fu_1543_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_1_7_cast_fu_1471_p1.read()) + sc_biguint<2>(res_1_cast_66_fu_1543_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp53_fu_1709_p2() {
    tmp53_fu_1709_p2 = (!tmp109_cast_fu_1705_p1.read().is_01() || !tmp108_cast_fu_1695_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp109_cast_fu_1705_p1.read()) + sc_biguint<3>(tmp108_cast_fu_1695_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp54_fu_1719_p2() {
    tmp54_fu_1719_p2 = (!tmp107_cast_fu_1715_p1.read().is_01() || !tmp50_fu_1683_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(tmp107_cast_fu_1715_p1.read()) + sc_biguint<32>(tmp50_fu_1683_p2.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp55_fu_1725_p2() {
    tmp55_fu_1725_p2 = (!res_1_9_cast_fu_1519_p1.read().is_01() || !res_1_cast_fu_1303_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_1_9_cast_fu_1519_p1.read()) + sc_biguint<2>(res_1_cast_fu_1303_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp56_fu_1735_p2() {
    tmp56_fu_1735_p2 = (!res_1_2_cast_fu_1351_p1.read().is_01() || !res_1_1_cast_fu_1327_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_1_2_cast_fu_1351_p1.read()) + sc_biguint<2>(res_1_1_cast_fu_1327_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp57_fu_1745_p2() {
    tmp57_fu_1745_p2 = (!tmp113_cast_fu_1741_p1.read().is_01() || !tmp112_cast_fu_1731_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp113_cast_fu_1741_p1.read()) + sc_biguint<3>(tmp112_cast_fu_1731_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp58_fu_1755_p2() {
    tmp58_fu_1755_p2 = (!res_1_4_cast_fu_1399_p1.read().is_01() || !res_1_3_cast_fu_1375_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_1_4_cast_fu_1399_p1.read()) + sc_biguint<2>(res_1_3_cast_fu_1375_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp59_fu_1765_p2() {
    tmp59_fu_1765_p2 = (!res_1_5_cast_fu_1423_p1.read().is_01() || !res_1_14_cast_fu_1663_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_1_5_cast_fu_1423_p1.read()) + sc_biguint<2>(res_1_14_cast_fu_1663_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp5_fu_761_p2() {
    tmp5_fu_761_p2 = (p_Result_2_0_4_fu_753_p3.read() ^ p_Result_0_4_fu_745_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp60_fu_1771_p2() {
    tmp60_fu_1771_p2 = (!tmp59_fu_1765_p2.read().is_01() || !res_1_6_cast_fu_1447_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(tmp59_fu_1765_p2.read()) + sc_biguint<2>(res_1_6_cast_fu_1447_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp61_cast_fu_1141_p1() {
    tmp61_cast_fu_1141_p1 = esl_zext<32,2>(tmp18_fu_1135_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp61_fu_1781_p2() {
    tmp61_fu_1781_p2 = (!tmp116_cast_fu_1777_p1.read().is_01() || !tmp115_cast_fu_1761_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp116_cast_fu_1777_p1.read()) + sc_biguint<3>(tmp115_cast_fu_1761_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp62_cast_fu_1177_p1() {
    tmp62_cast_fu_1177_p1 = esl_zext<32,3>(tmp22_fu_1171_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp62_fu_1791_p2() {
    tmp62_fu_1791_p2 = (!tmp114_cast_fu_1787_p1.read().is_01() || !tmp111_cast_fu_1751_p1.read().is_01())? sc_lv<4>(): (sc_biguint<4>(tmp114_cast_fu_1787_p1.read()) + sc_biguint<4>(tmp111_cast_fu_1751_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp63_cast_fu_1157_p1() {
    tmp63_cast_fu_1157_p1 = esl_zext<3,2>(tmp20_fu_1151_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp63_fu_1829_p2() {
    tmp63_fu_1829_p2 = (p_Result_2_fu_625_p3.read() ^ p_Result_s_73_fu_1821_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp64_cast_fu_1167_p1() {
    tmp64_cast_fu_1167_p1 = esl_zext<3,2>(tmp21_fu_1161_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp64_fu_1853_p2() {
    tmp64_fu_1853_p2 = (p_Result_2_0_1_fu_657_p3.read() ^ p_Result_28_1_fu_1845_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp65_cast_fu_1259_p1() {
    tmp65_cast_fu_1259_p1 = esl_zext<32,4>(tmp31_fu_1253_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp65_fu_1877_p2() {
    tmp65_fu_1877_p2 = (p_Result_2_0_2_fu_689_p3.read() ^ p_Result_28_2_fu_1869_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp66_cast_fu_1213_p1() {
    tmp66_cast_fu_1213_p1 = esl_zext<4,3>(tmp26_fu_1207_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp66_fu_1901_p2() {
    tmp66_fu_1901_p2 = (p_Result_2_0_3_fu_721_p3.read() ^ p_Result_28_3_fu_1893_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp67_cast_fu_1193_p1() {
    tmp67_cast_fu_1193_p1 = esl_zext<3,2>(tmp24_fu_1187_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp67_fu_1925_p2() {
    tmp67_fu_1925_p2 = (p_Result_2_0_4_fu_753_p3.read() ^ p_Result_28_4_fu_1917_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp68_cast_fu_1203_p1() {
    tmp68_cast_fu_1203_p1 = esl_zext<3,2>(tmp25_fu_1197_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp68_fu_1949_p2() {
    tmp68_fu_1949_p2 = (p_Result_2_0_5_fu_785_p3.read() ^ p_Result_28_5_fu_1941_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp69_cast_fu_1249_p1() {
    tmp69_cast_fu_1249_p1 = esl_zext<4,3>(tmp30_fu_1243_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp69_fu_1973_p2() {
    tmp69_fu_1973_p2 = (p_Result_2_0_6_fu_817_p3.read() ^ p_Result_28_6_fu_1965_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp6_fu_793_p2() {
    tmp6_fu_793_p2 = (p_Result_2_0_5_fu_785_p3.read() ^ p_Result_0_5_fu_777_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp70_cast_fu_1223_p1() {
    tmp70_cast_fu_1223_p1 = esl_zext<3,2>(tmp27_fu_1217_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp70_fu_1997_p2() {
    tmp70_fu_1997_p2 = (p_Result_2_0_7_fu_849_p3.read() ^ p_Result_28_7_fu_1989_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp71_cast_fu_1239_p1() {
    tmp71_cast_fu_1239_p1 = esl_zext<3,2>(tmp29_fu_1233_p2.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp71_fu_2021_p2() {
    tmp71_fu_2021_p2 = (p_Result_2_0_8_fu_881_p3.read() ^ p_Result_28_8_fu_2013_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp72_fu_2045_p2() {
    tmp72_fu_2045_p2 = (p_Result_2_0_9_fu_913_p3.read() ^ p_Result_28_9_fu_2037_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp73_fu_2069_p2() {
    tmp73_fu_2069_p2 = (p_Result_2_0_s_fu_945_p3.read() ^ p_Result_28_s_fu_2061_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp74_fu_2093_p2() {
    tmp74_fu_2093_p2 = (p_Result_2_0_10_fu_977_p3.read() ^ p_Result_28_10_fu_2085_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp75_fu_2117_p2() {
    tmp75_fu_2117_p2 = (p_Result_2_0_11_fu_1009_p3.read() ^ p_Result_28_11_fu_2109_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp76_fu_2141_p2() {
    tmp76_fu_2141_p2 = (p_Result_2_0_12_fu_1041_p3.read() ^ p_Result_28_12_fu_2133_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp77_fu_2165_p2() {
    tmp77_fu_2165_p2 = (p_Result_2_0_13_fu_1073_p3.read() ^ p_Result_28_13_fu_2157_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp78_fu_2189_p2() {
    tmp78_fu_2189_p2 = (p_Result_2_0_14_fu_1105_p3.read() ^ p_Result_28_14_fu_2181_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp79_fu_2205_p2() {
    tmp79_fu_2205_p2 = (!p_accu_V_2_fu_578_p3.read().is_01() || !res_29_s_fu_2153_p1.read().is_01())? sc_lv<32>(): (sc_biguint<32>(p_accu_V_2_fu_578_p3.read()) + sc_biguint<32>(res_29_s_fu_2153_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp7_fu_825_p2() {
    tmp7_fu_825_p2 = (p_Result_2_0_6_fu_817_p3.read() ^ p_Result_0_6_fu_809_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp80_fu_2211_p2() {
    tmp80_fu_2211_p2 = (!res_29_13_cast_fu_2177_p1.read().is_01() || !res_29_11_cast_fu_2129_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_29_13_cast_fu_2177_p1.read()) + sc_biguint<2>(res_29_11_cast_fu_2129_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp81_fu_2221_p2() {
    tmp81_fu_2221_p2 = (!tmp151_cast_fu_2217_p1.read().is_01() || !tmp79_fu_2205_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(tmp151_cast_fu_2217_p1.read()) + sc_biguint<32>(tmp79_fu_2205_p2.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp82_fu_2227_p2() {
    tmp82_fu_2227_p2 = (!res_29_10_cast_fu_2105_p1.read().is_01() || !res_29_8_cast_fu_2033_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_29_10_cast_fu_2105_p1.read()) + sc_biguint<2>(res_29_8_cast_fu_2033_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp83_fu_2237_p2() {
    tmp83_fu_2237_p2 = (!res_29_7_cast_fu_2009_p1.read().is_01() || !res_29_cast_fu_2081_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_29_7_cast_fu_2009_p1.read()) + sc_biguint<2>(res_29_cast_fu_2081_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp84_fu_2247_p2() {
    tmp84_fu_2247_p2 = (!tmp154_cast_fu_2243_p1.read().is_01() || !tmp153_cast_fu_2233_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp154_cast_fu_2243_p1.read()) + sc_biguint<3>(tmp153_cast_fu_2233_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp85_fu_2257_p2() {
    tmp85_fu_2257_p2 = (!tmp152_cast_fu_2253_p1.read().is_01() || !tmp81_fu_2221_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(tmp152_cast_fu_2253_p1.read()) + sc_biguint<32>(tmp81_fu_2221_p2.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp86_fu_2263_p2() {
    tmp86_fu_2263_p2 = (!res_29_9_cast_fu_2057_p1.read().is_01() || !res_cast_74_fu_1841_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_29_9_cast_fu_2057_p1.read()) + sc_biguint<2>(res_cast_74_fu_1841_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp87_fu_2273_p2() {
    tmp87_fu_2273_p2 = (!res_29_2_cast_fu_1889_p1.read().is_01() || !res_29_1_cast_fu_1865_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_29_2_cast_fu_1889_p1.read()) + sc_biguint<2>(res_29_1_cast_fu_1865_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp88_fu_2283_p2() {
    tmp88_fu_2283_p2 = (!tmp158_cast_fu_2279_p1.read().is_01() || !tmp157_cast_fu_2269_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp158_cast_fu_2279_p1.read()) + sc_biguint<3>(tmp157_cast_fu_2269_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp89_fu_2293_p2() {
    tmp89_fu_2293_p2 = (!res_29_4_cast_fu_1937_p1.read().is_01() || !res_29_3_cast_fu_1913_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_29_4_cast_fu_1937_p1.read()) + sc_biguint<2>(res_29_3_cast_fu_1913_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp8_fu_857_p2() {
    tmp8_fu_857_p2 = (p_Result_2_0_7_fu_849_p3.read() ^ p_Result_0_7_fu_841_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp90_fu_2303_p2() {
    tmp90_fu_2303_p2 = (!res_29_5_cast_fu_1961_p1.read().is_01() || !res_29_14_cast_fu_2201_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(res_29_5_cast_fu_1961_p1.read()) + sc_biguint<2>(res_29_14_cast_fu_2201_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp91_fu_2309_p2() {
    tmp91_fu_2309_p2 = (!tmp90_fu_2303_p2.read().is_01() || !res_29_6_cast_fu_1985_p1.read().is_01())? sc_lv<2>(): (sc_biguint<2>(tmp90_fu_2303_p2.read()) + sc_biguint<2>(res_29_6_cast_fu_1985_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp92_fu_2319_p2() {
    tmp92_fu_2319_p2 = (!tmp161_cast_fu_2315_p1.read().is_01() || !tmp160_cast_fu_2299_p1.read().is_01())? sc_lv<3>(): (sc_biguint<3>(tmp161_cast_fu_2315_p1.read()) + sc_biguint<3>(tmp160_cast_fu_2299_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp93_fu_2329_p2() {
    tmp93_fu_2329_p2 = (!tmp159_cast_fu_2325_p1.read().is_01() || !tmp156_cast_fu_2289_p1.read().is_01())? sc_lv<4>(): (sc_biguint<4>(tmp159_cast_fu_2325_p1.read()) + sc_biguint<4>(tmp156_cast_fu_2289_p1.read()));
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp94_fu_2367_p2() {
    tmp94_fu_2367_p2 = (p_Result_2_fu_625_p3.read() ^ p_Result_3_fu_2359_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp95_fu_2391_p2() {
    tmp95_fu_2391_p2 = (p_Result_2_0_1_fu_657_p3.read() ^ p_Result_310_1_fu_2383_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp96_fu_2415_p2() {
    tmp96_fu_2415_p2 = (p_Result_2_0_2_fu_689_p3.read() ^ p_Result_310_2_fu_2407_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp97_fu_2439_p2() {
    tmp97_fu_2439_p2 = (p_Result_2_0_3_fu_721_p3.read() ^ p_Result_310_3_fu_2431_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp98_fu_2463_p2() {
    tmp98_fu_2463_p2 = (p_Result_2_0_4_fu_753_p3.read() ^ p_Result_310_4_fu_2455_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp99_fu_2487_p2() {
    tmp99_fu_2487_p2 = (p_Result_2_0_5_fu_785_p3.read() ^ p_Result_310_5_fu_2479_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp9_fu_889_p2() {
    tmp9_fu_889_p2 = (p_Result_2_0_8_fu_881_p3.read() ^ p_Result_0_8_fu_873_p3.read());
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_0_10_fu_991_p2() {
    tmp_12_0_10_fu_991_p2 = (tmp12_fu_985_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_0_11_fu_1023_p2() {
    tmp_12_0_11_fu_1023_p2 = (tmp13_fu_1017_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_0_12_fu_1055_p2() {
    tmp_12_0_12_fu_1055_p2 = (tmp14_fu_1049_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_0_13_fu_1087_p2() {
    tmp_12_0_13_fu_1087_p2 = (tmp15_fu_1081_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_0_14_fu_1119_p2() {
    tmp_12_0_14_fu_1119_p2 = (tmp16_fu_1113_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_0_1_fu_671_p2() {
    tmp_12_0_1_fu_671_p2 = (tmp2_fu_665_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_0_2_fu_703_p2() {
    tmp_12_0_2_fu_703_p2 = (tmp3_fu_697_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_0_3_fu_735_p2() {
    tmp_12_0_3_fu_735_p2 = (tmp4_fu_729_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_0_4_fu_767_p2() {
    tmp_12_0_4_fu_767_p2 = (tmp5_fu_761_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_0_5_fu_799_p2() {
    tmp_12_0_5_fu_799_p2 = (tmp6_fu_793_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_0_6_fu_831_p2() {
    tmp_12_0_6_fu_831_p2 = (tmp7_fu_825_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_0_7_fu_863_p2() {
    tmp_12_0_7_fu_863_p2 = (tmp8_fu_857_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_0_8_fu_895_p2() {
    tmp_12_0_8_fu_895_p2 = (tmp9_fu_889_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_0_9_fu_927_p2() {
    tmp_12_0_9_fu_927_p2 = (tmp10_fu_921_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_0_s_fu_959_p2() {
    tmp_12_0_s_fu_959_p2 = (tmp11_fu_953_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_1_10_fu_1561_p2() {
    tmp_12_1_10_fu_1561_p2 = (tmp43_fu_1555_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_1_11_fu_1585_p2() {
    tmp_12_1_11_fu_1585_p2 = (tmp44_fu_1579_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_1_12_fu_1609_p2() {
    tmp_12_1_12_fu_1609_p2 = (tmp45_fu_1603_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_1_13_fu_1633_p2() {
    tmp_12_1_13_fu_1633_p2 = (tmp46_fu_1627_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_1_14_fu_1657_p2() {
    tmp_12_1_14_fu_1657_p2 = (tmp47_fu_1651_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_1_1_fu_1321_p2() {
    tmp_12_1_1_fu_1321_p2 = (tmp33_fu_1315_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_1_2_fu_1345_p2() {
    tmp_12_1_2_fu_1345_p2 = (tmp34_fu_1339_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_1_3_fu_1369_p2() {
    tmp_12_1_3_fu_1369_p2 = (tmp35_fu_1363_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_1_4_fu_1393_p2() {
    tmp_12_1_4_fu_1393_p2 = (tmp36_fu_1387_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_1_5_fu_1417_p2() {
    tmp_12_1_5_fu_1417_p2 = (tmp37_fu_1411_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_1_6_fu_1441_p2() {
    tmp_12_1_6_fu_1441_p2 = (tmp38_fu_1435_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_1_7_fu_1465_p2() {
    tmp_12_1_7_fu_1465_p2 = (tmp39_fu_1459_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_1_8_fu_1489_p2() {
    tmp_12_1_8_fu_1489_p2 = (tmp40_fu_1483_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_1_9_fu_1513_p2() {
    tmp_12_1_9_fu_1513_p2 = (tmp41_fu_1507_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_1_fu_1297_p2() {
    tmp_12_1_fu_1297_p2 = (tmp32_fu_1291_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_1_s_fu_1537_p2() {
    tmp_12_1_s_fu_1537_p2 = (tmp42_fu_1531_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_2_10_fu_2099_p2() {
    tmp_12_2_10_fu_2099_p2 = (tmp74_fu_2093_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_2_11_fu_2123_p2() {
    tmp_12_2_11_fu_2123_p2 = (tmp75_fu_2117_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_2_12_fu_2147_p2() {
    tmp_12_2_12_fu_2147_p2 = (tmp76_fu_2141_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_2_13_fu_2171_p2() {
    tmp_12_2_13_fu_2171_p2 = (tmp77_fu_2165_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_2_14_fu_2195_p2() {
    tmp_12_2_14_fu_2195_p2 = (tmp78_fu_2189_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_2_1_fu_1859_p2() {
    tmp_12_2_1_fu_1859_p2 = (tmp64_fu_1853_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_2_2_fu_1883_p2() {
    tmp_12_2_2_fu_1883_p2 = (tmp65_fu_1877_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_2_3_fu_1907_p2() {
    tmp_12_2_3_fu_1907_p2 = (tmp66_fu_1901_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_2_4_fu_1931_p2() {
    tmp_12_2_4_fu_1931_p2 = (tmp67_fu_1925_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_2_5_fu_1955_p2() {
    tmp_12_2_5_fu_1955_p2 = (tmp68_fu_1949_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_2_6_fu_1979_p2() {
    tmp_12_2_6_fu_1979_p2 = (tmp69_fu_1973_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_2_7_fu_2003_p2() {
    tmp_12_2_7_fu_2003_p2 = (tmp70_fu_1997_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_2_8_fu_2027_p2() {
    tmp_12_2_8_fu_2027_p2 = (tmp71_fu_2021_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_2_9_fu_2051_p2() {
    tmp_12_2_9_fu_2051_p2 = (tmp72_fu_2045_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_2_fu_1835_p2() {
    tmp_12_2_fu_1835_p2 = (tmp63_fu_1829_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_2_s_fu_2075_p2() {
    tmp_12_2_s_fu_2075_p2 = (tmp73_fu_2069_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_3_10_fu_2637_p2() {
    tmp_12_3_10_fu_2637_p2 = (tmp105_fu_2631_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_3_11_fu_2661_p2() {
    tmp_12_3_11_fu_2661_p2 = (tmp106_fu_2655_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_3_12_fu_2685_p2() {
    tmp_12_3_12_fu_2685_p2 = (tmp107_fu_2679_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_3_13_fu_2709_p2() {
    tmp_12_3_13_fu_2709_p2 = (tmp108_fu_2703_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_3_14_fu_2733_p2() {
    tmp_12_3_14_fu_2733_p2 = (tmp109_fu_2727_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_3_1_fu_2397_p2() {
    tmp_12_3_1_fu_2397_p2 = (tmp95_fu_2391_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_3_2_fu_2421_p2() {
    tmp_12_3_2_fu_2421_p2 = (tmp96_fu_2415_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_3_3_fu_2445_p2() {
    tmp_12_3_3_fu_2445_p2 = (tmp97_fu_2439_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_3_4_fu_2469_p2() {
    tmp_12_3_4_fu_2469_p2 = (tmp98_fu_2463_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_3_5_fu_2493_p2() {
    tmp_12_3_5_fu_2493_p2 = (tmp99_fu_2487_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_3_6_fu_2517_p2() {
    tmp_12_3_6_fu_2517_p2 = (tmp100_fu_2511_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_3_7_fu_2541_p2() {
    tmp_12_3_7_fu_2541_p2 = (tmp101_fu_2535_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_3_8_fu_2565_p2() {
    tmp_12_3_8_fu_2565_p2 = (tmp102_fu_2559_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_3_9_fu_2589_p2() {
    tmp_12_3_9_fu_2589_p2 = (tmp103_fu_2583_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_3_fu_2373_p2() {
    tmp_12_3_fu_2373_p2 = (tmp94_fu_2367_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_3_s_fu_2613_p2() {
    tmp_12_3_s_fu_2613_p2 = (tmp104_fu_2607_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_4_10_fu_3175_p2() {
    tmp_12_4_10_fu_3175_p2 = (tmp136_fu_3169_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_4_11_fu_3199_p2() {
    tmp_12_4_11_fu_3199_p2 = (tmp137_fu_3193_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_4_12_fu_3223_p2() {
    tmp_12_4_12_fu_3223_p2 = (tmp138_fu_3217_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_4_13_fu_3247_p2() {
    tmp_12_4_13_fu_3247_p2 = (tmp139_fu_3241_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_4_14_fu_3271_p2() {
    tmp_12_4_14_fu_3271_p2 = (tmp140_fu_3265_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_4_1_fu_2935_p2() {
    tmp_12_4_1_fu_2935_p2 = (tmp126_fu_2929_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_4_2_fu_2959_p2() {
    tmp_12_4_2_fu_2959_p2 = (tmp127_fu_2953_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_4_3_fu_2983_p2() {
    tmp_12_4_3_fu_2983_p2 = (tmp128_fu_2977_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_4_4_fu_3007_p2() {
    tmp_12_4_4_fu_3007_p2 = (tmp129_fu_3001_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_4_5_fu_3031_p2() {
    tmp_12_4_5_fu_3031_p2 = (tmp130_fu_3025_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_4_6_fu_3055_p2() {
    tmp_12_4_6_fu_3055_p2 = (tmp131_fu_3049_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_4_7_fu_3079_p2() {
    tmp_12_4_7_fu_3079_p2 = (tmp132_fu_3073_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_4_8_fu_3103_p2() {
    tmp_12_4_8_fu_3103_p2 = (tmp133_fu_3097_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_4_9_fu_3127_p2() {
    tmp_12_4_9_fu_3127_p2 = (tmp134_fu_3121_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_4_fu_2911_p2() {
    tmp_12_4_fu_2911_p2 = (tmp125_fu_2905_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_4_s_fu_3151_p2() {
    tmp_12_4_s_fu_3151_p2 = (tmp135_fu_3145_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_5_10_fu_3713_p2() {
    tmp_12_5_10_fu_3713_p2 = (tmp167_fu_3707_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_5_11_fu_3737_p2() {
    tmp_12_5_11_fu_3737_p2 = (tmp168_fu_3731_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_5_12_fu_3761_p2() {
    tmp_12_5_12_fu_3761_p2 = (tmp169_fu_3755_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_5_13_fu_3785_p2() {
    tmp_12_5_13_fu_3785_p2 = (tmp170_fu_3779_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_5_14_fu_3809_p2() {
    tmp_12_5_14_fu_3809_p2 = (tmp171_fu_3803_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_5_1_fu_3473_p2() {
    tmp_12_5_1_fu_3473_p2 = (tmp157_fu_3467_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_5_2_fu_3497_p2() {
    tmp_12_5_2_fu_3497_p2 = (tmp158_fu_3491_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_5_3_fu_3521_p2() {
    tmp_12_5_3_fu_3521_p2 = (tmp159_fu_3515_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_5_4_fu_3545_p2() {
    tmp_12_5_4_fu_3545_p2 = (tmp160_fu_3539_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_5_5_fu_3569_p2() {
    tmp_12_5_5_fu_3569_p2 = (tmp161_fu_3563_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_5_6_fu_3593_p2() {
    tmp_12_5_6_fu_3593_p2 = (tmp162_fu_3587_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_5_7_fu_3617_p2() {
    tmp_12_5_7_fu_3617_p2 = (tmp163_fu_3611_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_5_8_fu_3641_p2() {
    tmp_12_5_8_fu_3641_p2 = (tmp164_fu_3635_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_5_9_fu_3665_p2() {
    tmp_12_5_9_fu_3665_p2 = (tmp165_fu_3659_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_5_fu_3449_p2() {
    tmp_12_5_fu_3449_p2 = (tmp156_fu_3443_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_5_s_fu_3689_p2() {
    tmp_12_5_s_fu_3689_p2 = (tmp166_fu_3683_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_6_10_fu_4251_p2() {
    tmp_12_6_10_fu_4251_p2 = (tmp198_fu_4245_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_6_11_fu_4275_p2() {
    tmp_12_6_11_fu_4275_p2 = (tmp199_fu_4269_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_6_12_fu_4299_p2() {
    tmp_12_6_12_fu_4299_p2 = (tmp200_fu_4293_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_6_13_fu_4323_p2() {
    tmp_12_6_13_fu_4323_p2 = (tmp201_fu_4317_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_6_14_fu_4347_p2() {
    tmp_12_6_14_fu_4347_p2 = (tmp202_fu_4341_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_6_1_fu_4011_p2() {
    tmp_12_6_1_fu_4011_p2 = (tmp188_fu_4005_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_6_2_fu_4035_p2() {
    tmp_12_6_2_fu_4035_p2 = (tmp189_fu_4029_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_6_3_fu_4059_p2() {
    tmp_12_6_3_fu_4059_p2 = (tmp190_fu_4053_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_6_4_fu_4083_p2() {
    tmp_12_6_4_fu_4083_p2 = (tmp191_fu_4077_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_6_5_fu_4107_p2() {
    tmp_12_6_5_fu_4107_p2 = (tmp192_fu_4101_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_6_6_fu_4131_p2() {
    tmp_12_6_6_fu_4131_p2 = (tmp193_fu_4125_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_6_7_fu_4155_p2() {
    tmp_12_6_7_fu_4155_p2 = (tmp194_fu_4149_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_6_8_fu_4179_p2() {
    tmp_12_6_8_fu_4179_p2 = (tmp195_fu_4173_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_6_9_fu_4203_p2() {
    tmp_12_6_9_fu_4203_p2 = (tmp196_fu_4197_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_6_fu_3987_p2() {
    tmp_12_6_fu_3987_p2 = (tmp187_fu_3981_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_6_s_fu_4227_p2() {
    tmp_12_6_s_fu_4227_p2 = (tmp197_fu_4221_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_7_10_fu_4789_p2() {
    tmp_12_7_10_fu_4789_p2 = (tmp229_fu_4783_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_7_11_fu_4813_p2() {
    tmp_12_7_11_fu_4813_p2 = (tmp230_fu_4807_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_7_12_fu_4837_p2() {
    tmp_12_7_12_fu_4837_p2 = (tmp231_fu_4831_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_7_13_fu_4861_p2() {
    tmp_12_7_13_fu_4861_p2 = (tmp232_fu_4855_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_7_14_fu_4885_p2() {
    tmp_12_7_14_fu_4885_p2 = (tmp233_fu_4879_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_7_1_fu_4549_p2() {
    tmp_12_7_1_fu_4549_p2 = (tmp219_fu_4543_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_7_2_fu_4573_p2() {
    tmp_12_7_2_fu_4573_p2 = (tmp220_fu_4567_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_7_3_fu_4597_p2() {
    tmp_12_7_3_fu_4597_p2 = (tmp221_fu_4591_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_7_4_fu_4621_p2() {
    tmp_12_7_4_fu_4621_p2 = (tmp222_fu_4615_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_7_5_fu_4645_p2() {
    tmp_12_7_5_fu_4645_p2 = (tmp223_fu_4639_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_7_6_fu_4669_p2() {
    tmp_12_7_6_fu_4669_p2 = (tmp224_fu_4663_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_7_7_fu_4693_p2() {
    tmp_12_7_7_fu_4693_p2 = (tmp225_fu_4687_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_7_8_fu_4717_p2() {
    tmp_12_7_8_fu_4717_p2 = (tmp226_fu_4711_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_7_9_fu_4741_p2() {
    tmp_12_7_9_fu_4741_p2 = (tmp227_fu_4735_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_7_fu_4525_p2() {
    tmp_12_7_fu_4525_p2 = (tmp218_fu_4519_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_7_s_fu_4765_p2() {
    tmp_12_7_s_fu_4765_p2 = (tmp228_fu_4759_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_8_10_fu_5327_p2() {
    tmp_12_8_10_fu_5327_p2 = (tmp260_fu_5321_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_8_11_fu_5351_p2() {
    tmp_12_8_11_fu_5351_p2 = (tmp261_fu_5345_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_8_12_fu_5375_p2() {
    tmp_12_8_12_fu_5375_p2 = (tmp262_fu_5369_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_8_13_fu_5399_p2() {
    tmp_12_8_13_fu_5399_p2 = (tmp263_fu_5393_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_8_14_fu_5423_p2() {
    tmp_12_8_14_fu_5423_p2 = (tmp264_fu_5417_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_8_1_fu_5087_p2() {
    tmp_12_8_1_fu_5087_p2 = (tmp250_fu_5081_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_8_2_fu_5111_p2() {
    tmp_12_8_2_fu_5111_p2 = (tmp251_fu_5105_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_8_3_fu_5135_p2() {
    tmp_12_8_3_fu_5135_p2 = (tmp252_fu_5129_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_8_4_fu_5159_p2() {
    tmp_12_8_4_fu_5159_p2 = (tmp253_fu_5153_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_8_5_fu_5183_p2() {
    tmp_12_8_5_fu_5183_p2 = (tmp254_fu_5177_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_8_6_fu_5207_p2() {
    tmp_12_8_6_fu_5207_p2 = (tmp255_fu_5201_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_8_7_fu_5231_p2() {
    tmp_12_8_7_fu_5231_p2 = (tmp256_fu_5225_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_8_8_fu_5255_p2() {
    tmp_12_8_8_fu_5255_p2 = (tmp257_fu_5249_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_8_9_fu_5279_p2() {
    tmp_12_8_9_fu_5279_p2 = (tmp258_fu_5273_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_8_fu_5063_p2() {
    tmp_12_8_fu_5063_p2 = (tmp249_fu_5057_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_8_s_fu_5303_p2() {
    tmp_12_8_s_fu_5303_p2 = (tmp259_fu_5297_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_9_10_fu_5865_p2() {
    tmp_12_9_10_fu_5865_p2 = (tmp291_fu_5859_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_9_11_fu_5889_p2() {
    tmp_12_9_11_fu_5889_p2 = (tmp292_fu_5883_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_9_12_fu_5913_p2() {
    tmp_12_9_12_fu_5913_p2 = (tmp293_fu_5907_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_9_13_fu_5937_p2() {
    tmp_12_9_13_fu_5937_p2 = (tmp294_fu_5931_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_9_14_fu_5961_p2() {
    tmp_12_9_14_fu_5961_p2 = (tmp295_fu_5955_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_9_1_fu_5625_p2() {
    tmp_12_9_1_fu_5625_p2 = (tmp281_fu_5619_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_9_2_fu_5649_p2() {
    tmp_12_9_2_fu_5649_p2 = (tmp282_fu_5643_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_9_3_fu_5673_p2() {
    tmp_12_9_3_fu_5673_p2 = (tmp283_fu_5667_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_9_4_fu_5697_p2() {
    tmp_12_9_4_fu_5697_p2 = (tmp284_fu_5691_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_9_5_fu_5721_p2() {
    tmp_12_9_5_fu_5721_p2 = (tmp285_fu_5715_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_9_6_fu_5745_p2() {
    tmp_12_9_6_fu_5745_p2 = (tmp286_fu_5739_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_9_7_fu_5769_p2() {
    tmp_12_9_7_fu_5769_p2 = (tmp287_fu_5763_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_9_8_fu_5793_p2() {
    tmp_12_9_8_fu_5793_p2 = (tmp288_fu_5787_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_9_9_fu_5817_p2() {
    tmp_12_9_9_fu_5817_p2 = (tmp289_fu_5811_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_9_fu_5601_p2() {
    tmp_12_9_fu_5601_p2 = (tmp280_fu_5595_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_12_9_s_fu_5841_p2() {
    tmp_12_9_s_fu_5841_p2 = (tmp290_fu_5835_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_174_fu_344_p1() {
    tmp_174_fu_344_p1 = sf_fu_218.read().range(2-1, 0);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_176_fu_599_p1() {
    tmp_176_fu_599_p1 = tile_assign_fu_214.read().range(2-1, 0);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_3_fu_639_p2() {
    tmp_3_fu_639_p2 = (tmp1_fu_633_p2.read() ^ ap_const_lv1_1);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_4_fu_451_p2() {
    tmp_4_fu_451_p2 = (!sf_fu_218.read().is_01() || !ap_const_lv32_0.is_01())? sc_lv<1>(): sc_lv<1>(sf_fu_218.read() == ap_const_lv32_0);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_fu_305_p2() {
    tmp_fu_305_p2 = (!nf_fu_222.read().is_01() || !ap_const_lv32_0.is_01())? sc_lv<1>(): sc_lv<1>(nf_fu_222.read() == ap_const_lv32_0);
}

void StreamingFCLayer_Batch_3_Matrix_Vector_Activa::thread_tmp_s_fu_463_p2() {
    tmp_s_fu_463_p2 = (!sf_1_fu_457_p2.read().is_01() || !ap_const_lv32_4.is_01())? sc_lv<1>(): sc_lv<1>(sf_1_fu_457_p2.read() == ap_const_lv32_4);
}

}

