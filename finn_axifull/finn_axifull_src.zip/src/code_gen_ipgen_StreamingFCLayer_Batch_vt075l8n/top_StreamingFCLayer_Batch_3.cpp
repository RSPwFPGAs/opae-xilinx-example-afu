
#define AP_INT_MAX_W 4096
#include "bnn-library.h"
// includes for network parameters
#include "weights.hpp"
#include "activations.hpp"
#include "params.h"

// defines for network parameters
#define MW1 64
 #define MH1 10
 #define SIMD1 16

            #define PE1 10
 #define WMEM1 4
 #define TMEM1 0

            #define numReps 1
#define PRAGMA_SUB(x) _Pragma (#x)
#define DO_PRAGMA(x) PRAGMA_SUB(x)

void StreamingFCLayer_Batch_3(hls::stream<ap_uint<16>> &in0,
                hls::stream<ap_uint<320>> &out
                )
{
#pragma HLS INTERFACE axis port=in0
#pragma HLS INTERFACE axis port=out
#pragma HLS stream depth=50 variable=out
#pragma HLS INTERFACE ap_ctrl_none port=return
DO_PRAGMA(HLS ARRAY_PARTITION variable=weights.m_weights complete dim=1)
StreamingFCLayer_Batch<MW1, MH1, SIMD1, PE1, Recast<XnorMul>, Slice<ap_uint<32>>, Identity>
            (in0, out, weights, PassThroughActivation<ap_uint<32>>(), numReps, ap_resource_lut());
}
