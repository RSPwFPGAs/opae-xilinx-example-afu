#!/bin/bash 
cd /workspace/finn/tmp/finn_user-bibo/code_gen_ipgen_TLastMarker_e8g_u1rq
vivado_hls /workspace/finn/tmp/finn_user-bibo/code_gen_ipgen_TLastMarker_e8g_u1rq/hls_syn_TLastMarker_0.tcl
cd /workspace/finn
