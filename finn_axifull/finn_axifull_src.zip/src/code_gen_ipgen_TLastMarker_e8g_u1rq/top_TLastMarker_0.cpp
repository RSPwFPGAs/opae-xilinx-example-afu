
#define AP_INT_MAX_W 4096
#include "bnn-library.h"
// includes for network parameters
#include "ap_axi_sdata.h"

// defines for network parameters
#define StreamWidth 320
#define OutDType qdma_axis<320,0,0,0>
#define NumIters 1

void TLastMarker_0(hls::stream<ap_uint<StreamWidth> > &in0,
                hls::stream<OutDType> &out)
{
#pragma HLS INTERFACE axis port=in0
#pragma HLS INTERFACE axis port=out
#pragma HLS INTERFACE ap_ctrl_none port=return
for(int i=0; i<NumIters; i++) {
#pragma HLS PIPELINE II=1
OutDType t;
t.set_data(in0.read());
t.set_keep(-1);
t.set_last(i==(NumIters-1));
out.write(t);
}
}
