#include "compute.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void compute::thread_a_tensor_0_0_V_1_fu_10966_p3() {
    a_tensor_0_0_V_1_fu_10966_p3 = (!tmp_13_reg_14008.read()[0].is_01())? sc_lv<32>(): ((tmp_13_reg_14008.read()[0].to_bool())? ap_const_lv32_0: accum_V_2_reg_18882.read());
}

void compute::thread_a_tensor_0_0_V_fu_10563_p1() {
    a_tensor_0_0_V_fu_10563_p1 = acc_mem_V_q1.read().range(32-1, 0);
}

void compute::thread_a_tensor_0_11_V_1_fu_11032_p3() {
    a_tensor_0_11_V_1_fu_11032_p3 = (!tmp_13_reg_14008.read()[0].is_01())? sc_lv<32>(): ((tmp_13_reg_14008.read()[0].to_bool())? ap_const_lv32_0: accum_V_2_0_10_reg_18992.read());
}

void compute::thread_a_tensor_0_12_V_1_fu_11038_p3() {
    a_tensor_0_12_V_1_fu_11038_p3 = (!tmp_13_reg_14008.read()[0].is_01())? sc_lv<32>(): ((tmp_13_reg_14008.read()[0].to_bool())? ap_const_lv32_0: accum_V_2_0_11_reg_19002.read());
}

void compute::thread_a_tensor_0_13_V_1_fu_11044_p3() {
    a_tensor_0_13_V_1_fu_11044_p3 = (!tmp_13_reg_14008.read()[0].is_01())? sc_lv<32>(): ((tmp_13_reg_14008.read()[0].to_bool())? ap_const_lv32_0: accum_V_2_0_12_reg_19012.read());
}

void compute::thread_a_tensor_0_14_V_1_fu_11050_p3() {
    a_tensor_0_14_V_1_fu_11050_p3 = (!tmp_13_reg_14008.read()[0].is_01())? sc_lv<32>(): ((tmp_13_reg_14008.read()[0].to_bool())? ap_const_lv32_0: accum_V_2_0_13_reg_19022.read());
}

void compute::thread_a_tensor_0_15_V_1_fu_11056_p3() {
    a_tensor_0_15_V_1_fu_11056_p3 = (!tmp_13_reg_14008.read()[0].is_01())? sc_lv<32>(): ((tmp_13_reg_14008.read()[0].to_bool())? ap_const_lv32_0: accum_V_2_0_14_reg_19032.read());
}

void compute::thread_a_tensor_0_1_V_1_fu_10972_p3() {
    a_tensor_0_1_V_1_fu_10972_p3 = (!tmp_13_reg_14008.read()[0].is_01())? sc_lv<32>(): ((tmp_13_reg_14008.read()[0].to_bool())? ap_const_lv32_0: accum_V_2_0_1_reg_18892.read());
}

void compute::thread_a_tensor_0_2_V_1_fu_10978_p3() {
    a_tensor_0_2_V_1_fu_10978_p3 = (!tmp_13_reg_14008.read()[0].is_01())? sc_lv<32>(): ((tmp_13_reg_14008.read()[0].to_bool())? ap_const_lv32_0: accum_V_2_0_2_reg_18902.read());
}

void compute::thread_a_tensor_0_3_V_1_fu_10984_p3() {
    a_tensor_0_3_V_1_fu_10984_p3 = (!tmp_13_reg_14008.read()[0].is_01())? sc_lv<32>(): ((tmp_13_reg_14008.read()[0].to_bool())? ap_const_lv32_0: accum_V_2_0_3_reg_18912.read());
}

void compute::thread_a_tensor_0_4_V_1_fu_10990_p3() {
    a_tensor_0_4_V_1_fu_10990_p3 = (!tmp_13_reg_14008.read()[0].is_01())? sc_lv<32>(): ((tmp_13_reg_14008.read()[0].to_bool())? ap_const_lv32_0: accum_V_2_0_4_reg_18922.read());
}

void compute::thread_acc_mem_V_address0() {
    if ((esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter15.read()))) {
        acc_mem_V_address0 = acc_mem_V_addr_1_reg_18311_pp1_iter14_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()))) {
        acc_mem_V_address0 = acc_mem_V_addr_3_reg_13027_pp0_iter6_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter3.read()))) {
        acc_mem_V_address0 =  (sc_lv<11>) (tmp_55_fu_2090_p1.read());
    } else {
        acc_mem_V_address0 = "XXXXXXXXXXX";
    }
}

void compute::thread_acc_mem_V_address1() {
    if ((esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()))) {
        acc_mem_V_address1 =  (sc_lv<11>) (tmp_216_cast_fu_11318_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter11.read()))) {
        acc_mem_V_address1 =  (sc_lv<11>) (tmp_47_fu_9407_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter3.read()))) {
        acc_mem_V_address1 =  (sc_lv<11>) (tmp_56_fu_2094_p1.read());
    } else {
        acc_mem_V_address1 = "XXXXXXXXXXX";
    }
}

void compute::thread_acc_mem_V_ce0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter4.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter3.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter3.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter15.read())))) {
        acc_mem_V_ce0 = ap_const_logic_1;
    } else {
        acc_mem_V_ce0 = ap_const_logic_0;
    }
}

void compute::thread_acc_mem_V_ce1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter4.read())) || 
         (esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter13.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter3.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter3.read())) || 
         (esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter11.read())) || 
         (esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter12.read())) || 
         (esl_seteq<1,1,1>(ap_block_pp2_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read())))) {
        acc_mem_V_ce1 = ap_const_logic_1;
    } else {
        acc_mem_V_ce1 = ap_const_logic_0;
    }
}

void compute::thread_acc_mem_V_d0() {
    if ((esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter15.read()))) {
        acc_mem_V_d0 = tmp_48_fu_11062_p17.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()))) {
        acc_mem_V_d0 = tmp_60_fu_4398_p17.read();
    } else {
        acc_mem_V_d0 =  (sc_lv<512>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void compute::thread_acc_mem_V_d1() {
    acc_mem_V_d1 = (tmp_366_fu_11331_p3.read() & p_demorgan_reg_19115.read());
}

void compute::thread_acc_mem_V_we0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, exitcond_flatten3_reg_12909_pp0_iter6_reg.read())) || 
         (esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter15.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, exitcond_flatten1_reg_14063_pp1_iter14_reg.read())))) {
        acc_mem_V_we0 = ap_const_lv64_FFFFFFFFFFFFFFFF;
    } else {
        acc_mem_V_we0 = ap_const_lv64_0;
    }
}

void compute::thread_acc_mem_V_we1() {
    if ((esl_seteq<1,1,1>(ap_block_pp2_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, exitcond1_reg_19066_pp2_iter2_reg.read()))) {
        acc_mem_V_we1 = mask_reg_19120.read();
    } else {
        acc_mem_V_we1 = ap_const_lv64_0;
    }
}

void compute::thread_accum_V_2_0_10_fu_10904_p2() {
    accum_V_2_0_10_fu_10904_p2 = (!p_0264_0_i_0_10_fu_10901_p1.read().is_01() || !reg_1624.read().is_01())? sc_lv<32>(): (sc_bigint<32>(p_0264_0_i_0_10_fu_10901_p1.read()) + sc_biguint<32>(reg_1624.read()));
}

void compute::thread_accum_V_2_0_11_fu_10917_p2() {
    accum_V_2_0_11_fu_10917_p2 = (!p_0264_0_i_0_11_fu_10914_p1.read().is_01() || !reg_1628.read().is_01())? sc_lv<32>(): (sc_bigint<32>(p_0264_0_i_0_11_fu_10914_p1.read()) + sc_biguint<32>(reg_1628.read()));
}

void compute::thread_accum_V_2_0_12_fu_10930_p2() {
    accum_V_2_0_12_fu_10930_p2 = (!p_0264_0_i_0_12_fu_10927_p1.read().is_01() || !reg_1632.read().is_01())? sc_lv<32>(): (sc_bigint<32>(p_0264_0_i_0_12_fu_10927_p1.read()) + sc_biguint<32>(reg_1632.read()));
}

void compute::thread_accum_V_2_0_13_fu_10943_p2() {
    accum_V_2_0_13_fu_10943_p2 = (!p_0264_0_i_0_13_fu_10940_p1.read().is_01() || !reg_1636.read().is_01())? sc_lv<32>(): (sc_bigint<32>(p_0264_0_i_0_13_fu_10940_p1.read()) + sc_biguint<32>(reg_1636.read()));
}

void compute::thread_accum_V_2_0_14_fu_10956_p2() {
    accum_V_2_0_14_fu_10956_p2 = (!p_0264_0_i_0_14_fu_10953_p1.read().is_01() || !reg_1640.read().is_01())? sc_lv<32>(): (sc_bigint<32>(p_0264_0_i_0_14_fu_10953_p1.read()) + sc_biguint<32>(reg_1640.read()));
}

void compute::thread_accum_V_2_0_1_fu_10774_p2() {
    accum_V_2_0_1_fu_10774_p2 = (!p_0264_0_i_0_1_fu_10771_p1.read().is_01() || !reg_1584.read().is_01())? sc_lv<32>(): (sc_bigint<32>(p_0264_0_i_0_1_fu_10771_p1.read()) + sc_biguint<32>(reg_1584.read()));
}

void compute::thread_accum_V_2_0_2_fu_10787_p2() {
    accum_V_2_0_2_fu_10787_p2 = (!p_0264_0_i_0_2_fu_10784_p1.read().is_01() || !reg_1588.read().is_01())? sc_lv<32>(): (sc_bigint<32>(p_0264_0_i_0_2_fu_10784_p1.read()) + sc_biguint<32>(reg_1588.read()));
}

void compute::thread_accum_V_2_0_3_fu_10800_p2() {
    accum_V_2_0_3_fu_10800_p2 = (!p_0264_0_i_0_3_fu_10797_p1.read().is_01() || !reg_1592.read().is_01())? sc_lv<32>(): (sc_bigint<32>(p_0264_0_i_0_3_fu_10797_p1.read()) + sc_biguint<32>(reg_1592.read()));
}

void compute::thread_accum_V_2_0_4_fu_10813_p2() {
    accum_V_2_0_4_fu_10813_p2 = (!p_0264_0_i_0_4_fu_10810_p1.read().is_01() || !reg_1596.read().is_01())? sc_lv<32>(): (sc_bigint<32>(p_0264_0_i_0_4_fu_10810_p1.read()) + sc_biguint<32>(reg_1596.read()));
}

void compute::thread_accum_V_2_0_5_fu_10826_p2() {
    accum_V_2_0_5_fu_10826_p2 = (!p_0264_0_i_0_5_fu_10823_p1.read().is_01() || !reg_1600.read().is_01())? sc_lv<32>(): (sc_bigint<32>(p_0264_0_i_0_5_fu_10823_p1.read()) + sc_biguint<32>(reg_1600.read()));
}

void compute::thread_accum_V_2_0_6_fu_10839_p2() {
    accum_V_2_0_6_fu_10839_p2 = (!p_0264_0_i_0_6_fu_10836_p1.read().is_01() || !reg_1604.read().is_01())? sc_lv<32>(): (sc_bigint<32>(p_0264_0_i_0_6_fu_10836_p1.read()) + sc_biguint<32>(reg_1604.read()));
}

void compute::thread_accum_V_2_0_7_fu_10852_p2() {
    accum_V_2_0_7_fu_10852_p2 = (!p_0264_0_i_0_7_fu_10849_p1.read().is_01() || !reg_1608.read().is_01())? sc_lv<32>(): (sc_bigint<32>(p_0264_0_i_0_7_fu_10849_p1.read()) + sc_biguint<32>(reg_1608.read()));
}

void compute::thread_accum_V_2_0_8_fu_10865_p2() {
    accum_V_2_0_8_fu_10865_p2 = (!p_0264_0_i_0_8_fu_10862_p1.read().is_01() || !reg_1612.read().is_01())? sc_lv<32>(): (sc_bigint<32>(p_0264_0_i_0_8_fu_10862_p1.read()) + sc_biguint<32>(reg_1612.read()));
}

void compute::thread_accum_V_2_0_9_fu_10878_p2() {
    accum_V_2_0_9_fu_10878_p2 = (!p_0264_0_i_0_9_fu_10875_p1.read().is_01() || !reg_1616.read().is_01())? sc_lv<32>(): (sc_bigint<32>(p_0264_0_i_0_9_fu_10875_p1.read()) + sc_biguint<32>(reg_1616.read()));
}

void compute::thread_accum_V_2_0_s_fu_10891_p2() {
    accum_V_2_0_s_fu_10891_p2 = (!p_0264_0_i_0_s_fu_10888_p1.read().is_01() || !reg_1620.read().is_01())? sc_lv<32>(): (sc_bigint<32>(p_0264_0_i_0_s_fu_10888_p1.read()) + sc_biguint<32>(reg_1620.read()));
}

void compute::thread_accum_V_2_fu_10762_p2() {
    accum_V_2_fu_10762_p2 = (!p_0264_0_i_fu_10759_p1.read().is_01() || !a_tensor_0_0_V_reg_18797.read().is_01())? sc_lv<32>(): (sc_bigint<32>(p_0264_0_i_fu_10759_p1.read()) + sc_biguint<32>(a_tensor_0_0_V_reg_18797.read()));
}

void compute::thread_ap_CS_fsm_pp0_stage0() {
    ap_CS_fsm_pp0_stage0 = ap_CS_fsm.read()[15];
}

void compute::thread_ap_CS_fsm_pp0_stage1() {
    ap_CS_fsm_pp0_stage1 = ap_CS_fsm.read()[16];
}

void compute::thread_ap_CS_fsm_pp1_stage0() {
    ap_CS_fsm_pp1_stage0 = ap_CS_fsm.read()[32];
}

void compute::thread_ap_CS_fsm_pp2_stage0() {
    ap_CS_fsm_pp2_stage0 = ap_CS_fsm.read()[41];
}

void compute::thread_ap_CS_fsm_pp3_stage0() {
    ap_CS_fsm_pp3_stage0 = ap_CS_fsm.read()[51];
}

void compute::thread_ap_CS_fsm_state1() {
    ap_CS_fsm_state1 = ap_CS_fsm.read()[0];
}

void compute::thread_ap_CS_fsm_state10() {
    ap_CS_fsm_state10 = ap_CS_fsm.read()[9];
}

void compute::thread_ap_CS_fsm_state15() {
    ap_CS_fsm_state15 = ap_CS_fsm.read()[14];
}

void compute::thread_ap_CS_fsm_state2() {
    ap_CS_fsm_state2 = ap_CS_fsm.read()[1];
}

void compute::thread_ap_CS_fsm_state3() {
    ap_CS_fsm_state3 = ap_CS_fsm.read()[2];
}

void compute::thread_ap_CS_fsm_state30() {
    ap_CS_fsm_state30 = ap_CS_fsm.read()[17];
}

void compute::thread_ap_CS_fsm_state31() {
    ap_CS_fsm_state31 = ap_CS_fsm.read()[18];
}

void compute::thread_ap_CS_fsm_state32() {
    ap_CS_fsm_state32 = ap_CS_fsm.read()[19];
}

void compute::thread_ap_CS_fsm_state38() {
    ap_CS_fsm_state38 = ap_CS_fsm.read()[25];
}

void compute::thread_ap_CS_fsm_state39() {
    ap_CS_fsm_state39 = ap_CS_fsm.read()[26];
}

void compute::thread_ap_CS_fsm_state44() {
    ap_CS_fsm_state44 = ap_CS_fsm.read()[31];
}

void compute::thread_ap_CS_fsm_state61() {
    ap_CS_fsm_state61 = ap_CS_fsm.read()[33];
}

void compute::thread_ap_CS_fsm_state62() {
    ap_CS_fsm_state62 = ap_CS_fsm.read()[34];
}

void compute::thread_ap_CS_fsm_state68() {
    ap_CS_fsm_state68 = ap_CS_fsm.read()[40];
}

void compute::thread_ap_CS_fsm_state73() {
    ap_CS_fsm_state73 = ap_CS_fsm.read()[42];
}

void compute::thread_ap_CS_fsm_state74() {
    ap_CS_fsm_state74 = ap_CS_fsm.read()[43];
}

void compute::thread_ap_CS_fsm_state75() {
    ap_CS_fsm_state75 = ap_CS_fsm.read()[44];
}

void compute::thread_ap_CS_fsm_state81() {
    ap_CS_fsm_state81 = ap_CS_fsm.read()[50];
}

void compute::thread_ap_CS_fsm_state86() {
    ap_CS_fsm_state86 = ap_CS_fsm.read()[53];
}

void compute::thread_ap_CS_fsm_state87() {
    ap_CS_fsm_state87 = ap_CS_fsm.read()[54];
}

void compute::thread_ap_CS_fsm_state88() {
    ap_CS_fsm_state88 = ap_CS_fsm.read()[55];
}

void compute::thread_ap_CS_fsm_state9() {
    ap_CS_fsm_state9 = ap_CS_fsm.read()[8];
}

void compute::thread_ap_block_pp0() {
    ap_block_pp0 = ((esl_seteq<1,56,56>(ap_ST_fsm_pp0_stage0, ap_CS_fsm.read()) && 
  esl_seteq<1,1,1>(ap_const_boolean_1, ap_block_pp0_stage0_subdone.read())) || (esl_seteq<1,56,56>(ap_ST_fsm_pp0_stage1, ap_CS_fsm.read()) && 
  esl_seteq<1,1,1>(ap_const_boolean_1, ap_block_pp0_stage1_subdone.read())));
}

void compute::thread_ap_block_pp0_stage0() {
    ap_block_pp0_stage0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void compute::thread_ap_block_pp0_stage0_11001() {
    ap_block_pp0_stage0_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void compute::thread_ap_block_pp0_stage0_subdone() {
    ap_block_pp0_stage0_subdone = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void compute::thread_ap_block_pp0_stage1() {
    ap_block_pp0_stage1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void compute::thread_ap_block_pp0_stage1_11001() {
    ap_block_pp0_stage1_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void compute::thread_ap_block_pp0_stage1_subdone() {
    ap_block_pp0_stage1_subdone = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void compute::thread_ap_block_pp1() {
    ap_block_pp1 = (esl_seteq<1,56,56>(ap_ST_fsm_pp1_stage0, ap_CS_fsm.read()) && esl_seteq<1,1,1>(ap_const_boolean_1, ap_block_pp1_stage0_subdone.read()));
}

void compute::thread_ap_block_pp1_stage0() {
    ap_block_pp1_stage0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void compute::thread_ap_block_pp1_stage0_11001() {
    ap_block_pp1_stage0_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void compute::thread_ap_block_pp1_stage0_subdone() {
    ap_block_pp1_stage0_subdone = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void compute::thread_ap_block_pp2() {
    ap_block_pp2 = (esl_seteq<1,56,56>(ap_ST_fsm_pp2_stage0, ap_CS_fsm.read()) && esl_seteq<1,1,1>(ap_const_boolean_1, ap_block_pp2_stage0_subdone.read()));
}

void compute::thread_ap_block_pp2_stage0() {
    ap_block_pp2_stage0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void compute::thread_ap_block_pp2_stage0_11001() {
    ap_block_pp2_stage0_11001 = (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && esl_seteq<1,1,1>(ap_const_lv1_0, exitcond1_reg_19066.read()) && esl_seteq<1,1,1>(ap_const_logic_0, data_port_RVALID.read()));
}

void compute::thread_ap_block_pp2_stage0_subdone() {
    ap_block_pp2_stage0_subdone = (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && esl_seteq<1,1,1>(ap_const_lv1_0, exitcond1_reg_19066.read()) && esl_seteq<1,1,1>(ap_const_logic_0, data_port_RVALID.read()));
}

void compute::thread_ap_block_pp3() {
    ap_block_pp3 = (esl_seteq<1,56,56>(ap_ST_fsm_pp3_stage0, ap_CS_fsm.read()) && esl_seteq<1,1,1>(ap_const_boolean_1, ap_block_pp3_stage0_subdone.read()));
}

void compute::thread_ap_block_pp3_stage0() {
    ap_block_pp3_stage0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void compute::thread_ap_block_pp3_stage0_11001() {
    ap_block_pp3_stage0_11001 = (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter1.read()) && esl_seteq<1,1,1>(ap_const_lv1_0, exitcond_reg_19151.read()) && esl_seteq<1,1,1>(ap_const_logic_0, uop_port_RVALID.read()));
}

void compute::thread_ap_block_pp3_stage0_subdone() {
    ap_block_pp3_stage0_subdone = (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter1.read()) && esl_seteq<1,1,1>(ap_const_lv1_0, exitcond_reg_19151.read()) && esl_seteq<1,1,1>(ap_const_logic_0, uop_port_RVALID.read()));
}

void compute::thread_ap_block_state1() {
    ap_block_state1 = (esl_seteq<1,1,1>(ap_const_logic_0, ap_start.read()) || esl_seteq<1,1,1>(ap_const_logic_0, gemm_queue_V_V_0_vld_out.read()) || (esl_seteq<1,1,1>(ap_const_lv1_1, tmp_2_fu_1682_p3.read()) && 
  esl_seteq<1,1,1>(ap_const_logic_0, l2g_dep_queue_V_0_vld_out.read())) || (esl_seteq<1,1,1>(ap_const_lv1_1, tmp_3_fu_1690_p3.read()) && 
  esl_seteq<1,1,1>(ap_const_logic_0, s2g_dep_queue_V_0_vld_out.read())));
}

void compute::thread_ap_block_state16_pp0_stage0_iter0() {
    ap_block_state16_pp0_stage0_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void compute::thread_ap_block_state17_pp0_stage1_iter0() {
    ap_block_state17_pp0_stage1_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void compute::thread_ap_block_state18_pp0_stage0_iter1() {
    ap_block_state18_pp0_stage0_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void compute::thread_ap_block_state19_pp0_stage1_iter1() {
    ap_block_state19_pp0_stage1_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void compute::thread_ap_block_state20_pp0_stage0_iter2() {
    ap_block_state20_pp0_stage0_iter2 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void compute::thread_ap_block_state21_pp0_stage1_iter2() {
    ap_block_state21_pp0_stage1_iter2 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void compute::thread_ap_block_state22_pp0_stage0_iter3() {
    ap_block_state22_pp0_stage0_iter3 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void compute::thread_ap_block_state23_pp0_stage1_iter3() {
    ap_block_state23_pp0_stage1_iter3 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void compute::thread_ap_block_state24_pp0_stage0_iter4() {
    ap_block_state24_pp0_stage0_iter4 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void compute::thread_ap_block_state25_pp0_stage1_iter4() {
    ap_block_state25_pp0_stage1_iter4 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void compute::thread_ap_block_state26_pp0_stage0_iter5() {
    ap_block_state26_pp0_stage0_iter5 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void compute::thread_ap_block_state27_pp0_stage1_iter5() {
    ap_block_state27_pp0_stage1_iter5 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void compute::thread_ap_block_state28_pp0_stage0_iter6() {
    ap_block_state28_pp0_stage0_iter6 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void compute::thread_ap_block_state29_pp0_stage1_iter6() {
    ap_block_state29_pp0_stage1_iter6 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void compute::thread_ap_block_state30_io() {
    ap_block_state30_io = (esl_seteq<1,1,1>(ap_const_lv1_1, tmp_372_fu_4419_p3.read()) && esl_seteq<1,1,1>(ap_const_logic_0, g2l_dep_queue_V_1_ack_in.read()));
}

void compute::thread_ap_block_state45_pp1_stage0_iter0() {
    ap_block_state45_pp1_stage0_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void compute::thread_ap_block_state46_pp1_stage0_iter1() {
    ap_block_state46_pp1_stage0_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void compute::thread_ap_block_state47_pp1_stage0_iter2() {
    ap_block_state47_pp1_stage0_iter2 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void compute::thread_ap_block_state48_pp1_stage0_iter3() {
    ap_block_state48_pp1_stage0_iter3 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void compute::thread_ap_block_state49_pp1_stage0_iter4() {
    ap_block_state49_pp1_stage0_iter4 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void compute::thread_ap_block_state50_pp1_stage0_iter5() {
    ap_block_state50_pp1_stage0_iter5 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void compute::thread_ap_block_state51_pp1_stage0_iter6() {
    ap_block_state51_pp1_stage0_iter6 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void compute::thread_ap_block_state52_pp1_stage0_iter7() {
    ap_block_state52_pp1_stage0_iter7 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void compute::thread_ap_block_state53_pp1_stage0_iter8() {
    ap_block_state53_pp1_stage0_iter8 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void compute::thread_ap_block_state54_pp1_stage0_iter9() {
    ap_block_state54_pp1_stage0_iter9 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void compute::thread_ap_block_state55_pp1_stage0_iter10() {
    ap_block_state55_pp1_stage0_iter10 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void compute::thread_ap_block_state56_pp1_stage0_iter11() {
    ap_block_state56_pp1_stage0_iter11 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void compute::thread_ap_block_state57_pp1_stage0_iter12() {
    ap_block_state57_pp1_stage0_iter12 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void compute::thread_ap_block_state58_pp1_stage0_iter13() {
    ap_block_state58_pp1_stage0_iter13 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void compute::thread_ap_block_state59_pp1_stage0_iter14() {
    ap_block_state59_pp1_stage0_iter14 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void compute::thread_ap_block_state60_pp1_stage0_iter15() {
    ap_block_state60_pp1_stage0_iter15 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void compute::thread_ap_block_state69_pp2_stage0_iter0() {
    ap_block_state69_pp2_stage0_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void compute::thread_ap_block_state70_pp2_stage0_iter1() {
    ap_block_state70_pp2_stage0_iter1 = (esl_seteq<1,1,1>(ap_const_lv1_0, exitcond1_reg_19066.read()) && esl_seteq<1,1,1>(ap_const_logic_0, data_port_RVALID.read()));
}

void compute::thread_ap_block_state71_pp2_stage0_iter2() {
    ap_block_state71_pp2_stage0_iter2 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void compute::thread_ap_block_state72_pp2_stage0_iter3() {
    ap_block_state72_pp2_stage0_iter3 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void compute::thread_ap_block_state82_pp3_stage0_iter0() {
    ap_block_state82_pp3_stage0_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void compute::thread_ap_block_state83_pp3_stage0_iter1() {
    ap_block_state83_pp3_stage0_iter1 = (esl_seteq<1,1,1>(ap_const_lv1_0, exitcond_reg_19151.read()) && esl_seteq<1,1,1>(ap_const_logic_0, uop_port_RVALID.read()));
}

void compute::thread_ap_block_state84_pp3_stage0_iter2() {
    ap_block_state84_pp3_stage0_iter2 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void compute::thread_ap_block_state87_io() {
    ap_block_state87_io = ((esl_seteq<1,1,1>(ap_const_lv1_1, tmp_372_reg_13956.read()) && 
  esl_seteq<1,1,1>(ap_const_logic_0, g2l_dep_queue_V_1_ack_in.read())) || (esl_seteq<1,1,1>(ap_const_lv1_1, tmp_373_fu_11411_p3.read()) && 
  esl_seteq<1,1,1>(ap_const_logic_0, g2s_dep_queue_V_1_ack_in.read())));
}

void compute::thread_ap_block_state88() {
    ap_block_state88 = (esl_seteq<1,1,1>(ap_const_logic_0, g2l_dep_queue_V_1_ack_in.read()) || esl_seteq<1,1,1>(ap_const_logic_0, g2s_dep_queue_V_1_ack_in.read()));
}

void compute::thread_ap_block_state88_io() {
    ap_block_state88_io = (esl_seteq<1,1,1>(ap_const_lv1_1, tmp_373_reg_19170.read()) && esl_seteq<1,1,1>(ap_const_logic_0, g2s_dep_queue_V_1_ack_in.read()));
}

void compute::thread_ap_condition_pp0_exit_iter0_state16() {
    if (esl_seteq<1,1,1>(ap_const_lv1_1, exitcond_flatten3_fu_1953_p2.read())) {
        ap_condition_pp0_exit_iter0_state16 = ap_const_logic_1;
    } else {
        ap_condition_pp0_exit_iter0_state16 = ap_const_logic_0;
    }
}

void compute::thread_ap_condition_pp1_exit_iter0_state45() {
    if (esl_seteq<1,1,1>(ap_const_lv1_1, exitcond_flatten1_fu_4538_p2.read())) {
        ap_condition_pp1_exit_iter0_state45 = ap_const_logic_1;
    } else {
        ap_condition_pp1_exit_iter0_state45 = ap_const_logic_0;
    }
}

void compute::thread_ap_condition_pp2_exit_iter0_state69() {
    if (esl_seteq<1,1,1>(ap_const_lv1_1, exitcond1_fu_11170_p2.read())) {
        ap_condition_pp2_exit_iter0_state69 = ap_const_logic_1;
    } else {
        ap_condition_pp2_exit_iter0_state69 = ap_const_logic_0;
    }
}

void compute::thread_ap_condition_pp3_exit_iter0_state82() {
    if (esl_seteq<1,1,1>(ap_const_lv1_1, exitcond_fu_11386_p2.read())) {
        ap_condition_pp3_exit_iter0_state82 = ap_const_logic_1;
    } else {
        ap_condition_pp3_exit_iter0_state82 = ap_const_logic_0;
    }
}

void compute::thread_ap_done() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state88.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, g2l_dep_queue_V_1_state.read()[0]) && 
         esl_seteq<1,1,1>(ap_const_logic_0, g2s_dep_queue_V_1_state.read()[0]) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, g2l_dep_queue_V_1_ack_in.read()) || esl_seteq<1,1,1>(ap_const_logic_0, g2s_dep_queue_V_1_ack_in.read()) || esl_seteq<1,1,1>(ap_const_boolean_1, ap_block_state88_io.read())))) {
        ap_done = ap_const_logic_1;
    } else {
        ap_done = ap_const_logic_0;
    }
}

void compute::thread_ap_enable_operation_2400() {
    ap_enable_operation_2400 = esl_seteq<1,1,1>(ap_const_lv1_0, exitcond_flatten1_reg_14063_pp1_iter10_reg.read());
}

void compute::thread_ap_enable_operation_269() {
    ap_enable_operation_269 = esl_seteq<1,1,1>(ap_const_lv1_0, exitcond_flatten3_reg_12909_pp0_iter2_reg.read());
}

void compute::thread_ap_enable_operation_2690() {
    ap_enable_operation_2690 = esl_seteq<1,1,1>(ap_const_lv1_0, exitcond_flatten1_reg_14063_pp1_iter12_reg.read());
}

void compute::thread_ap_enable_operation_272() {
    ap_enable_operation_272 = esl_seteq<1,1,1>(ap_const_lv1_0, exitcond_flatten3_reg_12909_pp0_iter2_reg.read());
}

void compute::thread_ap_enable_operation_275() {
    ap_enable_operation_275 = esl_seteq<1,1,1>(ap_const_lv1_0, exitcond_flatten3_reg_12909_pp0_iter3_reg.read());
}

void compute::thread_ap_enable_operation_2825() {
    ap_enable_operation_2825 = esl_seteq<1,1,1>(ap_const_lv1_0, exitcond_flatten1_reg_14063_pp1_iter14_reg.read());
}

void compute::thread_ap_enable_operation_292() {
    ap_enable_operation_292 = esl_seteq<1,1,1>(ap_const_lv1_0, exitcond_flatten3_reg_12909_pp0_iter3_reg.read());
}

void compute::thread_ap_enable_operation_718() {
    ap_enable_operation_718 = esl_seteq<1,1,1>(ap_const_lv1_0, exitcond_flatten3_reg_12909_pp0_iter6_reg.read());
}

void compute::thread_ap_enable_pp0() {
    ap_enable_pp0 = (ap_idle_pp0.read() ^ ap_const_logic_1);
}

void compute::thread_ap_enable_pp1() {
    ap_enable_pp1 = (ap_idle_pp1.read() ^ ap_const_logic_1);
}

void compute::thread_ap_enable_pp2() {
    ap_enable_pp2 = (ap_idle_pp2.read() ^ ap_const_logic_1);
}

void compute::thread_ap_enable_pp3() {
    ap_enable_pp3 = (ap_idle_pp3.read() ^ ap_const_logic_1);
}

void compute::thread_ap_enable_state22_pp0_iter3_stage0() {
    ap_enable_state22_pp0_iter3_stage0 = (esl_seteq<1,1,1>(ap_enable_reg_pp0_iter3.read(), ap_const_logic_1) && esl_seteq<1,1,1>(ap_CS_fsm_pp0_stage0.read(), ap_const_logic_1));
}

void compute::thread_ap_enable_state24_pp0_iter4_stage0() {
    ap_enable_state24_pp0_iter4_stage0 = (esl_seteq<1,1,1>(ap_CS_fsm_pp0_stage0.read(), ap_const_logic_1) && esl_seteq<1,1,1>(ap_enable_reg_pp0_iter4.read(), ap_const_logic_1));
}

void compute::thread_ap_enable_state29_pp0_iter6_stage1() {
    ap_enable_state29_pp0_iter6_stage1 = (esl_seteq<1,1,1>(ap_enable_reg_pp0_iter6.read(), ap_const_logic_1) && esl_seteq<1,1,1>(ap_CS_fsm_pp0_stage1.read(), ap_const_logic_1));
}

void compute::thread_ap_enable_state56_pp1_iter11_stage0() {
    ap_enable_state56_pp1_iter11_stage0 = (esl_seteq<1,1,1>(ap_enable_reg_pp1_iter11.read(), ap_const_logic_1) && esl_seteq<1,1,1>(ap_CS_fsm_pp1_stage0.read(), ap_const_logic_1));
}

void compute::thread_ap_enable_state58_pp1_iter13_stage0() {
    ap_enable_state58_pp1_iter13_stage0 = (esl_seteq<1,1,1>(ap_CS_fsm_pp1_stage0.read(), ap_const_logic_1) && esl_seteq<1,1,1>(ap_enable_reg_pp1_iter13.read(), ap_const_logic_1));
}

void compute::thread_ap_enable_state60_pp1_iter15_stage0() {
    ap_enable_state60_pp1_iter15_stage0 = (esl_seteq<1,1,1>(ap_CS_fsm_pp1_stage0.read(), ap_const_logic_1) && esl_seteq<1,1,1>(ap_enable_reg_pp1_iter15.read(), ap_const_logic_1));
}

void compute::thread_ap_idle() {
    if ((esl_seteq<1,1,1>(ap_const_logic_0, ap_start.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()))) {
        ap_idle = ap_const_logic_1;
    } else {
        ap_idle = ap_const_logic_0;
    }
}

void compute::thread_ap_idle_pp0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp0_iter3.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp0_iter4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp0_iter5.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp0_iter6.read()))) {
        ap_idle_pp0 = ap_const_logic_1;
    } else {
        ap_idle_pp0 = ap_const_logic_0;
    }
}

void compute::thread_ap_idle_pp1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp1_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp1_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp1_iter2.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp1_iter4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp1_iter5.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp1_iter6.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp1_iter7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp1_iter8.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp1_iter9.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp1_iter10.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp1_iter11.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp1_iter12.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp1_iter13.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp1_iter14.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp1_iter15.read()))) {
        ap_idle_pp1 = ap_const_logic_1;
    } else {
        ap_idle_pp1 = ap_const_logic_0;
    }
}

void compute::thread_ap_idle_pp2() {
    if ((esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp2_iter2.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp2_iter3.read()))) {
        ap_idle_pp2 = ap_const_logic_1;
    } else {
        ap_idle_pp2 = ap_const_logic_0;
    }
}

void compute::thread_ap_idle_pp3() {
    if ((esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp3_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp3_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp3_iter2.read()))) {
        ap_idle_pp3 = ap_const_logic_1;
    } else {
        ap_idle_pp3 = ap_const_logic_0;
    }
}

void compute::thread_ap_phi_mux_dst_offset_in_0_i1_phi_fu_1140_p4() {
    if ((esl_seteq<1,1,1>(ap_const_lv1_0, exitcond_flatten3_reg_12909_pp0_iter1_reg.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
        ap_phi_mux_dst_offset_in_0_i1_phi_fu_1140_p4 = dst_offset_in_0_i1_m_1_reg_12980.read();
    } else {
        ap_phi_mux_dst_offset_in_0_i1_phi_fu_1140_p4 = dst_offset_in_0_i1_reg_1136.read();
    }
}

void compute::thread_ap_phi_mux_dst_offset_in_0_i_phi_fu_1229_p4() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, exitcond_flatten1_reg_14063_pp1_iter1_reg.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        ap_phi_mux_dst_offset_in_0_i_phi_fu_1229_p4 = dst_offset_in_0_i_mi_1_fu_4674_p3.read();
    } else {
        ap_phi_mux_dst_offset_in_0_i_phi_fu_1229_p4 = dst_offset_in_0_i_reg_1225.read();
    }
}

void compute::thread_ap_phi_mux_dst_offset_in_V_1_phi_fu_1105_p4() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, exitcond_flatten3_reg_12909.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        ap_phi_mux_dst_offset_in_V_1_phi_fu_1105_p4 = dst_offset_in_V_1_mi_reg_12965.read();
    } else {
        ap_phi_mux_dst_offset_in_V_1_phi_fu_1105_p4 = dst_offset_in_V_1_reg_1101.read();
    }
}

void compute::thread_ap_phi_mux_indvar_flatten2_phi_fu_1094_p4() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, exitcond_flatten3_reg_12909.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        ap_phi_mux_indvar_flatten2_phi_fu_1094_p4 = indvar_flatten_next3_reg_12913.read();
    } else {
        ap_phi_mux_indvar_flatten2_phi_fu_1094_p4 = indvar_flatten2_reg_1090.read();
    }
}

void compute::thread_ap_phi_mux_indvar_flatten3_phi_fu_1129_p4() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, exitcond_flatten3_reg_12909.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        ap_phi_mux_indvar_flatten3_phi_fu_1129_p4 = indvar_flatten_next2_reg_12975.read();
    } else {
        ap_phi_mux_indvar_flatten3_phi_fu_1129_p4 = indvar_flatten3_reg_1125.read();
    }
}

void compute::thread_ap_phi_mux_src_offset_in_0_i1_phi_fu_1152_p4() {
    if ((esl_seteq<1,1,1>(ap_const_lv1_0, exitcond_flatten3_reg_12909_pp0_iter1_reg.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
        ap_phi_mux_src_offset_in_0_i1_phi_fu_1152_p4 = src_offset_in_0_i1_m_1_reg_12986.read();
    } else {
        ap_phi_mux_src_offset_in_0_i1_phi_fu_1152_p4 = src_offset_in_0_i1_reg_1148.read();
    }
}

void compute::thread_ap_phi_mux_src_offset_in_0_i_phi_fu_1241_p4() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, exitcond_flatten1_reg_14063_pp1_iter1_reg.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        ap_phi_mux_src_offset_in_0_i_phi_fu_1241_p4 = src_offset_in_0_i_mi_1_fu_4679_p3.read();
    } else {
        ap_phi_mux_src_offset_in_0_i_phi_fu_1241_p4 = src_offset_in_0_i_reg_1237.read();
    }
}

void compute::thread_ap_phi_mux_src_offset_in_V_1_phi_fu_1117_p4() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, exitcond_flatten3_reg_12909.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        ap_phi_mux_src_offset_in_V_1_phi_fu_1117_p4 = src_offset_in_V_1_mi_reg_12970.read();
    } else {
        ap_phi_mux_src_offset_in_V_1_phi_fu_1117_p4 = src_offset_in_V_1_reg_1113.read();
    }
}

void compute::thread_ap_phi_mux_upc_0_i1_phi_fu_1163_p4() {
    if ((esl_seteq<1,1,1>(ap_const_lv1_0, exitcond_flatten3_reg_12909_pp0_iter1_reg.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
        ap_phi_mux_upc_0_i1_phi_fu_1163_p4 = upc_2_reg_12997.read();
    } else {
        ap_phi_mux_upc_0_i1_phi_fu_1163_p4 = upc_0_i1_reg_1160.read();
    }
}

void compute::thread_ap_phi_mux_upc_0_i_phi_fu_1264_p4() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, exitcond_flatten1_reg_14063.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        ap_phi_mux_upc_0_i_phi_fu_1264_p4 = upc_1_fu_4668_p2.read();
    } else {
        ap_phi_mux_upc_0_i_phi_fu_1264_p4 = upc_0_i_reg_1261.read();
    }
}

void compute::thread_ap_phi_mux_wgt_offset_in_0_i_phi_fu_1253_p4() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, exitcond_flatten1_reg_14063_pp1_iter1_reg.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        ap_phi_mux_wgt_offset_in_0_i_phi_fu_1253_p4 = wgt_offset_in_0_i_mi_1_fu_4684_p3.read();
    } else {
        ap_phi_mux_wgt_offset_in_0_i_phi_fu_1253_p4 = wgt_offset_in_0_i_reg_1249.read();
    }
}

void compute::thread_ap_ready() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state88.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, g2l_dep_queue_V_1_state.read()[0]) && 
         esl_seteq<1,1,1>(ap_const_logic_0, g2s_dep_queue_V_1_state.read()[0]) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, g2l_dep_queue_V_1_ack_in.read()) || esl_seteq<1,1,1>(ap_const_logic_0, g2s_dep_queue_V_1_ack_in.read()) || esl_seteq<1,1,1>(ap_const_boolean_1, ap_block_state88_io.read())))) {
        ap_ready = ap_const_logic_1;
    } else {
        ap_ready = ap_const_logic_0;
    }
}

void compute::thread_ap_rst_n_inv() {
    ap_rst_n_inv =  (sc_logic) (~ap_rst_n.read());
}

void compute::thread_ap_sig_ioackin_data_port_ARREADY() {
    if (esl_seteq<1,1,1>(ap_const_logic_0, ap_reg_ioackin_data_port_ARREADY.read())) {
        ap_sig_ioackin_data_port_ARREADY = data_port_ARREADY.read();
    } else {
        ap_sig_ioackin_data_port_ARREADY = ap_const_logic_1;
    }
}

void compute::thread_ap_sig_ioackin_uop_port_ARREADY() {
    if (esl_seteq<1,1,1>(ap_const_logic_0, ap_reg_ioackin_uop_port_ARREADY.read())) {
        ap_sig_ioackin_uop_port_ARREADY = uop_port_ARREADY.read();
    } else {
        ap_sig_ioackin_uop_port_ARREADY = ap_const_logic_1;
    }
}

void compute::thread_biases_V4_sum_cast_fu_11148_p1() {
    biases_V4_sum_cast_fu_11148_p1 = esl_zext<64,35>(biases_V4_sum_reg_19050.read());
}

void compute::thread_biases_V4_sum_fu_11143_p2() {
    biases_V4_sum_fu_11143_p2 = (!tmp_cast_reg_12442.read().is_01() || !ret_V_cast_cast_fu_11139_p1.read().is_01())? sc_lv<35>(): (sc_biguint<35>(tmp_cast_reg_12442.read()) + sc_biguint<35>(ret_V_cast_cast_fu_11139_p1.read()));
}

void compute::thread_data_port_ARADDR() {
    data_port_ARADDR =  (sc_lv<32>) (biases_V4_sum_cast_fu_11148_p1.read());
}

void compute::thread_data_port_ARVALID() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state62.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_reg_ioackin_data_port_ARREADY.read()))) {
        data_port_ARVALID = ap_const_logic_1;
    } else {
        data_port_ARVALID = ap_const_logic_0;
    }
}

void compute::thread_data_port_RREADY() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, exitcond1_reg_19066.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage0_11001.read(), ap_const_boolean_0))) {
        data_port_RREADY = ap_const_logic_1;
    } else {
        data_port_RREADY = ap_const_logic_0;
    }
}

void compute::thread_data_port_blk_n_AR() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state62.read())) {
        data_port_blk_n_AR = m_axi_data_port_ARREADY.read();
    } else {
        data_port_blk_n_AR = ap_const_logic_1;
    }
}

void compute::thread_data_port_blk_n_R() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, exitcond1_reg_19066.read()))) {
        data_port_blk_n_R = m_axi_data_port_RVALID.read();
    } else {
        data_port_blk_n_R = ap_const_logic_1;
    }
}

void compute::thread_done_o() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state86.read())) {
        done_o = ap_const_lv32_1;
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
                !(esl_seteq<1,1,1>(ap_const_logic_0, ap_start.read()) || esl_seteq<1,1,1>(ap_const_logic_0, gemm_queue_V_V_0_vld_out.read()) || (esl_seteq<1,1,1>(ap_const_lv1_1, tmp_2_fu_1682_p3.read()) && 
  esl_seteq<1,1,1>(ap_const_logic_0, l2g_dep_queue_V_0_vld_out.read())) || (esl_seteq<1,1,1>(ap_const_lv1_1, tmp_3_fu_1690_p3.read()) && 
  esl_seteq<1,1,1>(ap_const_logic_0, s2g_dep_queue_V_0_vld_out.read()))))) {
        done_o = ap_const_lv32_0;
    } else {
        done_o =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void compute::thread_done_o_ap_vld() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
          !(esl_seteq<1,1,1>(ap_const_logic_0, ap_start.read()) || esl_seteq<1,1,1>(ap_const_logic_0, gemm_queue_V_V_0_vld_out.read()) || (esl_seteq<1,1,1>(ap_const_lv1_1, tmp_2_fu_1682_p3.read()) && 
  esl_seteq<1,1,1>(ap_const_logic_0, l2g_dep_queue_V_0_vld_out.read())) || (esl_seteq<1,1,1>(ap_const_lv1_1, tmp_3_fu_1690_p3.read()) && 
  esl_seteq<1,1,1>(ap_const_logic_0, s2g_dep_queue_V_0_vld_out.read())))) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state86.read()))) {
        done_o_ap_vld = ap_const_logic_1;
    } else {
        done_o_ap_vld = ap_const_logic_0;
    }
}

void compute::thread_dram_idx_V_assign_1_fu_11349_p2() {
    dram_idx_V_assign_1_fu_11349_p2 = (!tmp_21_reg_12637.read().is_01() || !dram_idx_assign_reg_1281.read().is_01())? sc_lv<32>(): (sc_biguint<32>(tmp_21_reg_12637.read()) + sc_biguint<32>(dram_idx_assign_reg_1281.read()));
}

void compute::thread_dst_idx_V_1_fu_2076_p2() {
    dst_idx_V_1_fu_2076_p2 = (!tmp_53_fu_2073_p1.read().is_01() || !dst_offset_in_0_i1_m_1_reg_12980_pp0_iter2_reg.read().is_01())? sc_lv<12>(): (sc_biguint<12>(tmp_53_fu_2073_p1.read()) + sc_biguint<12>(dst_offset_in_0_i1_m_1_reg_12980_pp0_iter2_reg.read()));
}

void compute::thread_dst_idx_V_fu_4706_p2() {
    dst_idx_V_fu_4706_p2 = (!tmp_39_fu_4703_p1.read().is_01() || !dst_offset_in_0_i_mi_1_reg_14168_pp1_iter3_reg.read().is_01())? sc_lv<12>(): (sc_biguint<12>(tmp_39_fu_4703_p1.read()) + sc_biguint<12>(dst_offset_in_0_i_mi_1_reg_14168_pp1_iter3_reg.read()));
}

void compute::thread_dst_offset_in_0_i1_m_1_fu_2046_p3() {
    dst_offset_in_0_i1_m_1_fu_2046_p3 = (!tmp_184_mid1_reg_12958.read()[0].is_01())? sc_lv<12>(): ((tmp_184_mid1_reg_12958.read()[0].to_bool())? dst_offset_in_0_i1_m_reg_12946.read(): dst_offset_in_V_3_fu_2032_p2.read());
}

void compute::thread_dst_offset_in_0_i1_m_fu_1985_p3() {
    dst_offset_in_0_i1_m_fu_1985_p3 = (!exitcond_flatten2_reg_12924.read()[0].is_01())? sc_lv<12>(): ((exitcond_flatten2_reg_12924.read()[0].to_bool())? dst_offset_out_V_s_reg_12918.read(): ap_phi_mux_dst_offset_in_0_i1_phi_fu_1140_p4.read());
}

void compute::thread_dst_offset_in_0_i_mi_1_fu_4674_p3() {
    dst_offset_in_0_i_mi_1_fu_4674_p3 = (!tmp_178_mid1_reg_14136.read()[0].is_01())? sc_lv<12>(): ((tmp_178_mid1_reg_14136.read()[0].to_bool())? dst_offset_in_0_i_mi_reg_14121.read(): dst_offset_in_V_2_reg_14143.read());
}

void compute::thread_dst_offset_in_0_i_mi_fu_4612_p3() {
    dst_offset_in_0_i_mi_fu_4612_p3 = (!exitcond_flatten_reg_14077.read()[0].is_01())? sc_lv<12>(): ((exitcond_flatten_reg_14077.read()[0].to_bool())? dst_offset_out_V8_reg_14072.read(): ap_phi_mux_dst_offset_in_0_i_phi_fu_1229_p4.read());
}

void compute::thread_dst_offset_in_V_1_mi_fu_2008_p3() {
    dst_offset_in_V_1_mi_fu_2008_p3 = (!exitcond_flatten2_reg_12924.read()[0].is_01())? sc_lv<12>(): ((exitcond_flatten2_reg_12924.read()[0].to_bool())? dst_offset_out_V_s_reg_12918.read(): dst_offset_in_V_1_reg_1101.read());
}

void compute::thread_dst_offset_in_V_2_fu_4641_p2() {
    dst_offset_in_V_2_fu_4641_p2 = (!dst_offset_in_0_i_mi_fu_4612_p3.read().is_01() || !p_0225_0_i_cast_reg_14028.read().is_01())? sc_lv<12>(): (sc_biguint<12>(dst_offset_in_0_i_mi_fu_4612_p3.read()) + sc_biguint<12>(p_0225_0_i_cast_reg_14028.read()));
}

void compute::thread_dst_offset_in_V_3_fu_2032_p2() {
    dst_offset_in_V_3_fu_2032_p2 = (!dst_offset_in_0_i1_m_reg_12946.read().is_01() || !p_0280_0_i_cast_reg_12776.read().is_01())? sc_lv<12>(): (sc_biguint<12>(dst_offset_in_0_i1_m_reg_12946.read()) + sc_biguint<12>(p_0280_0_i_cast_reg_12776.read()));
}

void compute::thread_dst_offset_in_V_mid2_fu_4574_p3() {
    dst_offset_in_V_mid2_fu_4574_p3 = (!exitcond_flatten_fu_4554_p2.read()[0].is_01())? sc_lv<12>(): ((exitcond_flatten_fu_4554_p2.read()[0].to_bool())? dst_offset_out_V8_fu_4549_p2.read(): dst_offset_in_V_reg_1181.read());
}

void compute::thread_dst_offset_out_V8_fu_4549_p2() {
    dst_offset_out_V8_fu_4549_p2 = (!dst_offset_in_V_reg_1181.read().is_01() || !p_0198_0_i_cast_reg_14043.read().is_01())? sc_lv<12>(): (sc_biguint<12>(dst_offset_in_V_reg_1181.read()) + sc_biguint<12>(p_0198_0_i_cast_reg_14043.read()));
}

void compute::thread_dst_offset_out_V_s_fu_1964_p2() {
    dst_offset_out_V_s_fu_1964_p2 = (!ap_phi_mux_dst_offset_in_V_1_phi_fu_1105_p4.read().is_01() || !p_0350_0_i_cast_reg_12786.read().is_01())? sc_lv<12>(): (sc_biguint<12>(ap_phi_mux_dst_offset_in_V_1_phi_fu_1105_p4.read()) + sc_biguint<12>(p_0350_0_i_cast_reg_12786.read()));
}

void compute::thread_dst_tensor_0_0_V_1_fu_2560_p3() {
    dst_tensor_0_0_V_1_fu_2560_p3 = (!tmp_57_reg_13204.read()[0].is_01())? sc_lv<32>(): ((tmp_57_reg_13204.read()[0].to_bool())? p_in631_i_load_fu_2550_p3.read(): p_in_i_load_fu_2555_p3.read());
}

void compute::thread_dst_tensor_0_0_V_2_fu_2340_p2() {
    dst_tensor_0_0_V_2_fu_2340_p2 = (!dst_tensor_0_0_V_reg_13073.read().is_01() || !p_Result_11_0_0_sr_reg_13084.read().is_01())? sc_lv<32>(): (sc_biguint<32>(dst_tensor_0_0_V_reg_13073.read()) + sc_biguint<32>(p_Result_11_0_0_sr_reg_13084.read()));
}

void compute::thread_dst_tensor_0_0_V_3_fu_2597_p3() {
    dst_tensor_0_0_V_3_fu_2597_p3 = (!tmp_273_fu_2574_p3.read()[0].is_01())? sc_lv<32>(): ((tmp_273_fu_2574_p3.read()[0].to_bool())? r_V_fu_2584_p2.read(): r_V_1_fu_2592_p2.read());
}

void compute::thread_dst_tensor_0_0_V_4_fu_2619_p3() {
    dst_tensor_0_0_V_4_fu_2619_p3 = (!tmp_29_reg_12796.read()[0].is_01())? sc_lv<32>(): ((tmp_29_reg_12796.read()[0].to_bool())? dst_tensor_0_0_V_reg_13073.read(): dst_tensor_0_0_V_1_fu_2560_p3.read());
}

void compute::thread_dst_tensor_0_0_V_5_fu_2625_p3() {
    dst_tensor_0_0_V_5_fu_2625_p3 = (!sel_tmp1_reg_12832.read()[0].is_01())? sc_lv<32>(): ((sel_tmp1_reg_12832.read()[0].to_bool())? dst_tensor_0_0_V_2_reg_13209.read(): dst_tensor_0_0_V_4_fu_2619_p3.read());
}

void compute::thread_dst_tensor_0_0_V_6_fu_3386_p3() {
    dst_tensor_0_0_V_6_fu_3386_p3 = (!tmp_30_reg_12868.read()[0].is_01())? sc_lv<32>(): ((tmp_30_reg_12868.read()[0].to_bool())? dst_tensor_0_0_V_3_reg_13452.read(): dst_tensor_0_0_V_5_reg_13463.read());
}

void compute::thread_dst_tensor_0_0_V_fu_2252_p1() {
    dst_tensor_0_0_V_fu_2252_p1 = acc_mem_V_q1.read().range(32-1, 0);
}

void compute::thread_dst_tensor_0_10_V_1_fu_3673_p3() {
    dst_tensor_0_10_V_1_fu_3673_p3 = (!tmp_233_0_s_reg_13612.read()[0].is_01())? sc_lv<32>(): ((tmp_233_0_s_reg_13612.read()[0].to_bool())? p_in631_i_load_0_s_fu_3661_p3.read(): p_in_i_load_0_s_fu_3667_p3.read());
}

void compute::thread_dst_tensor_0_10_V_2_fu_3268_p2() {
    dst_tensor_0_10_V_2_fu_3268_p2 = (!reg_1620.read().is_01() || !src_1_V_10_reg_13362.read().is_01())? sc_lv<32>(): (sc_biguint<32>(reg_1620.read()) + sc_biguint<32>(src_1_V_10_reg_13362.read()));
}

void compute::thread_dst_tensor_0_10_V_3_fu_3712_p3() {
    dst_tensor_0_10_V_3_fu_3712_p3 = (!tmp_323_fu_3687_p3.read()[0].is_01())? sc_lv<32>(): ((tmp_323_fu_3687_p3.read()[0].to_bool())? r_V_0_s_fu_3697_p2.read(): r_V_1_0_s_fu_3706_p2.read());
}

void compute::thread_dst_tensor_0_10_V_4_fu_3734_p3() {
    dst_tensor_0_10_V_4_fu_3734_p3 = (!tmp_29_reg_12796.read()[0].is_01())? sc_lv<32>(): ((tmp_29_reg_12796.read()[0].to_bool())? reg_1620_pp0_iter5_reg.read(): dst_tensor_0_10_V_1_fu_3673_p3.read());
}

void compute::thread_dst_tensor_0_10_V_5_fu_3741_p3() {
    dst_tensor_0_10_V_5_fu_3741_p3 = (!sel_tmp1_reg_12832.read()[0].is_01())? sc_lv<32>(): ((sel_tmp1_reg_12832.read()[0].to_bool())? dst_tensor_0_10_V_2_reg_13617.read(): dst_tensor_0_10_V_4_fu_3734_p3.read());
}

void compute::thread_dst_tensor_0_10_V_6_fu_4254_p3() {
    dst_tensor_0_10_V_6_fu_4254_p3 = (!tmp_30_reg_12868.read()[0].is_01())? sc_lv<32>(): ((tmp_30_reg_12868.read()[0].to_bool())? dst_tensor_0_10_V_3_reg_13820.read(): dst_tensor_0_10_V_5_reg_13831.read());
}

void compute::thread_dst_tensor_0_11_V_1_fu_3759_p3() {
    dst_tensor_0_11_V_1_fu_3759_p3 = (!tmp_233_0_10_reg_13628.read()[0].is_01())? sc_lv<32>(): ((tmp_233_0_10_reg_13628.read()[0].to_bool())? p_in631_i_load_0_10_fu_3747_p3.read(): p_in_i_load_0_10_fu_3753_p3.read());
}

void compute::thread_dst_tensor_0_11_V_2_fu_3283_p2() {
    dst_tensor_0_11_V_2_fu_3283_p2 = (!reg_1624.read().is_01() || !src_1_V_11_reg_13377.read().is_01())? sc_lv<32>(): (sc_biguint<32>(reg_1624.read()) + sc_biguint<32>(src_1_V_11_reg_13377.read()));
}

void compute::thread_dst_tensor_0_11_V_3_fu_3798_p3() {
    dst_tensor_0_11_V_3_fu_3798_p3 = (!tmp_328_fu_3773_p3.read()[0].is_01())? sc_lv<32>(): ((tmp_328_fu_3773_p3.read()[0].to_bool())? r_V_0_10_fu_3783_p2.read(): r_V_1_0_10_fu_3792_p2.read());
}

void compute::thread_dst_tensor_0_11_V_4_fu_3820_p3() {
    dst_tensor_0_11_V_4_fu_3820_p3 = (!tmp_29_reg_12796.read()[0].is_01())? sc_lv<32>(): ((tmp_29_reg_12796.read()[0].to_bool())? reg_1624_pp0_iter5_reg.read(): dst_tensor_0_11_V_1_fu_3759_p3.read());
}

void compute::thread_dst_tensor_0_11_V_5_fu_3827_p3() {
    dst_tensor_0_11_V_5_fu_3827_p3 = (!sel_tmp1_reg_12832.read()[0].is_01())? sc_lv<32>(): ((sel_tmp1_reg_12832.read()[0].to_bool())? dst_tensor_0_11_V_2_reg_13633.read(): dst_tensor_0_11_V_4_fu_3820_p3.read());
}

void compute::thread_dst_tensor_0_11_V_6_fu_4268_p3() {
    dst_tensor_0_11_V_6_fu_4268_p3 = (!tmp_30_reg_12868.read()[0].is_01())? sc_lv<32>(): ((tmp_30_reg_12868.read()[0].to_bool())? dst_tensor_0_11_V_3_reg_13836.read(): dst_tensor_0_11_V_5_reg_13847.read());
}

void compute::thread_dst_tensor_0_12_V_1_fu_3845_p3() {
    dst_tensor_0_12_V_1_fu_3845_p3 = (!tmp_233_0_11_reg_13644.read()[0].is_01())? sc_lv<32>(): ((tmp_233_0_11_reg_13644.read()[0].to_bool())? p_in631_i_load_0_11_fu_3833_p3.read(): p_in_i_load_0_11_fu_3839_p3.read());
}

void compute::thread_dst_tensor_0_12_V_2_fu_3298_p2() {
    dst_tensor_0_12_V_2_fu_3298_p2 = (!reg_1628.read().is_01() || !src_1_V_12_reg_13392.read().is_01())? sc_lv<32>(): (sc_biguint<32>(reg_1628.read()) + sc_biguint<32>(src_1_V_12_reg_13392.read()));
}

void compute::thread_dst_tensor_0_12_V_3_fu_3884_p3() {
    dst_tensor_0_12_V_3_fu_3884_p3 = (!tmp_333_fu_3859_p3.read()[0].is_01())? sc_lv<32>(): ((tmp_333_fu_3859_p3.read()[0].to_bool())? r_V_0_11_fu_3869_p2.read(): r_V_1_0_11_fu_3878_p2.read());
}

void compute::thread_dst_tensor_0_12_V_4_fu_3906_p3() {
    dst_tensor_0_12_V_4_fu_3906_p3 = (!tmp_29_reg_12796.read()[0].is_01())? sc_lv<32>(): ((tmp_29_reg_12796.read()[0].to_bool())? reg_1628_pp0_iter5_reg.read(): dst_tensor_0_12_V_1_fu_3845_p3.read());
}

void compute::thread_dst_tensor_0_12_V_5_fu_3913_p3() {
    dst_tensor_0_12_V_5_fu_3913_p3 = (!sel_tmp1_reg_12832.read()[0].is_01())? sc_lv<32>(): ((sel_tmp1_reg_12832.read()[0].to_bool())? dst_tensor_0_12_V_2_reg_13649.read(): dst_tensor_0_12_V_4_fu_3906_p3.read());
}

void compute::thread_dst_tensor_0_12_V_6_fu_4282_p3() {
    dst_tensor_0_12_V_6_fu_4282_p3 = (!tmp_30_reg_12868.read()[0].is_01())? sc_lv<32>(): ((tmp_30_reg_12868.read()[0].to_bool())? dst_tensor_0_12_V_3_reg_13852.read(): dst_tensor_0_12_V_5_reg_13863.read());
}

void compute::thread_dst_tensor_0_13_V_1_fu_3931_p3() {
    dst_tensor_0_13_V_1_fu_3931_p3 = (!tmp_233_0_12_reg_13660.read()[0].is_01())? sc_lv<32>(): ((tmp_233_0_12_reg_13660.read()[0].to_bool())? p_in631_i_load_0_12_fu_3919_p3.read(): p_in_i_load_0_12_fu_3925_p3.read());
}

void compute::thread_dst_tensor_0_13_V_2_fu_3313_p2() {
    dst_tensor_0_13_V_2_fu_3313_p2 = (!reg_1632.read().is_01() || !src_1_V_13_reg_13407.read().is_01())? sc_lv<32>(): (sc_biguint<32>(reg_1632.read()) + sc_biguint<32>(src_1_V_13_reg_13407.read()));
}

void compute::thread_dst_tensor_0_13_V_3_fu_3970_p3() {
    dst_tensor_0_13_V_3_fu_3970_p3 = (!tmp_338_fu_3945_p3.read()[0].is_01())? sc_lv<32>(): ((tmp_338_fu_3945_p3.read()[0].to_bool())? r_V_0_12_fu_3955_p2.read(): r_V_1_0_12_fu_3964_p2.read());
}

void compute::thread_dst_tensor_0_13_V_4_fu_3992_p3() {
    dst_tensor_0_13_V_4_fu_3992_p3 = (!tmp_29_reg_12796.read()[0].is_01())? sc_lv<32>(): ((tmp_29_reg_12796.read()[0].to_bool())? reg_1632_pp0_iter5_reg.read(): dst_tensor_0_13_V_1_fu_3931_p3.read());
}

void compute::thread_dst_tensor_0_13_V_5_fu_3999_p3() {
    dst_tensor_0_13_V_5_fu_3999_p3 = (!sel_tmp1_reg_12832.read()[0].is_01())? sc_lv<32>(): ((sel_tmp1_reg_12832.read()[0].to_bool())? dst_tensor_0_13_V_2_reg_13665.read(): dst_tensor_0_13_V_4_fu_3992_p3.read());
}

void compute::thread_dst_tensor_0_13_V_6_fu_4296_p3() {
    dst_tensor_0_13_V_6_fu_4296_p3 = (!tmp_30_reg_12868.read()[0].is_01())? sc_lv<32>(): ((tmp_30_reg_12868.read()[0].to_bool())? dst_tensor_0_13_V_3_reg_13868.read(): dst_tensor_0_13_V_5_reg_13879.read());
}

void compute::thread_dst_tensor_0_14_V_1_fu_4017_p3() {
    dst_tensor_0_14_V_1_fu_4017_p3 = (!tmp_233_0_13_reg_13676.read()[0].is_01())? sc_lv<32>(): ((tmp_233_0_13_reg_13676.read()[0].to_bool())? p_in631_i_load_0_13_fu_4005_p3.read(): p_in_i_load_0_13_fu_4011_p3.read());
}

void compute::thread_dst_tensor_0_14_V_2_fu_3328_p2() {
    dst_tensor_0_14_V_2_fu_3328_p2 = (!reg_1636.read().is_01() || !src_1_V_14_reg_13422.read().is_01())? sc_lv<32>(): (sc_biguint<32>(reg_1636.read()) + sc_biguint<32>(src_1_V_14_reg_13422.read()));
}

void compute::thread_dst_tensor_0_14_V_3_fu_4056_p3() {
    dst_tensor_0_14_V_3_fu_4056_p3 = (!tmp_343_fu_4031_p3.read()[0].is_01())? sc_lv<32>(): ((tmp_343_fu_4031_p3.read()[0].to_bool())? r_V_0_13_fu_4041_p2.read(): r_V_1_0_13_fu_4050_p2.read());
}

void compute::thread_dst_tensor_0_14_V_4_fu_4078_p3() {
    dst_tensor_0_14_V_4_fu_4078_p3 = (!tmp_29_reg_12796.read()[0].is_01())? sc_lv<32>(): ((tmp_29_reg_12796.read()[0].to_bool())? reg_1636_pp0_iter5_reg.read(): dst_tensor_0_14_V_1_fu_4017_p3.read());
}

void compute::thread_dst_tensor_0_14_V_5_fu_4085_p3() {
    dst_tensor_0_14_V_5_fu_4085_p3 = (!sel_tmp1_reg_12832.read()[0].is_01())? sc_lv<32>(): ((sel_tmp1_reg_12832.read()[0].to_bool())? dst_tensor_0_14_V_2_reg_13681.read(): dst_tensor_0_14_V_4_fu_4078_p3.read());
}

void compute::thread_dst_tensor_0_14_V_6_fu_4310_p3() {
    dst_tensor_0_14_V_6_fu_4310_p3 = (!tmp_30_reg_12868.read()[0].is_01())? sc_lv<32>(): ((tmp_30_reg_12868.read()[0].to_bool())? dst_tensor_0_14_V_3_reg_13884.read(): dst_tensor_0_14_V_5_reg_13895.read());
}

void compute::thread_dst_tensor_0_15_V_1_fu_4103_p3() {
    dst_tensor_0_15_V_1_fu_4103_p3 = (!tmp_233_0_14_reg_13692.read()[0].is_01())? sc_lv<32>(): ((tmp_233_0_14_reg_13692.read()[0].to_bool())? p_in631_i_load_0_14_fu_4091_p3.read(): p_in_i_load_0_14_fu_4097_p3.read());
}

void compute::thread_dst_tensor_0_15_V_2_fu_3343_p2() {
    dst_tensor_0_15_V_2_fu_3343_p2 = (!reg_1640.read().is_01() || !src_1_V_15_reg_13437.read().is_01())? sc_lv<32>(): (sc_biguint<32>(reg_1640.read()) + sc_biguint<32>(src_1_V_15_reg_13437.read()));
}

void compute::thread_dst_tensor_0_15_V_3_fu_4142_p3() {
    dst_tensor_0_15_V_3_fu_4142_p3 = (!tmp_348_fu_4117_p3.read()[0].is_01())? sc_lv<32>(): ((tmp_348_fu_4117_p3.read()[0].to_bool())? r_V_0_14_fu_4127_p2.read(): r_V_1_0_14_fu_4136_p2.read());
}

void compute::thread_dst_tensor_0_15_V_4_fu_4164_p3() {
    dst_tensor_0_15_V_4_fu_4164_p3 = (!tmp_29_reg_12796.read()[0].is_01())? sc_lv<32>(): ((tmp_29_reg_12796.read()[0].to_bool())? reg_1640_pp0_iter5_reg.read(): dst_tensor_0_15_V_1_fu_4103_p3.read());
}

void compute::thread_dst_tensor_0_15_V_5_fu_4171_p3() {
    dst_tensor_0_15_V_5_fu_4171_p3 = (!sel_tmp1_reg_12832.read()[0].is_01())? sc_lv<32>(): ((sel_tmp1_reg_12832.read()[0].to_bool())? dst_tensor_0_15_V_2_reg_13697.read(): dst_tensor_0_15_V_4_fu_4164_p3.read());
}

void compute::thread_dst_tensor_0_15_V_6_fu_4324_p3() {
    dst_tensor_0_15_V_6_fu_4324_p3 = (!tmp_30_reg_12868.read()[0].is_01())? sc_lv<32>(): ((tmp_30_reg_12868.read()[0].to_bool())? dst_tensor_0_15_V_3_reg_13900.read(): dst_tensor_0_15_V_5_reg_13911.read());
}

void compute::thread_dst_tensor_0_1_V_1_fu_2643_p3() {
    dst_tensor_0_1_V_1_fu_2643_p3 = (!tmp_233_0_1_reg_13220.read()[0].is_01())? sc_lv<32>(): ((tmp_233_0_1_reg_13220.read()[0].to_bool())? p_in631_i_load_0_1_fu_2631_p3.read(): p_in_i_load_0_1_fu_2637_p3.read());
}

void compute::thread_dst_tensor_0_1_V_2_fu_2354_p2() {
    dst_tensor_0_1_V_2_fu_2354_p2 = (!reg_1584.read().is_01() || !src_1_V_1_reg_13099.read().is_01())? sc_lv<32>(): (sc_biguint<32>(reg_1584.read()) + sc_biguint<32>(src_1_V_1_reg_13099.read()));
}

void compute::thread_dst_tensor_0_1_V_3_fu_2682_p3() {
    dst_tensor_0_1_V_3_fu_2682_p3 = (!tmp_278_fu_2657_p3.read()[0].is_01())? sc_lv<32>(): ((tmp_278_fu_2657_p3.read()[0].to_bool())? r_V_0_1_fu_2667_p2.read(): r_V_1_0_1_fu_2676_p2.read());
}

void compute::thread_dst_tensor_0_1_V_4_fu_2704_p3() {
    dst_tensor_0_1_V_4_fu_2704_p3 = (!tmp_29_reg_12796.read()[0].is_01())? sc_lv<32>(): ((tmp_29_reg_12796.read()[0].to_bool())? reg_1584.read(): dst_tensor_0_1_V_1_fu_2643_p3.read());
}

void compute::thread_dst_tensor_0_1_V_5_fu_2711_p3() {
    dst_tensor_0_1_V_5_fu_2711_p3 = (!sel_tmp1_reg_12832.read()[0].is_01())? sc_lv<32>(): ((sel_tmp1_reg_12832.read()[0].to_bool())? dst_tensor_0_1_V_2_reg_13225.read(): dst_tensor_0_1_V_4_fu_2704_p3.read());
}

void compute::thread_dst_tensor_0_1_V_6_fu_3400_p3() {
    dst_tensor_0_1_V_6_fu_3400_p3 = (!tmp_30_reg_12868.read()[0].is_01())? sc_lv<32>(): ((tmp_30_reg_12868.read()[0].to_bool())? dst_tensor_0_1_V_3_reg_13468.read(): dst_tensor_0_1_V_5_reg_13479.read());
}

void compute::thread_dst_tensor_0_2_V_1_fu_2729_p3() {
    dst_tensor_0_2_V_1_fu_2729_p3 = (!tmp_233_0_2_reg_13236.read()[0].is_01())? sc_lv<32>(): ((tmp_233_0_2_reg_13236.read()[0].to_bool())? p_in631_i_load_0_2_fu_2717_p3.read(): p_in_i_load_0_2_fu_2723_p3.read());
}

void compute::thread_dst_tensor_0_2_V_2_fu_2369_p2() {
    dst_tensor_0_2_V_2_fu_2369_p2 = (!reg_1588.read().is_01() || !src_1_V_2_reg_13114.read().is_01())? sc_lv<32>(): (sc_biguint<32>(reg_1588.read()) + sc_biguint<32>(src_1_V_2_reg_13114.read()));
}

void compute::thread_dst_tensor_0_2_V_3_fu_2768_p3() {
    dst_tensor_0_2_V_3_fu_2768_p3 = (!tmp_283_fu_2743_p3.read()[0].is_01())? sc_lv<32>(): ((tmp_283_fu_2743_p3.read()[0].to_bool())? r_V_0_2_fu_2753_p2.read(): r_V_1_0_2_fu_2762_p2.read());
}

void compute::thread_dst_tensor_0_2_V_4_fu_2790_p3() {
    dst_tensor_0_2_V_4_fu_2790_p3 = (!tmp_29_reg_12796.read()[0].is_01())? sc_lv<32>(): ((tmp_29_reg_12796.read()[0].to_bool())? reg_1588.read(): dst_tensor_0_2_V_1_fu_2729_p3.read());
}

void compute::thread_dst_tensor_0_2_V_5_fu_2797_p3() {
    dst_tensor_0_2_V_5_fu_2797_p3 = (!sel_tmp1_reg_12832.read()[0].is_01())? sc_lv<32>(): ((sel_tmp1_reg_12832.read()[0].to_bool())? dst_tensor_0_2_V_2_reg_13241.read(): dst_tensor_0_2_V_4_fu_2790_p3.read());
}

void compute::thread_dst_tensor_0_2_V_6_fu_3414_p3() {
    dst_tensor_0_2_V_6_fu_3414_p3 = (!tmp_30_reg_12868.read()[0].is_01())? sc_lv<32>(): ((tmp_30_reg_12868.read()[0].to_bool())? dst_tensor_0_2_V_3_reg_13484.read(): dst_tensor_0_2_V_5_reg_13495.read());
}

void compute::thread_dst_tensor_0_3_V_1_fu_2815_p3() {
    dst_tensor_0_3_V_1_fu_2815_p3 = (!tmp_233_0_3_reg_13252.read()[0].is_01())? sc_lv<32>(): ((tmp_233_0_3_reg_13252.read()[0].to_bool())? p_in631_i_load_0_3_fu_2803_p3.read(): p_in_i_load_0_3_fu_2809_p3.read());
}

void compute::thread_dst_tensor_0_3_V_2_fu_2384_p2() {
    dst_tensor_0_3_V_2_fu_2384_p2 = (!reg_1592.read().is_01() || !src_1_V_3_reg_13129.read().is_01())? sc_lv<32>(): (sc_biguint<32>(reg_1592.read()) + sc_biguint<32>(src_1_V_3_reg_13129.read()));
}

void compute::thread_dst_tensor_0_3_V_3_fu_2854_p3() {
    dst_tensor_0_3_V_3_fu_2854_p3 = (!tmp_288_fu_2829_p3.read()[0].is_01())? sc_lv<32>(): ((tmp_288_fu_2829_p3.read()[0].to_bool())? r_V_0_3_fu_2839_p2.read(): r_V_1_0_3_fu_2848_p2.read());
}

void compute::thread_dst_tensor_0_3_V_4_fu_2876_p3() {
    dst_tensor_0_3_V_4_fu_2876_p3 = (!tmp_29_reg_12796.read()[0].is_01())? sc_lv<32>(): ((tmp_29_reg_12796.read()[0].to_bool())? reg_1592.read(): dst_tensor_0_3_V_1_fu_2815_p3.read());
}

void compute::thread_dst_tensor_0_3_V_5_fu_2883_p3() {
    dst_tensor_0_3_V_5_fu_2883_p3 = (!sel_tmp1_reg_12832.read()[0].is_01())? sc_lv<32>(): ((sel_tmp1_reg_12832.read()[0].to_bool())? dst_tensor_0_3_V_2_reg_13257.read(): dst_tensor_0_3_V_4_fu_2876_p3.read());
}

void compute::thread_dst_tensor_0_3_V_6_fu_3428_p3() {
    dst_tensor_0_3_V_6_fu_3428_p3 = (!tmp_30_reg_12868.read()[0].is_01())? sc_lv<32>(): ((tmp_30_reg_12868.read()[0].to_bool())? dst_tensor_0_3_V_3_reg_13500.read(): dst_tensor_0_3_V_5_reg_13511.read());
}

void compute::thread_dst_tensor_0_4_V_1_fu_2901_p3() {
    dst_tensor_0_4_V_1_fu_2901_p3 = (!tmp_233_0_4_reg_13268.read()[0].is_01())? sc_lv<32>(): ((tmp_233_0_4_reg_13268.read()[0].to_bool())? p_in631_i_load_0_4_fu_2889_p3.read(): p_in_i_load_0_4_fu_2895_p3.read());
}

void compute::thread_dst_tensor_0_4_V_2_fu_2399_p2() {
    dst_tensor_0_4_V_2_fu_2399_p2 = (!reg_1596.read().is_01() || !src_1_V_4_reg_13144.read().is_01())? sc_lv<32>(): (sc_biguint<32>(reg_1596.read()) + sc_biguint<32>(src_1_V_4_reg_13144.read()));
}

void compute::thread_dst_tensor_0_4_V_3_fu_2940_p3() {
    dst_tensor_0_4_V_3_fu_2940_p3 = (!tmp_293_fu_2915_p3.read()[0].is_01())? sc_lv<32>(): ((tmp_293_fu_2915_p3.read()[0].to_bool())? r_V_0_4_fu_2925_p2.read(): r_V_1_0_4_fu_2934_p2.read());
}

void compute::thread_dst_tensor_0_4_V_4_fu_2962_p3() {
    dst_tensor_0_4_V_4_fu_2962_p3 = (!tmp_29_reg_12796.read()[0].is_01())? sc_lv<32>(): ((tmp_29_reg_12796.read()[0].to_bool())? reg_1596.read(): dst_tensor_0_4_V_1_fu_2901_p3.read());
}

void compute::thread_dst_tensor_0_4_V_5_fu_2969_p3() {
    dst_tensor_0_4_V_5_fu_2969_p3 = (!sel_tmp1_reg_12832.read()[0].is_01())? sc_lv<32>(): ((sel_tmp1_reg_12832.read()[0].to_bool())? dst_tensor_0_4_V_2_reg_13273.read(): dst_tensor_0_4_V_4_fu_2962_p3.read());
}

void compute::thread_dst_tensor_0_4_V_6_fu_3442_p3() {
    dst_tensor_0_4_V_6_fu_3442_p3 = (!tmp_30_reg_12868.read()[0].is_01())? sc_lv<32>(): ((tmp_30_reg_12868.read()[0].to_bool())? dst_tensor_0_4_V_3_reg_13516.read(): dst_tensor_0_4_V_5_reg_13527.read());
}

void compute::thread_dst_tensor_0_5_V_1_fu_2987_p3() {
    dst_tensor_0_5_V_1_fu_2987_p3 = (!tmp_233_0_5_reg_13284.read()[0].is_01())? sc_lv<32>(): ((tmp_233_0_5_reg_13284.read()[0].to_bool())? p_in631_i_load_0_5_fu_2975_p3.read(): p_in_i_load_0_5_fu_2981_p3.read());
}

void compute::thread_dst_tensor_0_5_V_2_fu_2414_p2() {
    dst_tensor_0_5_V_2_fu_2414_p2 = (!reg_1600.read().is_01() || !src_1_V_5_reg_13159.read().is_01())? sc_lv<32>(): (sc_biguint<32>(reg_1600.read()) + sc_biguint<32>(src_1_V_5_reg_13159.read()));
}

void compute::thread_dst_tensor_0_5_V_3_fu_3026_p3() {
    dst_tensor_0_5_V_3_fu_3026_p3 = (!tmp_298_fu_3001_p3.read()[0].is_01())? sc_lv<32>(): ((tmp_298_fu_3001_p3.read()[0].to_bool())? r_V_0_5_fu_3011_p2.read(): r_V_1_0_5_fu_3020_p2.read());
}

void compute::thread_dst_tensor_0_5_V_4_fu_3048_p3() {
    dst_tensor_0_5_V_4_fu_3048_p3 = (!tmp_29_reg_12796.read()[0].is_01())? sc_lv<32>(): ((tmp_29_reg_12796.read()[0].to_bool())? reg_1600.read(): dst_tensor_0_5_V_1_fu_2987_p3.read());
}

void compute::thread_dst_tensor_0_5_V_5_fu_3055_p3() {
    dst_tensor_0_5_V_5_fu_3055_p3 = (!sel_tmp1_reg_12832.read()[0].is_01())? sc_lv<32>(): ((sel_tmp1_reg_12832.read()[0].to_bool())? dst_tensor_0_5_V_2_reg_13289.read(): dst_tensor_0_5_V_4_fu_3048_p3.read());
}

void compute::thread_dst_tensor_0_5_V_6_fu_3456_p3() {
    dst_tensor_0_5_V_6_fu_3456_p3 = (!tmp_30_reg_12868.read()[0].is_01())? sc_lv<32>(): ((tmp_30_reg_12868.read()[0].to_bool())? dst_tensor_0_5_V_3_reg_13532.read(): dst_tensor_0_5_V_5_reg_13543.read());
}

void compute::thread_dst_tensor_0_6_V_1_fu_3073_p3() {
    dst_tensor_0_6_V_1_fu_3073_p3 = (!tmp_233_0_6_reg_13300.read()[0].is_01())? sc_lv<32>(): ((tmp_233_0_6_reg_13300.read()[0].to_bool())? p_in631_i_load_0_6_fu_3061_p3.read(): p_in_i_load_0_6_fu_3067_p3.read());
}

void compute::thread_dst_tensor_0_6_V_2_fu_2429_p2() {
    dst_tensor_0_6_V_2_fu_2429_p2 = (!reg_1604.read().is_01() || !src_1_V_6_reg_13174.read().is_01())? sc_lv<32>(): (sc_biguint<32>(reg_1604.read()) + sc_biguint<32>(src_1_V_6_reg_13174.read()));
}

void compute::thread_dst_tensor_0_6_V_3_fu_3112_p3() {
    dst_tensor_0_6_V_3_fu_3112_p3 = (!tmp_303_fu_3087_p3.read()[0].is_01())? sc_lv<32>(): ((tmp_303_fu_3087_p3.read()[0].to_bool())? r_V_0_6_fu_3097_p2.read(): r_V_1_0_6_fu_3106_p2.read());
}

void compute::thread_dst_tensor_0_6_V_4_fu_3134_p3() {
    dst_tensor_0_6_V_4_fu_3134_p3 = (!tmp_29_reg_12796.read()[0].is_01())? sc_lv<32>(): ((tmp_29_reg_12796.read()[0].to_bool())? reg_1604.read(): dst_tensor_0_6_V_1_fu_3073_p3.read());
}

void compute::thread_dst_tensor_0_6_V_5_fu_3141_p3() {
    dst_tensor_0_6_V_5_fu_3141_p3 = (!sel_tmp1_reg_12832.read()[0].is_01())? sc_lv<32>(): ((sel_tmp1_reg_12832.read()[0].to_bool())? dst_tensor_0_6_V_2_reg_13305.read(): dst_tensor_0_6_V_4_fu_3134_p3.read());
}

void compute::thread_dst_tensor_0_6_V_6_fu_3470_p3() {
    dst_tensor_0_6_V_6_fu_3470_p3 = (!tmp_30_reg_12868.read()[0].is_01())? sc_lv<32>(): ((tmp_30_reg_12868.read()[0].to_bool())? dst_tensor_0_6_V_3_reg_13548.read(): dst_tensor_0_6_V_5_reg_13559.read());
}

void compute::thread_dst_tensor_0_7_V_1_fu_3159_p3() {
    dst_tensor_0_7_V_1_fu_3159_p3 = (!tmp_233_0_7_reg_13316.read()[0].is_01())? sc_lv<32>(): ((tmp_233_0_7_reg_13316.read()[0].to_bool())? p_in631_i_load_0_7_fu_3147_p3.read(): p_in_i_load_0_7_fu_3153_p3.read());
}

void compute::thread_dst_tensor_0_7_V_2_fu_2444_p2() {
    dst_tensor_0_7_V_2_fu_2444_p2 = (!reg_1608.read().is_01() || !src_1_V_7_reg_13189.read().is_01())? sc_lv<32>(): (sc_biguint<32>(reg_1608.read()) + sc_biguint<32>(src_1_V_7_reg_13189.read()));
}

void compute::thread_dst_tensor_0_7_V_3_fu_3198_p3() {
    dst_tensor_0_7_V_3_fu_3198_p3 = (!tmp_308_fu_3173_p3.read()[0].is_01())? sc_lv<32>(): ((tmp_308_fu_3173_p3.read()[0].to_bool())? r_V_0_7_fu_3183_p2.read(): r_V_1_0_7_fu_3192_p2.read());
}

void compute::thread_dst_tensor_0_7_V_4_fu_3220_p3() {
    dst_tensor_0_7_V_4_fu_3220_p3 = (!tmp_29_reg_12796.read()[0].is_01())? sc_lv<32>(): ((tmp_29_reg_12796.read()[0].to_bool())? reg_1608.read(): dst_tensor_0_7_V_1_fu_3159_p3.read());
}

void compute::thread_dst_tensor_0_7_V_5_fu_3227_p3() {
    dst_tensor_0_7_V_5_fu_3227_p3 = (!sel_tmp1_reg_12832.read()[0].is_01())? sc_lv<32>(): ((sel_tmp1_reg_12832.read()[0].to_bool())? dst_tensor_0_7_V_2_reg_13321.read(): dst_tensor_0_7_V_4_fu_3220_p3.read());
}

void compute::thread_dst_tensor_0_7_V_6_fu_3484_p3() {
    dst_tensor_0_7_V_6_fu_3484_p3 = (!tmp_30_reg_12868.read()[0].is_01())? sc_lv<32>(): ((tmp_30_reg_12868.read()[0].to_bool())? dst_tensor_0_7_V_3_reg_13564.read(): dst_tensor_0_7_V_5_reg_13575.read());
}

void compute::thread_dst_tensor_0_8_V_1_fu_3501_p3() {
    dst_tensor_0_8_V_1_fu_3501_p3 = (!tmp_233_0_8_reg_13580.read()[0].is_01())? sc_lv<32>(): ((tmp_233_0_8_reg_13580.read()[0].to_bool())? p_in631_i_load_0_8_fu_3489_p3.read(): p_in_i_load_0_8_fu_3495_p3.read());
}

void compute::thread_dst_tensor_0_8_V_2_fu_3238_p2() {
    dst_tensor_0_8_V_2_fu_3238_p2 = (!reg_1612.read().is_01() || !src_1_V_8_reg_13332.read().is_01())? sc_lv<32>(): (sc_biguint<32>(reg_1612.read()) + sc_biguint<32>(src_1_V_8_reg_13332.read()));
}

void compute::thread_dst_tensor_0_8_V_3_fu_3540_p3() {
    dst_tensor_0_8_V_3_fu_3540_p3 = (!tmp_313_fu_3515_p3.read()[0].is_01())? sc_lv<32>(): ((tmp_313_fu_3515_p3.read()[0].to_bool())? r_V_0_8_fu_3525_p2.read(): r_V_1_0_8_fu_3534_p2.read());
}

void compute::thread_dst_tensor_0_8_V_4_fu_3562_p3() {
    dst_tensor_0_8_V_4_fu_3562_p3 = (!tmp_29_reg_12796.read()[0].is_01())? sc_lv<32>(): ((tmp_29_reg_12796.read()[0].to_bool())? reg_1612_pp0_iter5_reg.read(): dst_tensor_0_8_V_1_fu_3501_p3.read());
}

void compute::thread_dst_tensor_0_8_V_5_fu_3569_p3() {
    dst_tensor_0_8_V_5_fu_3569_p3 = (!sel_tmp1_reg_12832.read()[0].is_01())? sc_lv<32>(): ((sel_tmp1_reg_12832.read()[0].to_bool())? dst_tensor_0_8_V_2_reg_13585.read(): dst_tensor_0_8_V_4_fu_3562_p3.read());
}

void compute::thread_dst_tensor_0_8_V_6_fu_4226_p3() {
    dst_tensor_0_8_V_6_fu_4226_p3 = (!tmp_30_reg_12868.read()[0].is_01())? sc_lv<32>(): ((tmp_30_reg_12868.read()[0].to_bool())? dst_tensor_0_8_V_3_reg_13788.read(): dst_tensor_0_8_V_5_reg_13799.read());
}

void compute::thread_dst_tensor_0_9_V_1_fu_3587_p3() {
    dst_tensor_0_9_V_1_fu_3587_p3 = (!tmp_233_0_9_reg_13596.read()[0].is_01())? sc_lv<32>(): ((tmp_233_0_9_reg_13596.read()[0].to_bool())? p_in631_i_load_0_9_fu_3575_p3.read(): p_in_i_load_0_9_fu_3581_p3.read());
}

void compute::thread_dst_tensor_0_9_V_2_fu_3253_p2() {
    dst_tensor_0_9_V_2_fu_3253_p2 = (!reg_1616.read().is_01() || !src_1_V_9_reg_13347.read().is_01())? sc_lv<32>(): (sc_biguint<32>(reg_1616.read()) + sc_biguint<32>(src_1_V_9_reg_13347.read()));
}

void compute::thread_dst_tensor_0_9_V_3_fu_3626_p3() {
    dst_tensor_0_9_V_3_fu_3626_p3 = (!tmp_318_fu_3601_p3.read()[0].is_01())? sc_lv<32>(): ((tmp_318_fu_3601_p3.read()[0].to_bool())? r_V_0_9_fu_3611_p2.read(): r_V_1_0_9_fu_3620_p2.read());
}

void compute::thread_dst_tensor_0_9_V_4_fu_3648_p3() {
    dst_tensor_0_9_V_4_fu_3648_p3 = (!tmp_29_reg_12796.read()[0].is_01())? sc_lv<32>(): ((tmp_29_reg_12796.read()[0].to_bool())? reg_1616_pp0_iter5_reg.read(): dst_tensor_0_9_V_1_fu_3587_p3.read());
}

void compute::thread_dst_tensor_0_9_V_5_fu_3655_p3() {
    dst_tensor_0_9_V_5_fu_3655_p3 = (!sel_tmp1_reg_12832.read()[0].is_01())? sc_lv<32>(): ((sel_tmp1_reg_12832.read()[0].to_bool())? dst_tensor_0_9_V_2_reg_13601.read(): dst_tensor_0_9_V_4_fu_3648_p3.read());
}

void compute::thread_dst_tensor_0_9_V_6_fu_4240_p3() {
    dst_tensor_0_9_V_6_fu_4240_p3 = (!tmp_30_reg_12868.read()[0].is_01())? sc_lv<32>(): ((tmp_30_reg_12868.read()[0].to_bool())? dst_tensor_0_9_V_3_reg_13804.read(): dst_tensor_0_9_V_5_reg_13815.read());
}

void compute::thread_exitcond1_fu_11170_p2() {
    exitcond1_fu_11170_p2 = (!indvar2_reg_1302.read().is_01() || !tmp_124_add_i32_shr_reg_12642.read().is_01())? sc_lv<1>(): sc_lv<1>(indvar2_reg_1302.read() == tmp_124_add_i32_shr_reg_12642.read());
}

void compute::thread_exitcond_flatten1_fu_4538_p2() {
    exitcond_flatten1_fu_4538_p2 = (!indvar_flatten1_reg_1170.read().is_01() || !bound5_reg_14058.read().is_01())? sc_lv<1>(): sc_lv<1>(indvar_flatten1_reg_1170.read() == bound5_reg_14058.read());
}

void compute::thread_exitcond_flatten2_fu_1969_p2() {
    exitcond_flatten2_fu_1969_p2 = (!ap_phi_mux_indvar_flatten3_phi_fu_1129_p4.read().is_01() || !bound1_reg_12672.read().is_01())? sc_lv<1>(): sc_lv<1>(ap_phi_mux_indvar_flatten3_phi_fu_1129_p4.read() == bound1_reg_12672.read());
}

void compute::thread_exitcond_flatten3_fu_1953_p2() {
    exitcond_flatten3_fu_1953_p2 = (!ap_phi_mux_indvar_flatten2_phi_fu_1094_p4.read().is_01() || !bound2_reg_12904.read().is_01())? sc_lv<1>(): sc_lv<1>(ap_phi_mux_indvar_flatten2_phi_fu_1094_p4.read() == bound2_reg_12904.read());
}

void compute::thread_exitcond_flatten_fu_4554_p2() {
    exitcond_flatten_fu_4554_p2 = (!indvar_flatten_reg_1214.read().is_01() || !bound_reg_13980.read().is_01())? sc_lv<1>(): sc_lv<1>(indvar_flatten_reg_1214.read() == bound_reg_13980.read());
}

void compute::thread_exitcond_fu_11386_p2() {
    exitcond_fu_11386_p2 = (!indvar_reg_1313.read().is_01() || !reg_1576.read().is_01())? sc_lv<1>(): sc_lv<1>(indvar_reg_1313.read() == reg_1576.read());
}

void compute::thread_exitcond_i_fu_11120_p2() {
    exitcond_i_fu_11120_p2 = (!i_op_assign_reg_1291.read().is_01() || !tmp_19_reg_12632.read().is_01())? sc_lv<1>(): sc_lv<1>(i_op_assign_reg_1291.read() == tmp_19_reg_12632.read());
}

void compute::thread_g2l_dep_queue_V_1_ack_in() {
    g2l_dep_queue_V_1_ack_in = g2l_dep_queue_V_1_state.read()[1];
}

void compute::thread_g2l_dep_queue_V_1_ack_out() {
    g2l_dep_queue_V_1_ack_out = g2l_dep_queue_V_TREADY.read();
}

void compute::thread_g2l_dep_queue_V_1_data_out() {
    g2l_dep_queue_V_1_data_out = ap_const_lv8_1;
}

void compute::thread_g2l_dep_queue_V_1_sel() {
    g2l_dep_queue_V_1_sel = g2l_dep_queue_V_1_sel_rd.read();
}

void compute::thread_g2l_dep_queue_V_1_vld_in() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state30.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_1, tmp_372_fu_4419_p3.read()) && 
         esl_seteq<1,1,1>(ap_block_state30_io.read(), ap_const_boolean_0))) {
        g2l_dep_queue_V_1_vld_in = ap_const_logic_1;
    } else {
        g2l_dep_queue_V_1_vld_in = ap_const_logic_0;
    }
}

void compute::thread_g2l_dep_queue_V_1_vld_out() {
    g2l_dep_queue_V_1_vld_out = g2l_dep_queue_V_1_state.read()[0];
}

void compute::thread_g2l_dep_queue_V_TDATA() {
    g2l_dep_queue_V_TDATA = g2l_dep_queue_V_1_data_out.read();
}

void compute::thread_g2l_dep_queue_V_TDATA_blk_n() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state30.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_1, tmp_372_fu_4419_p3.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state87.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_1, tmp_372_reg_13956.read())))) {
        g2l_dep_queue_V_TDATA_blk_n = g2l_dep_queue_V_1_state.read()[1];
    } else {
        g2l_dep_queue_V_TDATA_blk_n = ap_const_logic_1;
    }
}

void compute::thread_g2l_dep_queue_V_TVALID() {
    g2l_dep_queue_V_TVALID = g2l_dep_queue_V_1_state.read()[0];
}

void compute::thread_g2s_dep_queue_V_1_ack_in() {
    g2s_dep_queue_V_1_ack_in = g2s_dep_queue_V_1_state.read()[1];
}

void compute::thread_g2s_dep_queue_V_1_ack_out() {
    g2s_dep_queue_V_1_ack_out = g2s_dep_queue_V_TREADY.read();
}

void compute::thread_g2s_dep_queue_V_1_data_out() {
    g2s_dep_queue_V_1_data_out = ap_const_lv8_1;
}

void compute::thread_g2s_dep_queue_V_1_sel() {
    g2s_dep_queue_V_1_sel = g2s_dep_queue_V_1_sel_rd.read();
}

void compute::thread_g2s_dep_queue_V_1_vld_in() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state87.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_1, tmp_373_fu_11411_p3.read()) && 
         esl_seteq<1,1,1>(ap_block_state87_io.read(), ap_const_boolean_0))) {
        g2s_dep_queue_V_1_vld_in = ap_const_logic_1;
    } else {
        g2s_dep_queue_V_1_vld_in = ap_const_logic_0;
    }
}

void compute::thread_g2s_dep_queue_V_1_vld_out() {
    g2s_dep_queue_V_1_vld_out = g2s_dep_queue_V_1_state.read()[0];
}

void compute::thread_g2s_dep_queue_V_TDATA() {
    g2s_dep_queue_V_TDATA = g2s_dep_queue_V_1_data_out.read();
}

void compute::thread_g2s_dep_queue_V_TDATA_blk_n() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state87.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_1, tmp_373_fu_11411_p3.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state88.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_1, tmp_373_reg_19170.read())))) {
        g2s_dep_queue_V_TDATA_blk_n = g2s_dep_queue_V_1_state.read()[1];
    } else {
        g2s_dep_queue_V_TDATA_blk_n = ap_const_logic_1;
    }
}

void compute::thread_g2s_dep_queue_V_TVALID() {
    g2s_dep_queue_V_TVALID = g2s_dep_queue_V_1_state.read()[0];
}

void compute::thread_gemm_queue_V_V_0_ack_in() {
    gemm_queue_V_V_0_ack_in = gemm_queue_V_V_0_state.read()[1];
}

void compute::thread_gemm_queue_V_V_0_ack_out() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, ap_start.read()) || esl_seteq<1,1,1>(ap_const_logic_0, gemm_queue_V_V_0_vld_out.read()) || (esl_seteq<1,1,1>(ap_const_lv1_1, tmp_2_fu_1682_p3.read()) && 
  esl_seteq<1,1,1>(ap_const_logic_0, l2g_dep_queue_V_0_vld_out.read())) || (esl_seteq<1,1,1>(ap_const_lv1_1, tmp_3_fu_1690_p3.read()) && 
  esl_seteq<1,1,1>(ap_const_logic_0, s2g_dep_queue_V_0_vld_out.read()))))) {
        gemm_queue_V_V_0_ack_out = ap_const_logic_1;
    } else {
        gemm_queue_V_V_0_ack_out = ap_const_logic_0;
    }
}

void compute::thread_gemm_queue_V_V_0_data_out() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, gemm_queue_V_V_0_sel.read())) {
        gemm_queue_V_V_0_data_out = gemm_queue_V_V_0_payload_B.read();
    } else {
        gemm_queue_V_V_0_data_out = gemm_queue_V_V_0_payload_A.read();
    }
}

void compute::thread_gemm_queue_V_V_0_load_A() {
    gemm_queue_V_V_0_load_A = (gemm_queue_V_V_0_state_cmp_full.read() & ~gemm_queue_V_V_0_sel_wr.read());
}

void compute::thread_gemm_queue_V_V_0_load_B() {
    gemm_queue_V_V_0_load_B = (gemm_queue_V_V_0_sel_wr.read() & gemm_queue_V_V_0_state_cmp_full.read());
}

void compute::thread_gemm_queue_V_V_0_sel() {
    gemm_queue_V_V_0_sel = gemm_queue_V_V_0_sel_rd.read();
}

void compute::thread_gemm_queue_V_V_0_state_cmp_full() {
    gemm_queue_V_V_0_state_cmp_full =  (sc_logic) ((!gemm_queue_V_V_0_state.read().is_01() || !ap_const_lv2_1.is_01())? sc_lv<1>(): sc_lv<1>(gemm_queue_V_V_0_state.read() != ap_const_lv2_1))[0];
}

void compute::thread_gemm_queue_V_V_0_vld_in() {
    gemm_queue_V_V_0_vld_in = gemm_queue_V_V_TVALID.read();
}

void compute::thread_gemm_queue_V_V_0_vld_out() {
    gemm_queue_V_V_0_vld_out = gemm_queue_V_V_0_state.read()[0];
}

void compute::thread_gemm_queue_V_V_TDATA_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         esl_seteq<1,1,1>(ap_start.read(), ap_const_logic_1))) {
        gemm_queue_V_V_TDATA_blk_n = gemm_queue_V_V_0_state.read()[0];
    } else {
        gemm_queue_V_V_TDATA_blk_n = ap_const_logic_1;
    }
}

void compute::thread_gemm_queue_V_V_TREADY() {
    gemm_queue_V_V_TREADY = gemm_queue_V_V_0_state.read()[1];
}

void compute::thread_grp_fu_11418_p0() {
    grp_fu_11418_p0 =  (sc_lv<8>) (lhs_V_2_fu_7439_p1.read());
}

void compute::thread_grp_fu_11426_p0() {
    grp_fu_11426_p0 =  (sc_lv<8>) (lhs_V_2_0_0_2_fu_7445_p1.read());
}

void compute::thread_grp_fu_11434_p0() {
    grp_fu_11434_p0 =  (sc_lv<8>) (lhs_V_2_0_0_4_fu_7451_p1.read());
}

void compute::thread_grp_fu_11442_p0() {
    grp_fu_11442_p0 =  (sc_lv<8>) (lhs_V_2_0_0_6_fu_7457_p1.read());
}

void compute::thread_grp_fu_11450_p0() {
    grp_fu_11450_p0 =  (sc_lv<8>) (lhs_V_2_0_0_8_fu_7463_p1.read());
}

void compute::thread_grp_fu_11458_p0() {
    grp_fu_11458_p0 =  (sc_lv<8>) (lhs_V_2_0_0_s_fu_7469_p1.read());
}

void compute::thread_grp_fu_11466_p0() {
    grp_fu_11466_p0 =  (sc_lv<8>) (lhs_V_2_0_0_11_fu_7475_p1.read());
}

void compute::thread_grp_fu_11474_p0() {
    grp_fu_11474_p0 =  (sc_lv<8>) (lhs_V_2_0_0_13_fu_7481_p1.read());
}

void compute::thread_grp_fu_11482_p0() {
    grp_fu_11482_p0 =  (sc_lv<8>) (lhs_V_2_fu_7439_p1.read());
}

void compute::thread_grp_fu_11490_p0() {
    grp_fu_11490_p0 =  (sc_lv<8>) (lhs_V_2_0_0_2_fu_7445_p1.read());
}

void compute::thread_grp_fu_11498_p0() {
    grp_fu_11498_p0 =  (sc_lv<8>) (lhs_V_2_0_0_4_fu_7451_p1.read());
}

void compute::thread_grp_fu_11506_p0() {
    grp_fu_11506_p0 =  (sc_lv<8>) (lhs_V_2_0_0_6_fu_7457_p1.read());
}

void compute::thread_grp_fu_11514_p0() {
    grp_fu_11514_p0 =  (sc_lv<8>) (lhs_V_2_0_0_8_fu_7463_p1.read());
}

void compute::thread_grp_fu_11522_p0() {
    grp_fu_11522_p0 =  (sc_lv<8>) (lhs_V_2_0_0_s_fu_7469_p1.read());
}

void compute::thread_grp_fu_11530_p0() {
    grp_fu_11530_p0 =  (sc_lv<8>) (lhs_V_2_0_0_11_fu_7475_p1.read());
}

void compute::thread_grp_fu_11538_p0() {
    grp_fu_11538_p0 =  (sc_lv<8>) (lhs_V_2_0_0_13_fu_7481_p1.read());
}

void compute::thread_grp_fu_11546_p0() {
    grp_fu_11546_p0 =  (sc_lv<8>) (lhs_V_2_fu_7439_p1.read());
}

void compute::thread_grp_fu_11554_p0() {
    grp_fu_11554_p0 =  (sc_lv<8>) (lhs_V_2_0_0_2_fu_7445_p1.read());
}

void compute::thread_grp_fu_11562_p0() {
    grp_fu_11562_p0 =  (sc_lv<8>) (lhs_V_2_0_0_4_fu_7451_p1.read());
}

void compute::thread_grp_fu_11570_p0() {
    grp_fu_11570_p0 =  (sc_lv<8>) (lhs_V_2_0_0_6_fu_7457_p1.read());
}

void compute::thread_grp_fu_11578_p0() {
    grp_fu_11578_p0 =  (sc_lv<8>) (lhs_V_2_0_0_8_fu_7463_p1.read());
}

void compute::thread_grp_fu_11586_p0() {
    grp_fu_11586_p0 =  (sc_lv<8>) (lhs_V_2_0_0_s_fu_7469_p1.read());
}

void compute::thread_grp_fu_11594_p0() {
    grp_fu_11594_p0 =  (sc_lv<8>) (lhs_V_2_0_0_11_fu_7475_p1.read());
}

void compute::thread_grp_fu_11602_p0() {
    grp_fu_11602_p0 =  (sc_lv<8>) (lhs_V_2_0_0_13_fu_7481_p1.read());
}

void compute::thread_grp_fu_11610_p0() {
    grp_fu_11610_p0 =  (sc_lv<8>) (lhs_V_2_fu_7439_p1.read());
}

void compute::thread_grp_fu_11618_p0() {
    grp_fu_11618_p0 =  (sc_lv<8>) (lhs_V_2_0_0_2_fu_7445_p1.read());
}

void compute::thread_grp_fu_11626_p0() {
    grp_fu_11626_p0 =  (sc_lv<8>) (lhs_V_2_0_0_4_fu_7451_p1.read());
}

void compute::thread_grp_fu_11634_p0() {
    grp_fu_11634_p0 =  (sc_lv<8>) (lhs_V_2_0_0_6_fu_7457_p1.read());
}

void compute::thread_grp_fu_11642_p0() {
    grp_fu_11642_p0 =  (sc_lv<8>) (lhs_V_2_0_0_8_fu_7463_p1.read());
}

void compute::thread_grp_fu_11650_p0() {
    grp_fu_11650_p0 =  (sc_lv<8>) (lhs_V_2_0_0_s_fu_7469_p1.read());
}

void compute::thread_grp_fu_11658_p0() {
    grp_fu_11658_p0 =  (sc_lv<8>) (lhs_V_2_0_0_11_fu_7475_p1.read());
}

void compute::thread_grp_fu_11666_p0() {
    grp_fu_11666_p0 =  (sc_lv<8>) (lhs_V_2_0_0_13_fu_7481_p1.read());
}

void compute::thread_grp_fu_11674_p0() {
    grp_fu_11674_p0 =  (sc_lv<8>) (lhs_V_2_fu_7439_p1.read());
}

void compute::thread_grp_fu_11682_p0() {
    grp_fu_11682_p0 =  (sc_lv<8>) (lhs_V_2_0_0_2_fu_7445_p1.read());
}

void compute::thread_grp_fu_11690_p0() {
    grp_fu_11690_p0 =  (sc_lv<8>) (lhs_V_2_0_0_4_fu_7451_p1.read());
}

void compute::thread_grp_fu_11698_p0() {
    grp_fu_11698_p0 =  (sc_lv<8>) (lhs_V_2_0_0_6_fu_7457_p1.read());
}

void compute::thread_grp_fu_11706_p0() {
    grp_fu_11706_p0 =  (sc_lv<8>) (lhs_V_2_0_0_8_fu_7463_p1.read());
}

void compute::thread_grp_fu_11714_p0() {
    grp_fu_11714_p0 =  (sc_lv<8>) (lhs_V_2_0_0_s_fu_7469_p1.read());
}

void compute::thread_grp_fu_11722_p0() {
    grp_fu_11722_p0 =  (sc_lv<8>) (lhs_V_2_0_0_11_fu_7475_p1.read());
}

void compute::thread_grp_fu_11730_p0() {
    grp_fu_11730_p0 =  (sc_lv<8>) (lhs_V_2_0_0_13_fu_7481_p1.read());
}

void compute::thread_grp_fu_11738_p0() {
    grp_fu_11738_p0 =  (sc_lv<8>) (lhs_V_2_fu_7439_p1.read());
}

void compute::thread_grp_fu_11746_p0() {
    grp_fu_11746_p0 =  (sc_lv<8>) (lhs_V_2_0_0_2_fu_7445_p1.read());
}

void compute::thread_grp_fu_11754_p0() {
    grp_fu_11754_p0 =  (sc_lv<8>) (lhs_V_2_0_0_4_fu_7451_p1.read());
}

void compute::thread_grp_fu_11762_p0() {
    grp_fu_11762_p0 =  (sc_lv<8>) (lhs_V_2_0_0_6_fu_7457_p1.read());
}

void compute::thread_grp_fu_11770_p0() {
    grp_fu_11770_p0 =  (sc_lv<8>) (lhs_V_2_0_0_8_fu_7463_p1.read());
}

void compute::thread_grp_fu_11778_p0() {
    grp_fu_11778_p0 =  (sc_lv<8>) (lhs_V_2_0_0_s_fu_7469_p1.read());
}

void compute::thread_grp_fu_11786_p0() {
    grp_fu_11786_p0 =  (sc_lv<8>) (lhs_V_2_0_0_11_fu_7475_p1.read());
}

void compute::thread_grp_fu_11794_p0() {
    grp_fu_11794_p0 =  (sc_lv<8>) (lhs_V_2_0_0_13_fu_7481_p1.read());
}

void compute::thread_grp_fu_11802_p0() {
    grp_fu_11802_p0 =  (sc_lv<8>) (lhs_V_2_fu_7439_p1.read());
}

void compute::thread_grp_fu_11810_p0() {
    grp_fu_11810_p0 =  (sc_lv<8>) (lhs_V_2_0_0_2_fu_7445_p1.read());
}

void compute::thread_grp_fu_11818_p0() {
    grp_fu_11818_p0 =  (sc_lv<8>) (lhs_V_2_0_0_4_fu_7451_p1.read());
}

void compute::thread_grp_fu_11826_p0() {
    grp_fu_11826_p0 =  (sc_lv<8>) (lhs_V_2_0_0_6_fu_7457_p1.read());
}

void compute::thread_grp_fu_11834_p0() {
    grp_fu_11834_p0 =  (sc_lv<8>) (lhs_V_2_0_0_8_fu_7463_p1.read());
}

void compute::thread_grp_fu_11842_p0() {
    grp_fu_11842_p0 =  (sc_lv<8>) (lhs_V_2_0_0_s_fu_7469_p1.read());
}

void compute::thread_grp_fu_11850_p0() {
    grp_fu_11850_p0 =  (sc_lv<8>) (lhs_V_2_0_0_11_fu_7475_p1.read());
}

void compute::thread_grp_fu_11858_p0() {
    grp_fu_11858_p0 =  (sc_lv<8>) (lhs_V_2_0_0_13_fu_7481_p1.read());
}

void compute::thread_grp_fu_11866_p0() {
    grp_fu_11866_p0 =  (sc_lv<8>) (lhs_V_2_fu_7439_p1.read());
}

void compute::thread_grp_fu_11874_p0() {
    grp_fu_11874_p0 =  (sc_lv<8>) (lhs_V_2_0_0_2_fu_7445_p1.read());
}

void compute::thread_grp_fu_11882_p0() {
    grp_fu_11882_p0 =  (sc_lv<8>) (lhs_V_2_0_0_4_fu_7451_p1.read());
}

void compute::thread_grp_fu_11890_p0() {
    grp_fu_11890_p0 =  (sc_lv<8>) (lhs_V_2_0_0_6_fu_7457_p1.read());
}

void compute::thread_grp_fu_11898_p0() {
    grp_fu_11898_p0 =  (sc_lv<8>) (lhs_V_2_0_0_8_fu_7463_p1.read());
}

void compute::thread_grp_fu_11906_p0() {
    grp_fu_11906_p0 =  (sc_lv<8>) (lhs_V_2_0_0_s_fu_7469_p1.read());
}

void compute::thread_grp_fu_11914_p0() {
    grp_fu_11914_p0 =  (sc_lv<8>) (lhs_V_2_0_0_11_fu_7475_p1.read());
}

void compute::thread_grp_fu_11922_p0() {
    grp_fu_11922_p0 =  (sc_lv<8>) (lhs_V_2_0_0_13_fu_7481_p1.read());
}

void compute::thread_grp_fu_11930_p0() {
    grp_fu_11930_p0 =  (sc_lv<8>) (lhs_V_2_fu_7439_p1.read());
}

void compute::thread_grp_fu_11938_p0() {
    grp_fu_11938_p0 =  (sc_lv<8>) (lhs_V_2_0_0_2_fu_7445_p1.read());
}

void compute::thread_grp_fu_11946_p0() {
    grp_fu_11946_p0 =  (sc_lv<8>) (lhs_V_2_0_0_4_fu_7451_p1.read());
}

void compute::thread_grp_fu_11954_p0() {
    grp_fu_11954_p0 =  (sc_lv<8>) (lhs_V_2_0_0_6_fu_7457_p1.read());
}

void compute::thread_grp_fu_11962_p0() {
    grp_fu_11962_p0 =  (sc_lv<8>) (lhs_V_2_0_0_8_fu_7463_p1.read());
}

void compute::thread_grp_fu_11970_p0() {
    grp_fu_11970_p0 =  (sc_lv<8>) (lhs_V_2_0_0_s_fu_7469_p1.read());
}

void compute::thread_grp_fu_11978_p0() {
    grp_fu_11978_p0 =  (sc_lv<8>) (lhs_V_2_0_0_11_fu_7475_p1.read());
}

void compute::thread_grp_fu_11986_p0() {
    grp_fu_11986_p0 =  (sc_lv<8>) (lhs_V_2_0_0_13_fu_7481_p1.read());
}

void compute::thread_grp_fu_11994_p0() {
    grp_fu_11994_p0 =  (sc_lv<8>) (lhs_V_2_fu_7439_p1.read());
}

void compute::thread_grp_fu_12002_p0() {
    grp_fu_12002_p0 =  (sc_lv<8>) (lhs_V_2_0_0_2_fu_7445_p1.read());
}

void compute::thread_grp_fu_12010_p0() {
    grp_fu_12010_p0 =  (sc_lv<8>) (lhs_V_2_0_0_4_fu_7451_p1.read());
}

void compute::thread_grp_fu_12018_p0() {
    grp_fu_12018_p0 =  (sc_lv<8>) (lhs_V_2_0_0_6_fu_7457_p1.read());
}

void compute::thread_grp_fu_12026_p0() {
    grp_fu_12026_p0 =  (sc_lv<8>) (lhs_V_2_0_0_8_fu_7463_p1.read());
}

void compute::thread_grp_fu_12034_p0() {
    grp_fu_12034_p0 =  (sc_lv<8>) (lhs_V_2_0_0_s_fu_7469_p1.read());
}

void compute::thread_grp_fu_12042_p0() {
    grp_fu_12042_p0 =  (sc_lv<8>) (lhs_V_2_0_0_11_fu_7475_p1.read());
}

void compute::thread_grp_fu_12050_p0() {
    grp_fu_12050_p0 =  (sc_lv<8>) (lhs_V_2_0_0_13_fu_7481_p1.read());
}

void compute::thread_grp_fu_12058_p0() {
    grp_fu_12058_p0 =  (sc_lv<8>) (lhs_V_2_fu_7439_p1.read());
}

void compute::thread_grp_fu_12066_p0() {
    grp_fu_12066_p0 =  (sc_lv<8>) (lhs_V_2_0_0_2_fu_7445_p1.read());
}

void compute::thread_grp_fu_12074_p0() {
    grp_fu_12074_p0 =  (sc_lv<8>) (lhs_V_2_0_0_4_fu_7451_p1.read());
}

void compute::thread_grp_fu_12082_p0() {
    grp_fu_12082_p0 =  (sc_lv<8>) (lhs_V_2_0_0_6_fu_7457_p1.read());
}

void compute::thread_grp_fu_12090_p0() {
    grp_fu_12090_p0 =  (sc_lv<8>) (lhs_V_2_0_0_8_fu_7463_p1.read());
}

void compute::thread_grp_fu_12098_p0() {
    grp_fu_12098_p0 =  (sc_lv<8>) (lhs_V_2_0_0_s_fu_7469_p1.read());
}

void compute::thread_grp_fu_12106_p0() {
    grp_fu_12106_p0 =  (sc_lv<8>) (lhs_V_2_0_0_11_fu_7475_p1.read());
}

void compute::thread_grp_fu_12114_p0() {
    grp_fu_12114_p0 =  (sc_lv<8>) (lhs_V_2_0_0_13_fu_7481_p1.read());
}

void compute::thread_grp_fu_12122_p0() {
    grp_fu_12122_p0 =  (sc_lv<8>) (lhs_V_2_fu_7439_p1.read());
}

void compute::thread_grp_fu_12130_p0() {
    grp_fu_12130_p0 =  (sc_lv<8>) (lhs_V_2_0_0_2_fu_7445_p1.read());
}

void compute::thread_grp_fu_12138_p0() {
    grp_fu_12138_p0 =  (sc_lv<8>) (lhs_V_2_0_0_4_fu_7451_p1.read());
}

void compute::thread_grp_fu_12146_p0() {
    grp_fu_12146_p0 =  (sc_lv<8>) (lhs_V_2_0_0_6_fu_7457_p1.read());
}

void compute::thread_grp_fu_12154_p0() {
    grp_fu_12154_p0 =  (sc_lv<8>) (lhs_V_2_0_0_8_fu_7463_p1.read());
}

void compute::thread_grp_fu_12162_p0() {
    grp_fu_12162_p0 =  (sc_lv<8>) (lhs_V_2_0_0_s_fu_7469_p1.read());
}

void compute::thread_grp_fu_12170_p0() {
    grp_fu_12170_p0 =  (sc_lv<8>) (lhs_V_2_0_0_11_fu_7475_p1.read());
}

void compute::thread_grp_fu_12178_p0() {
    grp_fu_12178_p0 =  (sc_lv<8>) (lhs_V_2_0_0_13_fu_7481_p1.read());
}

void compute::thread_grp_fu_12186_p0() {
    grp_fu_12186_p0 =  (sc_lv<8>) (lhs_V_2_fu_7439_p1.read());
}

void compute::thread_grp_fu_12194_p0() {
    grp_fu_12194_p0 =  (sc_lv<8>) (lhs_V_2_0_0_2_fu_7445_p1.read());
}

void compute::thread_grp_fu_12202_p0() {
    grp_fu_12202_p0 =  (sc_lv<8>) (lhs_V_2_0_0_4_fu_7451_p1.read());
}

void compute::thread_grp_fu_12210_p0() {
    grp_fu_12210_p0 =  (sc_lv<8>) (lhs_V_2_0_0_6_fu_7457_p1.read());
}

void compute::thread_grp_fu_12218_p0() {
    grp_fu_12218_p0 =  (sc_lv<8>) (lhs_V_2_0_0_8_fu_7463_p1.read());
}

void compute::thread_grp_fu_12226_p0() {
    grp_fu_12226_p0 =  (sc_lv<8>) (lhs_V_2_0_0_s_fu_7469_p1.read());
}

void compute::thread_grp_fu_12234_p0() {
    grp_fu_12234_p0 =  (sc_lv<8>) (lhs_V_2_0_0_11_fu_7475_p1.read());
}

void compute::thread_grp_fu_12242_p0() {
    grp_fu_12242_p0 =  (sc_lv<8>) (lhs_V_2_0_0_13_fu_7481_p1.read());
}

void compute::thread_grp_fu_12250_p0() {
    grp_fu_12250_p0 =  (sc_lv<8>) (lhs_V_2_fu_7439_p1.read());
}

void compute::thread_grp_fu_12258_p0() {
    grp_fu_12258_p0 =  (sc_lv<8>) (lhs_V_2_0_0_2_fu_7445_p1.read());
}

void compute::thread_grp_fu_12266_p0() {
    grp_fu_12266_p0 =  (sc_lv<8>) (lhs_V_2_0_0_4_fu_7451_p1.read());
}

void compute::thread_grp_fu_12274_p0() {
    grp_fu_12274_p0 =  (sc_lv<8>) (lhs_V_2_0_0_6_fu_7457_p1.read());
}

void compute::thread_grp_fu_12282_p0() {
    grp_fu_12282_p0 =  (sc_lv<8>) (lhs_V_2_0_0_8_fu_7463_p1.read());
}

void compute::thread_grp_fu_12290_p0() {
    grp_fu_12290_p0 =  (sc_lv<8>) (lhs_V_2_0_0_s_fu_7469_p1.read());
}

void compute::thread_grp_fu_12298_p0() {
    grp_fu_12298_p0 =  (sc_lv<8>) (lhs_V_2_0_0_11_fu_7475_p1.read());
}

void compute::thread_grp_fu_12306_p0() {
    grp_fu_12306_p0 =  (sc_lv<8>) (lhs_V_2_0_0_13_fu_7481_p1.read());
}

void compute::thread_grp_fu_12314_p0() {
    grp_fu_12314_p0 =  (sc_lv<8>) (lhs_V_2_fu_7439_p1.read());
}

void compute::thread_grp_fu_12322_p0() {
    grp_fu_12322_p0 =  (sc_lv<8>) (lhs_V_2_0_0_2_fu_7445_p1.read());
}

void compute::thread_grp_fu_12330_p0() {
    grp_fu_12330_p0 =  (sc_lv<8>) (lhs_V_2_0_0_4_fu_7451_p1.read());
}

void compute::thread_grp_fu_12338_p0() {
    grp_fu_12338_p0 =  (sc_lv<8>) (lhs_V_2_0_0_6_fu_7457_p1.read());
}

void compute::thread_grp_fu_12346_p0() {
    grp_fu_12346_p0 =  (sc_lv<8>) (lhs_V_2_0_0_8_fu_7463_p1.read());
}

void compute::thread_grp_fu_12354_p0() {
    grp_fu_12354_p0 =  (sc_lv<8>) (lhs_V_2_0_0_s_fu_7469_p1.read());
}

void compute::thread_grp_fu_12362_p0() {
    grp_fu_12362_p0 =  (sc_lv<8>) (lhs_V_2_0_0_11_fu_7475_p1.read());
}

void compute::thread_grp_fu_12370_p0() {
    grp_fu_12370_p0 =  (sc_lv<8>) (lhs_V_2_0_0_13_fu_7481_p1.read());
}

void compute::thread_grp_fu_12378_p0() {
    grp_fu_12378_p0 =  (sc_lv<8>) (lhs_V_2_fu_7439_p1.read());
}

void compute::thread_grp_fu_12386_p0() {
    grp_fu_12386_p0 =  (sc_lv<8>) (lhs_V_2_0_0_2_fu_7445_p1.read());
}

void compute::thread_grp_fu_12394_p0() {
    grp_fu_12394_p0 =  (sc_lv<8>) (lhs_V_2_0_0_4_fu_7451_p1.read());
}

void compute::thread_grp_fu_12402_p0() {
    grp_fu_12402_p0 =  (sc_lv<8>) (lhs_V_2_0_0_6_fu_7457_p1.read());
}

void compute::thread_grp_fu_12410_p0() {
    grp_fu_12410_p0 =  (sc_lv<8>) (lhs_V_2_0_0_8_fu_7463_p1.read());
}

void compute::thread_grp_fu_12418_p0() {
    grp_fu_12418_p0 =  (sc_lv<8>) (lhs_V_2_0_0_s_fu_7469_p1.read());
}

void compute::thread_grp_fu_12426_p0() {
    grp_fu_12426_p0 =  (sc_lv<8>) (lhs_V_2_0_0_11_fu_7475_p1.read());
}

void compute::thread_grp_fu_12434_p0() {
    grp_fu_12434_p0 =  (sc_lv<8>) (lhs_V_2_0_0_13_fu_7481_p1.read());
}

void compute::thread_grp_fu_1324_p4() {
    grp_fu_1324_p4 = gemm_queue_V_V_0_data_out.read().range(20, 8);
}

void compute::thread_grp_fu_1334_p4() {
    grp_fu_1334_p4 = gemm_queue_V_V_0_data_out.read().range(34, 21);
}

void compute::thread_grp_fu_1344_p1() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state75.read())) {
        grp_fu_1344_p1 = tmp_V_reg_12452.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read())) {
        grp_fu_1344_p1 = gemm_queue_V_V_0_data_out.read();
    } else {
        grp_fu_1344_p1 =  (sc_lv<128>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void compute::thread_grp_fu_1344_p4() {
    grp_fu_1344_p4 = grp_fu_1344_p1.read().range(95, 80);
}

void compute::thread_grp_fu_1354_p4() {
    grp_fu_1354_p4 = tmp_V_reg_12452.read().range(62, 49);
}

void compute::thread_grp_fu_1363_p4() {
    grp_fu_1363_p4 = tmp_V_reg_12452.read().range(48, 35);
}

void compute::thread_grp_fu_1372_p4() {
    grp_fu_1372_p4 = tmp_V_reg_12452.read().range(85, 75);
}

void compute::thread_grp_fu_1381_p4() {
    grp_fu_1381_p4 = tmp_V_reg_12452.read().range(107, 97);
}

void compute::thread_grp_fu_1390_p4() {
    grp_fu_1390_p4 = tmp_V_reg_12452.read().range(74, 64);
}

void compute::thread_grp_fu_1399_p4() {
    grp_fu_1399_p4 = tmp_V_reg_12452.read().range(96, 86);
}

void compute::thread_grp_fu_1850_p0() {
    grp_fu_1850_p0 =  (sc_lv<32>) (grp_fu_1850_p00.read());
}

void compute::thread_grp_fu_1850_p00() {
    grp_fu_1850_p00 = esl_zext<46,32>(tmp_40_cast_fu_1839_p1.read());
}

void compute::thread_grp_fu_1850_p1() {
    grp_fu_1850_p1 =  (sc_lv<14>) (grp_fu_1850_p10.read());
}

void compute::thread_grp_fu_1850_p10() {
    grp_fu_1850_p10 = esl_zext<46,14>(grp_fu_1354_p4.read());
}

void compute::thread_grp_fu_1863_p0() {
    grp_fu_1863_p0 =  (sc_lv<46>) (grp_fu_1863_p00.read());
}

void compute::thread_grp_fu_1863_p00() {
    grp_fu_1863_p00 = esl_zext<60,46>(bound1_reg_12672.read());
}

void compute::thread_grp_fu_1863_p1() {
    grp_fu_1863_p1 =  (sc_lv<14>) (grp_fu_1863_p10.read());
}

void compute::thread_grp_fu_1863_p10() {
    grp_fu_1863_p10 = esl_zext<60,14>(grp_fu_1363_p4.read());
}

void compute::thread_grp_fu_4462_p0() {
    grp_fu_4462_p0 =  (sc_lv<14>) (grp_fu_4462_p00.read());
}

void compute::thread_grp_fu_4462_p00() {
    grp_fu_4462_p00 = esl_zext<46,14>(grp_fu_1354_p4.read());
}

void compute::thread_grp_fu_4462_p1() {
    grp_fu_4462_p1 =  (sc_lv<32>) (grp_fu_4462_p10.read());
}

void compute::thread_grp_fu_4462_p10() {
    grp_fu_4462_p10 = esl_zext<46,32>(tmp_23_cast_fu_4451_p1.read());
}

void compute::thread_grp_fu_4475_p0() {
    grp_fu_4475_p0 =  (sc_lv<14>) (grp_fu_4475_p00.read());
}

void compute::thread_grp_fu_4475_p00() {
    grp_fu_4475_p00 = esl_zext<60,14>(grp_fu_1363_p4.read());
}

void compute::thread_grp_fu_4475_p1() {
    grp_fu_4475_p1 =  (sc_lv<46>) (grp_fu_4475_p10.read());
}

void compute::thread_grp_fu_4475_p10() {
    grp_fu_4475_p10 = esl_zext<60,46>(bound_reg_13980.read());
}

void compute::thread_indvar_flatten25_op_fu_1979_p2() {
    indvar_flatten25_op_fu_1979_p2 = (!ap_const_lv46_1.is_01() || !ap_phi_mux_indvar_flatten3_phi_fu_1129_p4.read().is_01())? sc_lv<46>(): (sc_biguint<46>(ap_const_lv46_1) + sc_biguint<46>(ap_phi_mux_indvar_flatten3_phi_fu_1129_p4.read()));
}

void compute::thread_indvar_flatten_next1_fu_4543_p2() {
    indvar_flatten_next1_fu_4543_p2 = (!indvar_flatten1_reg_1170.read().is_01() || !ap_const_lv60_1.is_01())? sc_lv<60>(): (sc_biguint<60>(indvar_flatten1_reg_1170.read()) + sc_biguint<60>(ap_const_lv60_1));
}

void compute::thread_indvar_flatten_next2_fu_2020_p3() {
    indvar_flatten_next2_fu_2020_p3 = (!exitcond_flatten2_reg_12924.read()[0].is_01())? sc_lv<46>(): ((exitcond_flatten2_reg_12924.read()[0].to_bool())? ap_const_lv46_1: indvar_flatten25_op_reg_12941.read());
}

void compute::thread_indvar_flatten_next3_fu_1958_p2() {
    indvar_flatten_next3_fu_1958_p2 = (!ap_phi_mux_indvar_flatten2_phi_fu_1094_p4.read().is_01() || !ap_const_lv60_1.is_01())? sc_lv<60>(): (sc_biguint<60>(ap_phi_mux_indvar_flatten2_phi_fu_1094_p4.read()) + sc_biguint<60>(ap_const_lv60_1));
}

void compute::thread_indvar_flatten_next_fu_4604_p3() {
    indvar_flatten_next_fu_4604_p3 = (!exitcond_flatten_fu_4554_p2.read()[0].is_01())? sc_lv<46>(): ((exitcond_flatten_fu_4554_p2.read()[0].to_bool())? ap_const_lv46_1: indvar_flatten_op_fu_4598_p2.read());
}

void compute::thread_indvar_flatten_op_fu_4598_p2() {
    indvar_flatten_op_fu_4598_p2 = (!ap_const_lv46_1.is_01() || !indvar_flatten_reg_1214.read().is_01())? sc_lv<46>(): (sc_biguint<46>(ap_const_lv46_1) + sc_biguint<46>(indvar_flatten_reg_1214.read()));
}

void compute::thread_indvar_next1_fu_11175_p2() {
    indvar_next1_fu_11175_p2 = (!indvar2_reg_1302.read().is_01() || !ap_const_lv18_1.is_01())? sc_lv<18>(): (sc_biguint<18>(indvar2_reg_1302.read()) + sc_biguint<18>(ap_const_lv18_1));
}

void compute::thread_indvar_next_fu_11392_p2() {
    indvar_next_fu_11392_p2 = (!indvar_reg_1313.read().is_01() || !ap_const_lv16_1.is_01())? sc_lv<16>(): (sc_biguint<16>(indvar_reg_1313.read()) + sc_biguint<16>(ap_const_lv16_1));
}

void compute::thread_inp_mem_V_Addr_A() {
    inp_mem_V_Addr_A = (!ap_const_lv32_4.is_01())? sc_lv<32>(): inp_mem_V_Addr_A_orig.read() << (unsigned short)ap_const_lv32_4.to_uint();
}

void compute::thread_inp_mem_V_Addr_A_orig() {
    inp_mem_V_Addr_A_orig =  (sc_lv<32>) (tmp_45_fu_4733_p1.read());
}

void compute::thread_inp_mem_V_Clk_A() {
    inp_mem_V_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void compute::thread_inp_mem_V_Din_A() {
    inp_mem_V_Din_A = ap_const_lv128_lc_1;
}

void compute::thread_inp_mem_V_EN_A() {
    if ((esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter5.read()))) {
        inp_mem_V_EN_A = ap_const_logic_1;
    } else {
        inp_mem_V_EN_A = ap_const_logic_0;
    }
}

void compute::thread_inp_mem_V_Rst_A() {
    inp_mem_V_Rst_A = ap_rst_n_inv.read();
}

void compute::thread_inp_mem_V_WEN_A() {
    inp_mem_V_WEN_A = ap_const_lv16_0;
}

void compute::thread_l2g_dep_queue_V_0_ack_out() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_1, tmp_2_fu_1682_p3.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, ap_start.read()) || esl_seteq<1,1,1>(ap_const_logic_0, gemm_queue_V_V_0_vld_out.read()) || (esl_seteq<1,1,1>(ap_const_lv1_1, tmp_2_fu_1682_p3.read()) && 
  esl_seteq<1,1,1>(ap_const_logic_0, l2g_dep_queue_V_0_vld_out.read())) || (esl_seteq<1,1,1>(ap_const_lv1_1, tmp_3_fu_1690_p3.read()) && 
  esl_seteq<1,1,1>(ap_const_logic_0, s2g_dep_queue_V_0_vld_out.read()))))) {
        l2g_dep_queue_V_0_ack_out = ap_const_logic_1;
    } else {
        l2g_dep_queue_V_0_ack_out = ap_const_logic_0;
    }
}

void compute::thread_l2g_dep_queue_V_0_vld_in() {
    l2g_dep_queue_V_0_vld_in = l2g_dep_queue_V_TVALID.read();
}

void compute::thread_l2g_dep_queue_V_0_vld_out() {
    l2g_dep_queue_V_0_vld_out = l2g_dep_queue_V_0_state.read()[0];
}

void compute::thread_l2g_dep_queue_V_TDATA_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         esl_seteq<1,1,1>(ap_start.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_const_lv1_1, tmp_2_fu_1682_p3.read()))) {
        l2g_dep_queue_V_TDATA_blk_n = l2g_dep_queue_V_0_state.read()[0];
    } else {
        l2g_dep_queue_V_TDATA_blk_n = ap_const_logic_1;
    }
}

void compute::thread_l2g_dep_queue_V_TREADY() {
    l2g_dep_queue_V_TREADY = l2g_dep_queue_V_0_state.read()[1];
}

void compute::thread_lhs_V_2_0_0_10_fu_7907_p1() {
    lhs_V_2_0_0_10_fu_7907_p1 = esl_sext<16,8>(i_tensor_i_0_10_reg_15561_pp1_iter7_reg.read());
}

void compute::thread_lhs_V_2_0_0_11_fu_7475_p1() {
    lhs_V_2_0_0_11_fu_7475_p1 = esl_sext<16,8>(i_tensor_i_0_11_reg_15566.read());
}

void compute::thread_lhs_V_2_0_0_12_fu_7919_p1() {
    lhs_V_2_0_0_12_fu_7919_p1 = esl_sext<16,8>(i_tensor_i_0_12_reg_15571_pp1_iter7_reg.read());
}

void compute::thread_lhs_V_2_0_0_13_fu_7481_p1() {
    lhs_V_2_0_0_13_fu_7481_p1 = esl_sext<16,8>(i_tensor_i_0_13_reg_15576.read());
}

void compute::thread_lhs_V_2_0_0_14_fu_7931_p1() {
    lhs_V_2_0_0_14_fu_7931_p1 = esl_sext<16,8>(i_tensor_i_0_14_reg_15581_pp1_iter7_reg.read());
}

void compute::thread_lhs_V_2_0_0_1_fu_7847_p1() {
    lhs_V_2_0_0_1_fu_7847_p1 = esl_sext<16,8>(i_tensor_i_0_1_reg_15511_pp1_iter7_reg.read());
}

void compute::thread_lhs_V_2_0_0_2_fu_7445_p1() {
    lhs_V_2_0_0_2_fu_7445_p1 = esl_sext<16,8>(i_tensor_i_0_2_reg_15516.read());
}

void compute::thread_lhs_V_2_0_0_3_fu_7859_p1() {
    lhs_V_2_0_0_3_fu_7859_p1 = esl_sext<16,8>(i_tensor_i_0_3_reg_15521_pp1_iter7_reg.read());
}

void compute::thread_lhs_V_2_0_0_4_fu_7451_p1() {
    lhs_V_2_0_0_4_fu_7451_p1 = esl_sext<16,8>(i_tensor_i_0_4_reg_15526.read());
}

void compute::thread_lhs_V_2_0_0_5_fu_7871_p1() {
    lhs_V_2_0_0_5_fu_7871_p1 = esl_sext<16,8>(i_tensor_i_0_5_reg_15531_pp1_iter7_reg.read());
}

void compute::thread_lhs_V_2_0_0_6_fu_7457_p1() {
    lhs_V_2_0_0_6_fu_7457_p1 = esl_sext<16,8>(i_tensor_i_0_6_reg_15536.read());
}

void compute::thread_lhs_V_2_0_0_7_fu_7883_p1() {
    lhs_V_2_0_0_7_fu_7883_p1 = esl_sext<16,8>(i_tensor_i_0_7_reg_15541_pp1_iter7_reg.read());
}

void compute::thread_lhs_V_2_0_0_8_fu_7463_p1() {
    lhs_V_2_0_0_8_fu_7463_p1 = esl_sext<16,8>(i_tensor_i_0_8_reg_15546.read());
}

void compute::thread_lhs_V_2_0_0_9_fu_7895_p1() {
    lhs_V_2_0_0_9_fu_7895_p1 = esl_sext<16,8>(i_tensor_i_0_9_reg_15551_pp1_iter7_reg.read());
}

void compute::thread_lhs_V_2_0_0_s_fu_7469_p1() {
    lhs_V_2_0_0_s_fu_7469_p1 = esl_sext<16,8>(i_tensor_i_0_s_reg_15556.read());
}

void compute::thread_lhs_V_2_fu_7439_p1() {
    lhs_V_2_fu_7439_p1 = esl_sext<16,8>(tmp_46_reg_15506.read());
}

void compute::thread_mask4_fu_1672_p4() {
    mask4_fu_1672_p4 = gemm_queue_V_V_0_data_out.read().range(111, 96);
}

void compute::thread_mask_fu_11312_p2() {
    mask_fu_11312_p2 = (!tmp_371_fu_11308_p1.read().is_01())? sc_lv<64>(): ap_const_lv64_FFFF << (unsigned short)tmp_371_fu_11308_p1.read().to_uint();
}

void compute::thread_o_tensor_0_0_V_1_fu_10767_p1() {
    o_tensor_0_0_V_1_fu_10767_p1 = accum_V_2_fu_10762_p2.read().range(8-1, 0);
}

void compute::thread_o_tensor_0_0_V_2_fu_2567_p1() {
    o_tensor_0_0_V_2_fu_2567_p1 = dst_tensor_0_0_V_1_fu_2560_p3.read().range(8-1, 0);
}

void compute::thread_o_tensor_0_0_V_3_fu_2571_p1() {
    o_tensor_0_0_V_3_fu_2571_p1 = dst_tensor_0_0_V_2_reg_13209.read().range(8-1, 0);
}

void compute::thread_o_tensor_0_0_V_4_fu_2605_p3() {
    o_tensor_0_0_V_4_fu_2605_p3 = (!tmp_29_reg_12796.read()[0].is_01())? sc_lv<8>(): ((tmp_29_reg_12796.read()[0].to_bool())? o_tensor_0_0_V_fu_814.read(): o_tensor_0_0_V_2_fu_2567_p1.read());
}

void compute::thread_o_tensor_0_0_V_5_fu_2612_p3() {
    o_tensor_0_0_V_5_fu_2612_p3 = (!sel_tmp1_reg_12832.read()[0].is_01())? sc_lv<8>(): ((sel_tmp1_reg_12832.read()[0].to_bool())? o_tensor_0_0_V_3_fu_2571_p1.read(): o_tensor_0_0_V_4_fu_2605_p3.read());
}

void compute::thread_o_tensor_0_0_V_6_fu_3380_p3() {
    o_tensor_0_0_V_6_fu_3380_p3 = (!tmp_30_reg_12868.read()[0].is_01())? sc_lv<8>(): ((tmp_30_reg_12868.read()[0].to_bool())? o_tensor_0_0_V_7_fu_3377_p1.read(): o_tensor_0_0_V_5_reg_13458.read());
}

void compute::thread_o_tensor_0_0_V_7_fu_3377_p1() {
    o_tensor_0_0_V_7_fu_3377_p1 = dst_tensor_0_0_V_3_reg_13452.read().range(8-1, 0);
}

void compute::thread_o_tensor_0_10_V_1_fu_3680_p1() {
    o_tensor_0_10_V_1_fu_3680_p1 = dst_tensor_0_10_V_1_fu_3673_p3.read().range(8-1, 0);
}

void compute::thread_o_tensor_0_10_V_2_fu_3684_p1() {
    o_tensor_0_10_V_2_fu_3684_p1 = dst_tensor_0_10_V_2_reg_13617.read().range(8-1, 0);
}

void compute::thread_o_tensor_0_10_V_3_fu_3720_p3() {
    o_tensor_0_10_V_3_fu_3720_p3 = (!tmp_29_reg_12796.read()[0].is_01())? sc_lv<8>(): ((tmp_29_reg_12796.read()[0].to_bool())? o_tensor_0_10_V_fu_854.read(): o_tensor_0_10_V_1_fu_3680_p1.read());
}

void compute::thread_o_tensor_0_10_V_4_fu_3727_p3() {
    o_tensor_0_10_V_4_fu_3727_p3 = (!sel_tmp1_reg_12832.read()[0].is_01())? sc_lv<8>(): ((sel_tmp1_reg_12832.read()[0].to_bool())? o_tensor_0_10_V_2_fu_3684_p1.read(): o_tensor_0_10_V_3_fu_3720_p3.read());
}

void compute::thread_o_tensor_0_10_V_5_fu_4248_p3() {
    o_tensor_0_10_V_5_fu_4248_p3 = (!tmp_30_reg_12868.read()[0].is_01())? sc_lv<8>(): ((tmp_30_reg_12868.read()[0].to_bool())? o_tensor_0_10_V_6_fu_4245_p1.read(): o_tensor_0_10_V_4_reg_13826.read());
}

void compute::thread_o_tensor_0_10_V_6_fu_4245_p1() {
    o_tensor_0_10_V_6_fu_4245_p1 = dst_tensor_0_10_V_3_reg_13820.read().range(8-1, 0);
}

void compute::thread_o_tensor_0_11_V_1_fu_3766_p1() {
    o_tensor_0_11_V_1_fu_3766_p1 = dst_tensor_0_11_V_1_fu_3759_p3.read().range(8-1, 0);
}

void compute::thread_o_tensor_0_11_V_2_fu_3770_p1() {
    o_tensor_0_11_V_2_fu_3770_p1 = dst_tensor_0_11_V_2_reg_13633.read().range(8-1, 0);
}

void compute::thread_o_tensor_0_11_V_3_fu_3806_p3() {
    o_tensor_0_11_V_3_fu_3806_p3 = (!tmp_29_reg_12796.read()[0].is_01())? sc_lv<8>(): ((tmp_29_reg_12796.read()[0].to_bool())? o_tensor_0_11_V_fu_858.read(): o_tensor_0_11_V_1_fu_3766_p1.read());
}

void compute::thread_o_tensor_0_11_V_4_fu_3813_p3() {
    o_tensor_0_11_V_4_fu_3813_p3 = (!sel_tmp1_reg_12832.read()[0].is_01())? sc_lv<8>(): ((sel_tmp1_reg_12832.read()[0].to_bool())? o_tensor_0_11_V_2_fu_3770_p1.read(): o_tensor_0_11_V_3_fu_3806_p3.read());
}

void compute::thread_o_tensor_0_11_V_5_fu_4262_p3() {
    o_tensor_0_11_V_5_fu_4262_p3 = (!tmp_30_reg_12868.read()[0].is_01())? sc_lv<8>(): ((tmp_30_reg_12868.read()[0].to_bool())? o_tensor_0_11_V_6_fu_4259_p1.read(): o_tensor_0_11_V_4_reg_13842.read());
}

void compute::thread_o_tensor_0_11_V_6_fu_4259_p1() {
    o_tensor_0_11_V_6_fu_4259_p1 = dst_tensor_0_11_V_3_reg_13836.read().range(8-1, 0);
}

void compute::thread_o_tensor_0_12_V_1_fu_3852_p1() {
    o_tensor_0_12_V_1_fu_3852_p1 = dst_tensor_0_12_V_1_fu_3845_p3.read().range(8-1, 0);
}

void compute::thread_o_tensor_0_12_V_2_fu_3856_p1() {
    o_tensor_0_12_V_2_fu_3856_p1 = dst_tensor_0_12_V_2_reg_13649.read().range(8-1, 0);
}

void compute::thread_o_tensor_0_12_V_3_fu_3892_p3() {
    o_tensor_0_12_V_3_fu_3892_p3 = (!tmp_29_reg_12796.read()[0].is_01())? sc_lv<8>(): ((tmp_29_reg_12796.read()[0].to_bool())? o_tensor_0_12_V_fu_862.read(): o_tensor_0_12_V_1_fu_3852_p1.read());
}

void compute::thread_o_tensor_0_12_V_4_fu_3899_p3() {
    o_tensor_0_12_V_4_fu_3899_p3 = (!sel_tmp1_reg_12832.read()[0].is_01())? sc_lv<8>(): ((sel_tmp1_reg_12832.read()[0].to_bool())? o_tensor_0_12_V_2_fu_3856_p1.read(): o_tensor_0_12_V_3_fu_3892_p3.read());
}

void compute::thread_o_tensor_0_12_V_5_fu_4276_p3() {
    o_tensor_0_12_V_5_fu_4276_p3 = (!tmp_30_reg_12868.read()[0].is_01())? sc_lv<8>(): ((tmp_30_reg_12868.read()[0].to_bool())? o_tensor_0_12_V_6_fu_4273_p1.read(): o_tensor_0_12_V_4_reg_13858.read());
}

void compute::thread_o_tensor_0_12_V_6_fu_4273_p1() {
    o_tensor_0_12_V_6_fu_4273_p1 = dst_tensor_0_12_V_3_reg_13852.read().range(8-1, 0);
}

void compute::thread_o_tensor_0_13_V_1_fu_3938_p1() {
    o_tensor_0_13_V_1_fu_3938_p1 = dst_tensor_0_13_V_1_fu_3931_p3.read().range(8-1, 0);
}

void compute::thread_o_tensor_0_13_V_2_fu_3942_p1() {
    o_tensor_0_13_V_2_fu_3942_p1 = dst_tensor_0_13_V_2_reg_13665.read().range(8-1, 0);
}

void compute::thread_o_tensor_0_13_V_3_fu_3978_p3() {
    o_tensor_0_13_V_3_fu_3978_p3 = (!tmp_29_reg_12796.read()[0].is_01())? sc_lv<8>(): ((tmp_29_reg_12796.read()[0].to_bool())? o_tensor_0_13_V_fu_866.read(): o_tensor_0_13_V_1_fu_3938_p1.read());
}

void compute::thread_o_tensor_0_13_V_4_fu_3985_p3() {
    o_tensor_0_13_V_4_fu_3985_p3 = (!sel_tmp1_reg_12832.read()[0].is_01())? sc_lv<8>(): ((sel_tmp1_reg_12832.read()[0].to_bool())? o_tensor_0_13_V_2_fu_3942_p1.read(): o_tensor_0_13_V_3_fu_3978_p3.read());
}

void compute::thread_o_tensor_0_13_V_5_fu_4290_p3() {
    o_tensor_0_13_V_5_fu_4290_p3 = (!tmp_30_reg_12868.read()[0].is_01())? sc_lv<8>(): ((tmp_30_reg_12868.read()[0].to_bool())? o_tensor_0_13_V_6_fu_4287_p1.read(): o_tensor_0_13_V_4_reg_13874.read());
}

void compute::thread_o_tensor_0_13_V_6_fu_4287_p1() {
    o_tensor_0_13_V_6_fu_4287_p1 = dst_tensor_0_13_V_3_reg_13868.read().range(8-1, 0);
}

void compute::thread_o_tensor_0_14_V_1_fu_4024_p1() {
    o_tensor_0_14_V_1_fu_4024_p1 = dst_tensor_0_14_V_1_fu_4017_p3.read().range(8-1, 0);
}

void compute::thread_o_tensor_0_14_V_2_fu_4028_p1() {
    o_tensor_0_14_V_2_fu_4028_p1 = dst_tensor_0_14_V_2_reg_13681.read().range(8-1, 0);
}

void compute::thread_o_tensor_0_14_V_3_fu_4064_p3() {
    o_tensor_0_14_V_3_fu_4064_p3 = (!tmp_29_reg_12796.read()[0].is_01())? sc_lv<8>(): ((tmp_29_reg_12796.read()[0].to_bool())? o_tensor_0_14_V_fu_870.read(): o_tensor_0_14_V_1_fu_4024_p1.read());
}

void compute::thread_o_tensor_0_14_V_4_fu_4071_p3() {
    o_tensor_0_14_V_4_fu_4071_p3 = (!sel_tmp1_reg_12832.read()[0].is_01())? sc_lv<8>(): ((sel_tmp1_reg_12832.read()[0].to_bool())? o_tensor_0_14_V_2_fu_4028_p1.read(): o_tensor_0_14_V_3_fu_4064_p3.read());
}

void compute::thread_o_tensor_0_14_V_5_fu_4304_p3() {
    o_tensor_0_14_V_5_fu_4304_p3 = (!tmp_30_reg_12868.read()[0].is_01())? sc_lv<8>(): ((tmp_30_reg_12868.read()[0].to_bool())? o_tensor_0_14_V_6_fu_4301_p1.read(): o_tensor_0_14_V_4_reg_13890.read());
}

void compute::thread_o_tensor_0_14_V_6_fu_4301_p1() {
    o_tensor_0_14_V_6_fu_4301_p1 = dst_tensor_0_14_V_3_reg_13884.read().range(8-1, 0);
}

void compute::thread_o_tensor_0_15_V_1_fu_4110_p1() {
    o_tensor_0_15_V_1_fu_4110_p1 = dst_tensor_0_15_V_1_fu_4103_p3.read().range(8-1, 0);
}

void compute::thread_o_tensor_0_15_V_2_fu_4114_p1() {
    o_tensor_0_15_V_2_fu_4114_p1 = dst_tensor_0_15_V_2_reg_13697.read().range(8-1, 0);
}

void compute::thread_o_tensor_0_15_V_3_fu_4150_p3() {
    o_tensor_0_15_V_3_fu_4150_p3 = (!tmp_29_reg_12796.read()[0].is_01())? sc_lv<8>(): ((tmp_29_reg_12796.read()[0].to_bool())? o_tensor_0_15_V_fu_874.read(): o_tensor_0_15_V_1_fu_4110_p1.read());
}

void compute::thread_o_tensor_0_15_V_4_fu_4157_p3() {
    o_tensor_0_15_V_4_fu_4157_p3 = (!sel_tmp1_reg_12832.read()[0].is_01())? sc_lv<8>(): ((sel_tmp1_reg_12832.read()[0].to_bool())? o_tensor_0_15_V_2_fu_4114_p1.read(): o_tensor_0_15_V_3_fu_4150_p3.read());
}

void compute::thread_o_tensor_0_15_V_5_fu_4318_p3() {
    o_tensor_0_15_V_5_fu_4318_p3 = (!tmp_30_reg_12868.read()[0].is_01())? sc_lv<8>(): ((tmp_30_reg_12868.read()[0].to_bool())? o_tensor_0_15_V_6_fu_4315_p1.read(): o_tensor_0_15_V_4_reg_13906.read());
}

void compute::thread_o_tensor_0_15_V_6_fu_4315_p1() {
    o_tensor_0_15_V_6_fu_4315_p1 = dst_tensor_0_15_V_3_reg_13900.read().range(8-1, 0);
}

void compute::thread_o_tensor_0_1_V_1_fu_10780_p1() {
    o_tensor_0_1_V_1_fu_10780_p1 = accum_V_2_0_1_fu_10774_p2.read().range(8-1, 0);
}

void compute::thread_o_tensor_0_1_V_2_fu_2650_p1() {
    o_tensor_0_1_V_2_fu_2650_p1 = dst_tensor_0_1_V_1_fu_2643_p3.read().range(8-1, 0);
}

void compute::thread_o_tensor_0_1_V_3_fu_2654_p1() {
    o_tensor_0_1_V_3_fu_2654_p1 = dst_tensor_0_1_V_2_reg_13225.read().range(8-1, 0);
}

void compute::thread_o_tensor_0_1_V_4_fu_2690_p3() {
    o_tensor_0_1_V_4_fu_2690_p3 = (!tmp_29_reg_12796.read()[0].is_01())? sc_lv<8>(): ((tmp_29_reg_12796.read()[0].to_bool())? o_tensor_0_1_V_fu_818.read(): o_tensor_0_1_V_2_fu_2650_p1.read());
}

void compute::thread_o_tensor_0_1_V_5_fu_2697_p3() {
    o_tensor_0_1_V_5_fu_2697_p3 = (!sel_tmp1_reg_12832.read()[0].is_01())? sc_lv<8>(): ((sel_tmp1_reg_12832.read()[0].to_bool())? o_tensor_0_1_V_3_fu_2654_p1.read(): o_tensor_0_1_V_4_fu_2690_p3.read());
}

void compute::thread_o_tensor_0_1_V_6_fu_3394_p3() {
    o_tensor_0_1_V_6_fu_3394_p3 = (!tmp_30_reg_12868.read()[0].is_01())? sc_lv<8>(): ((tmp_30_reg_12868.read()[0].to_bool())? o_tensor_0_1_V_7_fu_3391_p1.read(): o_tensor_0_1_V_5_reg_13474.read());
}

void compute::thread_o_tensor_0_1_V_7_fu_3391_p1() {
    o_tensor_0_1_V_7_fu_3391_p1 = dst_tensor_0_1_V_3_reg_13468.read().range(8-1, 0);
}

void compute::thread_o_tensor_0_2_V_1_fu_10793_p1() {
    o_tensor_0_2_V_1_fu_10793_p1 = accum_V_2_0_2_fu_10787_p2.read().range(8-1, 0);
}

void compute::thread_o_tensor_0_2_V_2_fu_2736_p1() {
    o_tensor_0_2_V_2_fu_2736_p1 = dst_tensor_0_2_V_1_fu_2729_p3.read().range(8-1, 0);
}

void compute::thread_o_tensor_0_2_V_3_fu_2740_p1() {
    o_tensor_0_2_V_3_fu_2740_p1 = dst_tensor_0_2_V_2_reg_13241.read().range(8-1, 0);
}

void compute::thread_o_tensor_0_2_V_4_fu_2776_p3() {
    o_tensor_0_2_V_4_fu_2776_p3 = (!tmp_29_reg_12796.read()[0].is_01())? sc_lv<8>(): ((tmp_29_reg_12796.read()[0].to_bool())? o_tensor_0_2_V_fu_822.read(): o_tensor_0_2_V_2_fu_2736_p1.read());
}

void compute::thread_o_tensor_0_2_V_5_fu_2783_p3() {
    o_tensor_0_2_V_5_fu_2783_p3 = (!sel_tmp1_reg_12832.read()[0].is_01())? sc_lv<8>(): ((sel_tmp1_reg_12832.read()[0].to_bool())? o_tensor_0_2_V_3_fu_2740_p1.read(): o_tensor_0_2_V_4_fu_2776_p3.read());
}

void compute::thread_o_tensor_0_2_V_6_fu_3408_p3() {
    o_tensor_0_2_V_6_fu_3408_p3 = (!tmp_30_reg_12868.read()[0].is_01())? sc_lv<8>(): ((tmp_30_reg_12868.read()[0].to_bool())? o_tensor_0_2_V_7_fu_3405_p1.read(): o_tensor_0_2_V_5_reg_13490.read());
}

void compute::thread_o_tensor_0_2_V_7_fu_3405_p1() {
    o_tensor_0_2_V_7_fu_3405_p1 = dst_tensor_0_2_V_3_reg_13484.read().range(8-1, 0);
}

void compute::thread_o_tensor_0_3_V_1_fu_10806_p1() {
    o_tensor_0_3_V_1_fu_10806_p1 = accum_V_2_0_3_fu_10800_p2.read().range(8-1, 0);
}

void compute::thread_o_tensor_0_3_V_2_fu_2822_p1() {
    o_tensor_0_3_V_2_fu_2822_p1 = dst_tensor_0_3_V_1_fu_2815_p3.read().range(8-1, 0);
}

void compute::thread_o_tensor_0_3_V_3_fu_2826_p1() {
    o_tensor_0_3_V_3_fu_2826_p1 = dst_tensor_0_3_V_2_reg_13257.read().range(8-1, 0);
}

void compute::thread_o_tensor_0_3_V_4_fu_2862_p3() {
    o_tensor_0_3_V_4_fu_2862_p3 = (!tmp_29_reg_12796.read()[0].is_01())? sc_lv<8>(): ((tmp_29_reg_12796.read()[0].to_bool())? o_tensor_0_3_V_fu_826.read(): o_tensor_0_3_V_2_fu_2822_p1.read());
}

void compute::thread_o_tensor_0_3_V_5_fu_2869_p3() {
    o_tensor_0_3_V_5_fu_2869_p3 = (!sel_tmp1_reg_12832.read()[0].is_01())? sc_lv<8>(): ((sel_tmp1_reg_12832.read()[0].to_bool())? o_tensor_0_3_V_3_fu_2826_p1.read(): o_tensor_0_3_V_4_fu_2862_p3.read());
}

void compute::thread_o_tensor_0_3_V_6_fu_3422_p3() {
    o_tensor_0_3_V_6_fu_3422_p3 = (!tmp_30_reg_12868.read()[0].is_01())? sc_lv<8>(): ((tmp_30_reg_12868.read()[0].to_bool())? o_tensor_0_3_V_7_fu_3419_p1.read(): o_tensor_0_3_V_5_reg_13506.read());
}

void compute::thread_o_tensor_0_3_V_7_fu_3419_p1() {
    o_tensor_0_3_V_7_fu_3419_p1 = dst_tensor_0_3_V_3_reg_13500.read().range(8-1, 0);
}

void compute::thread_o_tensor_0_4_V_1_fu_10819_p1() {
    o_tensor_0_4_V_1_fu_10819_p1 = accum_V_2_0_4_fu_10813_p2.read().range(8-1, 0);
}

void compute::thread_o_tensor_0_4_V_2_fu_2908_p1() {
    o_tensor_0_4_V_2_fu_2908_p1 = dst_tensor_0_4_V_1_fu_2901_p3.read().range(8-1, 0);
}

void compute::thread_o_tensor_0_4_V_3_fu_2912_p1() {
    o_tensor_0_4_V_3_fu_2912_p1 = dst_tensor_0_4_V_2_reg_13273.read().range(8-1, 0);
}

void compute::thread_o_tensor_0_4_V_4_fu_2948_p3() {
    o_tensor_0_4_V_4_fu_2948_p3 = (!tmp_29_reg_12796.read()[0].is_01())? sc_lv<8>(): ((tmp_29_reg_12796.read()[0].to_bool())? o_tensor_0_4_V_fu_830.read(): o_tensor_0_4_V_2_fu_2908_p1.read());
}

void compute::thread_o_tensor_0_4_V_5_fu_2955_p3() {
    o_tensor_0_4_V_5_fu_2955_p3 = (!sel_tmp1_reg_12832.read()[0].is_01())? sc_lv<8>(): ((sel_tmp1_reg_12832.read()[0].to_bool())? o_tensor_0_4_V_3_fu_2912_p1.read(): o_tensor_0_4_V_4_fu_2948_p3.read());
}

void compute::thread_o_tensor_0_4_V_6_fu_3436_p3() {
    o_tensor_0_4_V_6_fu_3436_p3 = (!tmp_30_reg_12868.read()[0].is_01())? sc_lv<8>(): ((tmp_30_reg_12868.read()[0].to_bool())? o_tensor_0_4_V_7_fu_3433_p1.read(): o_tensor_0_4_V_5_reg_13522.read());
}

void compute::thread_o_tensor_0_4_V_7_fu_3433_p1() {
    o_tensor_0_4_V_7_fu_3433_p1 = dst_tensor_0_4_V_3_reg_13516.read().range(8-1, 0);
}

void compute::thread_o_tensor_0_5_V_1_fu_2994_p1() {
    o_tensor_0_5_V_1_fu_2994_p1 = dst_tensor_0_5_V_1_fu_2987_p3.read().range(8-1, 0);
}

void compute::thread_o_tensor_0_5_V_2_fu_2998_p1() {
    o_tensor_0_5_V_2_fu_2998_p1 = dst_tensor_0_5_V_2_reg_13289.read().range(8-1, 0);
}

void compute::thread_o_tensor_0_5_V_3_fu_3034_p3() {
    o_tensor_0_5_V_3_fu_3034_p3 = (!tmp_29_reg_12796.read()[0].is_01())? sc_lv<8>(): ((tmp_29_reg_12796.read()[0].to_bool())? o_tensor_0_5_V_fu_834.read(): o_tensor_0_5_V_1_fu_2994_p1.read());
}

void compute::thread_o_tensor_0_5_V_4_fu_3041_p3() {
    o_tensor_0_5_V_4_fu_3041_p3 = (!sel_tmp1_reg_12832.read()[0].is_01())? sc_lv<8>(): ((sel_tmp1_reg_12832.read()[0].to_bool())? o_tensor_0_5_V_2_fu_2998_p1.read(): o_tensor_0_5_V_3_fu_3034_p3.read());
}

void compute::thread_o_tensor_0_5_V_5_fu_3450_p3() {
    o_tensor_0_5_V_5_fu_3450_p3 = (!tmp_30_reg_12868.read()[0].is_01())? sc_lv<8>(): ((tmp_30_reg_12868.read()[0].to_bool())? o_tensor_0_5_V_6_fu_3447_p1.read(): o_tensor_0_5_V_4_reg_13538.read());
}

void compute::thread_o_tensor_0_5_V_6_fu_3447_p1() {
    o_tensor_0_5_V_6_fu_3447_p1 = dst_tensor_0_5_V_3_reg_13532.read().range(8-1, 0);
}

void compute::thread_o_tensor_0_6_V_1_fu_3080_p1() {
    o_tensor_0_6_V_1_fu_3080_p1 = dst_tensor_0_6_V_1_fu_3073_p3.read().range(8-1, 0);
}

void compute::thread_o_tensor_0_6_V_2_fu_3084_p1() {
    o_tensor_0_6_V_2_fu_3084_p1 = dst_tensor_0_6_V_2_reg_13305.read().range(8-1, 0);
}

void compute::thread_o_tensor_0_6_V_3_fu_3120_p3() {
    o_tensor_0_6_V_3_fu_3120_p3 = (!tmp_29_reg_12796.read()[0].is_01())? sc_lv<8>(): ((tmp_29_reg_12796.read()[0].to_bool())? o_tensor_0_6_V_fu_838.read(): o_tensor_0_6_V_1_fu_3080_p1.read());
}

void compute::thread_o_tensor_0_6_V_4_fu_3127_p3() {
    o_tensor_0_6_V_4_fu_3127_p3 = (!sel_tmp1_reg_12832.read()[0].is_01())? sc_lv<8>(): ((sel_tmp1_reg_12832.read()[0].to_bool())? o_tensor_0_6_V_2_fu_3084_p1.read(): o_tensor_0_6_V_3_fu_3120_p3.read());
}

void compute::thread_o_tensor_0_6_V_5_fu_3464_p3() {
    o_tensor_0_6_V_5_fu_3464_p3 = (!tmp_30_reg_12868.read()[0].is_01())? sc_lv<8>(): ((tmp_30_reg_12868.read()[0].to_bool())? o_tensor_0_6_V_6_fu_3461_p1.read(): o_tensor_0_6_V_4_reg_13554.read());
}

void compute::thread_o_tensor_0_6_V_6_fu_3461_p1() {
    o_tensor_0_6_V_6_fu_3461_p1 = dst_tensor_0_6_V_3_reg_13548.read().range(8-1, 0);
}

void compute::thread_o_tensor_0_7_V_1_fu_3166_p1() {
    o_tensor_0_7_V_1_fu_3166_p1 = dst_tensor_0_7_V_1_fu_3159_p3.read().range(8-1, 0);
}

void compute::thread_o_tensor_0_7_V_2_fu_3170_p1() {
    o_tensor_0_7_V_2_fu_3170_p1 = dst_tensor_0_7_V_2_reg_13321.read().range(8-1, 0);
}

void compute::thread_o_tensor_0_7_V_3_fu_3206_p3() {
    o_tensor_0_7_V_3_fu_3206_p3 = (!tmp_29_reg_12796.read()[0].is_01())? sc_lv<8>(): ((tmp_29_reg_12796.read()[0].to_bool())? o_tensor_0_7_V_fu_842.read(): o_tensor_0_7_V_1_fu_3166_p1.read());
}

void compute::thread_o_tensor_0_7_V_4_fu_3213_p3() {
    o_tensor_0_7_V_4_fu_3213_p3 = (!sel_tmp1_reg_12832.read()[0].is_01())? sc_lv<8>(): ((sel_tmp1_reg_12832.read()[0].to_bool())? o_tensor_0_7_V_2_fu_3170_p1.read(): o_tensor_0_7_V_3_fu_3206_p3.read());
}

void compute::thread_o_tensor_0_7_V_5_fu_3478_p3() {
    o_tensor_0_7_V_5_fu_3478_p3 = (!tmp_30_reg_12868.read()[0].is_01())? sc_lv<8>(): ((tmp_30_reg_12868.read()[0].to_bool())? o_tensor_0_7_V_6_fu_3475_p1.read(): o_tensor_0_7_V_4_reg_13570.read());
}

void compute::thread_o_tensor_0_7_V_6_fu_3475_p1() {
    o_tensor_0_7_V_6_fu_3475_p1 = dst_tensor_0_7_V_3_reg_13564.read().range(8-1, 0);
}

void compute::thread_o_tensor_0_8_V_1_fu_3508_p1() {
    o_tensor_0_8_V_1_fu_3508_p1 = dst_tensor_0_8_V_1_fu_3501_p3.read().range(8-1, 0);
}

void compute::thread_o_tensor_0_8_V_2_fu_3512_p1() {
    o_tensor_0_8_V_2_fu_3512_p1 = dst_tensor_0_8_V_2_reg_13585.read().range(8-1, 0);
}

void compute::thread_o_tensor_0_8_V_3_fu_3548_p3() {
    o_tensor_0_8_V_3_fu_3548_p3 = (!tmp_29_reg_12796.read()[0].is_01())? sc_lv<8>(): ((tmp_29_reg_12796.read()[0].to_bool())? o_tensor_0_8_V_fu_846.read(): o_tensor_0_8_V_1_fu_3508_p1.read());
}

void compute::thread_o_tensor_0_8_V_4_fu_3555_p3() {
    o_tensor_0_8_V_4_fu_3555_p3 = (!sel_tmp1_reg_12832.read()[0].is_01())? sc_lv<8>(): ((sel_tmp1_reg_12832.read()[0].to_bool())? o_tensor_0_8_V_2_fu_3512_p1.read(): o_tensor_0_8_V_3_fu_3548_p3.read());
}

void compute::thread_o_tensor_0_8_V_5_fu_4220_p3() {
    o_tensor_0_8_V_5_fu_4220_p3 = (!tmp_30_reg_12868.read()[0].is_01())? sc_lv<8>(): ((tmp_30_reg_12868.read()[0].to_bool())? o_tensor_0_8_V_6_fu_4217_p1.read(): o_tensor_0_8_V_4_reg_13794.read());
}

void compute::thread_o_tensor_0_8_V_6_fu_4217_p1() {
    o_tensor_0_8_V_6_fu_4217_p1 = dst_tensor_0_8_V_3_reg_13788.read().range(8-1, 0);
}

void compute::thread_o_tensor_0_9_V_1_fu_3594_p1() {
    o_tensor_0_9_V_1_fu_3594_p1 = dst_tensor_0_9_V_1_fu_3587_p3.read().range(8-1, 0);
}

void compute::thread_o_tensor_0_9_V_2_fu_3598_p1() {
    o_tensor_0_9_V_2_fu_3598_p1 = dst_tensor_0_9_V_2_reg_13601.read().range(8-1, 0);
}

void compute::thread_o_tensor_0_9_V_3_fu_3634_p3() {
    o_tensor_0_9_V_3_fu_3634_p3 = (!tmp_29_reg_12796.read()[0].is_01())? sc_lv<8>(): ((tmp_29_reg_12796.read()[0].to_bool())? o_tensor_0_9_V_fu_850.read(): o_tensor_0_9_V_1_fu_3594_p1.read());
}

void compute::thread_o_tensor_0_9_V_4_fu_3641_p3() {
    o_tensor_0_9_V_4_fu_3641_p3 = (!sel_tmp1_reg_12832.read()[0].is_01())? sc_lv<8>(): ((sel_tmp1_reg_12832.read()[0].to_bool())? o_tensor_0_9_V_2_fu_3598_p1.read(): o_tensor_0_9_V_3_fu_3634_p3.read());
}

void compute::thread_o_tensor_0_9_V_5_fu_4234_p3() {
    o_tensor_0_9_V_5_fu_4234_p3 = (!tmp_30_reg_12868.read()[0].is_01())? sc_lv<8>(): ((tmp_30_reg_12868.read()[0].to_bool())? o_tensor_0_9_V_6_fu_4231_p1.read(): o_tensor_0_9_V_4_reg_13810.read());
}

void compute::thread_o_tensor_0_9_V_6_fu_4231_p1() {
    o_tensor_0_9_V_6_fu_4231_p1 = dst_tensor_0_9_V_3_reg_13804.read().range(8-1, 0);
}

void compute::thread_out_mem_V_Addr_A() {
    out_mem_V_Addr_A = (!ap_const_lv32_4.is_01())? sc_lv<32>(): out_mem_V_Addr_A_orig.read() << (unsigned short)ap_const_lv32_4.to_uint();
}

void compute::thread_out_mem_V_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter15.read()))) {
        out_mem_V_Addr_A_orig =  (sc_lv<32>) (tmp_47_reg_18306_pp1_iter14_reg.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()))) {
        out_mem_V_Addr_A_orig =  (sc_lv<32>) (tmp_56_reg_13022_pp0_iter5_reg.read());
    } else {
        out_mem_V_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void compute::thread_out_mem_V_Clk_A() {
    out_mem_V_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void compute::thread_out_mem_V_Din_A() {
    if ((esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter15.read()))) {
        out_mem_V_Din_A = p_Result_8_0_s_fu_11099_p17.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()))) {
        out_mem_V_Din_A = p_Result_21_0_s_fu_4329_p17.read();
    } else {
        out_mem_V_Din_A =  (sc_lv<128>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void compute::thread_out_mem_V_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter15.read())))) {
        out_mem_V_EN_A = ap_const_logic_1;
    } else {
        out_mem_V_EN_A = ap_const_logic_0;
    }
}

void compute::thread_out_mem_V_Rst_A() {
    out_mem_V_Rst_A = ap_rst_n_inv.read();
}

void compute::thread_out_mem_V_WEN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, exitcond_flatten3_reg_12909_pp0_iter5_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter15.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, exitcond_flatten1_reg_14063_pp1_iter14_reg.read())))) {
        out_mem_V_WEN_A = ap_const_lv16_FFFF;
    } else {
        out_mem_V_WEN_A = ap_const_lv16_0;
    }
}

void compute::thread_p_0198_0_i_cast_fu_4517_p1() {
    p_0198_0_i_cast_fu_4517_p1 = esl_zext<12,11>(grp_fu_1390_p4.read());
}

void compute::thread_p_0216_0_i_cast_fu_4500_p1() {
    p_0216_0_i_cast_fu_4500_p1 = esl_zext<12,11>(grp_fu_1381_p4.read());
}

void compute::thread_p_0225_0_i_cast_fu_4496_p1() {
    p_0225_0_i_cast_fu_4496_p1 = esl_zext<12,11>(grp_fu_1372_p4.read());
}

void compute::thread_p_0264_0_i_0_10_fu_10901_p1() {
    p_0264_0_i_0_10_fu_10901_p1 = esl_sext<32,20>(tmp_V_0_11_s_reg_18857.read());
}

void compute::thread_p_0264_0_i_0_11_fu_10914_p1() {
    p_0264_0_i_0_11_fu_10914_p1 = esl_sext<32,20>(tmp_V_0_12_s_reg_18862.read());
}

void compute::thread_p_0264_0_i_0_12_fu_10927_p1() {
    p_0264_0_i_0_12_fu_10927_p1 = esl_sext<32,20>(tmp_V_0_13_s_reg_18867.read());
}

void compute::thread_p_0264_0_i_0_13_fu_10940_p1() {
    p_0264_0_i_0_13_fu_10940_p1 = esl_sext<32,20>(tmp_V_0_14_s_reg_18872.read());
}

void compute::thread_p_0264_0_i_0_14_fu_10953_p1() {
    p_0264_0_i_0_14_fu_10953_p1 = esl_sext<32,20>(tmp_V_0_15_s_reg_18877.read());
}

void compute::thread_p_0264_0_i_0_1_fu_10771_p1() {
    p_0264_0_i_0_1_fu_10771_p1 = esl_sext<32,20>(tmp_V_0_1_s_reg_18807.read());
}

void compute::thread_p_0264_0_i_0_2_fu_10784_p1() {
    p_0264_0_i_0_2_fu_10784_p1 = esl_sext<32,20>(tmp_V_0_2_s_reg_18812.read());
}

void compute::thread_p_0264_0_i_0_3_fu_10797_p1() {
    p_0264_0_i_0_3_fu_10797_p1 = esl_sext<32,20>(tmp_V_0_3_s_reg_18817.read());
}

void compute::thread_p_0264_0_i_0_4_fu_10810_p1() {
    p_0264_0_i_0_4_fu_10810_p1 = esl_sext<32,20>(tmp_V_0_4_s_reg_18822.read());
}

void compute::thread_p_0264_0_i_0_5_fu_10823_p1() {
    p_0264_0_i_0_5_fu_10823_p1 = esl_sext<32,20>(tmp_V_0_5_s_reg_18827.read());
}

void compute::thread_p_0264_0_i_0_6_fu_10836_p1() {
    p_0264_0_i_0_6_fu_10836_p1 = esl_sext<32,20>(tmp_V_0_6_s_reg_18832.read());
}

void compute::thread_p_0264_0_i_0_7_fu_10849_p1() {
    p_0264_0_i_0_7_fu_10849_p1 = esl_sext<32,20>(tmp_V_0_7_s_reg_18837.read());
}

void compute::thread_p_0264_0_i_0_8_fu_10862_p1() {
    p_0264_0_i_0_8_fu_10862_p1 = esl_sext<32,20>(tmp_V_0_8_s_reg_18842.read());
}

void compute::thread_p_0264_0_i_0_9_fu_10875_p1() {
    p_0264_0_i_0_9_fu_10875_p1 = esl_sext<32,20>(tmp_V_0_9_s_reg_18847.read());
}

void compute::thread_p_0264_0_i_0_s_fu_10888_p1() {
    p_0264_0_i_0_s_fu_10888_p1 = esl_sext<32,20>(tmp_V_0_10_s_reg_18852.read());
}

void compute::thread_p_0264_0_i_fu_10759_p1() {
    p_0264_0_i_fu_10759_p1 = esl_sext<32,20>(tmp_V_0_0_s_reg_18802.read());
}

void compute::thread_p_0271_0_i_cast_fu_1922_p1() {
    p_0271_0_i_cast_fu_1922_p1 = esl_zext<12,11>(grp_fu_1381_p4.read());
}

void compute::thread_p_0276_0_i_cast_fu_4521_p1() {
    p_0276_0_i_cast_fu_4521_p1 = esl_zext<12,11>(grp_fu_1399_p4.read());
}

void compute::thread_p_0280_0_i_cast_fu_1918_p1() {
    p_0280_0_i_cast_fu_1918_p1 = esl_zext<12,11>(grp_fu_1372_p4.read());
}

void compute::thread_p_0292_0_i_cast_fu_4534_p1() {
    p_0292_0_i_cast_fu_4534_p1 = esl_zext<11,10>(tmp_118_cast_fu_4525_p4.read());
}

void compute::thread_p_0350_0_i_cast_fu_1926_p1() {
    p_0350_0_i_cast_fu_1926_p1 = esl_zext<12,11>(grp_fu_1390_p4.read());
}

void compute::thread_p_0362_0_i_cast_fu_1930_p1() {
    p_0362_0_i_cast_fu_1930_p1 = esl_zext<12,11>(grp_fu_1399_p4.read());
}

void compute::thread_p_Result_11_0_0_sr_fu_2256_p3() {
    p_Result_11_0_0_sr_fu_2256_p3 = (!tmp_25_reg_12700.read()[0].is_01())? sc_lv<32>(): ((tmp_25_reg_12700.read()[0].to_bool())? src_1_V_reg_12756.read(): tmp_268_fu_2098_p1.read());
}

void compute::thread_p_Result_11_0_1_fu_2102_p4() {
    p_Result_11_0_1_fu_2102_p4 = acc_mem_V_q0.read().range(63, 32);
}

void compute::thread_p_Result_11_0_2_fu_2112_p4() {
    p_Result_11_0_2_fu_2112_p4 = acc_mem_V_q0.read().range(95, 64);
}

void compute::thread_p_Result_11_0_3_fu_2122_p4() {
    p_Result_11_0_3_fu_2122_p4 = acc_mem_V_q0.read().range(127, 96);
}

void compute::thread_p_Result_11_1_1_fu_2142_p4() {
    p_Result_11_1_1_fu_2142_p4 = acc_mem_V_q0.read().range(191, 160);
}

void compute::thread_p_Result_11_1_2_fu_2152_p4() {
    p_Result_11_1_2_fu_2152_p4 = acc_mem_V_q0.read().range(223, 192);
}

void compute::thread_p_Result_11_1_3_fu_2162_p4() {
    p_Result_11_1_3_fu_2162_p4 = acc_mem_V_q0.read().range(255, 224);
}

void compute::thread_p_Result_11_1_fu_2132_p4() {
    p_Result_11_1_fu_2132_p4 = acc_mem_V_q0.read().range(159, 128);
}

void compute::thread_p_Result_21_0_s_fu_4329_p17() {
    p_Result_21_0_s_fu_4329_p17 = esl_concat<120,8>(esl_concat<112,8>(esl_concat<104,8>(esl_concat<96,8>(esl_concat<88,8>(esl_concat<80,8>(esl_concat<72,8>(esl_concat<64,8>(esl_concat<56,8>(esl_concat<48,8>(esl_concat<40,8>(esl_concat<32,8>(esl_concat<24,8>(esl_concat<16,8>(esl_concat<8,8>(o_tensor_0_15_V_5_fu_4318_p3.read(), o_tensor_0_14_V_5_fu_4304_p3.read()), o_tensor_0_13_V_5_fu_4290_p3.read()), o_tensor_0_12_V_5_fu_4276_p3.read()), o_tensor_0_11_V_5_fu_4262_p3.read()), o_tensor_0_10_V_5_fu_4248_p3.read()), o_tensor_0_9_V_5_fu_4234_p3.read()), o_tensor_0_8_V_5_fu_4220_p3.read()), o_tensor_0_7_V_5_reg_13778.read()), o_tensor_0_6_V_5_reg_13768.read()), o_tensor_0_5_V_5_reg_13758.read()), o_tensor_0_4_V_6_reg_13748.read()), o_tensor_0_3_V_6_reg_13738.read()), o_tensor_0_2_V_6_reg_13728.read()), o_tensor_0_1_V_6_reg_13718.read()), o_tensor_0_0_V_6_reg_13708.read());
}

void compute::thread_p_Result_8_0_s_fu_11099_p17() {
    p_Result_8_0_s_fu_11099_p17 = esl_concat<120,8>(esl_concat<112,8>(esl_concat<104,8>(esl_concat<96,8>(esl_concat<88,8>(esl_concat<80,8>(esl_concat<72,8>(esl_concat<64,8>(esl_concat<56,8>(esl_concat<48,8>(esl_concat<40,8>(esl_concat<32,8>(esl_concat<24,8>(esl_concat<16,8>(esl_concat<8,8>(tmp_265_reg_19037.read(), tmp_251_reg_19027.read()), tmp_237_reg_19017.read()), tmp_223_reg_19007.read()), tmp_209_reg_18997.read()), tmp_195_reg_18987.read()), tmp_181_reg_18977.read()), tmp_167_reg_18967.read()), tmp_153_reg_18957.read()), tmp_139_reg_18947.read()), tmp_125_reg_18937.read()), o_tensor_0_4_V_1_reg_18927.read()), o_tensor_0_3_V_1_reg_18917.read()), o_tensor_0_2_V_1_reg_18907.read()), o_tensor_0_1_V_1_reg_18897.read()), o_tensor_0_0_V_1_reg_18887.read());
}

void compute::thread_p_Val2_11_0_5_fu_10996_p3() {
    p_Val2_11_0_5_fu_10996_p3 = (!tmp_13_reg_14008.read()[0].is_01())? sc_lv<32>(): ((tmp_13_reg_14008.read()[0].to_bool())? ap_const_lv32_0: accum_V_2_0_5_reg_18932.read());
}

void compute::thread_p_Val2_11_0_6_fu_11002_p3() {
    p_Val2_11_0_6_fu_11002_p3 = (!tmp_13_reg_14008.read()[0].is_01())? sc_lv<32>(): ((tmp_13_reg_14008.read()[0].to_bool())? ap_const_lv32_0: accum_V_2_0_6_reg_18942.read());
}

void compute::thread_p_Val2_11_0_7_fu_11008_p3() {
    p_Val2_11_0_7_fu_11008_p3 = (!tmp_13_reg_14008.read()[0].is_01())? sc_lv<32>(): ((tmp_13_reg_14008.read()[0].to_bool())? ap_const_lv32_0: accum_V_2_0_7_reg_18952.read());
}

void compute::thread_p_Val2_11_0_8_fu_11014_p3() {
    p_Val2_11_0_8_fu_11014_p3 = (!tmp_13_reg_14008.read()[0].is_01())? sc_lv<32>(): ((tmp_13_reg_14008.read()[0].to_bool())? ap_const_lv32_0: accum_V_2_0_8_reg_18962.read());
}

void compute::thread_p_Val2_11_0_9_fu_11020_p3() {
    p_Val2_11_0_9_fu_11020_p3 = (!tmp_13_reg_14008.read()[0].is_01())? sc_lv<32>(): ((tmp_13_reg_14008.read()[0].to_bool())? ap_const_lv32_0: accum_V_2_0_9_reg_18972.read());
}

void compute::thread_p_Val2_11_0_s_fu_11026_p3() {
    p_Val2_11_0_s_fu_11026_p3 = (!tmp_13_reg_14008.read()[0].is_01())? sc_lv<32>(): ((tmp_13_reg_14008.read()[0].to_bool())? ap_const_lv32_0: accum_V_2_0_s_reg_18982.read());
}

void compute::thread_p_demorgan_fu_11295_p2() {
    p_demorgan_fu_11295_p2 = (tmp_367_fu_11283_p2.read() & tmp_368_fu_11289_p2.read());
}

void compute::thread_p_in631_i_load_0_10_fu_3747_p3() {
    p_in631_i_load_0_10_fu_3747_p3 = (!tmp_26_reg_12720.read()[0].is_01())? sc_lv<32>(): ((tmp_26_reg_12720.read()[0].to_bool())? reg_1624_pp0_iter5_reg.read(): src_1_V_11_reg_13377.read());
}

void compute::thread_p_in631_i_load_0_11_fu_3833_p3() {
    p_in631_i_load_0_11_fu_3833_p3 = (!tmp_26_reg_12720.read()[0].is_01())? sc_lv<32>(): ((tmp_26_reg_12720.read()[0].to_bool())? reg_1628_pp0_iter5_reg.read(): src_1_V_12_reg_13392.read());
}

void compute::thread_p_in631_i_load_0_12_fu_3919_p3() {
    p_in631_i_load_0_12_fu_3919_p3 = (!tmp_26_reg_12720.read()[0].is_01())? sc_lv<32>(): ((tmp_26_reg_12720.read()[0].to_bool())? reg_1632_pp0_iter5_reg.read(): src_1_V_13_reg_13407.read());
}

void compute::thread_p_in631_i_load_0_13_fu_4005_p3() {
    p_in631_i_load_0_13_fu_4005_p3 = (!tmp_26_reg_12720.read()[0].is_01())? sc_lv<32>(): ((tmp_26_reg_12720.read()[0].to_bool())? reg_1636_pp0_iter5_reg.read(): src_1_V_14_reg_13422.read());
}

void compute::thread_p_in631_i_load_0_14_fu_4091_p3() {
    p_in631_i_load_0_14_fu_4091_p3 = (!tmp_26_reg_12720.read()[0].is_01())? sc_lv<32>(): ((tmp_26_reg_12720.read()[0].to_bool())? reg_1640_pp0_iter5_reg.read(): src_1_V_15_reg_13437.read());
}

void compute::thread_p_in631_i_load_0_1_fu_2631_p3() {
    p_in631_i_load_0_1_fu_2631_p3 = (!tmp_26_reg_12720.read()[0].is_01())? sc_lv<32>(): ((tmp_26_reg_12720.read()[0].to_bool())? reg_1584.read(): src_1_V_1_reg_13099.read());
}

void compute::thread_p_in631_i_load_0_2_fu_2717_p3() {
    p_in631_i_load_0_2_fu_2717_p3 = (!tmp_26_reg_12720.read()[0].is_01())? sc_lv<32>(): ((tmp_26_reg_12720.read()[0].to_bool())? reg_1588.read(): src_1_V_2_reg_13114.read());
}

void compute::thread_p_in631_i_load_0_3_fu_2803_p3() {
    p_in631_i_load_0_3_fu_2803_p3 = (!tmp_26_reg_12720.read()[0].is_01())? sc_lv<32>(): ((tmp_26_reg_12720.read()[0].to_bool())? reg_1592.read(): src_1_V_3_reg_13129.read());
}

void compute::thread_p_in631_i_load_0_4_fu_2889_p3() {
    p_in631_i_load_0_4_fu_2889_p3 = (!tmp_26_reg_12720.read()[0].is_01())? sc_lv<32>(): ((tmp_26_reg_12720.read()[0].to_bool())? reg_1596.read(): src_1_V_4_reg_13144.read());
}

void compute::thread_p_in631_i_load_0_5_fu_2975_p3() {
    p_in631_i_load_0_5_fu_2975_p3 = (!tmp_26_reg_12720.read()[0].is_01())? sc_lv<32>(): ((tmp_26_reg_12720.read()[0].to_bool())? reg_1600.read(): src_1_V_5_reg_13159.read());
}

void compute::thread_p_in631_i_load_0_6_fu_3061_p3() {
    p_in631_i_load_0_6_fu_3061_p3 = (!tmp_26_reg_12720.read()[0].is_01())? sc_lv<32>(): ((tmp_26_reg_12720.read()[0].to_bool())? reg_1604.read(): src_1_V_6_reg_13174.read());
}

void compute::thread_p_in631_i_load_0_7_fu_3147_p3() {
    p_in631_i_load_0_7_fu_3147_p3 = (!tmp_26_reg_12720.read()[0].is_01())? sc_lv<32>(): ((tmp_26_reg_12720.read()[0].to_bool())? reg_1608.read(): src_1_V_7_reg_13189.read());
}

void compute::thread_p_in631_i_load_0_8_fu_3489_p3() {
    p_in631_i_load_0_8_fu_3489_p3 = (!tmp_26_reg_12720.read()[0].is_01())? sc_lv<32>(): ((tmp_26_reg_12720.read()[0].to_bool())? reg_1612_pp0_iter5_reg.read(): src_1_V_8_reg_13332.read());
}

void compute::thread_p_in631_i_load_0_9_fu_3575_p3() {
    p_in631_i_load_0_9_fu_3575_p3 = (!tmp_26_reg_12720.read()[0].is_01())? sc_lv<32>(): ((tmp_26_reg_12720.read()[0].to_bool())? reg_1616_pp0_iter5_reg.read(): src_1_V_9_reg_13347.read());
}

void compute::thread_p_in631_i_load_0_s_fu_3661_p3() {
    p_in631_i_load_0_s_fu_3661_p3 = (!tmp_26_reg_12720.read()[0].is_01())? sc_lv<32>(): ((tmp_26_reg_12720.read()[0].to_bool())? reg_1620_pp0_iter5_reg.read(): src_1_V_10_reg_13362.read());
}

void compute::thread_p_in631_i_load_fu_2550_p3() {
    p_in631_i_load_fu_2550_p3 = (!tmp_26_reg_12720.read()[0].is_01())? sc_lv<32>(): ((tmp_26_reg_12720.read()[0].to_bool())? dst_tensor_0_0_V_reg_13073.read(): p_Result_11_0_0_sr_reg_13084.read());
}

void compute::thread_p_in_i_load_0_10_fu_3753_p3() {
    p_in_i_load_0_10_fu_3753_p3 = (!tmp_26_reg_12720.read()[0].is_01())? sc_lv<32>(): ((tmp_26_reg_12720.read()[0].to_bool())? src_1_V_11_reg_13377.read(): reg_1624_pp0_iter5_reg.read());
}

void compute::thread_p_in_i_load_0_11_fu_3839_p3() {
    p_in_i_load_0_11_fu_3839_p3 = (!tmp_26_reg_12720.read()[0].is_01())? sc_lv<32>(): ((tmp_26_reg_12720.read()[0].to_bool())? src_1_V_12_reg_13392.read(): reg_1628_pp0_iter5_reg.read());
}

void compute::thread_p_in_i_load_0_12_fu_3925_p3() {
    p_in_i_load_0_12_fu_3925_p3 = (!tmp_26_reg_12720.read()[0].is_01())? sc_lv<32>(): ((tmp_26_reg_12720.read()[0].to_bool())? src_1_V_13_reg_13407.read(): reg_1632_pp0_iter5_reg.read());
}

void compute::thread_p_in_i_load_0_13_fu_4011_p3() {
    p_in_i_load_0_13_fu_4011_p3 = (!tmp_26_reg_12720.read()[0].is_01())? sc_lv<32>(): ((tmp_26_reg_12720.read()[0].to_bool())? src_1_V_14_reg_13422.read(): reg_1636_pp0_iter5_reg.read());
}

void compute::thread_p_in_i_load_0_14_fu_4097_p3() {
    p_in_i_load_0_14_fu_4097_p3 = (!tmp_26_reg_12720.read()[0].is_01())? sc_lv<32>(): ((tmp_26_reg_12720.read()[0].to_bool())? src_1_V_15_reg_13437.read(): reg_1640_pp0_iter5_reg.read());
}

void compute::thread_p_in_i_load_0_1_fu_2637_p3() {
    p_in_i_load_0_1_fu_2637_p3 = (!tmp_26_reg_12720.read()[0].is_01())? sc_lv<32>(): ((tmp_26_reg_12720.read()[0].to_bool())? src_1_V_1_reg_13099.read(): reg_1584.read());
}

void compute::thread_p_in_i_load_0_2_fu_2723_p3() {
    p_in_i_load_0_2_fu_2723_p3 = (!tmp_26_reg_12720.read()[0].is_01())? sc_lv<32>(): ((tmp_26_reg_12720.read()[0].to_bool())? src_1_V_2_reg_13114.read(): reg_1588.read());
}

void compute::thread_p_in_i_load_0_3_fu_2809_p3() {
    p_in_i_load_0_3_fu_2809_p3 = (!tmp_26_reg_12720.read()[0].is_01())? sc_lv<32>(): ((tmp_26_reg_12720.read()[0].to_bool())? src_1_V_3_reg_13129.read(): reg_1592.read());
}

void compute::thread_p_in_i_load_0_4_fu_2895_p3() {
    p_in_i_load_0_4_fu_2895_p3 = (!tmp_26_reg_12720.read()[0].is_01())? sc_lv<32>(): ((tmp_26_reg_12720.read()[0].to_bool())? src_1_V_4_reg_13144.read(): reg_1596.read());
}

void compute::thread_p_in_i_load_0_5_fu_2981_p3() {
    p_in_i_load_0_5_fu_2981_p3 = (!tmp_26_reg_12720.read()[0].is_01())? sc_lv<32>(): ((tmp_26_reg_12720.read()[0].to_bool())? src_1_V_5_reg_13159.read(): reg_1600.read());
}

void compute::thread_p_in_i_load_0_6_fu_3067_p3() {
    p_in_i_load_0_6_fu_3067_p3 = (!tmp_26_reg_12720.read()[0].is_01())? sc_lv<32>(): ((tmp_26_reg_12720.read()[0].to_bool())? src_1_V_6_reg_13174.read(): reg_1604.read());
}

void compute::thread_p_in_i_load_0_7_fu_3153_p3() {
    p_in_i_load_0_7_fu_3153_p3 = (!tmp_26_reg_12720.read()[0].is_01())? sc_lv<32>(): ((tmp_26_reg_12720.read()[0].to_bool())? src_1_V_7_reg_13189.read(): reg_1608.read());
}

void compute::thread_p_in_i_load_0_8_fu_3495_p3() {
    p_in_i_load_0_8_fu_3495_p3 = (!tmp_26_reg_12720.read()[0].is_01())? sc_lv<32>(): ((tmp_26_reg_12720.read()[0].to_bool())? src_1_V_8_reg_13332.read(): reg_1612_pp0_iter5_reg.read());
}

void compute::thread_p_in_i_load_0_9_fu_3581_p3() {
    p_in_i_load_0_9_fu_3581_p3 = (!tmp_26_reg_12720.read()[0].is_01())? sc_lv<32>(): ((tmp_26_reg_12720.read()[0].to_bool())? src_1_V_9_reg_13347.read(): reg_1616_pp0_iter5_reg.read());
}

void compute::thread_p_in_i_load_0_s_fu_3667_p3() {
    p_in_i_load_0_s_fu_3667_p3 = (!tmp_26_reg_12720.read()[0].is_01())? sc_lv<32>(): ((tmp_26_reg_12720.read()[0].to_bool())? src_1_V_10_reg_13362.read(): reg_1620_pp0_iter5_reg.read());
}

void compute::thread_p_in_i_load_fu_2555_p3() {
    p_in_i_load_fu_2555_p3 = (!tmp_26_reg_12720.read()[0].is_01())? sc_lv<32>(): ((tmp_26_reg_12720.read()[0].to_bool())? p_Result_11_0_0_sr_reg_13084.read(): dst_tensor_0_0_V_reg_13073.read());
}

void compute::thread_r_V_0_10_fu_3783_p2() {
    r_V_0_10_fu_3783_p2 = (!tmp_249_0_10_fu_3780_p1.read().is_01())? sc_lv<32>(): reg_1624_pp0_iter5_reg.read() << (unsigned short)tmp_249_0_10_fu_3780_p1.read().to_uint();
}

void compute::thread_r_V_0_11_fu_3869_p2() {
    r_V_0_11_fu_3869_p2 = (!tmp_249_0_11_fu_3866_p1.read().is_01())? sc_lv<32>(): reg_1628_pp0_iter5_reg.read() << (unsigned short)tmp_249_0_11_fu_3866_p1.read().to_uint();
}

void compute::thread_r_V_0_12_fu_3955_p2() {
    r_V_0_12_fu_3955_p2 = (!tmp_249_0_12_fu_3952_p1.read().is_01())? sc_lv<32>(): reg_1632_pp0_iter5_reg.read() << (unsigned short)tmp_249_0_12_fu_3952_p1.read().to_uint();
}

void compute::thread_r_V_0_13_fu_4041_p2() {
    r_V_0_13_fu_4041_p2 = (!tmp_249_0_13_fu_4038_p1.read().is_01())? sc_lv<32>(): reg_1636_pp0_iter5_reg.read() << (unsigned short)tmp_249_0_13_fu_4038_p1.read().to_uint();
}

void compute::thread_r_V_0_14_fu_4127_p2() {
    r_V_0_14_fu_4127_p2 = (!tmp_249_0_14_fu_4124_p1.read().is_01())? sc_lv<32>(): reg_1640_pp0_iter5_reg.read() << (unsigned short)tmp_249_0_14_fu_4124_p1.read().to_uint();
}

void compute::thread_r_V_0_1_fu_2667_p2() {
    r_V_0_1_fu_2667_p2 = (!tmp_249_0_1_fu_2664_p1.read().is_01())? sc_lv<32>(): reg_1584.read() << (unsigned short)tmp_249_0_1_fu_2664_p1.read().to_uint();
}

void compute::thread_r_V_0_2_fu_2753_p2() {
    r_V_0_2_fu_2753_p2 = (!tmp_249_0_2_fu_2750_p1.read().is_01())? sc_lv<32>(): reg_1588.read() << (unsigned short)tmp_249_0_2_fu_2750_p1.read().to_uint();
}

void compute::thread_r_V_0_3_fu_2839_p2() {
    r_V_0_3_fu_2839_p2 = (!tmp_249_0_3_fu_2836_p1.read().is_01())? sc_lv<32>(): reg_1592.read() << (unsigned short)tmp_249_0_3_fu_2836_p1.read().to_uint();
}

void compute::thread_r_V_0_4_fu_2925_p2() {
    r_V_0_4_fu_2925_p2 = (!tmp_249_0_4_fu_2922_p1.read().is_01())? sc_lv<32>(): reg_1596.read() << (unsigned short)tmp_249_0_4_fu_2922_p1.read().to_uint();
}

void compute::thread_r_V_0_5_fu_3011_p2() {
    r_V_0_5_fu_3011_p2 = (!tmp_249_0_5_fu_3008_p1.read().is_01())? sc_lv<32>(): reg_1600.read() << (unsigned short)tmp_249_0_5_fu_3008_p1.read().to_uint();
}

void compute::thread_r_V_0_6_fu_3097_p2() {
    r_V_0_6_fu_3097_p2 = (!tmp_249_0_6_fu_3094_p1.read().is_01())? sc_lv<32>(): reg_1604.read() << (unsigned short)tmp_249_0_6_fu_3094_p1.read().to_uint();
}

void compute::thread_r_V_0_7_fu_3183_p2() {
    r_V_0_7_fu_3183_p2 = (!tmp_249_0_7_fu_3180_p1.read().is_01())? sc_lv<32>(): reg_1608.read() << (unsigned short)tmp_249_0_7_fu_3180_p1.read().to_uint();
}

void compute::thread_r_V_0_8_fu_3525_p2() {
    r_V_0_8_fu_3525_p2 = (!tmp_249_0_8_fu_3522_p1.read().is_01())? sc_lv<32>(): reg_1612_pp0_iter5_reg.read() << (unsigned short)tmp_249_0_8_fu_3522_p1.read().to_uint();
}

void compute::thread_r_V_0_9_fu_3611_p2() {
    r_V_0_9_fu_3611_p2 = (!tmp_249_0_9_fu_3608_p1.read().is_01())? sc_lv<32>(): reg_1616_pp0_iter5_reg.read() << (unsigned short)tmp_249_0_9_fu_3608_p1.read().to_uint();
}

void compute::thread_r_V_0_s_fu_3697_p2() {
    r_V_0_s_fu_3697_p2 = (!tmp_249_0_s_fu_3694_p1.read().is_01())? sc_lv<32>(): reg_1620_pp0_iter5_reg.read() << (unsigned short)tmp_249_0_s_fu_3694_p1.read().to_uint();
}

void compute::thread_r_V_1_0_10_fu_3792_p2() {
    r_V_1_0_10_fu_3792_p2 = (!reg_1624_pp0_iter5_reg.read().is_01() || !tmp_250_0_10_fu_3789_p1.read().is_01())? sc_lv<32>(): sc_bigint<32>(reg_1624_pp0_iter5_reg.read()) >> (unsigned short)tmp_250_0_10_fu_3789_p1.read().to_uint();
}

void compute::thread_r_V_1_0_11_fu_3878_p2() {
    r_V_1_0_11_fu_3878_p2 = (!reg_1628_pp0_iter5_reg.read().is_01() || !tmp_250_0_11_fu_3875_p1.read().is_01())? sc_lv<32>(): sc_bigint<32>(reg_1628_pp0_iter5_reg.read()) >> (unsigned short)tmp_250_0_11_fu_3875_p1.read().to_uint();
}

void compute::thread_r_V_1_0_12_fu_3964_p2() {
    r_V_1_0_12_fu_3964_p2 = (!reg_1632_pp0_iter5_reg.read().is_01() || !tmp_250_0_12_fu_3961_p1.read().is_01())? sc_lv<32>(): sc_bigint<32>(reg_1632_pp0_iter5_reg.read()) >> (unsigned short)tmp_250_0_12_fu_3961_p1.read().to_uint();
}

void compute::thread_r_V_1_0_13_fu_4050_p2() {
    r_V_1_0_13_fu_4050_p2 = (!reg_1636_pp0_iter5_reg.read().is_01() || !tmp_250_0_13_fu_4047_p1.read().is_01())? sc_lv<32>(): sc_bigint<32>(reg_1636_pp0_iter5_reg.read()) >> (unsigned short)tmp_250_0_13_fu_4047_p1.read().to_uint();
}

void compute::thread_r_V_1_0_14_fu_4136_p2() {
    r_V_1_0_14_fu_4136_p2 = (!reg_1640_pp0_iter5_reg.read().is_01() || !tmp_250_0_14_fu_4133_p1.read().is_01())? sc_lv<32>(): sc_bigint<32>(reg_1640_pp0_iter5_reg.read()) >> (unsigned short)tmp_250_0_14_fu_4133_p1.read().to_uint();
}

void compute::thread_r_V_1_0_1_fu_2676_p2() {
    r_V_1_0_1_fu_2676_p2 = (!reg_1584.read().is_01() || !tmp_250_0_1_fu_2673_p1.read().is_01())? sc_lv<32>(): sc_bigint<32>(reg_1584.read()) >> (unsigned short)tmp_250_0_1_fu_2673_p1.read().to_uint();
}

void compute::thread_r_V_1_0_2_fu_2762_p2() {
    r_V_1_0_2_fu_2762_p2 = (!reg_1588.read().is_01() || !tmp_250_0_2_fu_2759_p1.read().is_01())? sc_lv<32>(): sc_bigint<32>(reg_1588.read()) >> (unsigned short)tmp_250_0_2_fu_2759_p1.read().to_uint();
}

void compute::thread_r_V_1_0_3_fu_2848_p2() {
    r_V_1_0_3_fu_2848_p2 = (!reg_1592.read().is_01() || !tmp_250_0_3_fu_2845_p1.read().is_01())? sc_lv<32>(): sc_bigint<32>(reg_1592.read()) >> (unsigned short)tmp_250_0_3_fu_2845_p1.read().to_uint();
}

void compute::thread_r_V_1_0_4_fu_2934_p2() {
    r_V_1_0_4_fu_2934_p2 = (!reg_1596.read().is_01() || !tmp_250_0_4_fu_2931_p1.read().is_01())? sc_lv<32>(): sc_bigint<32>(reg_1596.read()) >> (unsigned short)tmp_250_0_4_fu_2931_p1.read().to_uint();
}

void compute::thread_r_V_1_0_5_fu_3020_p2() {
    r_V_1_0_5_fu_3020_p2 = (!reg_1600.read().is_01() || !tmp_250_0_5_fu_3017_p1.read().is_01())? sc_lv<32>(): sc_bigint<32>(reg_1600.read()) >> (unsigned short)tmp_250_0_5_fu_3017_p1.read().to_uint();
}

void compute::thread_r_V_1_0_6_fu_3106_p2() {
    r_V_1_0_6_fu_3106_p2 = (!reg_1604.read().is_01() || !tmp_250_0_6_fu_3103_p1.read().is_01())? sc_lv<32>(): sc_bigint<32>(reg_1604.read()) >> (unsigned short)tmp_250_0_6_fu_3103_p1.read().to_uint();
}

void compute::thread_r_V_1_0_7_fu_3192_p2() {
    r_V_1_0_7_fu_3192_p2 = (!reg_1608.read().is_01() || !tmp_250_0_7_fu_3189_p1.read().is_01())? sc_lv<32>(): sc_bigint<32>(reg_1608.read()) >> (unsigned short)tmp_250_0_7_fu_3189_p1.read().to_uint();
}

void compute::thread_r_V_1_0_8_fu_3534_p2() {
    r_V_1_0_8_fu_3534_p2 = (!reg_1612_pp0_iter5_reg.read().is_01() || !tmp_250_0_8_fu_3531_p1.read().is_01())? sc_lv<32>(): sc_bigint<32>(reg_1612_pp0_iter5_reg.read()) >> (unsigned short)tmp_250_0_8_fu_3531_p1.read().to_uint();
}

void compute::thread_r_V_1_0_9_fu_3620_p2() {
    r_V_1_0_9_fu_3620_p2 = (!reg_1616_pp0_iter5_reg.read().is_01() || !tmp_250_0_9_fu_3617_p1.read().is_01())? sc_lv<32>(): sc_bigint<32>(reg_1616_pp0_iter5_reg.read()) >> (unsigned short)tmp_250_0_9_fu_3617_p1.read().to_uint();
}

void compute::thread_r_V_1_0_s_fu_3706_p2() {
    r_V_1_0_s_fu_3706_p2 = (!reg_1620_pp0_iter5_reg.read().is_01() || !tmp_250_0_s_fu_3703_p1.read().is_01())? sc_lv<32>(): sc_bigint<32>(reg_1620_pp0_iter5_reg.read()) >> (unsigned short)tmp_250_0_s_fu_3703_p1.read().to_uint();
}

void compute::thread_r_V_1_fu_2592_p2() {
    r_V_1_fu_2592_p2 = (!dst_tensor_0_0_V_reg_13073.read().is_01() || !tmp_59_fu_2589_p1.read().is_01())? sc_lv<32>(): sc_bigint<32>(dst_tensor_0_0_V_reg_13073.read()) >> (unsigned short)tmp_59_fu_2589_p1.read().to_uint();
}

void compute::thread_r_V_fu_2584_p2() {
    r_V_fu_2584_p2 = (!tmp_58_fu_2581_p1.read().is_01())? sc_lv<32>(): dst_tensor_0_0_V_reg_13073.read() << (unsigned short)tmp_58_fu_2581_p1.read().to_uint();
}

void compute::thread_ret_V_15_0_0_10_fu_7913_p0() {
    ret_V_15_0_0_10_fu_7913_p0 =  (sc_lv<8>) (lhs_V_2_0_0_10_fu_7907_p1.read());
}

void compute::thread_ret_V_15_0_0_10_fu_7913_p1() {
    ret_V_15_0_0_10_fu_7913_p1 = w_tensor_i_0_10_reg_14281_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_0_10_fu_7913_p2() {
    ret_V_15_0_0_10_fu_7913_p2 = (!ret_V_15_0_0_10_fu_7913_p0.read().is_01() || !ret_V_15_0_0_10_fu_7913_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_0_10_fu_7913_p0.read()) * sc_bigint<8>(ret_V_15_0_0_10_fu_7913_p1.read());
}

void compute::thread_ret_V_15_0_0_12_fu_7925_p0() {
    ret_V_15_0_0_12_fu_7925_p0 =  (sc_lv<8>) (lhs_V_2_0_0_12_fu_7919_p1.read());
}

void compute::thread_ret_V_15_0_0_12_fu_7925_p1() {
    ret_V_15_0_0_12_fu_7925_p1 = w_tensor_i_0_12_reg_14291_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_0_12_fu_7925_p2() {
    ret_V_15_0_0_12_fu_7925_p2 = (!ret_V_15_0_0_12_fu_7925_p0.read().is_01() || !ret_V_15_0_0_12_fu_7925_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_0_12_fu_7925_p0.read()) * sc_bigint<8>(ret_V_15_0_0_12_fu_7925_p1.read());
}

void compute::thread_ret_V_15_0_0_14_fu_7937_p0() {
    ret_V_15_0_0_14_fu_7937_p0 =  (sc_lv<8>) (lhs_V_2_0_0_14_fu_7931_p1.read());
}

void compute::thread_ret_V_15_0_0_14_fu_7937_p1() {
    ret_V_15_0_0_14_fu_7937_p1 = w_tensor_i_0_14_reg_14301_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_0_14_fu_7937_p2() {
    ret_V_15_0_0_14_fu_7937_p2 = (!ret_V_15_0_0_14_fu_7937_p0.read().is_01() || !ret_V_15_0_0_14_fu_7937_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_0_14_fu_7937_p0.read()) * sc_bigint<8>(ret_V_15_0_0_14_fu_7937_p1.read());
}

void compute::thread_ret_V_15_0_0_1_fu_7853_p0() {
    ret_V_15_0_0_1_fu_7853_p0 =  (sc_lv<8>) (lhs_V_2_0_0_1_fu_7847_p1.read());
}

void compute::thread_ret_V_15_0_0_1_fu_7853_p1() {
    ret_V_15_0_0_1_fu_7853_p1 = w_tensor_i_0_1_reg_14231_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_0_1_fu_7853_p2() {
    ret_V_15_0_0_1_fu_7853_p2 = (!ret_V_15_0_0_1_fu_7853_p0.read().is_01() || !ret_V_15_0_0_1_fu_7853_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_0_1_fu_7853_p0.read()) * sc_bigint<8>(ret_V_15_0_0_1_fu_7853_p1.read());
}

void compute::thread_ret_V_15_0_0_3_fu_7865_p0() {
    ret_V_15_0_0_3_fu_7865_p0 =  (sc_lv<8>) (lhs_V_2_0_0_3_fu_7859_p1.read());
}

void compute::thread_ret_V_15_0_0_3_fu_7865_p1() {
    ret_V_15_0_0_3_fu_7865_p1 = w_tensor_i_0_3_reg_14241_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_0_3_fu_7865_p2() {
    ret_V_15_0_0_3_fu_7865_p2 = (!ret_V_15_0_0_3_fu_7865_p0.read().is_01() || !ret_V_15_0_0_3_fu_7865_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_0_3_fu_7865_p0.read()) * sc_bigint<8>(ret_V_15_0_0_3_fu_7865_p1.read());
}

void compute::thread_ret_V_15_0_0_5_fu_7877_p0() {
    ret_V_15_0_0_5_fu_7877_p0 =  (sc_lv<8>) (lhs_V_2_0_0_5_fu_7871_p1.read());
}

void compute::thread_ret_V_15_0_0_5_fu_7877_p1() {
    ret_V_15_0_0_5_fu_7877_p1 = w_tensor_i_0_5_reg_14251_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_0_5_fu_7877_p2() {
    ret_V_15_0_0_5_fu_7877_p2 = (!ret_V_15_0_0_5_fu_7877_p0.read().is_01() || !ret_V_15_0_0_5_fu_7877_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_0_5_fu_7877_p0.read()) * sc_bigint<8>(ret_V_15_0_0_5_fu_7877_p1.read());
}

void compute::thread_ret_V_15_0_0_7_fu_7889_p0() {
    ret_V_15_0_0_7_fu_7889_p0 =  (sc_lv<8>) (lhs_V_2_0_0_7_fu_7883_p1.read());
}

void compute::thread_ret_V_15_0_0_7_fu_7889_p1() {
    ret_V_15_0_0_7_fu_7889_p1 = w_tensor_i_0_7_reg_14261_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_0_7_fu_7889_p2() {
    ret_V_15_0_0_7_fu_7889_p2 = (!ret_V_15_0_0_7_fu_7889_p0.read().is_01() || !ret_V_15_0_0_7_fu_7889_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_0_7_fu_7889_p0.read()) * sc_bigint<8>(ret_V_15_0_0_7_fu_7889_p1.read());
}

void compute::thread_ret_V_15_0_0_9_fu_7901_p0() {
    ret_V_15_0_0_9_fu_7901_p0 =  (sc_lv<8>) (lhs_V_2_0_0_9_fu_7895_p1.read());
}

void compute::thread_ret_V_15_0_0_9_fu_7901_p1() {
    ret_V_15_0_0_9_fu_7901_p1 = w_tensor_i_0_9_reg_14271_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_0_9_fu_7901_p2() {
    ret_V_15_0_0_9_fu_7901_p2 = (!ret_V_15_0_0_9_fu_7901_p0.read().is_01() || !ret_V_15_0_0_9_fu_7901_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_0_9_fu_7901_p0.read()) * sc_bigint<8>(ret_V_15_0_0_9_fu_7901_p1.read());
}

void compute::thread_ret_V_15_0_10_10_fu_8639_p0() {
    ret_V_15_0_10_10_fu_8639_p0 =  (sc_lv<8>) (lhs_V_2_0_0_10_fu_7907_p1.read());
}

void compute::thread_ret_V_15_0_10_10_fu_8639_p1() {
    ret_V_15_0_10_10_fu_8639_p1 = w_tensor_i_10_10_reg_15081_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_10_10_fu_8639_p2() {
    ret_V_15_0_10_10_fu_8639_p2 = (!ret_V_15_0_10_10_fu_8639_p0.read().is_01() || !ret_V_15_0_10_10_fu_8639_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_10_10_fu_8639_p0.read()) * sc_bigint<8>(ret_V_15_0_10_10_fu_8639_p1.read());
}

void compute::thread_ret_V_15_0_10_12_fu_8648_p0() {
    ret_V_15_0_10_12_fu_8648_p0 =  (sc_lv<8>) (lhs_V_2_0_0_12_fu_7919_p1.read());
}

void compute::thread_ret_V_15_0_10_12_fu_8648_p1() {
    ret_V_15_0_10_12_fu_8648_p1 = w_tensor_i_10_12_reg_15091_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_10_12_fu_8648_p2() {
    ret_V_15_0_10_12_fu_8648_p2 = (!ret_V_15_0_10_12_fu_8648_p0.read().is_01() || !ret_V_15_0_10_12_fu_8648_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_10_12_fu_8648_p0.read()) * sc_bigint<8>(ret_V_15_0_10_12_fu_8648_p1.read());
}

void compute::thread_ret_V_15_0_10_14_fu_8657_p0() {
    ret_V_15_0_10_14_fu_8657_p0 =  (sc_lv<8>) (lhs_V_2_0_0_14_fu_7931_p1.read());
}

void compute::thread_ret_V_15_0_10_14_fu_8657_p1() {
    ret_V_15_0_10_14_fu_8657_p1 = w_tensor_i_10_14_reg_15101_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_10_14_fu_8657_p2() {
    ret_V_15_0_10_14_fu_8657_p2 = (!ret_V_15_0_10_14_fu_8657_p0.read().is_01() || !ret_V_15_0_10_14_fu_8657_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_10_14_fu_8657_p0.read()) * sc_bigint<8>(ret_V_15_0_10_14_fu_8657_p1.read());
}

void compute::thread_ret_V_15_0_10_1_fu_8594_p0() {
    ret_V_15_0_10_1_fu_8594_p0 =  (sc_lv<8>) (lhs_V_2_0_0_1_fu_7847_p1.read());
}

void compute::thread_ret_V_15_0_10_1_fu_8594_p1() {
    ret_V_15_0_10_1_fu_8594_p1 = w_tensor_i_10_1_reg_15031_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_10_1_fu_8594_p2() {
    ret_V_15_0_10_1_fu_8594_p2 = (!ret_V_15_0_10_1_fu_8594_p0.read().is_01() || !ret_V_15_0_10_1_fu_8594_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_10_1_fu_8594_p0.read()) * sc_bigint<8>(ret_V_15_0_10_1_fu_8594_p1.read());
}

void compute::thread_ret_V_15_0_10_3_fu_8603_p0() {
    ret_V_15_0_10_3_fu_8603_p0 =  (sc_lv<8>) (lhs_V_2_0_0_3_fu_7859_p1.read());
}

void compute::thread_ret_V_15_0_10_3_fu_8603_p1() {
    ret_V_15_0_10_3_fu_8603_p1 = w_tensor_i_10_3_reg_15041_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_10_3_fu_8603_p2() {
    ret_V_15_0_10_3_fu_8603_p2 = (!ret_V_15_0_10_3_fu_8603_p0.read().is_01() || !ret_V_15_0_10_3_fu_8603_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_10_3_fu_8603_p0.read()) * sc_bigint<8>(ret_V_15_0_10_3_fu_8603_p1.read());
}

void compute::thread_ret_V_15_0_10_5_fu_8612_p0() {
    ret_V_15_0_10_5_fu_8612_p0 =  (sc_lv<8>) (lhs_V_2_0_0_5_fu_7871_p1.read());
}

void compute::thread_ret_V_15_0_10_5_fu_8612_p1() {
    ret_V_15_0_10_5_fu_8612_p1 = w_tensor_i_10_5_reg_15051_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_10_5_fu_8612_p2() {
    ret_V_15_0_10_5_fu_8612_p2 = (!ret_V_15_0_10_5_fu_8612_p0.read().is_01() || !ret_V_15_0_10_5_fu_8612_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_10_5_fu_8612_p0.read()) * sc_bigint<8>(ret_V_15_0_10_5_fu_8612_p1.read());
}

void compute::thread_ret_V_15_0_10_7_fu_8621_p0() {
    ret_V_15_0_10_7_fu_8621_p0 =  (sc_lv<8>) (lhs_V_2_0_0_7_fu_7883_p1.read());
}

void compute::thread_ret_V_15_0_10_7_fu_8621_p1() {
    ret_V_15_0_10_7_fu_8621_p1 = w_tensor_i_10_7_reg_15061_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_10_7_fu_8621_p2() {
    ret_V_15_0_10_7_fu_8621_p2 = (!ret_V_15_0_10_7_fu_8621_p0.read().is_01() || !ret_V_15_0_10_7_fu_8621_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_10_7_fu_8621_p0.read()) * sc_bigint<8>(ret_V_15_0_10_7_fu_8621_p1.read());
}

void compute::thread_ret_V_15_0_10_9_fu_8630_p0() {
    ret_V_15_0_10_9_fu_8630_p0 =  (sc_lv<8>) (lhs_V_2_0_0_9_fu_7895_p1.read());
}

void compute::thread_ret_V_15_0_10_9_fu_8630_p1() {
    ret_V_15_0_10_9_fu_8630_p1 = w_tensor_i_10_9_reg_15071_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_10_9_fu_8630_p2() {
    ret_V_15_0_10_9_fu_8630_p2 = (!ret_V_15_0_10_9_fu_8630_p0.read().is_01() || !ret_V_15_0_10_9_fu_8630_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_10_9_fu_8630_p0.read()) * sc_bigint<8>(ret_V_15_0_10_9_fu_8630_p1.read());
}

void compute::thread_ret_V_15_0_11_10_fu_8711_p0() {
    ret_V_15_0_11_10_fu_8711_p0 =  (sc_lv<8>) (lhs_V_2_0_0_10_fu_7907_p1.read());
}

void compute::thread_ret_V_15_0_11_10_fu_8711_p1() {
    ret_V_15_0_11_10_fu_8711_p1 = w_tensor_i_11_10_reg_15161_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_11_10_fu_8711_p2() {
    ret_V_15_0_11_10_fu_8711_p2 = (!ret_V_15_0_11_10_fu_8711_p0.read().is_01() || !ret_V_15_0_11_10_fu_8711_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_11_10_fu_8711_p0.read()) * sc_bigint<8>(ret_V_15_0_11_10_fu_8711_p1.read());
}

void compute::thread_ret_V_15_0_11_12_fu_8720_p0() {
    ret_V_15_0_11_12_fu_8720_p0 =  (sc_lv<8>) (lhs_V_2_0_0_12_fu_7919_p1.read());
}

void compute::thread_ret_V_15_0_11_12_fu_8720_p1() {
    ret_V_15_0_11_12_fu_8720_p1 = w_tensor_i_11_12_reg_15171_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_11_12_fu_8720_p2() {
    ret_V_15_0_11_12_fu_8720_p2 = (!ret_V_15_0_11_12_fu_8720_p0.read().is_01() || !ret_V_15_0_11_12_fu_8720_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_11_12_fu_8720_p0.read()) * sc_bigint<8>(ret_V_15_0_11_12_fu_8720_p1.read());
}

void compute::thread_ret_V_15_0_11_14_fu_8729_p0() {
    ret_V_15_0_11_14_fu_8729_p0 =  (sc_lv<8>) (lhs_V_2_0_0_14_fu_7931_p1.read());
}

void compute::thread_ret_V_15_0_11_14_fu_8729_p1() {
    ret_V_15_0_11_14_fu_8729_p1 = w_tensor_i_11_14_reg_15181_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_11_14_fu_8729_p2() {
    ret_V_15_0_11_14_fu_8729_p2 = (!ret_V_15_0_11_14_fu_8729_p0.read().is_01() || !ret_V_15_0_11_14_fu_8729_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_11_14_fu_8729_p0.read()) * sc_bigint<8>(ret_V_15_0_11_14_fu_8729_p1.read());
}

void compute::thread_ret_V_15_0_11_1_fu_8666_p0() {
    ret_V_15_0_11_1_fu_8666_p0 =  (sc_lv<8>) (lhs_V_2_0_0_1_fu_7847_p1.read());
}

void compute::thread_ret_V_15_0_11_1_fu_8666_p1() {
    ret_V_15_0_11_1_fu_8666_p1 = w_tensor_i_11_1_reg_15111_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_11_1_fu_8666_p2() {
    ret_V_15_0_11_1_fu_8666_p2 = (!ret_V_15_0_11_1_fu_8666_p0.read().is_01() || !ret_V_15_0_11_1_fu_8666_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_11_1_fu_8666_p0.read()) * sc_bigint<8>(ret_V_15_0_11_1_fu_8666_p1.read());
}

void compute::thread_ret_V_15_0_11_3_fu_8675_p0() {
    ret_V_15_0_11_3_fu_8675_p0 =  (sc_lv<8>) (lhs_V_2_0_0_3_fu_7859_p1.read());
}

void compute::thread_ret_V_15_0_11_3_fu_8675_p1() {
    ret_V_15_0_11_3_fu_8675_p1 = w_tensor_i_11_3_reg_15121_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_11_3_fu_8675_p2() {
    ret_V_15_0_11_3_fu_8675_p2 = (!ret_V_15_0_11_3_fu_8675_p0.read().is_01() || !ret_V_15_0_11_3_fu_8675_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_11_3_fu_8675_p0.read()) * sc_bigint<8>(ret_V_15_0_11_3_fu_8675_p1.read());
}

void compute::thread_ret_V_15_0_11_5_fu_8684_p0() {
    ret_V_15_0_11_5_fu_8684_p0 =  (sc_lv<8>) (lhs_V_2_0_0_5_fu_7871_p1.read());
}

void compute::thread_ret_V_15_0_11_5_fu_8684_p1() {
    ret_V_15_0_11_5_fu_8684_p1 = w_tensor_i_11_5_reg_15131_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_11_5_fu_8684_p2() {
    ret_V_15_0_11_5_fu_8684_p2 = (!ret_V_15_0_11_5_fu_8684_p0.read().is_01() || !ret_V_15_0_11_5_fu_8684_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_11_5_fu_8684_p0.read()) * sc_bigint<8>(ret_V_15_0_11_5_fu_8684_p1.read());
}

void compute::thread_ret_V_15_0_11_7_fu_8693_p0() {
    ret_V_15_0_11_7_fu_8693_p0 =  (sc_lv<8>) (lhs_V_2_0_0_7_fu_7883_p1.read());
}

void compute::thread_ret_V_15_0_11_7_fu_8693_p1() {
    ret_V_15_0_11_7_fu_8693_p1 = w_tensor_i_11_7_reg_15141_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_11_7_fu_8693_p2() {
    ret_V_15_0_11_7_fu_8693_p2 = (!ret_V_15_0_11_7_fu_8693_p0.read().is_01() || !ret_V_15_0_11_7_fu_8693_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_11_7_fu_8693_p0.read()) * sc_bigint<8>(ret_V_15_0_11_7_fu_8693_p1.read());
}

void compute::thread_ret_V_15_0_11_9_fu_8702_p0() {
    ret_V_15_0_11_9_fu_8702_p0 =  (sc_lv<8>) (lhs_V_2_0_0_9_fu_7895_p1.read());
}

void compute::thread_ret_V_15_0_11_9_fu_8702_p1() {
    ret_V_15_0_11_9_fu_8702_p1 = w_tensor_i_11_9_reg_15151_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_11_9_fu_8702_p2() {
    ret_V_15_0_11_9_fu_8702_p2 = (!ret_V_15_0_11_9_fu_8702_p0.read().is_01() || !ret_V_15_0_11_9_fu_8702_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_11_9_fu_8702_p0.read()) * sc_bigint<8>(ret_V_15_0_11_9_fu_8702_p1.read());
}

void compute::thread_ret_V_15_0_12_10_fu_8783_p0() {
    ret_V_15_0_12_10_fu_8783_p0 =  (sc_lv<8>) (lhs_V_2_0_0_10_fu_7907_p1.read());
}

void compute::thread_ret_V_15_0_12_10_fu_8783_p1() {
    ret_V_15_0_12_10_fu_8783_p1 = w_tensor_i_12_10_reg_15241_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_12_10_fu_8783_p2() {
    ret_V_15_0_12_10_fu_8783_p2 = (!ret_V_15_0_12_10_fu_8783_p0.read().is_01() || !ret_V_15_0_12_10_fu_8783_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_12_10_fu_8783_p0.read()) * sc_bigint<8>(ret_V_15_0_12_10_fu_8783_p1.read());
}

void compute::thread_ret_V_15_0_12_12_fu_8792_p0() {
    ret_V_15_0_12_12_fu_8792_p0 =  (sc_lv<8>) (lhs_V_2_0_0_12_fu_7919_p1.read());
}

void compute::thread_ret_V_15_0_12_12_fu_8792_p1() {
    ret_V_15_0_12_12_fu_8792_p1 = w_tensor_i_12_12_reg_15251_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_12_12_fu_8792_p2() {
    ret_V_15_0_12_12_fu_8792_p2 = (!ret_V_15_0_12_12_fu_8792_p0.read().is_01() || !ret_V_15_0_12_12_fu_8792_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_12_12_fu_8792_p0.read()) * sc_bigint<8>(ret_V_15_0_12_12_fu_8792_p1.read());
}

void compute::thread_ret_V_15_0_12_14_fu_8801_p0() {
    ret_V_15_0_12_14_fu_8801_p0 =  (sc_lv<8>) (lhs_V_2_0_0_14_fu_7931_p1.read());
}

void compute::thread_ret_V_15_0_12_14_fu_8801_p1() {
    ret_V_15_0_12_14_fu_8801_p1 = w_tensor_i_12_14_reg_15261_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_12_14_fu_8801_p2() {
    ret_V_15_0_12_14_fu_8801_p2 = (!ret_V_15_0_12_14_fu_8801_p0.read().is_01() || !ret_V_15_0_12_14_fu_8801_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_12_14_fu_8801_p0.read()) * sc_bigint<8>(ret_V_15_0_12_14_fu_8801_p1.read());
}

void compute::thread_ret_V_15_0_12_1_fu_8738_p0() {
    ret_V_15_0_12_1_fu_8738_p0 =  (sc_lv<8>) (lhs_V_2_0_0_1_fu_7847_p1.read());
}

void compute::thread_ret_V_15_0_12_1_fu_8738_p1() {
    ret_V_15_0_12_1_fu_8738_p1 = w_tensor_i_12_1_reg_15191_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_12_1_fu_8738_p2() {
    ret_V_15_0_12_1_fu_8738_p2 = (!ret_V_15_0_12_1_fu_8738_p0.read().is_01() || !ret_V_15_0_12_1_fu_8738_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_12_1_fu_8738_p0.read()) * sc_bigint<8>(ret_V_15_0_12_1_fu_8738_p1.read());
}

void compute::thread_ret_V_15_0_12_3_fu_8747_p0() {
    ret_V_15_0_12_3_fu_8747_p0 =  (sc_lv<8>) (lhs_V_2_0_0_3_fu_7859_p1.read());
}

void compute::thread_ret_V_15_0_12_3_fu_8747_p1() {
    ret_V_15_0_12_3_fu_8747_p1 = w_tensor_i_12_3_reg_15201_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_12_3_fu_8747_p2() {
    ret_V_15_0_12_3_fu_8747_p2 = (!ret_V_15_0_12_3_fu_8747_p0.read().is_01() || !ret_V_15_0_12_3_fu_8747_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_12_3_fu_8747_p0.read()) * sc_bigint<8>(ret_V_15_0_12_3_fu_8747_p1.read());
}

void compute::thread_ret_V_15_0_12_5_fu_8756_p0() {
    ret_V_15_0_12_5_fu_8756_p0 =  (sc_lv<8>) (lhs_V_2_0_0_5_fu_7871_p1.read());
}

void compute::thread_ret_V_15_0_12_5_fu_8756_p1() {
    ret_V_15_0_12_5_fu_8756_p1 = w_tensor_i_12_5_reg_15211_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_12_5_fu_8756_p2() {
    ret_V_15_0_12_5_fu_8756_p2 = (!ret_V_15_0_12_5_fu_8756_p0.read().is_01() || !ret_V_15_0_12_5_fu_8756_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_12_5_fu_8756_p0.read()) * sc_bigint<8>(ret_V_15_0_12_5_fu_8756_p1.read());
}

void compute::thread_ret_V_15_0_12_7_fu_8765_p0() {
    ret_V_15_0_12_7_fu_8765_p0 =  (sc_lv<8>) (lhs_V_2_0_0_7_fu_7883_p1.read());
}

void compute::thread_ret_V_15_0_12_7_fu_8765_p1() {
    ret_V_15_0_12_7_fu_8765_p1 = w_tensor_i_12_7_reg_15221_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_12_7_fu_8765_p2() {
    ret_V_15_0_12_7_fu_8765_p2 = (!ret_V_15_0_12_7_fu_8765_p0.read().is_01() || !ret_V_15_0_12_7_fu_8765_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_12_7_fu_8765_p0.read()) * sc_bigint<8>(ret_V_15_0_12_7_fu_8765_p1.read());
}

void compute::thread_ret_V_15_0_12_9_fu_8774_p0() {
    ret_V_15_0_12_9_fu_8774_p0 =  (sc_lv<8>) (lhs_V_2_0_0_9_fu_7895_p1.read());
}

void compute::thread_ret_V_15_0_12_9_fu_8774_p1() {
    ret_V_15_0_12_9_fu_8774_p1 = w_tensor_i_12_9_reg_15231_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_12_9_fu_8774_p2() {
    ret_V_15_0_12_9_fu_8774_p2 = (!ret_V_15_0_12_9_fu_8774_p0.read().is_01() || !ret_V_15_0_12_9_fu_8774_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_12_9_fu_8774_p0.read()) * sc_bigint<8>(ret_V_15_0_12_9_fu_8774_p1.read());
}

void compute::thread_ret_V_15_0_13_10_fu_8855_p0() {
    ret_V_15_0_13_10_fu_8855_p0 =  (sc_lv<8>) (lhs_V_2_0_0_10_fu_7907_p1.read());
}

void compute::thread_ret_V_15_0_13_10_fu_8855_p1() {
    ret_V_15_0_13_10_fu_8855_p1 = w_tensor_i_13_10_reg_15321_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_13_10_fu_8855_p2() {
    ret_V_15_0_13_10_fu_8855_p2 = (!ret_V_15_0_13_10_fu_8855_p0.read().is_01() || !ret_V_15_0_13_10_fu_8855_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_13_10_fu_8855_p0.read()) * sc_bigint<8>(ret_V_15_0_13_10_fu_8855_p1.read());
}

void compute::thread_ret_V_15_0_13_12_fu_8864_p0() {
    ret_V_15_0_13_12_fu_8864_p0 =  (sc_lv<8>) (lhs_V_2_0_0_12_fu_7919_p1.read());
}

void compute::thread_ret_V_15_0_13_12_fu_8864_p1() {
    ret_V_15_0_13_12_fu_8864_p1 = w_tensor_i_13_12_reg_15331_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_13_12_fu_8864_p2() {
    ret_V_15_0_13_12_fu_8864_p2 = (!ret_V_15_0_13_12_fu_8864_p0.read().is_01() || !ret_V_15_0_13_12_fu_8864_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_13_12_fu_8864_p0.read()) * sc_bigint<8>(ret_V_15_0_13_12_fu_8864_p1.read());
}

void compute::thread_ret_V_15_0_13_14_fu_8873_p0() {
    ret_V_15_0_13_14_fu_8873_p0 =  (sc_lv<8>) (lhs_V_2_0_0_14_fu_7931_p1.read());
}

void compute::thread_ret_V_15_0_13_14_fu_8873_p1() {
    ret_V_15_0_13_14_fu_8873_p1 = w_tensor_i_13_14_reg_15341_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_13_14_fu_8873_p2() {
    ret_V_15_0_13_14_fu_8873_p2 = (!ret_V_15_0_13_14_fu_8873_p0.read().is_01() || !ret_V_15_0_13_14_fu_8873_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_13_14_fu_8873_p0.read()) * sc_bigint<8>(ret_V_15_0_13_14_fu_8873_p1.read());
}

void compute::thread_ret_V_15_0_13_1_fu_8810_p0() {
    ret_V_15_0_13_1_fu_8810_p0 =  (sc_lv<8>) (lhs_V_2_0_0_1_fu_7847_p1.read());
}

void compute::thread_ret_V_15_0_13_1_fu_8810_p1() {
    ret_V_15_0_13_1_fu_8810_p1 = w_tensor_i_13_1_reg_15271_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_13_1_fu_8810_p2() {
    ret_V_15_0_13_1_fu_8810_p2 = (!ret_V_15_0_13_1_fu_8810_p0.read().is_01() || !ret_V_15_0_13_1_fu_8810_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_13_1_fu_8810_p0.read()) * sc_bigint<8>(ret_V_15_0_13_1_fu_8810_p1.read());
}

void compute::thread_ret_V_15_0_13_3_fu_8819_p0() {
    ret_V_15_0_13_3_fu_8819_p0 =  (sc_lv<8>) (lhs_V_2_0_0_3_fu_7859_p1.read());
}

void compute::thread_ret_V_15_0_13_3_fu_8819_p1() {
    ret_V_15_0_13_3_fu_8819_p1 = w_tensor_i_13_3_reg_15281_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_13_3_fu_8819_p2() {
    ret_V_15_0_13_3_fu_8819_p2 = (!ret_V_15_0_13_3_fu_8819_p0.read().is_01() || !ret_V_15_0_13_3_fu_8819_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_13_3_fu_8819_p0.read()) * sc_bigint<8>(ret_V_15_0_13_3_fu_8819_p1.read());
}

void compute::thread_ret_V_15_0_13_5_fu_8828_p0() {
    ret_V_15_0_13_5_fu_8828_p0 =  (sc_lv<8>) (lhs_V_2_0_0_5_fu_7871_p1.read());
}

void compute::thread_ret_V_15_0_13_5_fu_8828_p1() {
    ret_V_15_0_13_5_fu_8828_p1 = w_tensor_i_13_5_reg_15291_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_13_5_fu_8828_p2() {
    ret_V_15_0_13_5_fu_8828_p2 = (!ret_V_15_0_13_5_fu_8828_p0.read().is_01() || !ret_V_15_0_13_5_fu_8828_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_13_5_fu_8828_p0.read()) * sc_bigint<8>(ret_V_15_0_13_5_fu_8828_p1.read());
}

void compute::thread_ret_V_15_0_13_7_fu_8837_p0() {
    ret_V_15_0_13_7_fu_8837_p0 =  (sc_lv<8>) (lhs_V_2_0_0_7_fu_7883_p1.read());
}

void compute::thread_ret_V_15_0_13_7_fu_8837_p1() {
    ret_V_15_0_13_7_fu_8837_p1 = w_tensor_i_13_7_reg_15301_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_13_7_fu_8837_p2() {
    ret_V_15_0_13_7_fu_8837_p2 = (!ret_V_15_0_13_7_fu_8837_p0.read().is_01() || !ret_V_15_0_13_7_fu_8837_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_13_7_fu_8837_p0.read()) * sc_bigint<8>(ret_V_15_0_13_7_fu_8837_p1.read());
}

void compute::thread_ret_V_15_0_13_9_fu_8846_p0() {
    ret_V_15_0_13_9_fu_8846_p0 =  (sc_lv<8>) (lhs_V_2_0_0_9_fu_7895_p1.read());
}

void compute::thread_ret_V_15_0_13_9_fu_8846_p1() {
    ret_V_15_0_13_9_fu_8846_p1 = w_tensor_i_13_9_reg_15311_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_13_9_fu_8846_p2() {
    ret_V_15_0_13_9_fu_8846_p2 = (!ret_V_15_0_13_9_fu_8846_p0.read().is_01() || !ret_V_15_0_13_9_fu_8846_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_13_9_fu_8846_p0.read()) * sc_bigint<8>(ret_V_15_0_13_9_fu_8846_p1.read());
}

void compute::thread_ret_V_15_0_14_10_fu_8927_p0() {
    ret_V_15_0_14_10_fu_8927_p0 =  (sc_lv<8>) (lhs_V_2_0_0_10_fu_7907_p1.read());
}

void compute::thread_ret_V_15_0_14_10_fu_8927_p1() {
    ret_V_15_0_14_10_fu_8927_p1 = w_tensor_i_14_10_reg_15401_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_14_10_fu_8927_p2() {
    ret_V_15_0_14_10_fu_8927_p2 = (!ret_V_15_0_14_10_fu_8927_p0.read().is_01() || !ret_V_15_0_14_10_fu_8927_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_14_10_fu_8927_p0.read()) * sc_bigint<8>(ret_V_15_0_14_10_fu_8927_p1.read());
}

void compute::thread_ret_V_15_0_14_12_fu_8936_p0() {
    ret_V_15_0_14_12_fu_8936_p0 =  (sc_lv<8>) (lhs_V_2_0_0_12_fu_7919_p1.read());
}

void compute::thread_ret_V_15_0_14_12_fu_8936_p1() {
    ret_V_15_0_14_12_fu_8936_p1 = w_tensor_i_14_12_reg_15411_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_14_12_fu_8936_p2() {
    ret_V_15_0_14_12_fu_8936_p2 = (!ret_V_15_0_14_12_fu_8936_p0.read().is_01() || !ret_V_15_0_14_12_fu_8936_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_14_12_fu_8936_p0.read()) * sc_bigint<8>(ret_V_15_0_14_12_fu_8936_p1.read());
}

void compute::thread_ret_V_15_0_14_14_fu_8945_p0() {
    ret_V_15_0_14_14_fu_8945_p0 =  (sc_lv<8>) (lhs_V_2_0_0_14_fu_7931_p1.read());
}

void compute::thread_ret_V_15_0_14_14_fu_8945_p1() {
    ret_V_15_0_14_14_fu_8945_p1 = w_tensor_i_14_14_reg_15421_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_14_14_fu_8945_p2() {
    ret_V_15_0_14_14_fu_8945_p2 = (!ret_V_15_0_14_14_fu_8945_p0.read().is_01() || !ret_V_15_0_14_14_fu_8945_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_14_14_fu_8945_p0.read()) * sc_bigint<8>(ret_V_15_0_14_14_fu_8945_p1.read());
}

void compute::thread_ret_V_15_0_14_1_fu_8882_p0() {
    ret_V_15_0_14_1_fu_8882_p0 =  (sc_lv<8>) (lhs_V_2_0_0_1_fu_7847_p1.read());
}

void compute::thread_ret_V_15_0_14_1_fu_8882_p1() {
    ret_V_15_0_14_1_fu_8882_p1 = w_tensor_i_14_1_reg_15351_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_14_1_fu_8882_p2() {
    ret_V_15_0_14_1_fu_8882_p2 = (!ret_V_15_0_14_1_fu_8882_p0.read().is_01() || !ret_V_15_0_14_1_fu_8882_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_14_1_fu_8882_p0.read()) * sc_bigint<8>(ret_V_15_0_14_1_fu_8882_p1.read());
}

void compute::thread_ret_V_15_0_14_3_fu_8891_p0() {
    ret_V_15_0_14_3_fu_8891_p0 =  (sc_lv<8>) (lhs_V_2_0_0_3_fu_7859_p1.read());
}

void compute::thread_ret_V_15_0_14_3_fu_8891_p1() {
    ret_V_15_0_14_3_fu_8891_p1 = w_tensor_i_14_3_reg_15361_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_14_3_fu_8891_p2() {
    ret_V_15_0_14_3_fu_8891_p2 = (!ret_V_15_0_14_3_fu_8891_p0.read().is_01() || !ret_V_15_0_14_3_fu_8891_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_14_3_fu_8891_p0.read()) * sc_bigint<8>(ret_V_15_0_14_3_fu_8891_p1.read());
}

void compute::thread_ret_V_15_0_14_5_fu_8900_p0() {
    ret_V_15_0_14_5_fu_8900_p0 =  (sc_lv<8>) (lhs_V_2_0_0_5_fu_7871_p1.read());
}

void compute::thread_ret_V_15_0_14_5_fu_8900_p1() {
    ret_V_15_0_14_5_fu_8900_p1 = w_tensor_i_14_5_reg_15371_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_14_5_fu_8900_p2() {
    ret_V_15_0_14_5_fu_8900_p2 = (!ret_V_15_0_14_5_fu_8900_p0.read().is_01() || !ret_V_15_0_14_5_fu_8900_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_14_5_fu_8900_p0.read()) * sc_bigint<8>(ret_V_15_0_14_5_fu_8900_p1.read());
}

void compute::thread_ret_V_15_0_14_7_fu_8909_p0() {
    ret_V_15_0_14_7_fu_8909_p0 =  (sc_lv<8>) (lhs_V_2_0_0_7_fu_7883_p1.read());
}

void compute::thread_ret_V_15_0_14_7_fu_8909_p1() {
    ret_V_15_0_14_7_fu_8909_p1 = w_tensor_i_14_7_reg_15381_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_14_7_fu_8909_p2() {
    ret_V_15_0_14_7_fu_8909_p2 = (!ret_V_15_0_14_7_fu_8909_p0.read().is_01() || !ret_V_15_0_14_7_fu_8909_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_14_7_fu_8909_p0.read()) * sc_bigint<8>(ret_V_15_0_14_7_fu_8909_p1.read());
}

void compute::thread_ret_V_15_0_14_9_fu_8918_p0() {
    ret_V_15_0_14_9_fu_8918_p0 =  (sc_lv<8>) (lhs_V_2_0_0_9_fu_7895_p1.read());
}

void compute::thread_ret_V_15_0_14_9_fu_8918_p1() {
    ret_V_15_0_14_9_fu_8918_p1 = w_tensor_i_14_9_reg_15391_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_14_9_fu_8918_p2() {
    ret_V_15_0_14_9_fu_8918_p2 = (!ret_V_15_0_14_9_fu_8918_p0.read().is_01() || !ret_V_15_0_14_9_fu_8918_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_14_9_fu_8918_p0.read()) * sc_bigint<8>(ret_V_15_0_14_9_fu_8918_p1.read());
}

void compute::thread_ret_V_15_0_15_10_fu_8999_p0() {
    ret_V_15_0_15_10_fu_8999_p0 =  (sc_lv<8>) (lhs_V_2_0_0_10_fu_7907_p1.read());
}

void compute::thread_ret_V_15_0_15_10_fu_8999_p1() {
    ret_V_15_0_15_10_fu_8999_p1 = w_tensor_i_15_10_reg_15481_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_15_10_fu_8999_p2() {
    ret_V_15_0_15_10_fu_8999_p2 = (!ret_V_15_0_15_10_fu_8999_p0.read().is_01() || !ret_V_15_0_15_10_fu_8999_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_15_10_fu_8999_p0.read()) * sc_bigint<8>(ret_V_15_0_15_10_fu_8999_p1.read());
}

void compute::thread_ret_V_15_0_15_12_fu_9008_p0() {
    ret_V_15_0_15_12_fu_9008_p0 =  (sc_lv<8>) (lhs_V_2_0_0_12_fu_7919_p1.read());
}

void compute::thread_ret_V_15_0_15_12_fu_9008_p1() {
    ret_V_15_0_15_12_fu_9008_p1 = w_tensor_i_15_12_reg_15491_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_15_12_fu_9008_p2() {
    ret_V_15_0_15_12_fu_9008_p2 = (!ret_V_15_0_15_12_fu_9008_p0.read().is_01() || !ret_V_15_0_15_12_fu_9008_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_15_12_fu_9008_p0.read()) * sc_bigint<8>(ret_V_15_0_15_12_fu_9008_p1.read());
}

void compute::thread_ret_V_15_0_15_14_fu_9017_p0() {
    ret_V_15_0_15_14_fu_9017_p0 =  (sc_lv<8>) (lhs_V_2_0_0_14_fu_7931_p1.read());
}

void compute::thread_ret_V_15_0_15_14_fu_9017_p1() {
    ret_V_15_0_15_14_fu_9017_p1 = w_tensor_i_15_14_reg_15501_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_15_14_fu_9017_p2() {
    ret_V_15_0_15_14_fu_9017_p2 = (!ret_V_15_0_15_14_fu_9017_p0.read().is_01() || !ret_V_15_0_15_14_fu_9017_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_15_14_fu_9017_p0.read()) * sc_bigint<8>(ret_V_15_0_15_14_fu_9017_p1.read());
}

void compute::thread_ret_V_15_0_15_1_fu_8954_p0() {
    ret_V_15_0_15_1_fu_8954_p0 =  (sc_lv<8>) (lhs_V_2_0_0_1_fu_7847_p1.read());
}

void compute::thread_ret_V_15_0_15_1_fu_8954_p1() {
    ret_V_15_0_15_1_fu_8954_p1 = w_tensor_i_15_1_reg_15431_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_15_1_fu_8954_p2() {
    ret_V_15_0_15_1_fu_8954_p2 = (!ret_V_15_0_15_1_fu_8954_p0.read().is_01() || !ret_V_15_0_15_1_fu_8954_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_15_1_fu_8954_p0.read()) * sc_bigint<8>(ret_V_15_0_15_1_fu_8954_p1.read());
}

void compute::thread_ret_V_15_0_15_3_fu_8963_p0() {
    ret_V_15_0_15_3_fu_8963_p0 =  (sc_lv<8>) (lhs_V_2_0_0_3_fu_7859_p1.read());
}

void compute::thread_ret_V_15_0_15_3_fu_8963_p1() {
    ret_V_15_0_15_3_fu_8963_p1 = w_tensor_i_15_3_reg_15441_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_15_3_fu_8963_p2() {
    ret_V_15_0_15_3_fu_8963_p2 = (!ret_V_15_0_15_3_fu_8963_p0.read().is_01() || !ret_V_15_0_15_3_fu_8963_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_15_3_fu_8963_p0.read()) * sc_bigint<8>(ret_V_15_0_15_3_fu_8963_p1.read());
}

void compute::thread_ret_V_15_0_15_5_fu_8972_p0() {
    ret_V_15_0_15_5_fu_8972_p0 =  (sc_lv<8>) (lhs_V_2_0_0_5_fu_7871_p1.read());
}

void compute::thread_ret_V_15_0_15_5_fu_8972_p1() {
    ret_V_15_0_15_5_fu_8972_p1 = w_tensor_i_15_5_reg_15451_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_15_5_fu_8972_p2() {
    ret_V_15_0_15_5_fu_8972_p2 = (!ret_V_15_0_15_5_fu_8972_p0.read().is_01() || !ret_V_15_0_15_5_fu_8972_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_15_5_fu_8972_p0.read()) * sc_bigint<8>(ret_V_15_0_15_5_fu_8972_p1.read());
}

void compute::thread_ret_V_15_0_15_7_fu_8981_p0() {
    ret_V_15_0_15_7_fu_8981_p0 =  (sc_lv<8>) (lhs_V_2_0_0_7_fu_7883_p1.read());
}

void compute::thread_ret_V_15_0_15_7_fu_8981_p1() {
    ret_V_15_0_15_7_fu_8981_p1 = w_tensor_i_15_7_reg_15461_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_15_7_fu_8981_p2() {
    ret_V_15_0_15_7_fu_8981_p2 = (!ret_V_15_0_15_7_fu_8981_p0.read().is_01() || !ret_V_15_0_15_7_fu_8981_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_15_7_fu_8981_p0.read()) * sc_bigint<8>(ret_V_15_0_15_7_fu_8981_p1.read());
}

void compute::thread_ret_V_15_0_15_9_fu_8990_p0() {
    ret_V_15_0_15_9_fu_8990_p0 =  (sc_lv<8>) (lhs_V_2_0_0_9_fu_7895_p1.read());
}

void compute::thread_ret_V_15_0_15_9_fu_8990_p1() {
    ret_V_15_0_15_9_fu_8990_p1 = w_tensor_i_15_9_reg_15471_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_15_9_fu_8990_p2() {
    ret_V_15_0_15_9_fu_8990_p2 = (!ret_V_15_0_15_9_fu_8990_p0.read().is_01() || !ret_V_15_0_15_9_fu_8990_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_15_9_fu_8990_p0.read()) * sc_bigint<8>(ret_V_15_0_15_9_fu_8990_p1.read());
}

void compute::thread_ret_V_15_0_1_10_fu_7991_p0() {
    ret_V_15_0_1_10_fu_7991_p0 =  (sc_lv<8>) (lhs_V_2_0_0_10_fu_7907_p1.read());
}

void compute::thread_ret_V_15_0_1_10_fu_7991_p1() {
    ret_V_15_0_1_10_fu_7991_p1 = w_tensor_i_1_10_reg_14361_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_1_10_fu_7991_p2() {
    ret_V_15_0_1_10_fu_7991_p2 = (!ret_V_15_0_1_10_fu_7991_p0.read().is_01() || !ret_V_15_0_1_10_fu_7991_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_1_10_fu_7991_p0.read()) * sc_bigint<8>(ret_V_15_0_1_10_fu_7991_p1.read());
}

void compute::thread_ret_V_15_0_1_12_fu_8000_p0() {
    ret_V_15_0_1_12_fu_8000_p0 =  (sc_lv<8>) (lhs_V_2_0_0_12_fu_7919_p1.read());
}

void compute::thread_ret_V_15_0_1_12_fu_8000_p1() {
    ret_V_15_0_1_12_fu_8000_p1 = w_tensor_i_1_12_reg_14371_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_1_12_fu_8000_p2() {
    ret_V_15_0_1_12_fu_8000_p2 = (!ret_V_15_0_1_12_fu_8000_p0.read().is_01() || !ret_V_15_0_1_12_fu_8000_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_1_12_fu_8000_p0.read()) * sc_bigint<8>(ret_V_15_0_1_12_fu_8000_p1.read());
}

void compute::thread_ret_V_15_0_1_14_fu_8009_p0() {
    ret_V_15_0_1_14_fu_8009_p0 =  (sc_lv<8>) (lhs_V_2_0_0_14_fu_7931_p1.read());
}

void compute::thread_ret_V_15_0_1_14_fu_8009_p1() {
    ret_V_15_0_1_14_fu_8009_p1 = w_tensor_i_1_14_reg_14381_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_1_14_fu_8009_p2() {
    ret_V_15_0_1_14_fu_8009_p2 = (!ret_V_15_0_1_14_fu_8009_p0.read().is_01() || !ret_V_15_0_1_14_fu_8009_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_1_14_fu_8009_p0.read()) * sc_bigint<8>(ret_V_15_0_1_14_fu_8009_p1.read());
}

void compute::thread_ret_V_15_0_1_1_fu_7946_p0() {
    ret_V_15_0_1_1_fu_7946_p0 =  (sc_lv<8>) (lhs_V_2_0_0_1_fu_7847_p1.read());
}

void compute::thread_ret_V_15_0_1_1_fu_7946_p1() {
    ret_V_15_0_1_1_fu_7946_p1 = w_tensor_i_1_1_reg_14311_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_1_1_fu_7946_p2() {
    ret_V_15_0_1_1_fu_7946_p2 = (!ret_V_15_0_1_1_fu_7946_p0.read().is_01() || !ret_V_15_0_1_1_fu_7946_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_1_1_fu_7946_p0.read()) * sc_bigint<8>(ret_V_15_0_1_1_fu_7946_p1.read());
}

void compute::thread_ret_V_15_0_1_3_fu_7955_p0() {
    ret_V_15_0_1_3_fu_7955_p0 =  (sc_lv<8>) (lhs_V_2_0_0_3_fu_7859_p1.read());
}

void compute::thread_ret_V_15_0_1_3_fu_7955_p1() {
    ret_V_15_0_1_3_fu_7955_p1 = w_tensor_i_1_3_reg_14321_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_1_3_fu_7955_p2() {
    ret_V_15_0_1_3_fu_7955_p2 = (!ret_V_15_0_1_3_fu_7955_p0.read().is_01() || !ret_V_15_0_1_3_fu_7955_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_1_3_fu_7955_p0.read()) * sc_bigint<8>(ret_V_15_0_1_3_fu_7955_p1.read());
}

void compute::thread_ret_V_15_0_1_5_fu_7964_p0() {
    ret_V_15_0_1_5_fu_7964_p0 =  (sc_lv<8>) (lhs_V_2_0_0_5_fu_7871_p1.read());
}

void compute::thread_ret_V_15_0_1_5_fu_7964_p1() {
    ret_V_15_0_1_5_fu_7964_p1 = w_tensor_i_1_5_reg_14331_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_1_5_fu_7964_p2() {
    ret_V_15_0_1_5_fu_7964_p2 = (!ret_V_15_0_1_5_fu_7964_p0.read().is_01() || !ret_V_15_0_1_5_fu_7964_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_1_5_fu_7964_p0.read()) * sc_bigint<8>(ret_V_15_0_1_5_fu_7964_p1.read());
}

void compute::thread_ret_V_15_0_1_7_fu_7973_p0() {
    ret_V_15_0_1_7_fu_7973_p0 =  (sc_lv<8>) (lhs_V_2_0_0_7_fu_7883_p1.read());
}

void compute::thread_ret_V_15_0_1_7_fu_7973_p1() {
    ret_V_15_0_1_7_fu_7973_p1 = w_tensor_i_1_7_reg_14341_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_1_7_fu_7973_p2() {
    ret_V_15_0_1_7_fu_7973_p2 = (!ret_V_15_0_1_7_fu_7973_p0.read().is_01() || !ret_V_15_0_1_7_fu_7973_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_1_7_fu_7973_p0.read()) * sc_bigint<8>(ret_V_15_0_1_7_fu_7973_p1.read());
}

void compute::thread_ret_V_15_0_1_9_fu_7982_p0() {
    ret_V_15_0_1_9_fu_7982_p0 =  (sc_lv<8>) (lhs_V_2_0_0_9_fu_7895_p1.read());
}

void compute::thread_ret_V_15_0_1_9_fu_7982_p1() {
    ret_V_15_0_1_9_fu_7982_p1 = w_tensor_i_1_9_reg_14351_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_1_9_fu_7982_p2() {
    ret_V_15_0_1_9_fu_7982_p2 = (!ret_V_15_0_1_9_fu_7982_p0.read().is_01() || !ret_V_15_0_1_9_fu_7982_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_1_9_fu_7982_p0.read()) * sc_bigint<8>(ret_V_15_0_1_9_fu_7982_p1.read());
}

void compute::thread_ret_V_15_0_2_10_fu_8063_p0() {
    ret_V_15_0_2_10_fu_8063_p0 =  (sc_lv<8>) (lhs_V_2_0_0_10_fu_7907_p1.read());
}

void compute::thread_ret_V_15_0_2_10_fu_8063_p1() {
    ret_V_15_0_2_10_fu_8063_p1 = w_tensor_i_2_10_reg_14441_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_2_10_fu_8063_p2() {
    ret_V_15_0_2_10_fu_8063_p2 = (!ret_V_15_0_2_10_fu_8063_p0.read().is_01() || !ret_V_15_0_2_10_fu_8063_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_2_10_fu_8063_p0.read()) * sc_bigint<8>(ret_V_15_0_2_10_fu_8063_p1.read());
}

void compute::thread_ret_V_15_0_2_12_fu_8072_p0() {
    ret_V_15_0_2_12_fu_8072_p0 =  (sc_lv<8>) (lhs_V_2_0_0_12_fu_7919_p1.read());
}

void compute::thread_ret_V_15_0_2_12_fu_8072_p1() {
    ret_V_15_0_2_12_fu_8072_p1 = w_tensor_i_2_12_reg_14451_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_2_12_fu_8072_p2() {
    ret_V_15_0_2_12_fu_8072_p2 = (!ret_V_15_0_2_12_fu_8072_p0.read().is_01() || !ret_V_15_0_2_12_fu_8072_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_2_12_fu_8072_p0.read()) * sc_bigint<8>(ret_V_15_0_2_12_fu_8072_p1.read());
}

void compute::thread_ret_V_15_0_2_14_fu_8081_p0() {
    ret_V_15_0_2_14_fu_8081_p0 =  (sc_lv<8>) (lhs_V_2_0_0_14_fu_7931_p1.read());
}

void compute::thread_ret_V_15_0_2_14_fu_8081_p1() {
    ret_V_15_0_2_14_fu_8081_p1 = w_tensor_i_2_14_reg_14461_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_2_14_fu_8081_p2() {
    ret_V_15_0_2_14_fu_8081_p2 = (!ret_V_15_0_2_14_fu_8081_p0.read().is_01() || !ret_V_15_0_2_14_fu_8081_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_2_14_fu_8081_p0.read()) * sc_bigint<8>(ret_V_15_0_2_14_fu_8081_p1.read());
}

void compute::thread_ret_V_15_0_2_1_fu_8018_p0() {
    ret_V_15_0_2_1_fu_8018_p0 =  (sc_lv<8>) (lhs_V_2_0_0_1_fu_7847_p1.read());
}

void compute::thread_ret_V_15_0_2_1_fu_8018_p1() {
    ret_V_15_0_2_1_fu_8018_p1 = w_tensor_i_2_1_reg_14391_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_2_1_fu_8018_p2() {
    ret_V_15_0_2_1_fu_8018_p2 = (!ret_V_15_0_2_1_fu_8018_p0.read().is_01() || !ret_V_15_0_2_1_fu_8018_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_2_1_fu_8018_p0.read()) * sc_bigint<8>(ret_V_15_0_2_1_fu_8018_p1.read());
}

void compute::thread_ret_V_15_0_2_3_fu_8027_p0() {
    ret_V_15_0_2_3_fu_8027_p0 =  (sc_lv<8>) (lhs_V_2_0_0_3_fu_7859_p1.read());
}

void compute::thread_ret_V_15_0_2_3_fu_8027_p1() {
    ret_V_15_0_2_3_fu_8027_p1 = w_tensor_i_2_3_reg_14401_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_2_3_fu_8027_p2() {
    ret_V_15_0_2_3_fu_8027_p2 = (!ret_V_15_0_2_3_fu_8027_p0.read().is_01() || !ret_V_15_0_2_3_fu_8027_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_2_3_fu_8027_p0.read()) * sc_bigint<8>(ret_V_15_0_2_3_fu_8027_p1.read());
}

void compute::thread_ret_V_15_0_2_5_fu_8036_p0() {
    ret_V_15_0_2_5_fu_8036_p0 =  (sc_lv<8>) (lhs_V_2_0_0_5_fu_7871_p1.read());
}

void compute::thread_ret_V_15_0_2_5_fu_8036_p1() {
    ret_V_15_0_2_5_fu_8036_p1 = w_tensor_i_2_5_reg_14411_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_2_5_fu_8036_p2() {
    ret_V_15_0_2_5_fu_8036_p2 = (!ret_V_15_0_2_5_fu_8036_p0.read().is_01() || !ret_V_15_0_2_5_fu_8036_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_2_5_fu_8036_p0.read()) * sc_bigint<8>(ret_V_15_0_2_5_fu_8036_p1.read());
}

void compute::thread_ret_V_15_0_2_7_fu_8045_p0() {
    ret_V_15_0_2_7_fu_8045_p0 =  (sc_lv<8>) (lhs_V_2_0_0_7_fu_7883_p1.read());
}

void compute::thread_ret_V_15_0_2_7_fu_8045_p1() {
    ret_V_15_0_2_7_fu_8045_p1 = w_tensor_i_2_7_reg_14421_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_2_7_fu_8045_p2() {
    ret_V_15_0_2_7_fu_8045_p2 = (!ret_V_15_0_2_7_fu_8045_p0.read().is_01() || !ret_V_15_0_2_7_fu_8045_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_2_7_fu_8045_p0.read()) * sc_bigint<8>(ret_V_15_0_2_7_fu_8045_p1.read());
}

void compute::thread_ret_V_15_0_2_9_fu_8054_p0() {
    ret_V_15_0_2_9_fu_8054_p0 =  (sc_lv<8>) (lhs_V_2_0_0_9_fu_7895_p1.read());
}

void compute::thread_ret_V_15_0_2_9_fu_8054_p1() {
    ret_V_15_0_2_9_fu_8054_p1 = w_tensor_i_2_9_reg_14431_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_2_9_fu_8054_p2() {
    ret_V_15_0_2_9_fu_8054_p2 = (!ret_V_15_0_2_9_fu_8054_p0.read().is_01() || !ret_V_15_0_2_9_fu_8054_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_2_9_fu_8054_p0.read()) * sc_bigint<8>(ret_V_15_0_2_9_fu_8054_p1.read());
}

void compute::thread_ret_V_15_0_3_10_fu_8135_p0() {
    ret_V_15_0_3_10_fu_8135_p0 =  (sc_lv<8>) (lhs_V_2_0_0_10_fu_7907_p1.read());
}

void compute::thread_ret_V_15_0_3_10_fu_8135_p1() {
    ret_V_15_0_3_10_fu_8135_p1 = w_tensor_i_3_10_reg_14521_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_3_10_fu_8135_p2() {
    ret_V_15_0_3_10_fu_8135_p2 = (!ret_V_15_0_3_10_fu_8135_p0.read().is_01() || !ret_V_15_0_3_10_fu_8135_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_3_10_fu_8135_p0.read()) * sc_bigint<8>(ret_V_15_0_3_10_fu_8135_p1.read());
}

void compute::thread_ret_V_15_0_3_12_fu_8144_p0() {
    ret_V_15_0_3_12_fu_8144_p0 =  (sc_lv<8>) (lhs_V_2_0_0_12_fu_7919_p1.read());
}

void compute::thread_ret_V_15_0_3_12_fu_8144_p1() {
    ret_V_15_0_3_12_fu_8144_p1 = w_tensor_i_3_12_reg_14531_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_3_12_fu_8144_p2() {
    ret_V_15_0_3_12_fu_8144_p2 = (!ret_V_15_0_3_12_fu_8144_p0.read().is_01() || !ret_V_15_0_3_12_fu_8144_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_3_12_fu_8144_p0.read()) * sc_bigint<8>(ret_V_15_0_3_12_fu_8144_p1.read());
}

void compute::thread_ret_V_15_0_3_14_fu_8153_p0() {
    ret_V_15_0_3_14_fu_8153_p0 =  (sc_lv<8>) (lhs_V_2_0_0_14_fu_7931_p1.read());
}

void compute::thread_ret_V_15_0_3_14_fu_8153_p1() {
    ret_V_15_0_3_14_fu_8153_p1 = w_tensor_i_3_14_reg_14541_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_3_14_fu_8153_p2() {
    ret_V_15_0_3_14_fu_8153_p2 = (!ret_V_15_0_3_14_fu_8153_p0.read().is_01() || !ret_V_15_0_3_14_fu_8153_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_3_14_fu_8153_p0.read()) * sc_bigint<8>(ret_V_15_0_3_14_fu_8153_p1.read());
}

void compute::thread_ret_V_15_0_3_1_fu_8090_p0() {
    ret_V_15_0_3_1_fu_8090_p0 =  (sc_lv<8>) (lhs_V_2_0_0_1_fu_7847_p1.read());
}

void compute::thread_ret_V_15_0_3_1_fu_8090_p1() {
    ret_V_15_0_3_1_fu_8090_p1 = w_tensor_i_3_1_reg_14471_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_3_1_fu_8090_p2() {
    ret_V_15_0_3_1_fu_8090_p2 = (!ret_V_15_0_3_1_fu_8090_p0.read().is_01() || !ret_V_15_0_3_1_fu_8090_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_3_1_fu_8090_p0.read()) * sc_bigint<8>(ret_V_15_0_3_1_fu_8090_p1.read());
}

void compute::thread_ret_V_15_0_3_3_fu_8099_p0() {
    ret_V_15_0_3_3_fu_8099_p0 =  (sc_lv<8>) (lhs_V_2_0_0_3_fu_7859_p1.read());
}

void compute::thread_ret_V_15_0_3_3_fu_8099_p1() {
    ret_V_15_0_3_3_fu_8099_p1 = w_tensor_i_3_3_reg_14481_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_3_3_fu_8099_p2() {
    ret_V_15_0_3_3_fu_8099_p2 = (!ret_V_15_0_3_3_fu_8099_p0.read().is_01() || !ret_V_15_0_3_3_fu_8099_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_3_3_fu_8099_p0.read()) * sc_bigint<8>(ret_V_15_0_3_3_fu_8099_p1.read());
}

void compute::thread_ret_V_15_0_3_5_fu_8108_p0() {
    ret_V_15_0_3_5_fu_8108_p0 =  (sc_lv<8>) (lhs_V_2_0_0_5_fu_7871_p1.read());
}

void compute::thread_ret_V_15_0_3_5_fu_8108_p1() {
    ret_V_15_0_3_5_fu_8108_p1 = w_tensor_i_3_5_reg_14491_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_3_5_fu_8108_p2() {
    ret_V_15_0_3_5_fu_8108_p2 = (!ret_V_15_0_3_5_fu_8108_p0.read().is_01() || !ret_V_15_0_3_5_fu_8108_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_3_5_fu_8108_p0.read()) * sc_bigint<8>(ret_V_15_0_3_5_fu_8108_p1.read());
}

void compute::thread_ret_V_15_0_3_7_fu_8117_p0() {
    ret_V_15_0_3_7_fu_8117_p0 =  (sc_lv<8>) (lhs_V_2_0_0_7_fu_7883_p1.read());
}

void compute::thread_ret_V_15_0_3_7_fu_8117_p1() {
    ret_V_15_0_3_7_fu_8117_p1 = w_tensor_i_3_7_reg_14501_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_3_7_fu_8117_p2() {
    ret_V_15_0_3_7_fu_8117_p2 = (!ret_V_15_0_3_7_fu_8117_p0.read().is_01() || !ret_V_15_0_3_7_fu_8117_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_3_7_fu_8117_p0.read()) * sc_bigint<8>(ret_V_15_0_3_7_fu_8117_p1.read());
}

void compute::thread_ret_V_15_0_3_9_fu_8126_p0() {
    ret_V_15_0_3_9_fu_8126_p0 =  (sc_lv<8>) (lhs_V_2_0_0_9_fu_7895_p1.read());
}

void compute::thread_ret_V_15_0_3_9_fu_8126_p1() {
    ret_V_15_0_3_9_fu_8126_p1 = w_tensor_i_3_9_reg_14511_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_3_9_fu_8126_p2() {
    ret_V_15_0_3_9_fu_8126_p2 = (!ret_V_15_0_3_9_fu_8126_p0.read().is_01() || !ret_V_15_0_3_9_fu_8126_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_3_9_fu_8126_p0.read()) * sc_bigint<8>(ret_V_15_0_3_9_fu_8126_p1.read());
}

void compute::thread_ret_V_15_0_4_10_fu_8207_p0() {
    ret_V_15_0_4_10_fu_8207_p0 =  (sc_lv<8>) (lhs_V_2_0_0_10_fu_7907_p1.read());
}

void compute::thread_ret_V_15_0_4_10_fu_8207_p1() {
    ret_V_15_0_4_10_fu_8207_p1 = w_tensor_i_4_10_reg_14601_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_4_10_fu_8207_p2() {
    ret_V_15_0_4_10_fu_8207_p2 = (!ret_V_15_0_4_10_fu_8207_p0.read().is_01() || !ret_V_15_0_4_10_fu_8207_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_4_10_fu_8207_p0.read()) * sc_bigint<8>(ret_V_15_0_4_10_fu_8207_p1.read());
}

void compute::thread_ret_V_15_0_4_12_fu_8216_p0() {
    ret_V_15_0_4_12_fu_8216_p0 =  (sc_lv<8>) (lhs_V_2_0_0_12_fu_7919_p1.read());
}

void compute::thread_ret_V_15_0_4_12_fu_8216_p1() {
    ret_V_15_0_4_12_fu_8216_p1 = w_tensor_i_4_12_reg_14611_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_4_12_fu_8216_p2() {
    ret_V_15_0_4_12_fu_8216_p2 = (!ret_V_15_0_4_12_fu_8216_p0.read().is_01() || !ret_V_15_0_4_12_fu_8216_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_4_12_fu_8216_p0.read()) * sc_bigint<8>(ret_V_15_0_4_12_fu_8216_p1.read());
}

void compute::thread_ret_V_15_0_4_14_fu_8225_p0() {
    ret_V_15_0_4_14_fu_8225_p0 =  (sc_lv<8>) (lhs_V_2_0_0_14_fu_7931_p1.read());
}

void compute::thread_ret_V_15_0_4_14_fu_8225_p1() {
    ret_V_15_0_4_14_fu_8225_p1 = w_tensor_i_4_14_reg_14621_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_4_14_fu_8225_p2() {
    ret_V_15_0_4_14_fu_8225_p2 = (!ret_V_15_0_4_14_fu_8225_p0.read().is_01() || !ret_V_15_0_4_14_fu_8225_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_4_14_fu_8225_p0.read()) * sc_bigint<8>(ret_V_15_0_4_14_fu_8225_p1.read());
}

void compute::thread_ret_V_15_0_4_1_fu_8162_p0() {
    ret_V_15_0_4_1_fu_8162_p0 =  (sc_lv<8>) (lhs_V_2_0_0_1_fu_7847_p1.read());
}

void compute::thread_ret_V_15_0_4_1_fu_8162_p1() {
    ret_V_15_0_4_1_fu_8162_p1 = w_tensor_i_4_1_reg_14551_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_4_1_fu_8162_p2() {
    ret_V_15_0_4_1_fu_8162_p2 = (!ret_V_15_0_4_1_fu_8162_p0.read().is_01() || !ret_V_15_0_4_1_fu_8162_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_4_1_fu_8162_p0.read()) * sc_bigint<8>(ret_V_15_0_4_1_fu_8162_p1.read());
}

void compute::thread_ret_V_15_0_4_3_fu_8171_p0() {
    ret_V_15_0_4_3_fu_8171_p0 =  (sc_lv<8>) (lhs_V_2_0_0_3_fu_7859_p1.read());
}

void compute::thread_ret_V_15_0_4_3_fu_8171_p1() {
    ret_V_15_0_4_3_fu_8171_p1 = w_tensor_i_4_3_reg_14561_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_4_3_fu_8171_p2() {
    ret_V_15_0_4_3_fu_8171_p2 = (!ret_V_15_0_4_3_fu_8171_p0.read().is_01() || !ret_V_15_0_4_3_fu_8171_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_4_3_fu_8171_p0.read()) * sc_bigint<8>(ret_V_15_0_4_3_fu_8171_p1.read());
}

void compute::thread_ret_V_15_0_4_5_fu_8180_p0() {
    ret_V_15_0_4_5_fu_8180_p0 =  (sc_lv<8>) (lhs_V_2_0_0_5_fu_7871_p1.read());
}

void compute::thread_ret_V_15_0_4_5_fu_8180_p1() {
    ret_V_15_0_4_5_fu_8180_p1 = w_tensor_i_4_5_reg_14571_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_4_5_fu_8180_p2() {
    ret_V_15_0_4_5_fu_8180_p2 = (!ret_V_15_0_4_5_fu_8180_p0.read().is_01() || !ret_V_15_0_4_5_fu_8180_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_4_5_fu_8180_p0.read()) * sc_bigint<8>(ret_V_15_0_4_5_fu_8180_p1.read());
}

void compute::thread_ret_V_15_0_4_7_fu_8189_p0() {
    ret_V_15_0_4_7_fu_8189_p0 =  (sc_lv<8>) (lhs_V_2_0_0_7_fu_7883_p1.read());
}

void compute::thread_ret_V_15_0_4_7_fu_8189_p1() {
    ret_V_15_0_4_7_fu_8189_p1 = w_tensor_i_4_7_reg_14581_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_4_7_fu_8189_p2() {
    ret_V_15_0_4_7_fu_8189_p2 = (!ret_V_15_0_4_7_fu_8189_p0.read().is_01() || !ret_V_15_0_4_7_fu_8189_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_4_7_fu_8189_p0.read()) * sc_bigint<8>(ret_V_15_0_4_7_fu_8189_p1.read());
}

void compute::thread_ret_V_15_0_4_9_fu_8198_p0() {
    ret_V_15_0_4_9_fu_8198_p0 =  (sc_lv<8>) (lhs_V_2_0_0_9_fu_7895_p1.read());
}

void compute::thread_ret_V_15_0_4_9_fu_8198_p1() {
    ret_V_15_0_4_9_fu_8198_p1 = w_tensor_i_4_9_reg_14591_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_4_9_fu_8198_p2() {
    ret_V_15_0_4_9_fu_8198_p2 = (!ret_V_15_0_4_9_fu_8198_p0.read().is_01() || !ret_V_15_0_4_9_fu_8198_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_4_9_fu_8198_p0.read()) * sc_bigint<8>(ret_V_15_0_4_9_fu_8198_p1.read());
}

void compute::thread_ret_V_15_0_5_10_fu_8279_p0() {
    ret_V_15_0_5_10_fu_8279_p0 =  (sc_lv<8>) (lhs_V_2_0_0_10_fu_7907_p1.read());
}

void compute::thread_ret_V_15_0_5_10_fu_8279_p1() {
    ret_V_15_0_5_10_fu_8279_p1 = w_tensor_i_5_10_reg_14681_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_5_10_fu_8279_p2() {
    ret_V_15_0_5_10_fu_8279_p2 = (!ret_V_15_0_5_10_fu_8279_p0.read().is_01() || !ret_V_15_0_5_10_fu_8279_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_5_10_fu_8279_p0.read()) * sc_bigint<8>(ret_V_15_0_5_10_fu_8279_p1.read());
}

void compute::thread_ret_V_15_0_5_12_fu_8288_p0() {
    ret_V_15_0_5_12_fu_8288_p0 =  (sc_lv<8>) (lhs_V_2_0_0_12_fu_7919_p1.read());
}

void compute::thread_ret_V_15_0_5_12_fu_8288_p1() {
    ret_V_15_0_5_12_fu_8288_p1 = w_tensor_i_5_12_reg_14691_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_5_12_fu_8288_p2() {
    ret_V_15_0_5_12_fu_8288_p2 = (!ret_V_15_0_5_12_fu_8288_p0.read().is_01() || !ret_V_15_0_5_12_fu_8288_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_5_12_fu_8288_p0.read()) * sc_bigint<8>(ret_V_15_0_5_12_fu_8288_p1.read());
}

void compute::thread_ret_V_15_0_5_14_fu_8297_p0() {
    ret_V_15_0_5_14_fu_8297_p0 =  (sc_lv<8>) (lhs_V_2_0_0_14_fu_7931_p1.read());
}

void compute::thread_ret_V_15_0_5_14_fu_8297_p1() {
    ret_V_15_0_5_14_fu_8297_p1 = w_tensor_i_5_14_reg_14701_pp1_iter7_reg.read();
}

void compute::thread_ret_V_15_0_5_14_fu_8297_p2() {
    ret_V_15_0_5_14_fu_8297_p2 = (!ret_V_15_0_5_14_fu_8297_p0.read().is_01() || !ret_V_15_0_5_14_fu_8297_p1.read().is_01())? sc_lv<16>(): sc_bigint<8>(ret_V_15_0_5_14_fu_8297_p0.read()) * sc_bigint<8>(ret_V_15_0_5_14_fu_8297_p1.read());
}

}

